# تحديث v37 — تقارير PDF و Excel

تمت إضافة طبقة تصدير التقارير داخل شاشة **التقارير**.

## الإضافات

- تصدير التقرير الحالي إلى **PDF / طباعة** عبر نافذة طباعة يمكن حفظها كملف PDF.
- تصدير التقرير الحالي إلى **Excel XLS** متوافق مع Excel و Google Sheets.
- تصدير التقرير الحالي إلى **CSV**.
- تصدير **كل تقارير الصيانة** في ملف Excel واحد متعدد الأوراق.
- فلاتر قبل التصدير:
  - من تاريخ.
  - إلى تاريخ.
  - بحث نصي داخل التقرير.
- معاينة جدولية للنتائج قبل التصدير.
- حفظ سجل التصدير في:
  - `reportJobs`
  - `savedReportOutputs`

## التقارير المشمولة

- Open Work Orders Report
- Past Due Work Orders Report
- Completed Work Orders Report
- Preventive Maintenance Compliance
- Corrective Maintenance Report
- Emergency Work Orders Report
- Work Order Cost Report
- Technician Performance Report
- Failure Analysis Report
- Asset Maintenance History
- Maintenance Forecast Report
- Material Usage by Work Order
- Repeated Failures Report
- MTBF Report
- MTTR Report
- Daily Maintenance Execution Report
- Technician Workload Report
- Work Completion Report
- Rejected Work Report
- Material Usage During Execution
- Labor Hours Report
- Failure Capture Report
- Before / After Photo Report
- Supervisor Review Report

## ملاحظات

- لا توجد مكتبات جديدة؛ التصدير يعمل من داخل المتصفح/WebView.
- لا حاجة لتحديث Firestore Rules لأن التحديث يستخدم الكيانات الموجودة سابقًا.
- زر PDF يفتح نافذة طباعة، ومن خلالها يمكن اختيار **Save as PDF**.
