# تحديث v36 — تحسين هيكل الكود

تم تفكيك الكود الكبير إلى ملفات ومجلدات أوضح، مع الحفاظ على نفس وظائف التطبيق والواجهة.

## ما الذي تغير؟

بدل أن تكون كل الثوابت، أدوات التاريخ، ضغط الصور، التطبيع، Offline Queue، وعناصر الواجهة داخل `src/App.tsx`، أصبحت موزعة كالتالي:

```txt
src/
├── App.tsx                         # التطبيق والشاشات الرئيسية
├── firebase.ts                      # تهيئة Firebase الأساسية
├── firebaseCmms.ts                  # ربط Firestore/Auth/Storage
├── components/
│   ├── index.ts
│   └── ui.tsx                       # Btn, Badge, Chip, Stat, Section, Row, Sheet...
├── core/
│   ├── index.ts
│   ├── appCore.ts                   # Barrel export للتوافق مع App.tsx
│   ├── constants.ts                 # الثوابت، الأدوار، الحالات، القوائم، إعدادات الإنتاج
│   ├── media.ts                     # ضغط الصور ورفع/تحضير ملفات المرفقات
│   ├── state.ts                     # normalizeDb + النسخة المحلية
│   └── offline.ts                   # Offline Queue + Conflict Resolution
└── modules/
    └── README.md                    # خطة تقسيم الوحدات القادمة
```

## لماذا هذا مهم؟

- أصبح تعديل الألوان أو التبويبات أو الثوابت من `core/constants.ts` بدل البحث داخل ملف ضخم.
- أصبحت عناصر الواجهة قابلة لإعادة الاستخدام من `components/ui.tsx`.
- أصبح منطق الصور وFirebase Storage في `core/media.ts`.
- أصبح منطق Offline والتعارضات في `core/offline.ts`.
- أصبح تطبيع البيانات والترقيات في `core/state.ts`.
- انخفض حجم `App.tsx` وأصبح أسهل للصيانة.

## هل تغيرت البيانات أو Firebase Rules؟

لا. هذا تحديث هيكل كود فقط، ولا يضيف مسارات Firestore أو Storage جديدة.

## هل تغيرت الواجهة؟

لا. حافظت النسخة على الواجهة المحسنة والتبويبات الحالية، بما فيها:

- إخفاء تبويب المزيد عن غير المدير.
- Firebase والصلاحيات للمدير.
- الاعتمادات.
- التنبيهات.
- QR للأصول.
- Offline Queue.
- Firebase Storage.
- حوكمة المخزون والطلبات.
- قفل أدوات الإنتاج.

## التحقق

تم التحقق من تركيب ملفات TS/TSX باستخدام TypeScript transpile، ولم تظهر أخطاء syntax. لم أشغل build كامل محليًا بسبب عدم توفر `node_modules` داخل بيئة العمل، وسيقوم GitHub Actions عندك بتنفيذ `npm install` و`npm run build` كالمعتاد.

## الخطوة التالية المقترحة

بعد هذه المرحلة، يمكن نقل الشاشات الكبيرة تدريجيًا إلى:

```txt
src/modules/assets
src/modules/work-orders
src/modules/inventory
src/modules/governance
src/modules/reports
src/modules/offline-sync
src/modules/media
```

لكنني لم أنقل كل الشاشات دفعة واحدة حتى لا نكسر التطبيق، وبدأت بالتقسيم الآمن للثوابت والمساعدات والواجهة المشتركة.
