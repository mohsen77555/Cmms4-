import { useState } from "react";
import { C } from "../core/appCore";

/* ───────────────────────── عناصر واجهة ───────────────────────── */
export function AddInline({ placeholder, onAdd }: any) {
  const [t, setT] = useState("");
  return (
    <div style={{ display: "flex", gap: 8 }}>
      <input value={t} onChange={(e) => setT(e.target.value)} placeholder={placeholder} style={input} />
      <Btn bg={C.ink} onClick={() => { if (t.trim()) { onAdd(t.trim()); setT(""); } }}>+</Btn>
    </div>
  );
}
export const card = () => ({ background: C.card, border: `1px solid ${C.line}`, borderRight: `6px solid ${C.ink}`, borderRadius: 18, padding: "12px 14px", marginBottom: 10, boxShadow: "0 10px 28px rgba(15,23,42,.06)" });
export const input = { width: "100%", padding: "11px 13px", border: `1px solid ${C.line}`, borderRadius: 14, background: "#fff", boxSizing: "border-box", outline: "none" };
export const inputStyle = () => ({ ...input });
export const delBtn = { marginTop: 6, background: "none", border: "none", color: C.steel, fontSize: 12, textDecoration: "underline", padding: 0 };

export function Btn({ bg, children, style, onClick, disabled }: any) {
  return <button disabled={disabled} onClick={(e) => { e.stopPropagation(); if (!disabled) onClick && onClick(); }} style={{ background: bg, color: "#fff", border: "none", borderRadius: 14, padding: "9px 13px", fontSize: 13, fontWeight: 900, boxShadow: "0 8px 18px rgba(15,23,42,.12)", opacity: disabled ? 0.55 : 1, ...style }}>{children}</button>;
}
export function Badge({ text, color }: any) {
  return <span style={{ background: color, color: "#fff", borderRadius: 999, padding: "4px 9px", fontSize: 11.5, fontWeight: 900, whiteSpace: "nowrap", display:"inline-flex", alignItems:"center", gap:4 }}>{text}</span>;
}
export function Chip({ active, children, onClick }: any) {
  return <button onClick={onClick} style={{ padding: "7px 12px", borderRadius: 999, border: `1px solid ${active ? C.ink : C.line}`, background: active ? C.ink : "#fff", color: active ? "#fff" : C.ink, fontSize: 12.5, fontWeight:800, whiteSpace: "nowrap" }}>{children}</button>;
}
export function Stat({ n, label, color, small }: any) {
  return <div style={{ flex: 1, background: C.card, border: `1px solid ${C.line}`, borderRadius: 18, padding: "10px 11px", boxShadow:"0 8px 22px rgba(15,23,42,.05)" }}>
    <div style={{ fontSize: small ? 14 : 24, fontWeight: 900, color, lineHeight: 1.25 }}>{n}</div>
    <div style={{ fontSize: 10.5, color: C.steel, fontWeight:800 }}>{label}</div>
  </div>;
}
export function Section({ title, children }: any) {
  return <section style={{ marginBottom: 20 }}>
    <h2 style={{ fontSize: 15.5, fontWeight: 900, paddingBottom: 7, margin: "0 0 10px", display:"flex", alignItems:"center", gap:8 }}><span style={{ width:8, height:8, borderRadius:99, background:C.orange, display:"inline-block" }} />{title}</h2>
    {children}
  </section>;
}
export function Row({ main, sub, badge, action }: any) {
  return <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "flex-start" }}>
    <div style={{ minWidth: 0, flex:1 }}>
      <div style={{ fontWeight: 900, fontSize: 14.5, lineHeight:1.45 }}>{main}</div>
      {sub && <div style={{ fontSize: 12.5, color: C.steel, lineHeight:1.55 }}>{sub}</div>}
    </div>
    {badge && <Badge text={badge.text} color={badge.color} />}
    {action}
  </div>;
}
export function Empty({ text }: any) {
  return <div style={{ padding: "24px 12px", textAlign: "center", color: C.steel, border: `1px dashed ${C.line}`, borderRadius: 18, marginBottom: 10, fontSize: 13.5, background:"rgba(255,255,255,.55)" }}>{text}</div>;
}
export function Field({ label, children }: any) {
  return <label style={{ display: "block", marginBottom: 12, flex: 1 }}>
    <div style={{ fontSize: 12, color: C.steel, marginBottom: 5, fontWeight: 900 }}>{label}</div>
    {children}
  </label>;
}
export function Sheet({ title, onClose, children }: any) {
  return (
    <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,.52)", zIndex: 10, display: "flex", alignItems: "flex-end", backdropFilter:"blur(3px)", WebkitBackdropFilter:"blur(3px)" }}>
      <div dir="rtl" onClick={(e) => e.stopPropagation()} style={{ background: C.card, width: "100%", maxHeight: "92vh", overflowY: "auto", border:`1px solid ${C.line}`, borderRadius: "24px 24px 0 0", padding: 16, paddingBottom:"calc(16px + env(safe-area-inset-bottom))", fontFamily: "'Cairo', system-ui, sans-serif", boxShadow:"0 -20px 50px rgba(15,23,42,.24)" }}>
        <div style={{ width:44, height:5, borderRadius:99, background:C.line, margin:"0 auto 12px" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 900 }}>{title}</h2>
          <button onClick={onClose} style={{ background: C.soft, border: `1px solid ${C.line}`, borderRadius:12, fontSize: 20, width:36, height:36 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}
