import { useEffect, useState } from "react";
import { type CmmsFirebaseServices, FIREBASE_OWNER_EMAIL, deleteCmmsStorageFile, ensureFirebaseUserProfile, getFirebaseServices, loadCmmsStateFromFirestore, normalizeFirebaseRole, saveCmmsStateToFirestore, subscribeFirebaseAuth, uploadCmmsDataUrlToStorage } from "./firebaseCmms";
import { ACTIVE_STATES, C, EMPTY, GROUP_ATTRS, SAFETY_DEFAULTS, SHOW_DANGEROUS_TOOLS, SHOW_DEMO_TOOLS, SHOW_SETUP_TOOLS, addDateDays, addOfflineHistory, changedKeysBetween, compactConflict, daysBetween, daysUntil, downloadJsonFile, estimateDataUrlBytes, fmt, forceApplyOfflineEntry, isProductionBuild, loadLocalBackup, loadOfflineHistory, loadOfflineQueue, makeOfflineQueueEntry, mergeOfflineEntryIntoRemote, normalizeDb, now, offlineQueueStats, resizeImage, saveLocalBackup, saveOfflineQueue, today, uid } from "./core/appCore";
import { input } from "./components/ui";


/* ───────────────────────── التطبيق ───────────────────────── */
export default function CMMS() {
  const [db, setDb] = useState(EMPTY);
  const [loaded, setLoaded] = useState(false);
  const [syncStatus, setSyncStatus] = useState("جارٍ التحميل…");
  const [tab, setTab] = useState("home");
  const [woDetail, setWoDetail] = useState(null);
  const [assetDetail, setAssetDetail] = useState(null);
  const [firebaseServices] = useState<CmmsFirebaseServices | null>(() => getFirebaseServices());
  const firebaseEnabled = !!firebaseServices;
  const [firebaseUser, setFirebaseUser] = useState<any>(null);
  const [firebaseProfile, setFirebaseProfile] = useState<any>(null);
  const [authReady, setAuthReady] = useState(!firebaseEnabled);
  const [offlineQueue, setOfflineQueueState] = useState(() => loadOfflineQueue());
  const [offlineHistory, setOfflineHistory] = useState(() => loadOfflineHistory());
  const [syncRunning, setSyncRunning] = useState(false);
  const [browserOnline, setBrowserOnline] = useState(() => typeof navigator === "undefined" ? true : !!navigator.onLine);

  const role = firebaseEnabled ? (normalizeFirebaseRole(firebaseProfile?.role) || "طالب خدمة") : db.settings.role;
  const myTechId = firebaseEnabled ? (firebaseProfile?.technicianId || "") : db.settings.myTechId;
  const can = {
    manage: role === "مدير" || role === "مشرف" || role === "مسؤول النظام",
    execute: role === "فني" || role === "مدير" || role === "مشرف" || role === "مسؤول النظام",
    review: role === "مدير" || role === "مشرف" || role === "مسؤول النظام" || role === "مدير المصنع",
    warehouse: role === "مخزن" || role === "مدير" || role === "مشرف" || role === "مسؤول النظام",
    requestOnly: role === "طالب خدمة",
    admin: role === "مدير" || role === "مسؤول النظام",
  };
  const productionMode = isProductionBuild();
  const canUseDemoTools = can.admin && (!productionMode || SHOW_DEMO_TOOLS);
  const canUseSetupTools = can.admin && (!productionMode || SHOW_SETUP_TOOLS);
  const canUseDangerousTools = can.admin && (!productionMode || SHOW_DANGEROUS_TOOLS);

  // v35: تبويبات الإدارة والإعدادات محصورة بالمدير/مسؤول النظام.
  // لا نعتمد فقط على إخفاء الزر؛ لو وصل غير المدير للتبويب بأي طريقة يرجعه التطبيق للرئيسية.
  useEffect(() => {
    const adminOnlyTabs = new Set(["more", "firebase", "users", "data", "governance", "governance100", "org", "oracle", "media", "qrlabels"]);
    if (!can.admin && adminOnlyTabs.has(tab)) setTab("home");
    if (!can.review && tab === "schedule") setTab("home");
  }, [can.admin, can.review, tab]);

  useEffect(() => {
    const refresh = () => setBrowserOnline(typeof navigator === "undefined" ? true : !!navigator.onLine);
    refresh();
    window.addEventListener("online", refresh);
    window.addEventListener("offline", refresh);
    return () => { window.removeEventListener("online", refresh); window.removeEventListener("offline", refresh); };
  }, []);

  useEffect(() => {
    if (!firebaseServices) return;
    setAuthReady(false);
    return subscribeFirebaseAuth(firebaseServices, async (user) => {
      setFirebaseUser(user);
      if (!user) {
        setFirebaseProfile(null);
        setAuthReady(true);
        setLoaded(true);
        setSyncStatus("سجّل الدخول إلى Firebase");
        return;
      }
      try {
        setSyncStatus("جارٍ قراءة صلاحيات Firebase…");
        const profile = await ensureFirebaseUserProfile(firebaseServices, user);
        setFirebaseProfile(profile);
        setSyncStatus("تم تسجيل الدخول — " + (profile.role || "بدون دور"));
      } catch (e) {
        console.error("فشل قراءة صلاحيات Firebase", e);
        setFirebaseProfile({ role: user.email?.toLowerCase() === FIREBASE_OWNER_EMAIL ? "مدير" : "طالب خدمة", email: user.email || "" });
        setSyncStatus("تعذر قراءة ملف المستخدم — تم استخدام دور احتياطي");
      }
      setAuthReady(true);
    });
  }, [firebaseServices]);

  useEffect(() => {
    if (firebaseServices) {
      if (!authReady) return;
      if (!firebaseUser) return;
      (async () => {
        const startedAt = typeof performance !== "undefined" ? performance.now() : Date.now();
        const local = loadLocalBackup();
        if (local) {
          setDb(normalizeDb(local));
          setLoaded(true);
          setSyncStatus("تم فتح النسخة المحلية — جارٍ مزامنة Firestore بالخلفية…");
        } else {
          setLoaded(false);
          setSyncStatus("جارٍ تحميل بيانات CMMS من Firestore…");
        }

        try {
          const d = await loadCmmsStateFromFirestore(firebaseServices);
          if (d) {
            const normalized = normalizeDb(d);
            setDb(normalized);
            saveLocalBackup(normalized);
          } else if (!local) {
            const emptyState = normalizeDb({ settings: { ...EMPTY.settings, role, myTechId } });
            setDb(emptyState);
            saveLocalBackup(emptyState);
          }
          const elapsed = Math.max(0.1, (((typeof performance !== "undefined" ? performance.now() : Date.now()) - startedAt) / 1000));
          setSyncStatus("متصل بـ Firebase Firestore — مزامنة " + elapsed.toFixed(1) + "ث");
        } catch (e) {
          console.error("فشل تحميل بيانات Firestore", e);
          if (local) {
            setSyncStatus("تم فتح النسخة المحلية — Firestore غير متاح أو القواعد تمنع القراءة");
          } else {
            setSyncStatus("لا توجد بيانات — تحقق من Firebase Auth و Firestore Rules");
          }
        }
        setLoaded(true);
      })();
      return;
    }

    (async () => {
      try {
        setSyncStatus("Firebase غير مفعّل — جارٍ تجربة الخادم القديم…");
        const res = await fetch(`${API}/state`, { cache: "no-store" });
        if (!res.ok) throw new Error("فشل تحميل البيانات من الخادم");
        const d = await res.json();
        if (d) setDb(normalizeDb(d));
        setSyncStatus("متصل بالخادم القديم — فعّل Firebase للحوكمة الخلفية");
      } catch (e) {
        console.error("فشل تحميل بيانات الخادم", e);
        const local = loadLocalBackup();
        if (local) {
          setDb(normalizeDb(local));
          setSyncStatus("وضع محلي مؤقت — Firebase غير مفعّل");
        } else {
          setSyncStatus("بيانات محلية فارغة — افتح المزيد ← Firebase والصلاحيات للربط");
        }
      }
      setLoaded(true);
    })();
  }, [firebaseServices, authReady, firebaseUser?.uid]);

  const setOfflineQueue = (rows) => {
    const clean = Array.isArray(rows) ? rows : [];
    saveOfflineQueue(clean);
    setOfflineQueueState(clean);
  };
  const refreshOfflineState = () => {
    setOfflineQueueState(loadOfflineQueue());
    setOfflineHistory(loadOfflineHistory());
  };
  const enqueueOfflineChange = (prev, next, reason) => {
    const changedKeys = changedKeysBetween(prev, next);
    if (!changedKeys.length) return null;
    const entry = makeOfflineQueueEntry(prev, next, { uid: firebaseUser?.uid, email: firebaseUser?.email, role }, reason);
    const rows = [...loadOfflineQueue().filter((x)=>x.status !== "applied" || daysUntil(x.updatedAt || x.createdAt) > -2), entry];
    setOfflineQueue(rows);
    addOfflineHistory({ type:"queued", queueId:entry.id, changedKeys, reason:String(reason || "") });
    setOfflineHistory(loadOfflineHistory());
    return entry;
  };

  const save = async (next) => {
    const nextWithAuth = firebaseEnabled ? { ...next, settings: { ...next.settings, role, myTechId } } : next;
    const prevSnapshot = db;
    setDb(nextWithAuth);

    if (firebaseServices && firebaseUser) {
      try {
        const changed = await saveCmmsStateToFirestore(firebaseServices, prevSnapshot, nextWithAuth, {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          role,
        });
        saveLocalBackup(nextWithAuth);
        setSyncStatus(changed.length ? "تم الحفظ في Firestore كمستندات مستقلة — " + changed.join("، ") : "لا توجد تغييرات للحفظ");
      } catch (e) {
        console.error("فشل الحفظ في Firestore", e);
        saveLocalBackup(nextWithAuth);
        const entry = enqueueOfflineChange(prevSnapshot, nextWithAuth, e?.message || e?.code || "تعذر الحفظ في Firestore");
        const stats = offlineQueueStats(entry ? [...loadOfflineQueue()] : loadOfflineQueue());
        setSyncStatus("حفظ محلي + طابور Offline — معلّق " + stats.pending + " / تعارض " + stats.conflict);
      }
      return;
    }

    try {
      const res = await fetch(`${API}/state`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextWithAuth),
      });
      if (!res.ok) throw new Error(await res.text().catch(() => "فشل الحفظ في الخادم"));
      saveLocalBackup(nextWithAuth);
      setSyncStatus("تم الحفظ في الخادم القديم");
    } catch (e) {
      console.error("فشل الحفظ في الخادم", e);
      if (saveLocalBackup(nextWithAuth)) {
        setSyncStatus("حفظ محلي مؤقت — لا يوجد Firebase أو خادم متاح");
      } else {
        setSyncStatus("فشل الحفظ — تحقق من Firebase وحجم الصور");
        alert("فشل الحفظ ولم تنجح النسخة المحلية — قد تكون مساحة التخزين امتلأت بسبب الصور.");
      }
    }
  };

  const runOfflineSync = async (source = "manual") => {
    if (!firebaseServices || !firebaseUser) { alert("فعّل Firebase وسجّل الدخول أولًا."); return; }
    if (syncRunning) return;
    const queueNow = loadOfflineQueue();
    const actionable = queueNow.filter((x)=>["pending", "retry"].includes(x.status));
    if (!actionable.length) { setSyncStatus("لا توجد تغييرات Offline معلقة"); refreshOfflineState(); return; }
    setSyncRunning(true);
    setSyncStatus("جارٍ مزامنة طابور Offline…");
    try {
      const remoteRaw = await loadCmmsStateFromFirestore(firebaseServices);
      const remote = normalizeDb(remoteRaw || { settings:{...EMPTY.settings, role, myTechId} });
      let working = remote;
      const nextQueue = queueNow.map((x)=>({ ...x }));
      let applied = 0, conflicts = 0;
      for (const entry of nextQueue) {
        if (!["pending", "retry"].includes(entry.status)) continue;
        entry.attempts = Number(entry.attempts || 0) + 1;
        entry.lastAttemptAt = now();
        const result = mergeOfflineEntryIntoRemote(working, entry);
        if (result.conflicts.length) {
          conflicts += result.conflicts.length;
          entry.status = "conflict";
          entry.conflicts = result.conflicts.map(compactConflict);
          entry.updatedAt = now();
          entry.error = "يوجد تعارض مع بيانات Firestore الحالية";
          addOfflineHistory({ type:"conflict", queueId:entry.id, changedKeys:entry.changedKeys, conflicts:entry.conflicts.length });
        } else {
          working = normalizeDb(result.merged);
          entry.status = "applied";
          entry.appliedAt = now();
          entry.updatedAt = now();
          entry.error = "";
          applied += 1;
          addOfflineHistory({ type:"applied", queueId:entry.id, changedKeys:entry.changedKeys, source });
        }
      }
      if (applied > 0) {
        await saveCmmsStateToFirestore(firebaseServices, remote, working, { uid:firebaseUser.uid, email:firebaseUser.email, role });
        setDb(working);
        saveLocalBackup(working);
      }
      setOfflineQueue(nextQueue);
      setOfflineHistory(loadOfflineHistory());
      setSyncStatus("مزامنة Offline: تم " + applied + " / تعارض " + conflicts);
    } catch (e) {
      console.error("فشل مزامنة Offline", e);
      const rows = loadOfflineQueue().map((x)=>["pending","retry"].includes(x.status) ? { ...x, status:"retry", attempts:Number(x.attempts||0)+1, error:String(e?.message || e), updatedAt:now() } : x);
      setOfflineQueue(rows);
      setSyncStatus("تعذر مزامنة Offline — سيعاد المحاولة لاحقًا");
    } finally {
      setSyncRunning(false);
    }
  };

  const resolveOfflineConflict = async (entryId, strategy) => {
    if (!firebaseServices || !firebaseUser) { alert("سجّل الدخول إلى Firebase أولًا"); return; }
    const queueNow = loadOfflineQueue();
    const entry = queueNow.find((x)=>x.id === entryId);
    if (!entry) return;
    try {
      if (strategy === "remote") {
        const rows = queueNow.map((x)=>x.id === entryId ? { ...x, status:"dropped", resolution:"remote", resolvedAt:now(), updatedAt:now(), error:"" } : x);
        setOfflineQueue(rows); addOfflineHistory({ type:"resolved-remote", queueId:entryId }); refreshOfflineState();
        setSyncStatus("تم تجاهل التغيير المحلي واعتماد نسخة Firestore");
        return;
      }
      const remoteRaw = await loadCmmsStateFromFirestore(firebaseServices);
      const remote = normalizeDb(remoteRaw || { settings:{...EMPTY.settings, role, myTechId} });
      const merged = normalizeDb(forceApplyOfflineEntry(remote, entry));
      await saveCmmsStateToFirestore(firebaseServices, remote, merged, { uid:firebaseUser.uid, email:firebaseUser.email, role });
      saveLocalBackup(merged); setDb(merged);
      const rows = queueNow.map((x)=>x.id === entryId ? { ...x, status:"applied", resolution:"local", resolvedAt:now(), updatedAt:now(), error:"" } : x);
      setOfflineQueue(rows); addOfflineHistory({ type:"resolved-local", queueId:entryId, changedKeys:entry.changedKeys }); refreshOfflineState();
      setSyncStatus("تم حل التعارض باعتماد نسخة هذا الجهاز");
    } catch (e) {
      alert("تعذر حل التعارض: " + String(e?.message || e));
    }
  };

  const clearOfflineDone = () => {
    const rows = loadOfflineQueue().filter((x)=>!["applied", "dropped"].includes(x.status));
    setOfflineQueue(rows); refreshOfflineState(); setSyncStatus("تم تنظيف سجلات Offline المكتملة");
  };
  const exportOfflineQueue = () => downloadJsonFile("cmms-offline-queue-" + today() + ".json", { queue:loadOfflineQueue(), history:loadOfflineHistory() });

  useEffect(() => {
    const stats = offlineQueueStats(offlineQueue);
    if (!browserOnline || !firebaseServices || !firebaseUser || syncRunning || stats.pending === 0) return;
    const t = window.setTimeout(() => runOfflineSync("auto"), 1800);
    return () => window.clearTimeout(t);
  }, [browserOnline, firebaseUser?.uid, firebaseServices, offlineQueue.length, syncRunning]);

  const put = (entity, rows) => save({ ...db, [entity]: rows });
  const add = (entity, row) => { const r = { id: uid(), ...row }; put(entity, [...db[entity], r]); return r; };
  const update = (entity, id, patch) => put(entity, db[entity].map((r) => (r.id === id ? { ...r, ...patch } : r)));
  const remove = (entity, id) => put(entity, db[entity].filter((r) => r.id !== id));
  const setSetting = (k, v) => save({ ...db, settings: { ...db.settings, [k]: v } });
  const nameOf = (entity, id, key = "name") => db[entity].find((r) => r.id === id)?.[key] || "—";

  const buildMediaRecord = (media, extra = {}) => ({
    id: media.id || uid(),
    entity: extra.entity || media.entity || "",
    recordId: extra.recordId || media.recordId || "",
    kind: extra.kind || media.kind || media.type || "",
    type: extra.type || media.type || extra.kind || media.kind || "",
    at: media.at || today(),
    uploadedAtIso: media.uploadedAtIso || now(),
    uploadedByRole: media.uploadedByRole || role,
    uploadedByUid: media.uploadedByUid || firebaseUser?.uid || "",
    uploadedByEmail: media.uploadedByEmail || firebaseUser?.email || "",
    ...media,
    ...extra,
  });

  const createMediaFromFile = async (file, extra = {}) => {
    const compressed = await resizeImage(file);
    const base = buildMediaRecord({
      name: file?.name || (extra.kind || "photo") + ".jpg",
      originalName: file?.name || "",
      contentType: "image/jpeg",
      sizeBytes: estimateDataUrlBytes(compressed),
    }, extra);

    if (firebaseServices && firebaseUser) {
      try {
        const uploaded = await uploadCmmsDataUrlToStorage(firebaseServices, compressed, {
          entity: base.entity || "general",
          recordId: base.recordId || "unlinked",
          kind: base.kind || base.type || "photo",
          fileName: base.name,
          contentType: "image/jpeg",
          uploadedByUid: firebaseUser.uid,
          uploadedByEmail: firebaseUser.email,
          uploadedByRole: role,
        });
        return buildMediaRecord({ ...base, ...uploaded, data: undefined, storageStatus:"uploaded" }, extra);
      } catch (e) {
        console.error("فشل رفع الملف إلى Firebase Storage", e);
        setSyncStatus("تعذر رفع الصورة إلى Storage — حُفظت محليًا مؤقتًا");
        return buildMediaRecord({ ...base, data: compressed, storageProvider:"local-base64", storageStatus:"pending-upload", storageError:String(e?.message || e) }, extra);
      }
    }
    return buildMediaRecord({ ...base, data: compressed, storageProvider:"local-base64", storageStatus:"local-only" }, extra);
  };

  const deleteMediaFromStorage = async (media) => {
    if (!firebaseServices || !media?.storagePath) return;
    try { await deleteCmmsStorageFile(firebaseServices, media.storagePath); }
    catch (e) { console.warn("تعذر حذف ملف Storage؛ سيتم حذف الرابط من السجل فقط", e); }
  };

  const migrateLocalMediaToStorage = async () => {
    if (!firebaseServices || !firebaseUser) return alert("فعّل Firebase وسجّل الدخول أولًا.");
    if (!can.admin && !can.manage) return alert("ترحيل الصور يحتاج مدير أو مشرف.");
    let uploadedCount = 0, failedCount = 0;
    const mediaRecords = [...(db.mediaFiles || [])];
    const convert = async (media, extra) => {
      if (!media?.data || media.storagePath) return media;
      try {
        const uploaded = await uploadCmmsDataUrlToStorage(firebaseServices, media.data, {
          entity: extra.entity,
          recordId: extra.recordId,
          kind: extra.kind || media.type || "photo",
          fileName: media.name || `${extra.kind || media.type || "photo"}.jpg`,
          contentType: media.contentType || "image/jpeg",
          uploadedByUid: firebaseUser.uid,
          uploadedByEmail: firebaseUser.email,
          uploadedByRole: role,
        });
        uploadedCount += 1;
        const nextMedia = buildMediaRecord({ ...media, ...uploaded, data: undefined, storageStatus:"uploaded" }, extra);
        mediaRecords.push(nextMedia);
        return nextMedia;
      } catch (e) {
        failedCount += 1;
        return { ...media, storageStatus:"upload-failed", storageError:String(e?.message || e) };
      }
    };
    const nextAssets = [];
    for (const a of db.assets || []) {
      const photos = [];
      for (const p of a.photos || []) photos.push(await convert(p, { entity:"assets", recordId:a.id, kind:p.type || "أصل", type:p.type || "أصل" }));
      nextAssets.push({ ...a, photos });
    }
    const nextWos = [];
    for (const w of db.workOrders || []) {
      const photos = [];
      for (const p of w.photos || []) photos.push(await convert(p, { entity:"workOrders", recordId:w.id, kind:p.type || "أمر عمل", type:p.type || "أمر عمل" }));
      nextWos.push({ ...w, photos });
    }
    await save({ ...db, assets:nextAssets, workOrders:nextWos, mediaFiles:mediaRecords });
    alert(`تم رفع ${uploadedCount} صورة إلى Firebase Storage.${failedCount ? " فشل: " + failedCount : ""}`);
  };

  /* ───── محرك العدادات (ف5): Net Change / Displayed / Life-to-Date ───── */
  const meterReadings = (amId) => db.readings.filter((r) => r.assetMeterId === amId).sort((a, b) => (a.at < b.at ? -1 : 1));
  const activeReadings = (amId) => meterReadings(amId).filter((r) => !["معطلة", "ملغاة"].includes(r.status));
  const lastReading = (amId) => activeReadings(amId).slice(-1)[0] || null;
  /* حساب الصفوف: لكل قراءة فعالة net/displayed/ltd حسب نوع العداد والاتجاه مع التصفير والتدوير */
  const meterRows = (am) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
    let prevDisp = Number(am.initial || 0), ltdv = 0, started = false;
    const out = [];
    for (const r of activeReadings(am.id)) {
      const v = Number(r.value);
      let net = 0, disp = v;
      if (tpl.meterType === "مقياس") { net = started ? v - prevDisp : 0; disp = v; ltdv = v; }
      else if (tpl.readingType === "تغير") {
        net = v; disp = prevDisp + (tpl.direction === "تنازلي" ? -v : v);
        ltdv += (tpl.direction === "تنازلي" ? -v : v);
      } else { /* مستمر مطلق */
        if (r.status === "تصفير" || r.isReset) { net = 0; disp = v; }
        else if (r.rollover) { net = (Number(tpl.rolloverMax || 0) - prevDisp) + (v - Number(tpl.rolloverMin || 0)); disp = v; }
        else { net = started ? v - prevDisp : (r.status === "أولية" ? 0 : v - prevDisp); disp = v; }
        if (tpl.direction === "تنازلي") ltdv = disp; /* التنازلي: العمر ≈ المعروض */
        else ltdv += Math.max(0, net);
      }
      out.push({ ...r, net, displayed: disp, ltd: ltdv });
      prevDisp = disp; started = true;
    }
    return out;
  };
  const ltd = (am) => { const rows = meterRows(am); return rows.length ? rows[rows.length - 1].ltd : 0; };
  const currentValue = (am) => { const rows = meterRows(am); return rows.length ? rows[rows.length - 1].displayed : Number(am.initial || 0); };
  /* معدل الاستخدام المحسوب من آخر N قراءات: (نهاية − بداية) ÷ الأيام (ف5 §15.1) */
  const calcUtilRate = (am) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
    if (tpl.meterType === "مقياس") return null;
    const n = Number(am.readingsForRate || tpl.readingsForRate || 0);
    const rows = meterRows(am);
    if (n < 2 || rows.length < n) return null;
    const seg = rows.slice(-n);
    const days = daysBetween(seg[seg.length - 1].at, seg[0].at);
    return (seg[seg.length - 1].ltd - seg[0].ltd) / days;
  };
  /* الأولوية: المعدل المحسوب ← المقدّر على مستوى الأصل ← المقدّر بالقالب ← متوسط التاريخ كله */
  const utilRate = (am) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
    const calc = calcUtilRate(am);
    if (calc != null && calc > 0) return calc;
    if (Number(am.estDailyRate)) return Number(am.estDailyRate);
    if (Number(tpl.estDailyRate)) return Number(tpl.estDailyRate);
    const rows = meterRows(am);
    if (!rows.length) return 0;
    const span = daysBetween(today(), rows[0].at);
    return rows[rows.length - 1].ltd / span;
  };
  const addReading = (am, value, at, opts = {}) => {
    const tpl = db.meterTemplates.find((t) => t.id === am.templateId);
    const v = Number(value);
    const rows = activeReadings(am.id);
    const last = rows.slice(-1)[0] || null;
    if (am.endDate && at > am.endDate) return "العداد معطل (نهاية " + am.endDate + ") — لا قراءات بعد هذا التاريخ";
    if (rows.some((r) => r.at === at)) return "توجد قراءة فعالة بنفس التاريخ";
    if (!opts.historical && last && at < last.at) return "تاريخ القراءة يجب أن يكون بعد آخر قراءة (" + last.at + ") — أو فعّل «قراءة تاريخية»";
    if ((opts.historical || opts.source === "REST" || opts.source === "استيراد") && opts.source && opts.source !== "يدوي" && opts.historical)
      return "القراءة التاريخية من شاشة الإدخال فقط (قاعدة ف5)";
    /* الجار السابق حسب التاريخ (للتاريخية) */
    const prevRow = meterRows(am).filter((r) => r.at < at).slice(-1)[0] || null;
    const prevDisp = prevRow ? prevRow.displayed : Number(am.initial || 0);
    if (opts.rollover) {
      if (!(tpl.rolloverAllowed && tpl.meterType === "مستمر" && tpl.readingType === "مطلق" && tpl.direction === "تصاعدي"))
        return "التدوير متاح فقط للمستمر المطلق التصاعدي مع تفعيله بالقالب";
      if (tpl.rolloverMin !== "" && v < Number(tpl.rolloverMin)) return "بعد التدوير: القيمة ≥ " + tpl.rolloverMin;
      if (v >= prevDisp) return "التدوير يعني قيمة أقل من السابقة (" + prevDisp + ")";
    } else if (opts.isReset) {
      if (tpl.resetAllowed === false) return "التصفير غير مفعّل في هذا القالب";
    } else if (tpl.readingType === "مطلق" && tpl.meterType === "مستمر") {
      if (tpl.direction === "تصاعدي" && v < prevDisp) return "عداد تصاعدي: القيمة يجب أن تكون ≥ " + prevDisp + " (أو استخدم تدوير/تصفير)";
      if (tpl.direction === "تنازلي" && v > prevDisp) return "عداد تنازلي: القيمة يجب أن تكون ≤ " + prevDisp;
    }
    if (tpl.readingType === "تغير" || tpl.meterType === "مقياس") {
      if (tpl.readingType === "تغير" && tpl.direction !== "تنازلي" && v < 0) return "قراءة التغير يجب أن تكون ≥ 0";
      if (tpl.min !== "" && tpl.min != null && v < Number(tpl.min)) return "أقل من الحد الأدنى (" + tpl.min + ")";
      if (tpl.max !== "" && tpl.max != null && v > Number(tpl.max)) return "أعلى من الحد الأقصى (" + tpl.max + ")";
    }
    add("readings", { assetMeterId: am.id, value: v, at,
      source: opts.source || "يدوي", isReset: !!opts.isReset, rollover: !!opts.rollover,
      status: opts.isReset ? "تصفير" : opts.rollover ? "تدوير" : opts.status || "مسجلة",
      comments: opts.comments || "", workOrderId: opts.workOrderId || "" });
    return null;
  };
  /* تعطيل قراءة: تُستبعد من الحسابات (إعادة الحساب تلقائية لأن القيم تُشتق ديناميكيًا) */
  const disableReading = (am, r) => {
    const rows = activeReadings(am.id);
    const isLatest = rows.length && rows[rows.length - 1].id === r.id;
    if (r.status === "أولية") return "لا تُعطّل القراءة الأولية";
    if ((r.status === "تصفير" || r.status === "تدوير") && !isLatest) return "التصفير/التدوير يُعطّل فقط إذا كان آخر قراءة فعالة";
    update("readings", r.id, { status: "معطلة" });
    return null;
  };

  /* فحص PM بعد القراءة (وثيقة الأصول): تنبيهات الاستحقاق والاقتراب */
  const pmCheckAfterReading = (am, newValue) => {
    const alerts = [];
    db.programs.filter((p) => p.method === "فاصل عداد" && p.assetMeterId === am.id).forEach((p) => {
      const tpl = db.meterTemplates.find((t) => t.id === am.templateId);
      const delta = tpl?.readingType === "تغير" ? Number(newValue) : Math.abs(Number(newValue) - currentValue(am));
      const since = ltd(am) + delta - Number(p.lastMeterValue || 0);
      const remaining = Number(p.interval) - since;
      if (remaining <= 0) alerts.push({ program: p, msg: "🔴 «" + p.name + "» مستحق الآن — إنشاء أمر عمل" });
      else if (remaining <= Number(p.interval) * 0.1)
        alerts.push({ program: null, msg: "⏳ «" + p.name + "»: الصيانة مستحقة بعد " + remaining + " " + (tpl?.uom || "وحدة") });
    });
    return alerts;
  };

  /* ───── محرك ضمان المورد (ف6) ───── */
  const dailyRate = (am) => utilRate(am);
  /* تاريخ الانتهاء المتوقع من العدادات: اليوم + (نهاية العداد − العمر) ÷ معدل الاستخدام اليومي */
  const contractCalcExpiration = (c) => {
    const dates = (c.meters || []).map((cm) => {
      const am = db.assetMeters.find((m) => m.assetId === c.assetId && m.templateId === cm.templateId);
      if (!am) return null;
      const endValue = Number(cm.startValue || 0) + Number(cm.interval || 0);
      const rate = dailyRate(am);
      const remaining = endValue - ltd(am);
      if (remaining <= 0) return today();
      if (rate <= 0) return null;
      const offset = Math.floor(Number(remaining) / Number(rate));
      return Number.isFinite(offset) ? addDateDays(today(), offset) : null;
    }).filter(Boolean).sort();
    return dates[0] || null;
  };
  const contractEffectiveEnd = (c) => {
    const calc = contractCalcExpiration(c);
    if (c.endDate && calc) return c.endDate < calc ? c.endDate : calc; /* الأقرب انتهاءً */
    return c.endDate || calc || null;
  };
  const contractState = (c) => {
    if (c.status === "مسودة") return "مسودة";
    const end = contractEffectiveEnd(c);
    if (end && daysUntil(end) < 0) return "منتهٍ";
    return "جاهز";
  };
  /* العقود الفعالة للأصل وأصوله المرتبطة (الأب والمكونات التابعة) */
  const activeContracts = (assetId) => {
    const fam = new Set([assetId]);
    const a = db.assets.find((x) => x.id === assetId);
    if (a?.parentId) fam.add(a.parentId);
    db.assets.filter((x) => x.parentId === assetId).forEach((x) => fam.add(x.id));
    return db.contracts.filter((c) => fam.has(c.assetId) && contractState(c) === "جاهز")
      .sort((x, y) => String(contractEffectiveEnd(x) || "9999") < String(contractEffectiveEnd(y) || "9999") ? -1 : 1);
  };
  /* توافق قديم: لافتات الضمان تعمل من العقود أولًا ثم الضمانات البسيطة */
  const activeWarranty = (assetId) => {
    const c = activeContracts(assetId)[0];
    if (c) {
      const cov = db.coverages.find((v) => v.id === c.coverageId);
      return { supplier: nameOf("warrantyProviders", cov?.providerId) !== "—" ? nameOf("warrantyProviders", cov?.providerId) : (cov?.name || "ضمان"), end: contractEffectiveEnd(c) || "" };
    }
    return db.warranties.find((w) => w.assetId === assetId && daysUntil(w.end) >= 0 && (!w.start || daysUntil(w.start) <= 0));
  };
  /* ───── الأصول (ف3): قابلية الاستخدام، السجل، النسخ، التقسيم، وراثة الموقع ───── */
  const assetUsable = (a) => a && a.active !== false && (!a.endDate || a.endDate >= today());
  const nextAssetNumber = () => {
    let n = db.assets.length + 1, num;
    do { num = "AST-" + String(1000 + n); n++; } while (db.assets.some((a) => a.number === num));
    return num;
  };
  const logAsset = (assetId, action, extraPatch = {}) => {
    const a = db.assets.find((x) => x.id === assetId);
    if (!a) return;
    update("assets", assetId, { ...extraPatch, history: [...(a.history || []), { action, at: now(), by: role }] });
  };
  const assetSaveErrors = (d, editingId) => {
    if (!String(d.name || "").trim()) return "اسم الأصل مطلوب";
    if (d.number && db.assets.some((a) => a.number === d.number && a.id !== editingId)) return "رقم الأصل مستخدم — يجب أن يكون فريدًا";
    const orgKey = d.operatingOrganizationId || "__global__";
    if (d.serial && db.assets.some((a) => a.serial && a.serial === d.serial && (a.operatingOrganizationId || "__global__") === orgKey && a.id !== editingId)) return "الرقم التسلسلي مستخدم داخل نفس منظمة التشغيل";
    if (d.serial && Number(d.quantity || 1) !== 1) return "الأصل المسلسل يجب أن تكون كميته 1";
    if (d.itemRequired && !(String(d.itemId || "").trim() || String(d.itemName || "").trim())) return "الصنف Item مطلوب عند تفعيل item_required";
    if (d.ownership === "عميل" && !(String(d.customer || "").trim() || String(d.customerId || "").trim())) return "أصل العميل يحتاج اسم/معرف العميل";
    if ((d.locationType || "") === "INVENTORY" && !d.createdFromInventoryTx) return "Location = Inventory لا يضبط يدويًا من شاشة الأصل؛ يأتي من حركة مخزون";
    if (!String(d.location || "").trim()) return "لا أصل بدون موقع (قاعدة النظام)";
    return null;
  };
  /* الهرمية المادية: الفرع يرث موقع الأب الأعلى، وتغيير موقع الأب يحدّث كل الأبناء (ف3 §12) */
  const descendants = (assetId) => {
    const out = [];
    const walk = (id) => db.assets.filter((x) => x.parentId === id).forEach((c) => { out.push(c); walk(c.id); });
    walk(assetId);
    return out;
  };
  const propagateLocation = (assetId, location) => {
    const kids = descendants(assetId);
    if (!kids.length) return 0;
    save({ ...db, assets: db.assets.map((a) => kids.some((k) => k.id === a.id) ? { ...a, location } : a) });
    return kids.length;
  };
  /* نسخ أصل موجود (مع خيار نسخ العدادات) — حفظ ذري حتى لا تضيع الإضافات المتزامنة */
  const copyAsset = (a, withMeters) => {
    const created = { ...a, id: uid(), number: nextAssetNumber(), name: a.name + " (نسخة)",
      serial: "", parentId: a.parentId || "", notes: [], photos: [], docs: (a.docs || []).map((x) => ({ ...x, id: uid() })),
      parts: (a.parts || []).map((x) => ({ ...x, id: uid() })),
      history: [{ action: "إنشاء بالنسخ من " + a.number, at: now(), by: role }] };
    const copiedMeters = withMeters ? db.assetMeters.filter((m) => m.assetId === a.id && (!m.endDate || m.endDate >= today()))
      .map((m) => ({ id: uid(), assetId: created.id, templateId: m.templateId, initial: 0, recordAtWO: m.recordAtWO, endDate: "", estDailyRate: m.estDailyRate, readingsForRate: m.readingsForRate })) : [];
    save({ ...db, assets: [...db.assets, created], assetMeters: [...db.assetMeters, ...copiedMeters] });
    return created;
  };
  /* تقسيم أصل غير مسلسل (ف3 §7): شروط الأهلية ثم وحدات كمية = 1 */
  const splitAsset = (a) => {
    const qty = Number(a.quantity || 1);
    if (a.serial) return "الأصل مسلسل — لا يقبل التقسيم";
    if (!(Number.isInteger(qty) && qty > 1)) return "الكمية يجب أن تكون عددًا صحيحًا أكبر من 1";
    if ((a.locationType || "") === "INVENTORY") return "الأصل في المخزون — التقسيم من شاشة الأصل غير مسموح";
    if (a.endDate && a.endDate < today()) return "الأصل منتهٍ — لا تقسيم";
    if (db.workOrders.some((w) => w.assetId === a.id && ACTIVE_STATES.includes(w.status))) return "يوجد أمر عمل مفتوح على الأصل — أغلقه أولًا";
    const clones = [];
    for (let i = 2; i <= qty; i++) {
      clones.push({ ...a, id: uid(), number: nextAssetNumber().replace(/\d+$/, (n) => String(Number(n) + i - 2)), name: a.name + " /" + i, quantity: 1,
        notes: [], photos: [], docs: [], parts: (a.parts || []).map((x) => ({ ...x, id: uid() })),
        history: [{ action: "إنشاء بالتقسيم من " + a.number, at: now(), by: role }] });
    }
    save({ ...db, assets: db.assets.map((x) => x.id === a.id ? { ...x, quantity: 1, history: [...(x.history || []), { action: "تقسيم إلى " + qty + " وحدات: " + clones.map((c) => c.number).join("، "), at: now(), by: role }] } : x).concat(clones) });
    return null;
  };

  /* ───── قواعد مجموعات الأصول (ف4) ───── */
  const groupRule = (g) => db.assetGroupRules.find((r) => r.id === g.ruleId);
  const groupActive = (g) => !g.inactiveOn || g.inactiveOn >= today();
  const activeAssignments = (g) => (g.assignments || []).filter((x) => !x.end);
  /* أهلية الأصل للمجموعة: المجموعة فعالة + الأصل نشط + تطابق الخصائص + قيد الفريد ضمن القاعدة */
  const canAssignAsset = (asset, g) => {
    if (!asset || asset.active === false) return "الأصل منتهٍ/موقوف";
    if (!groupActive(g)) return "المجموعة معطلة — لا تعيينات جديدة";
    if (activeAssignments(g).some((x) => x.assetId === asset.id)) return "معين مسبقًا";
    const rule = groupRule(g);
    for (const attr of (rule?.attributes || [])) {
      const want = (g.attrValues || {})[attr];
      if (want && String(asset[attr] || "") !== String(want)) return "لا يطابق خاصية " + (GROUP_ATTRS.find(([k]) => k === attr)?.[1] || attr);
    }
    if (rule?.enforceUnique) {
      const other = db.assetGroups.find((og) => og.ruleId === rule.id && og.id !== g.id && activeAssignments(og).some((x) => x.assetId === asset.id));
      if (other) return "تعيين فريد: الأصل في «" + other.name + "» ضمن نفس القاعدة";
    }
    return null;
  };
  const syncIds = (g, assignments) => ({ assignments, assetIds: assignments.filter((x) => !x.end).map((x) => x.assetId) });
  const assignAsset = (g, assetId) => {
    const err = canAssignAsset(db.assets.find((a) => a.id === assetId), g);
    if (err) return err;
    const assignments = [...(g.assignments || []), { id: uid(), assetId, start: today(), end: "", endReason: "", by: role }];
    update("assetGroups", g.id, syncIds(g, assignments));
    return null;
  };
  const unassignAsset = (g, assignmentId, reason) => {
    const assignments = (g.assignments || []).map((x) => x.id === assignmentId ? { ...x, end: today(), endReason: reason || "إلغاء يدوي" } : x);
    update("assetGroups", g.id, syncIds(g, assignments));
  };
  /* إعادة التحقق: تغيّر الأصل ← أنهِ التعيين بسبب واضح بدل الحذف (ف4 §13) */
  const revalidateGroup = (g) => {
    const rule = groupRule(g);
    const bad = [];
    const assignments = (g.assignments || []).map((x) => {
      if (x.end) return x;
      const a = db.assets.find((z) => z.id === x.assetId);
      let reason = "";
      if (!a || a.active === false) reason = "إنهاء الأصل";
      else for (const attr of (rule?.attributes || [])) {
        const want = (g.attrValues || {})[attr];
        if (want && String(a[attr] || "") !== String(want)) { reason = "تغير بيانات الأصل"; break; }
      }
      if (reason) { bad.push((a?.name || "أصل") + " (" + reason + ")"); return { ...x, end: today(), endReason: reason }; }
      return x;
    });
    update("assetGroups", g.id, syncIds(g, assignments));
    return bad;
  };
  /* استبعادات قاعدة «حالة الأصل»: منع طلبات/أوامر العمل لأصول المجموعة */
  const assetExclusion = (assetId) => {
    for (const g of db.assetGroups) {
      if (!groupActive(g)) continue;
      if (!activeAssignments(g).some((x) => x.assetId === assetId)) continue;
      if (g.excludeFromWO || g.excludeFromRequests)
        return { wo: !!g.excludeFromWO, requests: !!g.excludeFromRequests, groupName: g.name };
    }
    return { wo: false, requests: false, groupName: "" };
  };

  /* توليد الاستحقاقات وتجميعها في مطالبة (يحاكي الـ Scheduled Process) */
  const generateEntitlements = (wo) => {
    if (!wo.warrantyRepair) { alert("مؤشر «إصلاح ضمان» غير مفعّل لهذا الأمر — لا تُنشأ استحقاقات (قاعدة ف6)"); return; }
    const cs = activeContracts(wo.assetId);
    if (!cs.length) { alert("لا عقود ضمان فعالة للأصل أو أصوله المرتبطة"); return; }
    const contract = cs[0]; /* الأقرب انتهاءً */
    const cov = db.coverages.find((v) => v.id === contract.coverageId) || {};
    const provId = cov.providerId || "";
    const codes = (cov.repairCodes || []).filter((r) => r.enabled !== false).map((r) => r.code);
    const useMatch = !!wo.matchCodes && codes.length > 0;
    const opCovered = (op) => !useMatch || codes.some((cd) => String(op.repairTx || "").startsWith(cd));
    const anyOpCovered = (wo.operations || []).some(opCovered);
    const findRate = () => {
      const r = db.laborRates.find((x) => x.providerId === provId && x.active !== false && (!x.startDate || x.startDate <= (contract.startDate || today())) && (!x.endDate || x.endDate >= (contract.startDate || today())));
      return r ? Number(r.hourlyRate || 0) : null;
    };
    const hourly = findRate();
    const ents = [];
    (wo.materials || []).forEach((m) => {
      const used = Number(m.usedQty || 0);
      if (used <= 0) return;
      const covd = anyOpCovered;
      ents.push({ id: uid(), workOrderId: wo.id, type: "صرف مادة", description: m.itemId ? nameOf("items", m.itemId) : m.name,
        qty: used, unitCost: Number(m.unitCost || 0), total: used * Number(m.unitCost || 0),
        contractId: covd ? contract.id : "", included: covd && cov.partsReimb !== false && !!cov.partsReimb, claimId: "" });
    });
    (wo.operations || []).filter((o) => o.status === "مكتملة").forEach((op) => {
      const covd = opCovered(op);
      const srt = db.repairTimes.find((t) => t.providerId === provId && t.stdOpId === op.stdOpId && t.active !== false && (!t.startDate || t.startDate <= (contract.startDate || today())));
      const tech = db.technicians.find((t) => t.id === op.assigneeId);
      const rate = hourly != null ? hourly : Number(tech?.rate || 0);
      if (srt) ents.push({ id: uid(), workOrderId: wo.id, type: "إصلاح قياسي", description: op.name + " (زمن قياسي)",
        qty: Number(srt.hours || 0), unitCost: rate, total: Number(srt.hours || 0) * rate,
        contractId: covd ? contract.id : "", included: covd && !!cov.laborReimb, claimId: "" });
      else if (Number(op.actualHours || 0) > 0) ents.push({ id: uid(), workOrderId: wo.id, type: "تحميل مورد", description: op.name,
        qty: Number(op.actualHours || 0), unitCost: rate, total: Number(op.actualHours || 0) * rate,
        contractId: covd ? contract.id : "", included: covd && !!cov.laborReimb, claimId: "" });
    });
    if (!ents.length) { alert("لا معاملات (مواد مستخدمة أو ساعات) لتوليد استحقاقات منها"); return; }
    /* أزل توليدًا سابقًا لنفس الأمر ومطالباته التلقائية */
    const oldEnts = db.entitlements.filter((e) => e.workOrderId === wo.id);
    const oldClaimIds = new Set(oldEnts.map((e) => e.claimId).filter(Boolean));
    let claims = db.claims.filter((c) => !(oldClaimIds.has(c.id) && c.auto));
    let entitlements = db.entitlements.filter((e) => e.workOrderId !== wo.id);
    const included = ents.filter((e) => e.included);
    if (included.length) {
      const claim = { id: uid(), number: "CLM-" + String(1000 + claims.length + 1), workOrderId: wo.id,
        providerId: provId, status: "قيد المراجعة", auto: true, createdAt: today(), submitBy: "", assignedTo: "", notes: "", adjustments: [], reimbursementAmount: "", claimType: "" };
      included.forEach((e) => { e.claimId = claim.id; });
      claims = [...claims, claim];
    }
    entitlements = [...entitlements, ...ents];
    save({ ...db, entitlements, claims });
    alert("✓ أُنشئ " + ents.length + " استحقاق (" + included.length + " ضمن مطالبة" + (included.length ? " " + "CLM-" + String(1000 + claims.length) : "") + ")\n" +
      (useMatch ? "تمت مطابقة أكواد الإصلاح مع التغطية." : "بدون مطابقة أكواد — اعتمد على العقد الفعال الأقرب انتهاءً."));
  };

  /* ───── المخزون: الرصيد من الحركات فقط (لا تعديل مباشر) ───── */
  const onHand = (itemId, whId) => db.stockTx.reduce((s, t) => {
    if (t.itemId !== itemId) return s;
    const q = Number(t.qty || 0);
    if (whId && t.type === "تحويل") return s + (t.toWarehouseId === whId ? q : 0) - (t.warehouseId === whId ? q : 0);
    if (whId && t.warehouseId !== whId) return s;
    if (t.type === "استلام" || t.type === "إرجاع من أمر عمل") return s + q;
    if (t.type === "صرف لأمر عمل" || t.type === "إتلاف") return s - q;
    if (t.type === "تسوية") return s + q;
    if (t.type === "تحويل") return s; /* بدون مستودع: التحويل لا يغيّر الإجمالي */
    return s;
  }, 0);
  /* المحجوز لأوامر العمل المفتوحة (لم يُصرف بعد) */
  const reservedQty = (itemId) => db.workOrders.reduce((s, w) =>
    ACTIVE_STATES.includes(w.status)
      ? s + (w.materials || []).reduce((x, m) => x + (m.itemId === itemId && m.reserved && !Number(m.issuedQty || 0) ? Number(m.qty || 0) : 0), 0)
      : s, 0);
  const availableQty = (itemId) => onHand(itemId) - reservedQty(itemId);
  const addTx = (tx) => add("stockTx", { at: today(), ...tx });
  /* فحص توفر مواد أمر العمل (قاعدة: لا إصدار بدون فحص التوفر) */
  const woShortages = (wo) => (wo.materials || []).filter((m) =>
    m.itemId && !Number(m.issuedQty || 0) && Number(m.qty || 0) > availableQty(m.itemId) + (m.reserved ? Number(m.qty || 0) : 0));

  /* أوامر العمل */
  const woNumber = () => "WO-" + String(1000 + db.workOrders.length + 1);
  const log = (wo, action) => [...(wo.execLog || []), { action, at: now(), by: role + (myTechId ? " — " + nameOf("technicians", myTechId) : "") }];
  const woAssignedTechIds = (wo) => [...new Set([
    ...(wo._cmmsAssignedTechIds || []),
    ...(wo.assignments || []).map((a) => a.technicianId),
    ...(db.workOrderAssignments || []).filter((a) => a.workOrderId === wo.id).map((a) => a.technicianId),
    ...(wo.operations || []).map((o) => o.assigneeId),
  ].filter(Boolean))];
  const hasAssignedTechnician = (wo) => woAssignedTechIds(wo).length > 0;
  const materialStatusOf = (wo) => {
    const mats = wo.materials || [];
    if (!mats.length) return "لا مواد";
    if (mats.every((m) => Number(m.issuedQty || 0) > 0)) return "مصروف";
    if (mats.every((m) => m.reserved || Number(m.issuedQty || 0) > 0)) return "Available";
    return woShortages(wo).length ? "Waiting Material" : "Available";
  };
  const transitionError = (wo, next, extra = {}) => {
    if (!wo.assetId) return "No Work Order without Asset — لا أمر عمل بدون أصل.";
    if (wo.type === "وقائي" && !wo.programId && !wo.workDefId && !wo.followUpOf) return "No PM Work Order without Maintenance Program or Work Definition.";
    if (["مُصدر", "جاهز", "قيد التنفيذ", "بانتظار المراجعة", "مغلق"].includes(next) && !hasAssignedTechnician(wo)) return "No work order without technicians assign — أسند فنيًا واحدًا على الأقل قبل المتابعة.";
    if (next === "قيد التنفيذ" && wo.safetyRequired && (wo.checklist || []).some((c) => !c.done)) return "No start without safety checklist if required — أكمل قائمة السلامة أولًا.";
    if (next === "بانتظار المراجعة") {
      const gaps = completionGaps(wo);
      if (gaps.length) return "لا يمكن طلب الإكمال:\n• " + gaps.join("\n• ");
    }
    if (next === "مغلق" && !extra.supervisorApproved && !wo.supervisorApproved) return "No final close without supervisor approval — لا إغلاق نهائي بدون اعتماد المشرف.";
    return "";
  };
  const createWO = (data) => {
    if (!data.assetId) { alert("No Work Order without Asset — اختر الأصل أولًا."); return; }
    if (data.type === "وقائي" && !data.programId && !data.workDefId && !data.routeId) { alert("No PM Work Order without Maintenance Program or Work Definition."); return; }
    const asset = db.assets.find((a) => a.id === data.assetId);
    if (asset && !assetUsable(asset)) { alert("⛔ الأصل منتهٍ/موقوف (" + (asset.endDate ? "تاريخ الإنهاء " + fmt(asset.endDate) : "موقوف") + ") — لا أوامر عمل"); return; }
    if (asset && asset.allowWO === false) { alert("⛔ هذا الأصل لا يسمح بأوامر العمل (علم الأصل)"); return; }
    if (asset && asset.defaultWOType && !data.type) data.type = asset.defaultWOType;
    const exc = assetExclusion(data.assetId);
    if (exc.wo) { alert("⛔ الأصل مستبعد من أوامر العمل بواسطة مجموعة التحقق «" + exc.groupName + "» (قاعدة حالة الأصل)"); return; }
    const def = db.workDefs.find((d) => d.id === data.workDefId);
    const primaryTechId = data.assignedTechnicianId || "";
    const operations = (def?.opIds || []).map((opId, i) => {
      const op = db.stdOps.find((o) => o.id === opId);
      return { id: uid(), seq: (i + 1) * 10, stdOpId: opId, name: op?.name || "عملية", workCenterId: op?.workCenterId || "",
        minutes: op?.minutes || "", status: "معلقة", assigneeId: i === 0 ? primaryTechId : "", actualHours: 0,
        steps: (op?.steps || "").split("\n").filter(Boolean).map((text, idx) => ({ id: uid(), seq: idx + 1, text, done: false })),
        opType: op?.type || "داخلية", supplier: op?.supplier || "",
        attachments: (op?.attachments || []).map((a) => ({ ...a })),
        repairReason: op?.repairReason || "", repairTx: op?.repairTx || "", workDone: op?.workDone || "",
        chargeType: (op?.resources || [])[0]?.chargeType || "يدوي" };
    });
    const assignments = primaryTechId ? [{ id: uid(), technicianId: primaryTechId, role: "فني رئيسي", status: "مسند", assignedAt: today(), assignedBy: role }] : [];
    const checklist = data.safetyRequired ? SAFETY_DEFAULTS.map((t) => ({ id: uid(), text: t, done: false })) : [];
    const w = activeWarranty(data.assetId);
    if (w && ["تصحيحي", "طارئ"].includes(data.type)) alert("⚠ تنبيه: هذا الأصل تحت ضمان ساري لدى «" + w.supplier + "» حتى " + fmt(w.end) + ".\nراجع الضمان قبل تحميل تكلفة إصلاح داخلي.");
    const wcs = activeContracts(data.assetId);
    const wCov = wcs[0] ? db.coverages.find((v) => v.id === wcs[0].coverageId) : null;
    data.warrantyRepair = wcs.length > 0 && data.type !== "وقائي";
    data.matchCodes = !!(wCov && (wCov.repairCodes || []).some((r) => r.enabled !== false));
    const createdEvent = { id: uid(), from: "", to: "مسودة", at: today(), atText: now(), by: role, action: "إنشاء أمر العمل" };
    add("workOrders", { number: woNumber(), status: "مسودة", operations, checklist, materials: [], photos: [],
      failure: null, exceptions: [], assignments, resources: [], statusHistory: [createdEvent], approvals: [], completionRequests: [], supervisorReviews: [],
      execLog: [{ action: "إنشاء أمر العمل", at: now(), by: role }],
      history: [{ to: "مسودة", at: today() }], underWarranty: !!w, _cmmsAssignedTechIds: assignments.map((a) => a.technicianId), ...data });
  };
  const setWOStatus = (wo, next, extra = {}) => {
    const err = transitionError(wo, next, extra);
    if (err) { alert(err); return false; }
    const atText = now();
    const event = { id: uid(), workOrderId: wo.id, number: wo.number, from: wo.status, to: next, at: today(), atText, by: role, byTechId: myTechId || "" };
    const assignedIds = woAssignedTechIds(wo);
    const execEvent = { id: uid(), workOrderId: wo.id, number: wo.number, action: "STATUS_CHANGE", description: "تغيير الحالة: " + wo.status + " ← " + next, at: today(), atText, by: role, byTechId: myTechId || "" };
    const patchedWo = {
      ...wo, status: next, ...extra, _cmmsAssignedTechIds: assignedIds,
      history: [...(wo.history || []), { from: wo.status, to: next, at: today() }],
      statusHistory: [...(wo.statusHistory || []), event],
      execLog: log(wo, "تغيير الحالة: " + wo.status + " ← " + next),
      ...(next === "بانتظار المراجعة" ? { completionRequestedAt: today(), completionRequestStatus: "مفتوح" } : {}),
      ...(next === "مغلق" ? { completedAt: today(), supervisorApproved: true, completionRequestStatus: "معتمد" } : {}),
    };
    const nextDb = { ...db,
      workOrders: db.workOrders.map((w) => (w.id === wo.id ? patchedWo : w)),
      workOrderStatusHistory: [...(db.workOrderStatusHistory || []), event],
      workOrderExecutionHistory: [...(db.workOrderExecutionHistory || []), execEvent],
    };
    if (next === "بانتظار المراجعة") {
      nextDb.workOrderCompletionRequests = [...(db.workOrderCompletionRequests || []), { id: uid(), workOrderId: wo.id, number: wo.number, status: "مفتوح", requestedAt: today(), requestedByRole: role, requestedByTechId: myTechId || "", notes: wo.executionNotes || "" }];
      nextDb.workOrderLaborTransactions = [...(db.workOrderLaborTransactions || []), ...(wo.operations || []).filter((op) => Number(op.actualHours || 0) > 0 && !(db.workOrderLaborTransactions || []).some((x) => x.workOrderId === wo.id && x.operationId === op.id)).map((op) => ({ id: uid(), workOrderId: wo.id, operationId: op.id, technicianId: op.assigneeId || myTechId || "", hours: Number(op.actualHours || 0), rate: Number(db.technicians.find((t) => t.id === (op.assigneeId || myTechId))?.rate || 0), at: today(), source: "Submit Completion" }))];
      nextDb.workOrderMaterialUsage = [...(db.workOrderMaterialUsage || []), ...(wo.materials || []).filter((m) => Number(m.usedQty || 0) > 0 && !(db.workOrderMaterialUsage || []).some((x) => x.workOrderId === wo.id && x.materialLineId === m.id)).map((m) => ({ id: uid(), workOrderId: wo.id, materialLineId: m.id, itemId: m.itemId, usedQty: Number(m.usedQty || 0), unitCost: Number(m.unitCost || 0), at: today(), confirmedByRole: role, confirmedByTechId: myTechId || "" }))];
    }
    if (next === "مغلق") {
      nextDb.workOrderApprovals = [...(db.workOrderApprovals || []), { id: uid(), workOrderId: wo.id, number: wo.number, decision: "Approve", approvedAt: today(), approvedByRole: role, notes: extra.reviewNotes || "" }];
      nextDb.workOrderSupervisorReviews = [...(db.workOrderSupervisorReviews || []), { id: uid(), workOrderId: wo.id, number: wo.number, decision: "Approve", reviewedAt: today(), reviewedByRole: role, notes: extra.reviewNotes || "" }];
      const cost = woCost(patchedWo);
      nextDb.workOrderCosts = [...(db.workOrderCosts || []), { id: uid(), workOrderId: wo.id, number: wo.number, labor: cost.labor, material: cost.material, total: cost.total, at: today(), source: "Close Work Order" }];
      if (wo.programId) nextDb.programs = db.programs.map((p) => p.id === wo.programId ? { ...p, lastDone: today() } : p);
    }
    if (next === "مُعاد للتصحيح") {
      nextDb.workOrderSupervisorReviews = [...(db.workOrderSupervisorReviews || []), { id: uid(), workOrderId: wo.id, number: wo.number, decision: "Reject", reviewedAt: today(), reviewedByRole: role, notes: extra.reviewNotes || "" }];
    }
    save(nextDb);
    return true;
  };

  /* بوابات التحقق قبل طلب الإكمال (وثيقة التنفيذ §12) */
  const completionGaps = (wo) => {
    const gaps = [];
    if (!hasAssignedTechnician(wo)) gaps.push("لا يوجد فني مسند لأمر العمل");
    if ((wo.checklist || []).some((c) => !c.done)) gaps.push("قائمة فحص السلامة غير مكتملة");
    if ((wo.operations || []).some((o) => o.status !== "مكتملة")) gaps.push("توجد عمليات غير مكتملة");
    const hours = (wo.operations || []).reduce((s, o) => s + Number(o.actualHours || 0), 0);
    if (hours <= 0) gaps.push("لم تُسجّل ساعات عمل");
    if ((wo.materials || []).some((m) => Number(m.issuedQty || 0) > 0 && (m.usedQty === "" || m.usedQty == null))) gaps.push("أكّد كميات المواد المستخدمة");
    if (["تصحيحي", "طارئ"].includes(wo.type) && !wo.failure) gaps.push("سجّل بيانات العطل (إلزامي للتصحيحي/الطارئ)");
    if ((wo.routeAssets || []).some((x) => x.status === "معلق")) gaps.push("أكمل أو تخطَّ كل أصول المسار");
    const mandMeters = db.assetMeters.filter((m) => m.assetId === wo.assetId && !(m.endDate && m.endDate < today()) &&
      ((m.recordAtWO || db.meterTemplates.find((t) => t.id === m.templateId)?.recordAtWO) === "إلزامي"));
    if (mandMeters.some((m) => !db.readings.some((r) => r.workOrderId === wo.id && r.assetMeterId === m.id && !["معطلة", "ملغاة"].includes(r.status))))
      gaps.push("سجّل قراءات العدادات الإلزامية عند الإكمال");
    if (!String(wo.executionNotes || "").trim()) gaps.push("أضف ملاحظات الإكمال/النتيجة");
    if (wo.photoRequired) {
      const types = (wo.photos || []).map((p) => p.type);
      if (!types.includes("قبل")) gaps.push("صورة قبل العمل مطلوبة");
      if (!types.includes("بعد")) gaps.push("صورة بعد العمل مطلوبة");
    }
    return gaps;
  };

  /* تكلفة أمر العمل: عمالة + مواد مستخدمة فعليًا */
  const woCost = (wo) => {
    let labor = 0, material = 0;
    for (const op of wo.operations || []) {
      const tech = db.technicians.find((t) => t.id === op.assigneeId);
      labor += Number(op.actualHours || 0) * Number(tech?.rate || 0);
    }
    for (const m of wo.materials || []) material += Number(m.usedQty || 0) * Number(m.unitCost || 0);
    return { labor, material, total: labor + material };
  };

  /* ───── البرامج: على أصل واحد أو مجموعة ───── */
  const programAssets = (p) => (p.targetType === "مجموعة"
    ? (db.assetGroups.find((g) => g.id === p.assetGroupId)?.assetIds || []).map((id) => db.assets.find((a) => a.id === id)).filter(Boolean)
    : [db.assets.find((a) => a.id === p.assetId)].filter(Boolean))
    .filter((a) => assetUsable(a) && a.allowPrograms !== false);
  const programDue = (p) => {
    if (p.method === "فاصل عداد") {
      const am = db.assetMeters.find((m) => m.id === p.assetMeterId);
      if (!am) return { due: false, label: "عداد غير محدد" };
      const since = ltd(am) - Number(p.lastMeterValue || 0);
      const rem = Number(p.interval) - since;
      return { due: since >= Number(p.interval), soon: rem > 0 && rem <= Number(p.interval) * 0.1,
        label: since + " / " + p.interval + " " + nameOf("meterTemplates", am.templateId, "uom") + (rem > 0 ? " (متبقٍ " + rem + ")" : "") };
    }
    const base = p.lastDone || p.startDate || today();
    const nd = addDateDays(base, Number(p.interval || 0));
    return { due: daysUntil(nd) <= 0, soon: daysUntil(nd) > 0 && daysUntil(nd) <= 7, label: "الاستحقاق " + fmt(nd), nextDate: nd };
  };
  const generateWO = (p) => {
    const info = programDue(p);
    const targets = programAssets(p);
    targets.forEach((a) => {
      createWO({ title: "صيانة وقائية — " + p.name + (targets.length > 1 ? " (" + a.name + ")" : ""),
        assetId: a.id, type: "وقائي", priority: "عادية",
        plannedStart: today(), plannedEnd: info.nextDate || today(), workDefId: p.workDefId, programId: p.id, safetyRequired: true });
    });
    if (targets.length > 1) alert("أُنشئ " + targets.length + " أمر عمل — واحد لكل أصل في المجموعة");
    if (p.method === "فاصل عداد") {
      const am = db.assetMeters.find((m) => m.id === p.assetMeterId);
      update("programs", p.id, { lastMeterValue: am ? ltd(am) : 0 });
    } else update("programs", p.id, { lastDone: today() });
  };

  /* طلبات العمل */
  const actRequest = (req, action) => {
    if (action === "قبول") update("workRequests", req.id, { status: "مقبول" });
    if (action === "رفض") update("workRequests", req.id, { status: "مرفوض" });
    if (action === "تحويل لأمر عمل") {
      update("workRequests", req.id, { status: "محوّل" });
      createWO({ title: req.title, assetId: req.assetId, type: req.severity === "حرجة" ? "طارئ" : "تصحيحي",
        priority: req.severity === "حرجة" ? "طارئ" : "عالية", plannedStart: today(), plannedEnd: "", safetyRequired: true });
    }
  };

  /* نسخ احتياطي */
  const exportData = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "cmms-backup-" + today() + ".json"; a.click();
  };
  /* تصدير سجل الأصول CSV (وثيقة الأصول §Export_Assets) */
  const exportAssetsCSV = () => {
    const head = "رقم الأصل,الاسم,النوع,المجموعة,الموقع,الأصل الأب,حرج,نشط";
    const rows = db.assets.map((a) => [a.number, a.name, a.type,
      db.assetGroups.find((g) => (g.assetIds || []).includes(a.id))?.name || "",
      a.location, a.parentId ? nameOf("assets", a.parentId) : "", a.critical ? "نعم" : "لا", a.active === false ? "لا" : "نعم"
    ].map((x) => '"' + String(x || "").replace(/"/g, '""') + '"').join(","));
    const blob = new Blob(["\uFEFF" + [head, ...rows].join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "asset-register-" + today() + ".csv"; a.click();
  };
  const importData = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      try { save(normalizeDb(JSON.parse(reader.result))); alert("تم الاستيراد بنجاح"); }
      catch (e) { alert("ملف غير صالح"); }
    };
    reader.readAsText(file);
  };

  if (firebaseEnabled && !authReady) return <div style={{ minHeight: "100vh", background: C.paper, display: "grid", placeItems: "center" }}>جارٍ التحقق من تسجيل الدخول…</div>;
  if (firebaseEnabled && authReady && !firebaseUser) return <FirebaseAuthScreen services={firebaseServices} />;
  if (!loaded) return <div style={{ minHeight: "100vh", background: C.paper, display: "grid", placeItems: "center" }}>جارٍ التحميل…</div>;

  const openWOs = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const ctx = { db, add, update, remove, nameOf, lastReading, ltd, addReading, meterReadings, currentValue, setTab,
    can, role, woCost, completionGaps, setWOStatus, log, createWO, myTechId,
    activeWarranty, pmCheckAfterReading, programAssets, programDue, generateWO, exportAssetsCSV, woAssignedTechIds, hasAssignedTechnician, materialStatusOf,
    onHand, reservedQty, availableQty, addTx, woShortages,
    activeContracts, contractState, contractEffectiveEnd, contractCalcExpiration, dailyRate, generateEntitlements, save,
    meterRows, activeReadings, calcUtilRate, utilRate, disableReading,
    groupRule, groupActive, activeAssignments, canAssignAsset, assignAsset, unassignAsset, revalidateGroup, assetExclusion,
    assetUsable, nextAssetNumber, logAsset, assetSaveErrors, descendants, propagateLocation, copyAsset, splitAsset,
    createMediaFromFile, deleteMediaFromStorage, migrateLocalMediaToStorage,
    firebaseEnabled, firebaseServices, firebaseUser, firebaseProfile, setSyncStatus,
    productionMode, canUseDemoTools, canUseSetupTools, canUseDangerousTools,
    offlineQueue, offlineHistory, offlineStats: offlineQueueStats(offlineQueue), browserOnline, syncRunning, runOfflineSync, resolveOfflineConflict, clearOfflineDone, exportOfflineQueue, refreshOfflineState };

  const notificationList = buildNotifications(ctx);
  const offlineStatsNow = offlineQueueStats(offlineQueue);

  const MAIN_TABS = can.requestOnly
    ? [["home", "الرئيسية"], ["requests", "طلباتي"]]
    : role === "فني"
      ? [["home", "الرئيسية"], ["mywork", "أعمالي"], ["wo", "أوامر العمل"]]
      : role === "مخزن"
        ? [["home", "الرئيسية"], ["inventory", "المخزون"], ["invgov", "الطلبات"], ["wo", "أوامر العمل"]]
        : can.admin
          ? [["home", "الرئيسية"], ["wo", "أوامر العمل"], ["super", "الإشراف"], ["assets", "الأصول"], ["more", "المزيد"]]
          : [["home", "الرئيسية"], ["wo", "أوامر العمل"], ["super", "الإشراف"], ["schedule", "جدولة"], ["assets", "الأصول"]];
  const MORE = [
    ["firebase", "Firebase والصلاحيات"], ["sync", "المزامنة Offline"], ...(can.admin || can.review ? [["users", "المستخدمون والصلاحيات"]] : []),
    ["maintenance", "إدارة الصيانة"], ["schedule", "محرك الجدولة"], ["inventory", "المخزون وقطع الغيار"], ["invgov", "حوكمة المخزون والطلبات"], ["media", "الصور والمرفقات"], ["mywork", "قائمة الإرسال"], ["requests", "طلبات العمل"], ["programs", "البرامج الوقائية"], ["forecast", "توقعات الصيانة"],
    ["meters", "العدادات"], ["assets", "الأصول"], ["qrlabels", "ملصقات QR للأصول"], ["org", "منظمة الصيانة"], ["oracle", "مطابقة المتطلبات"], ["governance", "الحوكمة والرقابة"], ["governance100", "الحوكمة 100%"], ["techs", "الفنيون"],
    ["groups", "مجموعات الأصول"], ["lh", "الهرميات والمسارات"], ["warranty", "الضمانات"], ["stdops", "العمليات القياسية"], ["workdefs", "تعريفات العمل"],
    ["failures", "تحليل الأعطال"], ["reports", "التقارير"], ["data", "البيانات والنسخ"],
  ];
  const currentMeta = TAB_META[tab] || { label: "نظام الصيانة", icon: "•", desc: "", color: C.ink };
  const syncOk = (syncStatus.includes("الخادم") || syncStatus.includes("Firestore") || syncStatus.includes("Firebase")) && !syncStatus.includes("غير") && !syncStatus.includes("فشل") && !syncStatus.includes("رفض");
  const quickTabsBase = role === "فني"
    ? ["notifications", "mywork", "assets"]
    : role === "مخزن"
      ? ["notifications", "inventory", "invgov", "wo"]
      : can.admin
        ? ["notifications", "maintenance", "schedule", "qrlabels", "invgov", "super", "forecast", "governance100"]
        : can.review
          ? ["notifications", "schedule", "super", "wo", "assets"]
          : ["notifications", "requests", "home"];
  const quickTabs = (offlineStatsNow.pending || offlineStatsNow.conflict) ? ["sync", ...quickTabsBase.filter((x)=>x!=="sync")] : quickTabsBase;

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: `radial-gradient(circle at top right, rgba(249,115,22,.10), transparent 32%), ${C.paper}`, color: C.ink, fontFamily: "'Cairo', system-ui, sans-serif", paddingBottom: 104 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;800;900&display=swap');
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        button { cursor: pointer; font-family: inherit; touch-action: manipulation; }
        input, select, textarea { font-size: 16px; font-family: inherit; }
        body { margin: 0; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-thumb { background: ${C.line}; border-radius: 999px; }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
      `}</style>

      <header style={{ padding: "12px 14px 10px", borderBottom: `1px solid ${C.line}`, position: "sticky", top: 0, zIndex: 5, background: "rgba(246,247,251,.92)", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)", boxShadow: "0 10px 30px rgba(15,23,42,.06)" }}>
        <div style={{ maxWidth:760, margin:"0 auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap:12 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10, minWidth:0 }}>
              <div style={{ width:44, height:44, borderRadius:16, display:"grid", placeItems:"center", background:`linear-gradient(135deg, ${currentMeta.color}, ${C.ink})`, color:"#fff", fontWeight:900, fontSize:20, boxShadow:"0 8px 22px rgba(15,23,42,.18)" }}>{currentMeta.icon}</div>
              <div style={{ minWidth:0 }}>
                <div style={{ fontSize:12, color:C.steel, fontWeight:800, letterSpacing:.2 }}>Alhadi CMMS</div>
                <div style={{ fontSize:21, lineHeight:1.1, fontWeight:900, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{currentMeta.label}<span style={{ color: C.orange }}>.</span></div>
                <div style={{ fontSize:11.5, color:C.steel, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", maxWidth:220 }}>{currentMeta.desc}</div>
              </div>
            </div>
            {firebaseEnabled ? (
              <div style={{ textAlign: "left", minWidth:96 }}>
                <Badge text={role} color={role === "مدير" ? C.green : role === "مشرف" ? C.blue : role === "مخزن" ? C.purple : role === "فني" ? C.amber : C.steel} />
                <div style={{ fontSize: 10.5, color: C.steel, maxWidth: 145, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginTop:3 }}>{firebaseUser?.email || "Firebase"}</div>
                <button onClick={() => firebaseServices && signOutFirebase(firebaseServices)} style={{ border: "none", background: "transparent", color: C.red, fontSize: 11, fontWeight: 900, padding:0 }}>خروج</button>
              </div>
            ) : canUseSetupTools ? (
              <select value={role} onChange={(e) => setSetting("role", e.target.value)}
                title="أداة إعداد فقط — مخفية في الإنتاج"
                style={{ border: `1px solid ${C.line}`, borderRadius: 14, padding: "8px 10px", fontSize: 12.5, fontWeight: 800, background: "#fff", maxWidth:140 }}>
                {ROLES.map((r) => <option key={r}>{r}</option>)}
              </select>
            ) : (
              <div style={{ textAlign:"left", minWidth:112 }}>
                <Badge text="Production" color={C.green} />
                <div style={{ fontSize:10.5, color:C.steel, marginTop:3 }}>الأدوار من Firebase</div>
              </div>
            )}
          </div>

          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1.4fr", gap:8, marginTop:12 }}>
            <MiniMetric n={db.assets.length} label="أصل" color={C.green} />
            <MiniMetric n={openWOs.length} label="أمر مفتوح" color={openWOs.length ? C.blue : C.steel} />
            <div style={{ background:syncOk ? "#ECFDF5" : "#FFF7ED", color:syncOk ? C.green : C.amber, border:`1px solid ${syncOk ? "#BBF7D0" : "#FED7AA"}`, borderRadius:16, padding:"8px 10px", minWidth:0 }}>
              <div style={{ fontSize:10.5, fontWeight:900 }}>حالة المزامنة</div>
              <div style={{ fontSize:10.5, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{syncStatus}</div>
            </div>
          </div>

          <div style={{ display:"flex", gap:7, overflowX:"auto", paddingTop:10, paddingBottom:1 }}>
            {quickTabs.map((id) => {
              const meta = TAB_META[id] || { label:id, icon:"•", color:C.ink };
              const on = tab === id;
              const label = id === "notifications" && notificationList.length ? `${meta.label} (${notificationList.length})` : meta.label;
              return <button key={id} onClick={()=>setTab(id)} style={{ border:`1px solid ${on ? meta.color : C.line}`, background:on ? meta.color : "rgba(255,255,255,.8)", color:on ? "#fff" : C.ink, borderRadius:999, padding:"7px 11px", fontSize:12, fontWeight:900, display:"flex", alignItems:"center", gap:6, whiteSpace:"nowrap", boxShadow:on ? "0 7px 16px rgba(15,23,42,.12)" : "none" }}><span>{meta.icon}</span>{label}</button>;
            })}
          </div>

          {role === "فني" && !firebaseEnabled && !productionMode && (
            <select value={db.settings.myTechId} onChange={(e) => setSetting("myTechId", e.target.value)}
              style={{ marginTop: 8, width: "100%", border: `1px solid ${C.line}`, borderRadius: 14, padding: "9px 10px", fontSize: 13, background:"#fff" }}>
              <option value="">— اختر اسمك من قائمة الفنيين —</option>
              {db.technicians.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          )}
          {role === "فني" && firebaseEnabled && !myTechId && (
            <div style={{ marginTop: 8, fontSize: 12, color: C.amber, fontWeight: 800, background:"#FFF7ED", border:"1px solid #FED7AA", borderRadius:14, padding:"8px 10px" }}>يجب أن يربط المدير حسابك بفني من شاشة المستخدمين والصلاحيات.</div>
          )}
        </div>
      </header>

      <main style={{ padding: "14px 14px 18px", maxWidth: 760, margin: "0 auto" }}>
        {tab === "home" && <Home db={db} nameOf={nameOf} programDue={programDue} generateWO={generateWO} setTab={setTab} openWO={setWoDetail} can={can} ctx={ctx} />}
        {tab === "notifications" && <NotificationsCenter ctx={ctx} openWO={setWoDetail} openAsset={setAssetDetail} setTab={setTab} />}
        {tab === "sync" && <OfflineSyncCenter ctx={ctx} />}
        {tab === "wo" && <WorkOrders ctx={ctx} openWO={setWoDetail} />}
        {tab === "mywork" && <MyWork ctx={ctx} openWO={setWoDetail} />}
        {tab === "assets" && <Assets ctx={ctx} openAsset={setAssetDetail} />}
        {tab === "qrlabels" && can.admin && <AssetQrLabels ctx={ctx} openAsset={setAssetDetail} />}
        {tab === "inventory" && <Inventory ctx={ctx} openWO={setWoDetail} />}
        {tab === "invgov" && <InventoryGovernanceHub ctx={ctx} openWO={setWoDetail} />}
        {tab === "lh" && <LogicalHierarchies ctx={ctx} openAsset={setAssetDetail} />}
        {tab === "more" && can.admin && <MoreHub items={MORE} setTab={setTab} db={db} can={can} role={role} productionMode={productionMode} canUseDemoTools={canUseDemoTools} canUseDangerousTools={canUseDangerousTools} />}
        {tab === "firebase" && can.admin && <FirebaseSecurityPanel ctx={ctx} />}
        {tab === "users" && can.admin && <FirebaseUsersPanel ctx={ctx} />}
        {tab === "maintenance" && <MaintenanceManagementHub ctx={ctx} openWO={setWoDetail} setTab={setTab} />}
        {tab === "org" && can.admin && <Organization ctx={ctx} />}
        {tab === "oracle" && can.admin && <OracleCompliance ctx={ctx} setTab={setTab} />}
        {tab === "governance" && can.admin && <GovernanceHub ctx={ctx} />}
        {tab === "governance100" && can.admin && <Governance100Hub ctx={ctx} />}
        {tab === "techs" && <Crud ctx={ctx} entity="technicians" title="الفنيون" schema={[
          { k: "name", label: "اسم الفني" },
          { k: "specialty", label: "التخصص", type: "select", options: ["ميكانيكي", "كهربائي", "عام"] },
          { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
          { k: "rate", label: "أجر الساعة (ر.س)", type: "number" }, { k: "phone", label: "الجوال" },
        ]} render={(t) => [t.name, [t.specialty, nameOf("workCenters", t.workCenterId) !== "—" ? nameOf("workCenters", t.workCenterId) : "", t.rate ? money(t.rate) + "/ساعة" : ""].filter(Boolean).join(" · ")]} />}
        {tab === "groups" && <AssetGroups ctx={ctx} />}
        {tab === "meters" && <Meters ctx={ctx} />}
        {tab === "warranty" && <WarrantyHub ctx={ctx} openWO={setWoDetail} />}
        {tab === "stdops" && <StdOpsManager ctx={ctx} />}
        {tab === "workdefs" && <WorkDefs ctx={ctx} />}
        {tab === "requests" && <Requests ctx={ctx} actRequest={actRequest} />}
        {tab === "programs" && <Programs ctx={ctx} programDue={programDue} generateWO={generateWO} />}
        {tab === "forecast" && <Forecast ctx={ctx} programDue={programDue} generateWO={generateWO} />}
        {tab === "super" && <Supervision ctx={ctx} openWO={setWoDetail} />}
        {tab === "schedule" && can.review && <AdvancedSchedulingEngine ctx={ctx} openWO={setWoDetail} />}
        {tab === "failures" && <FailureAnalysis ctx={ctx} openWO={setWoDetail} />}
        {tab === "reports" && <Reports ctx={ctx} />}
        {tab === "data" && can.admin && <DataTab exportData={exportData} importData={importData} exportAssetsCSV={exportAssetsCSV} db={db} can={can} save={save} productionMode={productionMode} canUseSetupTools={canUseSetupTools} canUseDangerousTools={canUseDangerousTools} />}
        {tab === "media" && can.admin && <MediaStorageCenter ctx={ctx} />}
      </main>

      {woDetail && <WODetail ctx={ctx} woId={woDetail} onClose={() => setWoDetail(null)}
        openAsset={(id) => { setWoDetail(null); setAssetDetail(id); }} />}
      {assetDetail && <AssetDetail ctx={ctx} assetId={assetDetail} onClose={() => setAssetDetail(null)}
        openWO={(id) => { setAssetDetail(null); setWoDetail(id); }} />}

      <nav style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 6, background:"linear-gradient(180deg, rgba(246,247,251,0), rgba(246,247,251,.96) 25%)", padding:"8px 10px calc(8px + env(safe-area-inset-bottom))" }}>
        <div style={{ maxWidth:760, margin:"0 auto", display:"flex", gap:7, background:"rgba(255,255,255,.92)", border:`1px solid ${C.line}`, borderRadius:24, padding:7, boxShadow:"0 -12px 34px rgba(15,23,42,.14)", backdropFilter:"blur(14px)", WebkitBackdropFilter:"blur(14px)" }}>
          {MAIN_TABS.map(([id, label]) => {
            const on = tab === id || (id === "more" && !MAIN_TABS.some(([t]) => t === tab));
            const meta = TAB_META[id] || { icon:"•", color:C.ink };
            return <button key={id} onClick={() => setTab(id)} aria-label={label} style={{ flex: 1, minWidth:0, padding: "8px 4px", border: "none", borderRadius:18, fontWeight: 900, fontSize: 11.2, background: on ? `linear-gradient(135deg, ${meta.color}, ${C.ink})` : "transparent", color: on ? "#fff" : C.steel, display:"grid", gap:2, justifyItems:"center", transition:"all .18s ease" }}>
              <span style={{ fontSize:18, lineHeight:1 }}>{meta.icon}</span>
              <span style={{ whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis", maxWidth:"100%" }}>{label}</span>
            </button>;
          })}
        </div>
      </nav>
    </div>
  );
}


/* ───────────────────────── Firebase Auth / Governance Backend ───────────────────────── */
