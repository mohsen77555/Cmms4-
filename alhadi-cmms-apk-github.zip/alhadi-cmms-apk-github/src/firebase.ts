import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const env = (import.meta as any).env || {};

const runtimeConfig = (() => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return {} as any;
    const raw = window.localStorage.getItem("cmms-firebase-config");
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {} as any;
  }
})();

const pick = (envName: string, runtimeName: string) => env[envName] || runtimeConfig[runtimeName] || runtimeConfig[envName] || "";

export const FIREBASE_OWNER_EMAIL = env.VITE_FIREBASE_OWNER_EMAIL || runtimeConfig.ownerEmail || runtimeConfig.VITE_FIREBASE_OWNER_EMAIL || "mohsenalhadi77555@gmail.com";

const firebaseConfig = {
  apiKey: pick("VITE_FIREBASE_API_KEY", "apiKey"),
  authDomain: pick("VITE_FIREBASE_AUTH_DOMAIN", "authDomain"),
  projectId: pick("VITE_FIREBASE_PROJECT_ID", "projectId"),
  storageBucket: pick("VITE_FIREBASE_STORAGE_BUCKET", "storageBucket"),
  messagingSenderId: pick("VITE_FIREBASE_MESSAGING_SENDER_ID", "messagingSenderId"),
  appId: pick("VITE_FIREBASE_APP_ID", "appId"),
};

export const firebaseMissingKeys = Object.entries(firebaseConfig)
  .filter(([, value]) => !value)
  .map(([key]) => {
    const envName: Record<string, string> = {
      apiKey: "apiKey / VITE_FIREBASE_API_KEY",
      authDomain: "authDomain / VITE_FIREBASE_AUTH_DOMAIN",
      projectId: "projectId / VITE_FIREBASE_PROJECT_ID",
      storageBucket: "storageBucket / VITE_FIREBASE_STORAGE_BUCKET",
      messagingSenderId: "messagingSenderId / VITE_FIREBASE_MESSAGING_SENDER_ID",
      appId: "appId / VITE_FIREBASE_APP_ID",
    };
    return envName[key] || key;
  });

export const firebaseReady = firebaseMissingKeys.length === 0;

const app = firebaseReady ? initializeApp(firebaseConfig) : null;

export const auth = app ? getAuth(app) : (null as any);
export const firestore = app ? getFirestore(app) : (null as any);
export const storage = app ? getStorage(app) : (null as any);
