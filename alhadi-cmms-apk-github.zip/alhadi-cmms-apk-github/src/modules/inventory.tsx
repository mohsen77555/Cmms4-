import { useMemo, useState } from "react";
import { ACTIVE_STATES, C, ITEM_CATS, WO_COLORS, daysUntil, money, now, today, uid } from "../core/appCore";
import { Btn, Chip, Empty, Row, Section, Sheet, Stat, card } from "../components/ui";
import { Crud, FormSheet } from "./crud";

export const INV_REQUEST_TYPES = ["طلب صرف", "طلب إرجاع", "طلب تحويل", "طلب تسوية", "طلب إتلاف", "طلب شراء"];
export const INV_REQUEST_STATUS_COLORS = { "مفتوح": C.amber, "بانتظار اعتماد": C.amber, "معتمد": C.green, "منفذ": C.ink, "مرفوض": C.red, "ملغي": C.steel };
export function InventoryGovernanceHub({ ctx, openWO, embedded=false }) {
  const { db, save, nameOf, can, role, onHand, availableQty, canUseSetupTools } = ctx;
  const [sub, setSub] = useState("الطلبات");
  const [reqForm, setReqForm] = useState(false);
  const [countForm, setCountForm] = useState(false);
  const requests = db.inventoryRequests || [];
  const approvals = db.inventoryApprovals || [];
  const policies = db.inventoryGovernancePolicies || [];
  const audit = db.inventoryAuditTrail || [];
  const issues = db.inventoryReconciliationIssues || [];
  const openRequests = requests.filter((r)=>["مفتوح","بانتظار اعتماد"].includes(r.status));
  const approvedNotDone = requests.filter((r)=>r.status === "معتمد");
  const canApprove = can.admin || can.review || can.warehouse;
  const canExecute = can.admin || can.warehouse;
  const canCreate = can.admin || can.warehouse || can.execute || role === "فني";
  const invAudit = (action, entity, entityId, note) => ({ id:uid(), at:now(), action, entity, entityId, note:note || "", byRole:role });
  const nextNumber = () => "IR-" + String(1000 + requests.length + 1);
  const savePatch = (patch) => save({ ...db, ...patch });

  const seedPolicies = () => {
    const defaults = [
      ["INV-001", "لا صرف مخزون بدون طلب معتمد أو أمر عمل", "طلب صرف", "عال"],
      ["INV-002", "لا تسوية مخزون بدون سبب واعتماد مشرف/مدير", "تسوية", "حرج"],
      ["INV-003", "لا إتلاف بدون مبرر وصورة أو ملاحظة", "إتلاف", "عال"],
      ["INV-004", "لا تحويل بين مستودعات بدون مستودع مصدر ووجهة", "تحويل", "متوسط"],
      ["INV-005", "لا إرجاع مواد بدون ربط بأمر عمل عند الإمكان", "إرجاع", "متوسط"],
      ["INV-006", "كل صنف تحت الحد الأدنى يجب أن يكون له طلب شراء أو إعادة طلب", "إعادة طلب", "عال"],
      ["INV-007", "أي فرق جرد يجب أن ينتج طلب تسوية وفروقات", "جرد", "حرج"],
      ["INV-008", "فصل مهام: مقدم الطلب لا يعتمد نفس الطلب إلا المدير", "SoD", "حرج"]
    ];
    const existing = new Set(policies.map((p)=>p.code));
    const addRows = defaults.filter(([code])=>!existing.has(code)).map(([code,name,process,severity])=>({ id:uid(), code, name, process, severity, ownerRole: process === "إعادة طلب" ? "مخزن" : "مشرف", requiresApproval:true, active:true, evidence:"طلب + اعتماد + سجل حركة + تدقيق" }));
    if (!addRows.length) return alert("سياسات حوكمة المخزون موجودة بالفعل");
    savePatch({ inventoryGovernancePolicies:[...policies, ...addRows], inventoryAuditTrail:[...audit, invAudit("Seed inventory policies", "inventoryGovernancePolicies", "bulk", addRows.length + " سياسة")] });
  };

  const createRequest = (d) => {
    if (!d.type) return alert("اختر نوع الطلب");
    if (!d.itemId) return alert("اختر الصنف");
    if (!Number(d.qty)) return alert("أدخل كمية صحيحة");
    if (d.type === "طلب صرف" && !d.workOrderId) return alert("طلب الصرف يجب أن يرتبط بأمر عمل");
    if (d.type === "طلب تحويل" && (!d.warehouseId || !d.toWarehouseId)) return alert("طلب التحويل يحتاج مستودع مصدر ووجهة");
    if (["طلب تسوية", "طلب إتلاف"].includes(d.type) && !String(d.justification || "").trim()) return alert("هذا النوع يحتاج مبررًا واضحًا");
    const req = { id:uid(), number:nextNumber(), status:"بانتظار اعتماد", requestedAt:today(), requestedByRole:role, requestedByEmail:db._meta?.actorEmail || "", priority:d.priority || "متوسطة", ...d, qty:Number(d.qty || 0) };
    savePatch({ inventoryRequests:[...requests, req], inventoryAuditTrail:[...audit, invAudit("Create inventory request", "inventoryRequests", req.id, req.type + " · " + nameOf("items", req.itemId))] });
    setReqForm(false);
  };

  const approveRequest = (r) => {
    if (!canApprove) return alert("لا تملك صلاحية الاعتماد");
    if (!can.admin && r.requestedByRole && r.requestedByRole === role) return alert("فصل المهام: لا يمكن لمقدم الطلب اعتماد طلبه بنفسه");
    const approval = { id:uid(), requestId:r.id, decision:"معتمد", decidedAt:today(), decidedByRole:role, note:"اعتماد حوكمة مخزون" };
    savePatch({
      inventoryRequests: requests.map((x)=>x.id===r.id ? { ...x, status:"معتمد", approvedAt:today(), approvedByRole:role } : x),
      inventoryApprovals:[...approvals, approval],
      inventoryAuditTrail:[...audit, invAudit("Approve inventory request", "inventoryRequests", r.id, r.number)]
    });
  };

  const rejectRequest = (r) => {
    if (!canApprove) return alert("لا تملك صلاحية الرفض");
    const reason = prompt("سبب الرفض؟") || "رفض من الاعتماد";
    savePatch({
      inventoryRequests: requests.map((x)=>x.id===r.id ? { ...x, status:"مرفوض", rejectedAt:today(), rejectedByRole:role, rejectionReason:reason } : x),
      inventoryApprovals:[...approvals, { id:uid(), requestId:r.id, decision:"مرفوض", decidedAt:today(), decidedByRole:role, note:reason }],
      inventoryAuditTrail:[...audit, invAudit("Reject inventory request", "inventoryRequests", r.id, reason)]
    });
  };

  const executeRequest = (r) => {
    if (!canExecute) return alert("التنفيذ للمخزن أو المدير فقط");
    if (r.status !== "معتمد") return alert("يجب اعتماد الطلب قبل التنفيذ");
    const qty = Number(r.qty || 0);
    if (["طلب صرف", "طلب إتلاف", "طلب تحويل"].includes(r.type) && qty > Number(onHand(r.itemId, r.warehouseId) || 0)) return alert("الكمية أكبر من الرصيد في المستودع المحدد");
    const txBase = { id:uid(), at:today(), itemId:r.itemId, qty, warehouseId:r.warehouseId || "", toWarehouseId:r.toWarehouseId || "", workOrderId:r.workOrderId || "", approvedRequestId:r.id, note:"من طلب مخزون معتمد " + r.number };
    let tx = null;
    if (r.type === "طلب صرف") tx = { ...txBase, type:"صرف لأمر عمل" };
    if (r.type === "طلب إرجاع") tx = { ...txBase, type:"إرجاع من أمر عمل" };
    if (r.type === "طلب تحويل") tx = { ...txBase, type:"تحويل" };
    if (r.type === "طلب تسوية") tx = { ...txBase, type:"تسوية" };
    if (r.type === "طلب إتلاف") tx = { ...txBase, type:"إتلاف" };
    const nextTx = tx ? [...(db.stockTx || []), tx] : (db.stockTx || []);
    savePatch({
      stockTx: nextTx,
      inventoryRequests: requests.map((x)=>x.id===r.id ? { ...x, status:"منفذ", executedAt:today(), executedByRole:role, transactionId:tx?.id || "" } : x),
      inventoryAuditTrail:[...audit, invAudit("Execute inventory request", "inventoryRequests", r.id, tx ? tx.type : "اعتمد للشراء")]
    });
  };

  const createCycleCount = (d) => {
    if (!d.itemId) return alert("اختر الصنف");
    const counted = Number(d.countedQty);
    if (!Number.isFinite(counted)) return alert("أدخل رصيد العد الصحيح");
    const systemQty = Number(onHand(d.itemId, d.warehouseId) || 0);
    const variance = counted - systemQty;
    const count = { id:uid(), number:"CC-" + String(1000 + (db.inventoryCycleCounts || []).length + 1), status: variance === 0 ? "مغلق" : "فرق يحتاج اعتماد", countDate:today(), itemId:d.itemId, warehouseId:d.warehouseId || "", countedQty:counted, systemQty, variance, ownerRole:role, note:d.note || "" };
    const line = { id:uid(), countId:count.id, itemId:d.itemId, warehouseId:d.warehouseId || "", countedQty:counted, systemQty, variance };
    const issue = variance !== 0 ? { id:uid(), countId:count.id, itemId:d.itemId, warehouseId:d.warehouseId || "", variance, severity: Math.abs(variance) > 5 ? "عال" : "متوسط", status:"بانتظار تسوية", detectedAt:today(), note:"فرق جرد " + variance } : null;
    const req = variance !== 0 ? { id:uid(), number:nextNumber(), type:"طلب تسوية", status:"بانتظار اعتماد", requestedAt:today(), requestedByRole:role, itemId:d.itemId, warehouseId:d.warehouseId || "", qty:variance, priority:Math.abs(variance) > 5 ? "عالية" : "متوسطة", justification:"تسوية فرق جرد " + count.number, cycleCountId:count.id } : null;
    savePatch({
      inventoryCycleCounts:[...(db.inventoryCycleCounts || []), count],
      inventoryCycleCountLines:[...(db.inventoryCycleCountLines || []), line],
      inventoryReconciliationIssues: issue ? [...issues, issue] : issues,
      inventoryRequests: req ? [...requests, req] : requests,
      inventoryAuditTrail:[...audit, invAudit("Cycle count", "inventoryCycleCounts", count.id, variance === 0 ? "لا فرق" : "فرق " + variance)]
    });
    setCountForm(false);
  };

  const auditIssues = [];
  (db.stockTx || []).forEach((t)=>{
    if (["صرف لأمر عمل","إرجاع من أمر عمل","تحويل","تسوية","إتلاف"].includes(t.type) && !t.approvedRequestId) auditIssues.push({ id:"tx-"+t.id, severity:"عال", text:"حركة " + t.type + " بدون طلب مخزون معتمد: " + nameOf("items", t.itemId) });
    if (t.type === "صرف لأمر عمل" && !t.workOrderId) auditIssues.push({ id:"wo-"+t.id, severity:"متوسط", text:"صرف بدون ربط بأمر عمل" });
    if (t.type === "تحويل" && !t.toWarehouseId) auditIssues.push({ id:"tr-"+t.id, severity:"متوسط", text:"تحويل بدون مستودع وجهة" });
  });
  (db.items || []).forEach((i)=>{
    if (Number(onHand(i.id) || 0) < 0) auditIssues.push({ id:"neg-"+i.id, severity:"حرج", text:"رصيد سالب للصنف " + (i.code || i.name) });
    const min = Number(i.min ?? i.minQty ?? 0);
    if (min && Number(availableQty(i.id) || 0) <= min && !requests.some((r)=>r.itemId===i.id && r.type==="طلب شراء" && ["مفتوح","بانتظار اعتماد","معتمد"].includes(r.status))) auditIssues.push({ id:"low-"+i.id, severity:"متوسط", text:"صنف تحت الحد الأدنى بدون طلب شراء: " + (i.code || i.name) });
  });
  openRequests.filter((r)=>daysUntil(String(r.requestedAt || today()).slice(0,10)) < -2).forEach((r)=>auditIssues.push({ id:"late-"+r.id, severity:"متوسط", text:"طلب مخزون مفتوح أكثر من يومين: " + r.number }));

  const createCapaFromAudit = () => {
    if (!auditIssues.length) return alert("لا توجد مخالفات تدقيق");
    const rows = auditIssues.slice(0, 10).map((x)=>({ id:uid(), number:"CAPA-INV-"+uid().toUpperCase(), title:"تصحيح حوكمة مخزون", area:"Inventory Control", priority:x.severity === "حرج" ? "عالية" : "متوسطة", status:"مفتوح", requestedBy:role, dueDate:today(), description:x.text }));
    savePatch({ governanceCapaActions:[...(db.governanceCapaActions || []), ...rows], inventoryAuditTrail:[...audit, invAudit("Create CAPA from inventory audit", "governanceCapaActions", "bulk", rows.length + " CAPA")] });
  };

  const requestCard = (r) => <div key={r.id} style={{ ...card(), borderRightColor:INV_REQUEST_STATUS_COLORS[r.status] || C.steel }}>
    <Row main={(r.number || "طلب") + " — " + (r.type || "")} sub={[nameOf("items", r.itemId), r.qty ? "كمية " + r.qty : "", r.workOrderId ? (db.workOrders.find((w)=>w.id===r.workOrderId)?.number || "أمر عمل") : "", r.justification].filter(Boolean).join(" · ")} badge={{ text:r.status || "مفتوح", color:INV_REQUEST_STATUS_COLORS[r.status] || C.steel }} />
    <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginTop:8 }}>
      {r.workOrderId && <Btn bg={C.blue} onClick={()=>openWO && openWO(r.workOrderId)}>فتح أمر العمل</Btn>}
      {canApprove && ["مفتوح","بانتظار اعتماد"].includes(r.status) && <Btn bg={C.green} onClick={()=>approveRequest(r)}>اعتماد</Btn>}
      {canApprove && ["مفتوح","بانتظار اعتماد"].includes(r.status) && <Btn bg={C.red} onClick={()=>rejectRequest(r)}>رفض</Btn>}
      {canExecute && r.status === "معتمد" && <Btn bg={C.ink} onClick={()=>executeRequest(r)}>تنفيذ الحركة</Btn>}
    </div>
  </div>;

  return <>
    {!embedded && <Section title="حوكمة المخزون والطلبات"><div style={{ display:"flex", gap:8 }}><Stat n={openRequests.length} label="بانتظار" color={openRequests.length?C.amber:C.steel}/><Stat n={approvedNotDone.length} label="معتمد غير منفذ" color={approvedNotDone.length?C.blue:C.steel}/><Stat n={auditIssues.length} label="ملاحظات تدقيق" color={auditIssues.length?C.red:C.green}/><Stat n={policies.length} label="سياسات" color={C.ink}/></div></Section>}
    <div style={{ display:"flex", gap:6, overflowX:"auto", marginBottom:12 }}>{["الطلبات","الاعتمادات","السياسات","الجرد","الفروقات","التدقيق"].map((x)=><Chip key={x} active={sub===x} onClick={()=>setSub(x)}>{x}</Chip>)}</div>

    {sub === "الطلبات" && <>
      {canCreate && <Btn bg={C.amber} onClick={()=>setReqForm(true)} style={{ marginBottom:10 }}>+ طلب مخزون</Btn>}
      {requests.length === 0 && <Empty text="لا توجد طلبات مخزون بعد. أنشئ طلب صرف/إرجاع/تحويل/تسوية/إتلاف/شراء." />}
      {requests.slice().reverse().slice(0,60).map(requestCard)}
    </>}

    {sub === "الاعتمادات" && <>
      {openRequests.length === 0 && approvedNotDone.length === 0 && <Empty text="لا توجد طلبات بانتظار اعتماد أو تنفيذ." />}
      {[...openRequests, ...approvedNotDone].map(requestCard)}
      <Section title="سجل قرارات الاعتماد">{approvals.slice().reverse().slice(0,30).map((a)=><div key={a.id} style={card()}><Row main={(a.decision || "قرار") + " — " + (requests.find((r)=>r.id===a.requestId)?.number || a.requestId)} sub={[a.decidedAt, a.decidedByRole, a.note].filter(Boolean).join(" · ")} /></div>)}{!approvals.length && <Empty text="لا قرارات اعتماد بعد." />}</Section>
    </>}

    {sub === "السياسات" && <>
      {canUseSetupTools && <Btn bg={C.ink} onClick={seedPolicies} style={{ marginBottom:10 }}>إنشاء/تحديث سياسات المخزون</Btn>}
      {policies.length === 0 && <Empty text="لم تُنشأ سياسات حوكمة المخزون بعد." />}
      {policies.map((p)=><div key={p.id} style={{ ...card(), borderRightColor:p.severity === "حرج" ? C.red : p.severity === "عال" ? C.amber : C.blue }}><Row main={p.code + " — " + p.name} sub={[p.process, "مالك: " + p.ownerRole, p.requiresApproval ? "يتطلب اعتماد" : "بدون اعتماد", p.evidence].filter(Boolean).join(" · ")} badge={{ text:p.active ? p.severity : "معطلة", color:p.active ? (p.severity === "حرج" ? C.red : C.amber) : C.steel }} /></div>)}
    </>}

    {sub === "الجرد" && <>
      {(can.admin || can.warehouse) && <Btn bg={C.purple} onClick={()=>setCountForm(true)} style={{ marginBottom:10 }}>+ جرد/عد صنف</Btn>}
      {(db.inventoryCycleCounts || []).slice().reverse().map((c)=><div key={c.id} style={{ ...card(), borderRightColor:Number(c.variance||0)===0?C.green:C.amber }}><Row main={(c.number || "جرد") + " — " + nameOf("items", c.itemId)} sub={["النظام " + c.systemQty, "العد " + c.countedQty, "الفرق " + c.variance, c.countDate].join(" · ")} badge={{ text:c.status, color:Number(c.variance||0)===0?C.green:C.amber }} /></div>)}
      {!(db.inventoryCycleCounts || []).length && <Empty text="لا توجد عمليات جرد مسجلة." />}
    </>}

    {sub === "الفروقات" && <>
      {issues.length === 0 && <Empty text="لا توجد فروقات جرد مفتوحة." />}
      {issues.slice().reverse().map((x)=><div key={x.id} style={{ ...card(), borderRightColor:x.severity === "عال" || x.severity === "حرج" ? C.red : C.amber }}><Row main={nameOf("items", x.itemId) + " — فرق " + x.variance} sub={[x.status, x.detectedAt, x.note].filter(Boolean).join(" · ")} badge={{ text:x.severity, color:x.severity === "عال" || x.severity === "حرج" ? C.red : C.amber }} /></div>)}
    </>}

    {sub === "التدقيق" && <>
      <div style={{ display:"flex", gap:8, marginBottom:10 }}><Stat n={auditIssues.filter((x)=>x.severity==="حرج").length} label="حرج" color={C.red}/><Stat n={auditIssues.length} label="إجمالي" color={auditIssues.length?C.amber:C.green}/><Stat n={audit.length} label="أحداث" color={C.blue}/></div>
      {auditIssues.length === 0 ? <Empty text="لا توجد مخالفات حوكمة مخزون حالية." /> : auditIssues.map((x)=><div key={x.id} style={{ ...card(), borderRightColor:x.severity === "حرج" ? C.red : C.amber }}><Row main={x.text} sub={x.severity} badge={{ text:x.severity, color:x.severity === "حرج" ? C.red : C.amber }} /></div>)}
      {(can.admin || can.review) && <Btn bg={C.red} onClick={createCapaFromAudit} style={{ width:"100%", margin:"8px 0" }}>إنشاء CAPA من مخالفات التدقيق</Btn>}
      <Section title="سجل تدقيق المخزون">{audit.slice().reverse().slice(0,40).map((a)=><div key={a.id} style={card()}><Row main={a.action} sub={[a.at, a.byRole, a.entity, a.note].filter(Boolean).join(" · ")} /></div>)}{!audit.length && <Empty text="لا أحداث تدقيق بعد." />}</Section>
    </>}

    {reqForm && <FormSheet title="طلب مخزون" onClose={()=>setReqForm(false)} db={db} initial={{ type:"طلب صرف", qty:1, priority:"متوسطة" }} schema={[
      { k:"type", label:"نوع الطلب", type:"select", options:INV_REQUEST_TYPES },
      { k:"itemId", label:"الصنف", type:"select", from:"items", fromLabel:(i)=>i.code + " — " + i.name },
      { k:"qty", label:"الكمية", type:"number" },
      { k:"warehouseId", label:"المستودع", type:"select", from:"warehouses", fromKey:"name" },
      { k:"toWarehouseId", label:"إلى مستودع (للتحويل)", type:"select", from:"warehouses", fromKey:"name" },
      { k:"workOrderId", label:"أمر العمل", type:"select", from:"workOrders", fromLabel:(w)=>w.number + " — " + w.title },
      { k:"priority", label:"الأولوية", type:"select", options:["منخفضة","متوسطة","عالية","حرجة"] },
      { k:"justification", label:"المبرر", type:"textarea" },
    ]} onSave={createRequest} />}

    {countForm && <FormSheet title="جرد/عد صنف" onClose={()=>setCountForm(false)} db={db} initial={{ countedQty:0 }} schema={[
      { k:"itemId", label:"الصنف", type:"select", from:"items", fromLabel:(i)=>i.code + " — " + i.name },
      { k:"warehouseId", label:"المستودع", type:"select", from:"warehouses", fromKey:"name" },
      { k:"countedQty", label:"الكمية المعدودة", type:"number" },
      { k:"note", label:"ملاحظة", type:"textarea" },
    ]} onSave={createCycleCount} />}
  </>;
}

/* ───────────────────────── المخزون وقطع الغيار (وثيقة المخزون) ───────────────────────── */
export function Inventory({ ctx, openWO }) {
  const { db, add, update, remove, nameOf, can, onHand, reservedQty, availableQty, addTx } = ctx;
  const [sub, setSub] = useState("الرصيد");
  const [txForm, setTxForm] = useState(null); // نوع الحركة
  const [stockCard, setStockCard] = useState(null);
  const SUBS = ["الرصيد", "الأصناف", "المستودعات", "الحركات", "التجهيز والصرف", "حوكمة وطلبات", "تنبيهات", "تقارير"];
  const canStock = can.warehouse; /* لا تعديل مخزون مباشر من الفني */

  /* قوائم التجهيز: أوامر مفتوحة فيها مواد محجوزة لم تُصرف */
  const pickWOs = useMemo(() => db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status) &&
    (w.materials || []).some((m) => m.itemId && m.reserved && !Number(m.issuedQty || 0))), [db.workOrders]);
  const lowStock = useMemo(() => db.items.filter((i) => i.min !== "" && i.min != null && onHand(i.id) <= Number(i.min)), [db]);
  const valuation = useMemo(() => db.items.reduce((s, i) => s + onHand(i.id) * Number(i.unitCost || 0), 0), [db]);

  /* استهلاك المواد حسب الأصل */
  const consumption = useMemo(() => {
    const consumptionByAsset = {};
    db.workOrders.forEach((w) => (w.materials || []).forEach((m) => {
      const c = Number(m.usedQty || 0) * Number(m.unitCost || 0);
      if (c > 0) consumptionByAsset[w.assetId] = (consumptionByAsset[w.assetId] || 0) + c;
    }));
    return Object.entries(consumptionByAsset).map(([id, c]) => ({ name: nameOf("assets", id), c })).sort((a, b) => b.c - a.c).slice(0, 8);
  }, [db]);

  return (
    <>
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {SUBS.map((s) => <Chip key={s} active={sub === s} onClick={() => setSub(s)}>{s}</Chip>)}
      </div>

      {sub === "الأصناف" && (
        <Crud ctx={ctx} entity="items" title="ماستر الأصناف" schema={[
          { k: "code", label: "كود الصنف (BRG-6312…)" }, { k: "name", label: "اسم الصنف" },
          { k: "category", label: "الفئة", type: "select", options: ITEM_CATS },
          { k: "uom", label: "وحدة القياس (قطعة، لتر…)" },
          { k: "unitCost", label: "تكلفة الوحدة (ر.س)", type: "number" },
          { k: "min", label: "الحد الأدنى", type: "number" }, { k: "max", label: "الحد الأقصى", type: "number" },
          { k: "critical", label: "قطعة حرجة", type: "check" },
        ]} render={(i) => [i.code + " — " + i.name,
          [i.category, "رصيد " + onHand(i.id) + " " + (i.uom || ""), money(i.unitCost) + "/وحدة", i.critical ? "⚠ حرجة" : ""].filter(Boolean).join(" · ")]} />
      )}

      {sub === "المستودعات" && (
        <Crud ctx={ctx} entity="warehouses" title="المستودعات والمخازن الفرعية" schema={[
          { k: "name", label: "اسم المستودع/المخزن" }, { k: "code", label: "الرمز" },
          { k: "location", label: "الموقع" },
        ]} render={(w) => [w.name, [w.code, w.location].filter(Boolean).join(" · ")]} />
      )}

      {sub === "الرصيد" && (<>
        {canStock && (
          <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
            <Btn bg={C.green} onClick={() => setTxForm("استلام")}>+ استلام</Btn>
            <Btn bg={C.blue} onClick={() => setTxForm("تحويل")}>تحويل</Btn>
            <Btn bg={C.amber} onClick={() => setTxForm("تسوية")}>تسوية</Btn>
            <Btn bg={C.red} onClick={() => setTxForm("إتلاف")}>إتلاف</Btn>
          </div>
        )}
        {db.items.length === 0 && <Empty text="أضف الأصناف أولًا من تبويب «الأصناف» ثم سجّل استلامًا." />}
        {db.items.map((i) => {
          const oh = onHand(i.id), rs = reservedQty(i.id), av = oh - rs;
          const low = i.min !== "" && i.min != null && oh <= Number(i.min);
          return (
            <div key={i.id} style={{ ...card(), borderRightColor: low ? C.red : C.ink }} onClick={() => setStockCard(i)}>
              <Row main={i.code + " — " + i.name}
                sub={"الرصيد: " + oh + " · محجوز: " + rs + " · المتاح: " + av + " " + (i.uom || "") + (low ? " · ⚠ تحت الحد الأدنى (" + i.min + ")" : "")}
                badge={i.critical ? { text: "حرجة", color: C.red } : undefined} />
            </div>
          );
        })}
      </>)}

      {sub === "الحركات" && (<>
        {db.stockTx.length === 0 && <Empty text="لا حركات بعد — الرصيد لا يتغير إلا بحركة (قاعدة النظام)." />}
        {db.stockTx.slice().reverse().slice(0, 50).map((t) => (
          <div key={t.id} style={{ ...card(), borderRightColor: ["صرف لأمر عمل", "إتلاف"].includes(t.type) ? C.red : t.type === "استلام" || t.type === "إرجاع من أمر عمل" ? C.green : C.amber }}>
            <Row main={t.type + " — " + nameOf("items", t.itemId)}
              sub={["كمية " + t.qty, t.at, t.workOrderId ? db.workOrders.find((w) => w.id === t.workOrderId)?.number : "",
                t.warehouseId ? nameOf("warehouses", t.warehouseId) : "", t.note].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {sub === "التجهيز والصرف" && (<>
        {pickWOs.length === 0 && <Empty text="لا مواد محجوزة بانتظار التجهيز. تُحجز المواد من داخل أمر العمل." />}
        {pickWOs.map((w) => (
          <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
            <Row main={"قائمة تجهيز — " + w.number} badge={{ text: w.status, color: WO_COLORS[w.status] }}
              sub={(w.materials || []).filter((m) => m.reserved && !Number(m.issuedQty || 0))
                .map((m) => nameOf("items", m.itemId) + " ×" + m.qty).join("، ")} />
          </div>
        ))}
      </>)}

      {sub === "حوكمة وطلبات" && <InventoryGovernanceHub ctx={ctx} openWO={openWO} embedded />}

      {sub === "تنبيهات" && (<>
        {lowStock.length === 0 && <Empty text="لا أصناف تحت الحد الأدنى. 👌" />}
        {lowStock.map((i) => (
          <div key={i.id} style={{ ...card(), borderRightColor: C.red }}>
            <Row main={i.code + " — " + i.name}
              sub={"الرصيد " + onHand(i.id) + " ≤ الحد الأدنى " + i.min + " — أنشئ طلب شراء"}
              badge={i.critical ? { text: "حرجة ⚠", color: C.red } : { text: "إعادة طلب", color: C.amber }} />
          </div>
        ))}
      </>)}

      {sub === "تقارير" && (<>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          <Stat n={money(valuation)} label="قيمة المخزون" color={C.blue} small />
          <Stat n={db.items.length} label="أصناف" color={C.ink} />
          <Stat n={lowStock.length} label="تحت الحد" color={lowStock.length ? C.red : C.steel} />
        </div>
        <Section title="استهلاك المواد حسب الأصل (ر.س)">
          {consumption.length === 0 && <Empty text="سيظهر عند صرف واستخدام مواد على أوامر العمل." />}
          <div style={card()}>
            {consumption.map((x) => (
              <div key={x.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}>
                <span>{x.name}</span><b>{money(x.c)}</b>
              </div>
            ))}
          </div>
        </Section>
      </>)}

      {txForm && (
        <FormSheet title={"حركة مخزون — " + txForm} onClose={() => setTxForm(null)} db={db}
          schema={[
            { k: "itemId", label: "الصنف", type: "select", from: "items", fromLabel: (i) => i.code + " — " + i.name },
            { k: "qty", label: txForm === "تسوية" ? "الكمية (+/−)" : "الكمية", type: "number" },
            ...(db.warehouses.length ? [{ k: "warehouseId", label: txForm === "تحويل" ? "من مستودع" : "المستودع", type: "select", from: "warehouses", fromKey: "name" }] : []),
            ...(txForm === "تحويل" ? [{ k: "toWarehouseId", label: "إلى مستودع", type: "select", from: "warehouses", fromKey: "name" }] : []),
            { k: "note", label: "ملاحظة" },
          ]} initial={{ qty: 1 }}
          onSave={(d) => {
            if (!d.itemId) { alert("اختر الصنف"); return; }
            if (["صرف لأمر عمل", "إتلاف"].includes(txForm) && Number(d.qty) > onHand(d.itemId)) { alert("الكمية أكبر من الرصيد"); return; }
            if (txForm === "إتلاف" && Number(d.qty) > onHand(d.itemId)) { alert("الكمية أكبر من الرصيد"); return; }
            addTx({ type: txForm, ...d }); setTxForm(null);
          }} />
      )}
      {stockCard && (
        <Sheet title={"بطاقة صنف — " + stockCard.code} onClose={() => setStockCard(null)}>
          <div style={{ ...card(), fontSize: 14, lineHeight: 2 }}>
            <b>{stockCard.name}</b> · {stockCard.category || "—"}<br />
            الرصيد: <b>{onHand(stockCard.id)}</b> · محجوز: <b>{reservedQty(stockCard.id)}</b> · المتاح: <b>{availableQty(stockCard.id)}</b> {stockCard.uom || ""}<br />
            تكلفة الوحدة: {money(stockCard.unitCost)} · قيمة الرصيد: <b>{money(onHand(stockCard.id) * Number(stockCard.unitCost || 0))}</b>
          </div>
          <Section title="يُستخدم في الأصول">
            {db.assets.filter((a) => (a.parts || []).some((p) => p.itemId === stockCard.id || p.name === stockCard.name)).map((a) => (
              <div key={a.id} style={card()}><Row main={a.number + " — " + a.name} sub={a.location} /></div>
            ))}
            {db.assets.filter((a) => (a.parts || []).some((p) => p.itemId === stockCard.id || p.name === stockCard.name)).length === 0 &&
              <Empty text="غير مربوط بأصول — اربطه من ملف الأصل ← قطع الغيار." />}
          </Section>
          <Section title="الحركات (بطاقة الصنف)">
            {db.stockTx.filter((t) => t.itemId === stockCard.id).slice().reverse().map((t) => (
              <div key={t.id} style={{ fontSize: 13, color: C.steel, marginBottom: 4, borderBottom: `1px dashed ${C.line}`, paddingBottom: 4 }}>
                <b style={{ color: C.ink }}>{t.type}</b> · {t.qty} · {t.at}
                {t.workOrderId ? " · " + (db.workOrders.find((w) => w.id === t.workOrderId)?.number || "") : ""}
              </div>
            ))}
            {db.stockTx.filter((t) => t.itemId === stockCard.id).length === 0 && <Empty text="لا حركات لهذا الصنف." />}
          </Section>
        </Sheet>
      )}
    </>
  );
}

/* ───────────────────────── الأصول ───────────────────────── */
/* ───────────────────────── مجموعات الأصول: قواعد ← مجموعات ← تعيينات (ف4) ───────────────────────── */
