import { useState } from "react";
import { ASSET_CREATION_MODES, C, EXCEPTION_TYPES, MAINT_ORG_STATUS, ORACLE_FEATURES, RESOURCE_TYPES, RESOURCE_UOMS, SHIFT_TYPES, fmt, uid } from "../core/appCore";
import { Btn, Chip, Field, Row, Section, card, input } from "../components/ui";
import { Assets } from "./assets";
import { Crud } from "./crud";

export function Organization({ ctx }) {
  const { db } = ctx;
  const [sub, setSub] = useState("orgs");
  const resourceLocked = (r) => db.workCenters.some((wc) => wc.id === r.workCenterId) || db.resourceInstances.some((i) => i.resourceId === r.id);
  const orgReady = db.maintenanceOrganizations.length > 0 && db.workAreas.length > 0 && db.workCenters.length > 0;
  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12, overflowX: "auto" }}>
        <Chip active={sub === "orgs"} onClick={() => setSub("orgs")}>المنظمة</Chip>
        <Chip active={sub === "plant"} onClick={() => setSub("plant")}>Plant Parameters</Chip>
        <Chip active={sub === "areas"} onClick={() => setSub("areas")}>مناطق العمل</Chip>
        <Chip active={sub === "centers"} onClick={() => setSub("centers")}>مراكز العمل</Chip>
        <Chip active={sub === "resources"} onClick={() => setSub("resources")}>الموارد</Chip>
        <Chip active={sub === "instances"} onClick={() => setSub("instances")}>Resource Instances</Chip>
        <Chip active={sub === "shifts"} onClick={() => setSub("shifts")}>الورديات</Chip>
        <Chip active={sub === "exceptions"} onClick={() => setSub("exceptions")}>الاستثناءات</Chip>
      </div>
      <div style={{ ...card(), borderRightColor: orgReady ? C.green : C.amber, fontSize:13, marginBottom:12 }}>
        حالة التشغيل: {orgReady ? "جاهزة تشغيليًا" : "غير مكتملة — تحتاج منظمة + منطقة عمل + مركز عمل"}
      </div>
      {sub === "orgs" && <Crud ctx={ctx} entity="maintenanceOrganizations" title="منظمات الصيانة" schema={[
        { k:"code", label:"كود المنظمة" }, { k:"name", label:"اسم المنظمة" },
        { k:"status", label:"الحالة", type:"select", options: MAINT_ORG_STATUS },
        { k:"isMaintenanceEnabled", label:"مفعلة للصيانة", type:"check" },
        { k:"isProjectTracked", label:"Project Tracked", type:"check" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => !String(d.code||"").trim() ? "كود المنظمة مطلوب" : db.maintenanceOrganizations.some((o) => o.code === d.code && o.id !== form?.id) ? "كود المنظمة مستخدم" : null}
      render={(o) => [o.name || o.code, [o.code, o.status, o.isMaintenanceEnabled ? "Maintenance Enabled" : "غير مفعلة", o.isProjectTracked ? "Project" : ""].filter(Boolean).join(" · ")]} />}
      {sub === "plant" && <Crud ctx={ctx} entity="plantParameters" title="Plant Parameters" schema={[
        { k:"organizationId", label:"منظمة الصيانة", type:"select", from:"maintenanceOrganizations", fromKey:"name" },
        { k:"assetCreationMode", label:"Asset Creation Mode", type:"select", options: ASSET_CREATION_MODES },
        { k:"autoAssetPrefix", label:"بادئة أرقام الأصول" },
        { k:"requireItemForEnterpriseAssets", label:"Item مطلوب لأصول المؤسسة", type:"check" },
        { k:"requireFullLifecycleForWO", label:"Full Lifecycle مطلوب لأوامر العمل", type:"check" },
        { k:"defaultUnknownLocation", label:"اجعل الموقع Unknown عند النقص", type:"check" },
        { k:"projectTrackingEnabled", label:"Project Driven Supply Chain", type:"check" },
        { k:"inventoryIssuePolicy", label:"سياسة صرف المواد" },
      ]} validate={(d) => !d.organizationId ? "اختر منظمة الصيانة" : null}
      render={(p) => [ctx.nameOf("maintenanceOrganizations", p.organizationId), [p.assetCreationMode, p.inventoryIssuePolicy, p.projectTrackingEnabled ? "Project" : ""].filter(Boolean).join(" · ")]} />}
      {sub === "areas" && <Crud ctx={ctx} entity="workAreas" title="مناطق العمل" schema={[
        { k: "organizationId", label:"المنظمة", type:"select", from:"maintenanceOrganizations", fromKey:"name" },
        { k: "name", label: "الاسم" }, { k: "code", label: "الرمز" }, { k: "description", label: "الوصف" }, { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => !d.organizationId ? "منطقة العمل يجب أن تتبع منظمة" : !String(d.name||"").trim() ? "الاسم مطلوب" : db.workAreas.some((x) => x.organizationId === d.organizationId && x.code === d.code && x.id !== form?.id) ? "رمز منطقة العمل مستخدم داخل نفس المنظمة" : null}
      render={(a) => [a.name, [a.code, ctx.nameOf("maintenanceOrganizations", a.organizationId)].filter(Boolean).join(" · ")]} />}
      {sub === "centers" && <Crud ctx={ctx} entity="workCenters" title="مراكز العمل" schema={[
        { k: "organizationId", label:"المنظمة", type:"select", from:"maintenanceOrganizations", fromKey:"name" },
        { k: "name", label: "الاسم (الورشة الميكانيكية…)" }, { k: "code", label: "الرمز" },
        { k: "workAreaId", label: "منطقة العمل", type: "select", from: "workAreas", fromKey: "name" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d) => !d.workAreaId ? "مركز العمل يجب أن يتبع منطقة عمل" : null}
      render={(a) => [a.name, "ضمن " + ctx.nameOf("workAreas", a.workAreaId)]} />}
      {sub === "resources" && <Crud ctx={ctx} entity="resources" title="الموارد" schema={[
        { k: "code", label:"كود المورد" }, { k: "name", label: "الاسم" },
        { k: "type", label: "النوع", type: "select", options: RESOURCE_TYPES },
        { k: "usageUom", label: "UOM الاستخدام", type:"select", options: RESOURCE_UOMS },
        { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
        { k: "qty", label: "العدد المتاح", type: "number" },
        { k:"available24h", label:"متاح 24 ساعة", type:"check" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => form?.id && resourceLocked(form) && d.usageUom !== form.usageUom ? "UOM المورد لا يغيّر بعد ربطه بمركز عمل أو Instance" : null}
      validateDelete={(r) => resourceLocked(r) ? "لا يمكن حذف المورد لأنه مرتبط بمركز عمل أو Resource Instance نشط" : null}
      render={(r) => [r.name, [r.code, r.type, r.usageUom, ctx.nameOf("workCenters", r.workCenterId), r.available24h ? "24h" : "ورديات"].filter((x) => x && x !== "—").join(" · ")]} />}
      {sub === "instances" && <Crud ctx={ctx} entity="resourceInstances" title="Resource Instances" schema={[
        { k:"identifier", label:"معرّف فريد للـ Instance" },
        { k:"resourceId", label:"المورد", type:"select", from:"resources", fromKey:"name" },
        { k:"instanceType", label:"مصدر الإنشاء", type:"select", options:["شخص", "أصل", "يدوي"] },
        { k:"personName", label:"اسم الشخص / اليدوي" },
        { k:"assetId", label:"الأصل المرتبط للمعدات", type:"select", from:"assets", fromKey:"name" },
        { k:"qualifications", label:"المؤهلات", type:"textarea" },
        { k:"active", label:"نشط", type:"check" },
        { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} validate={(d, form) => !String(d.identifier||"").trim() ? "المعرّف مطلوب" : db.resourceInstances.some((x) => x.identifier === d.identifier && x.id !== form?.id) ? "المعرّف مستخدم" : (db.resources.find((r) => r.id === d.resourceId)?.type === "معدات" && d.instanceType === "أصل" && !d.assetId) ? "تأهيل المعدات يتطلب ربط Asset Number" : null}
      render={(i) => [i.identifier, [ctx.nameOf("resources", i.resourceId), i.instanceType, i.assetId ? "Asset: " + ctx.nameOf("assets", i.assetId) : i.personName].filter(Boolean).join(" · ")]} />}
      {sub === "shifts" && <Crud ctx={ctx} entity="shifts" title="الورديات" schema={[
        { k:"name", label:"اسم الوردية" }, { k:"code", label:"الكود" },
        { k:"shiftType", label:"النوع", type:"select", options: SHIFT_TYPES },
        { k:"startTime", label:"وقت البداية" }, { k:"endTime", label:"وقت النهاية" },
        { k:"days", label:"الأيام" }, { k:"inactiveOn", label:"تاريخ التعطيل", type:"date" },
      ]} render={(s) => [s.name, [s.code, s.shiftType, s.startTime + "-" + s.endTime, s.days].filter(Boolean).join(" · ")]} />}
      {sub === "exceptions" && <Crud ctx={ctx} entity="resourceExceptions" title="استثناءات تقويم المورد" schema={[
        { k:"workCenterId", label:"مركز العمل", type:"select", from:"workCenters", fromKey:"name" },
        { k:"resourceId", label:"المورد", type:"select", from:"resources", fromKey:"name" },
        { k:"date", label:"التاريخ", type:"date" },
        { k:"exceptionType", label:"نوع الاستثناء", type:"select", options: EXCEPTION_TYPES },
        { k:"startTime", label:"من" }, { k:"endTime", label:"إلى" },
        { k:"reason", label:"السبب", type:"textarea" },
      ]} validate={(d) => db.resources.find((r) => r.id === d.resourceId)?.available24h ? "لا تنشئ استثناء لمورد متاح 24 ساعة" : null}
      render={(e) => [ctx.nameOf("resources", e.resourceId), [e.exceptionType, fmt(e.date), e.reason].filter(Boolean).join(" · ")]} />}
    </>
  );
}

export function OracleCompliance({ ctx, setTab }) {
  const { db, save } = ctx;
  const checks = [
    ["Maintenance Organization", db.maintenanceOrganizations.length > 0, "org"],
    ["Plant Parameters", db.plantParameters.length > 0, "org"],
    ["Work Area", db.workAreas.length > 0, "org"],
    ["Work Center", db.workCenters.length > 0, "org"],
    ["Resources", db.resources.length > 0, "org"],
    ["Resource Instances", db.resourceInstances.length > 0, "org"],
    ["Shifts", db.shifts.length > 0, "org"],
    ["Smart Asset Search", true, "assets"],
    ["Asset 360", true, "assets"],
    ["Flexfields / Fixed Assets / Service / IoT", true, "assets"],
    ["Asset Import/Export", true, "data"],
  ];
  const seed = () => {
    const orgId = db.maintenanceOrganizations[0]?.id || uid();
    const areaId = db.workAreas[0]?.id || uid();
    const wcId = db.workCenters[0]?.id || uid();
    const resId = db.resources[0]?.id || uid();
    save({ ...db,
      maintenanceOrganizations: db.maintenanceOrganizations.length ? db.maintenanceOrganizations : [{ id:orgId, code:"MAIN", name:"Main Maintenance Organization", status:"عاملة", isMaintenanceEnabled:true, isProjectTracked:false, inactiveOn:"" }],
      plantParameters: db.plantParameters.length ? db.plantParameters : [{ id:uid(), organizationId:orgId, assetCreationMode:"IMMEDIATE", autoAssetPrefix:"AST", requireItemForEnterpriseAssets:false, requireFullLifecycleForWO:false, defaultUnknownLocation:true, projectTrackingEnabled:false, inventoryIssuePolicy:"لا صرف مواد بدون أمر عمل" }],
      workAreas: db.workAreas.length ? db.workAreas : [{ id:areaId, organizationId:orgId, code:"MILL", name:"Mill Maintenance Area", description:"منطقة صيانة المطحن", inactiveOn:"" }],
      workCenters: db.workCenters.length ? db.workCenters : [{ id:wcId, organizationId:orgId, workAreaId:areaId, code:"MECH", name:"Mechanical Workshop", inactiveOn:"" }],
      resources: db.resources.length ? db.resources : [{ id:resId, code:"LAB-MECH", name:"Mechanical Labor", type:"عمالة", usageUom:"ساعة", workCenterId:wcId, qty:4, available24h:false, inactiveOn:"" }],
      resourceInstances: db.resourceInstances.length ? db.resourceInstances : [{ id:uid(), resourceId:resId, identifier:"TECH-001", instanceType:"يدوي", personName:"Technician 001", assetId:"", active:true, qualifications:"عام", inactiveOn:"" }],
      shifts: db.shifts.length ? db.shifts : [{ id:uid(), name:"Day Shift", code:"DAY", shiftType:"صباحي", startTime:"08:00", endTime:"17:00", days:"الأحد,الاثنين,الثلاثاء,الأربعاء,الخميس", inactiveOn:"" }],
    });
  };
  return (
    <>
      <Section title="مطابقة الملفات المرفوعة — Chapters 01, 02, 03">
        <div style={card()}>
          <div style={{ fontWeight:800, marginBottom:6 }}>تمت إضافة المتطلبات الناقصة كوظائف داخل التطبيق.</div>
          <div style={{ fontSize:13, color:C.steel }}>هذه الشاشة تعطيك Audit سريع: هل توجد بيانات تشغيلية لكل وحدة، وأين تفتحها.</div>
        </div>
        {checks.map(([name, ok, tab]) => <div key={name} style={{ ...card(), borderRightColor: ok ? C.green : C.amber }} onClick={() => setTab(tab)}>
          <Row main={name} sub={ok ? "موجود / جاهز" : "الواجهة موجودة وتحتاج بيانات"} badge={{ text: ok ? "✓" : "بيانات", color: ok ? C.green : C.amber }} />
        </div>)}
        {ctx.canUseSetupTools && <Btn bg={C.orange} style={{ width:"100%", padding:12 }} onClick={seed}>+ إنشاء إعدادات صيانة افتراضية</Btn>}
      </Section>
      <Section title="قائمة الميزات المضافة من الملفات">
        {ORACLE_FEATURES.map(([feature, ch, tab]) => <div key={feature} style={card()} onClick={() => setTab(tab)}><Row main={feature} sub={ch + " · اضغط للانتقال"} /></div>)}
      </Section>
    </>
  );
}

export function ServiceMappingForm({ db, assetId, save }) {
  const [source, setSource] = useState("Sales Order");
  const [targetField, setTargetField] = useState("customer");
  const [rule, setRule] = useState("");
  return <div style={card()}>
    <Field label="المصدر"><select value={source} onChange={(e) => setSource(e.target.value)} style={input}>{["Sales Order", "Service Request", "Field Service Work Order", "Subscription", "Manual"].map((x) => <option key={x}>{x}</option>)}</select></Field>
    <Field label="الحقل الهدف في الأصل"><input value={targetField} onChange={(e) => setTargetField(e.target.value)} style={input} /></Field>
    <Field label="قاعدة النقل"><textarea value={rule} onChange={(e) => setRule(e.target.value)} rows={2} style={{ ...input, resize:"vertical" }} /></Field>
    <Btn bg={C.green} style={{ width:"100%" }} onClick={() => { if (!targetField.trim()) return; save({ ...db, assetServiceMappings: [...(db.assetServiceMappings || []), { id:uid(), assetId, source, targetField, rule }] }); setRule(""); }}>+ إضافة Service Mapping</Btn>
  </div>;
}

/* ───────────────────────── الحوكمة والرقابة ───────────────────────── */
