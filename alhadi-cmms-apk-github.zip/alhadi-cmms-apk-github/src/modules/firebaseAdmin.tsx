import { useEffect, useState } from "react";
import { FIREBASE_OWNER_EMAIL, clearRuntimeFirebaseConfig, extractFirebaseConfig, listFirebaseUsers, migrateCmmsStateToRecordFirestore, registerFirebase, saveRuntimeFirebaseConfig, signInFirebase, signOutFirebase, updateFirebaseUserProfile } from "../firebaseCmms";
import { C, ROLES, isProductionBuild, uid } from "../core/appCore";
import { Btn, Empty, Field, Row, Section, card, input, inputStyle } from "../components/ui";

export function FirebaseAuthScreen({ services }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState("login");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setError("");
    try {
      if (mode === "register") {
        if (isProductionBuild()) throw new Error("Self registration disabled in production");
        await registerFirebase(services, email, password);
      } else await signInFirebase(services, email, password);
    } catch (err) {
      console.error(err);
      setError("تعذر تسجيل الدخول. تأكد من تفعيل Email/Password في Firebase Authentication وصحة البيانات.");
    }
    setBusy(false);
  };
  return (
    <div dir="rtl" style={{ minHeight:"100vh", background:C.paper, display:"grid", placeItems:"center", padding:18, fontFamily:"'Cairo', system-ui, sans-serif" }}>
      <form onSubmit={submit} style={{ ...card(), width:"100%", maxWidth:430, padding:18 }}>
        <div style={{ fontSize:24, fontWeight:900, marginBottom:4 }}>تسجيل دخول Firebase</div>
        <div style={{ fontSize:13, color:C.steel, marginBottom:14 }}>الصلاحيات الآن من Firebase وليست من اختيار داخل الواجهة. بريد المالك الافتراضي: {FIREBASE_OWNER_EMAIL}</div>
        <Field label="البريد الإلكتروني"><input value={email} onChange={(e)=>setEmail(e.target.value)} type="email" required style={inputStyle()} /></Field>
        <Field label="كلمة المرور"><input value={password} onChange={(e)=>setPassword(e.target.value)} type="password" required minLength={6} style={inputStyle()} /></Field>
        {error && <div style={{ color:C.red, fontSize:13, marginBottom:8 }}>{error}</div>}
        <button type="submit" disabled={busy} style={{ background:C.ink, color:"#fff", border:`1.5px solid ${C.ink}`, borderRadius:4, padding:12, fontSize:13, fontWeight:800, width:"100%" }}>{busy ? "جارٍ التنفيذ…" : mode === "register" ? "إنشاء حساب" : "دخول"}</button>
        {!isProductionBuild() && <button type="button" onClick={()=>setMode(mode === "login" ? "register" : "login")} style={{ marginTop:10, width:"100%", border:"none", background:"transparent", color:C.blue, fontWeight:800 }}>
          {mode === "login" ? "إنشاء حساب جديد كطالب خدمة" : "لدي حساب بالفعل"}
        </button>}
        {!isProductionBuild() && <button type="button" onClick={()=>{ clearRuntimeFirebaseConfig(); location.reload(); }} style={{ marginTop:8, width:"100%", border:"none", background:"transparent", color:C.red, fontWeight:800 }}>تغيير إعدادات Firebase</button>}
        {isProductionBuild() && <div style={{ marginTop:10, fontSize:12, color:C.steel, lineHeight:1.7, background:C.soft, border:`1px solid ${C.line}`, borderRadius:12, padding:10 }}>وضع الإنتاج مفعّل: إنشاء المستخدمين وتغيير إعدادات Firebase يتمان من المدير أو من بناء إعداد خاص، وليس من شاشة الدخول العامة.</div>}
      </form>
    </div>
  );
}

export function FirebaseSecurityPanel({ ctx }) {
  const { firebaseEnabled, firebaseServices, firebaseUser, firebaseProfile, role, db, can, setSyncStatus, productionMode, canUseSetupTools, canUseDangerousTools } = ctx;
  const [configText, setConfigText] = useState("");
  const [migrating, setMigrating] = useState(false);
  const saveConfig = () => {
    const cfg = extractFirebaseConfig(configText);
    if (!cfg) return alert("لم أستطع قراءة firebaseConfig. الصق الكائن كاملًا من Firebase Web App settings.");
    saveRuntimeFirebaseConfig(cfg);
    alert("تم حفظ إعدادات Firebase على هذا الجهاز. سيُعاد تشغيل التطبيق الآن.");
    location.reload();
  };
  const migrateRecords = async () => {
    if (!firebaseServices || !firebaseUser) return alert("سجل الدخول إلى Firebase أولًا.");
    if (!can?.admin && !can?.review) return alert("الترحيل يحتاج مدير أو مشرف.");
    setMigrating(true);
    try {
      const res = await migrateCmmsStateToRecordFirestore(firebaseServices, db, {
        uid: firebaseUser.uid,
        email: firebaseUser.email,
        role,
      });
      setSyncStatus?.("تم ترحيل البيانات إلى مستندات Firestore مستقلة");
      alert("تم ترحيل " + res.records + " سجل إلى مستندات مستقلة داخل Firestore.");
    } catch (e) {
      console.error(e);
      alert("فشل الترحيل. تأكد أن قواعد Firestore الجديدة منشورة وأن حسابك مدير/مشرف.");
    }
    setMigrating(false);
  };
  return (
    <>
      <Section title="Firebase والصلاحيات الخلفية">
        <div style={{ ...card(), borderRightColor: firebaseEnabled ? C.green : C.amber }}>
          <Row main={firebaseEnabled ? "Firebase مفعّل" : "Firebase غير مفعّل على هذا الجهاز"}
            sub={firebaseEnabled ? "Project: " + (firebaseServices?.config?.projectId || "—") + " · الدور الحالي: " + role : "الصق إعدادات Firebase مرة واحدة من التطبيق، أو ابنه بمتغيرات VITE_FIREBASE_*"}
            badge={{ text: firebaseEnabled ? "محمي" : "إعداد مطلوب", color: firebaseEnabled ? C.green : C.amber }} />
        </div>
      </Section>

      <Section title="قفل الإنتاج">
        <div style={{ ...card(), borderRightColor: productionMode ? C.green : C.amber }}>
          <Row main={productionMode ? "Production Lock مفعّل" : "وضع التدريب/الإعداد"}
            sub={productionMode ? "تم إخفاء أدوات التجربة والإعداد والخطر: تغيير الدور اليدوي، إنشاء بيانات نموذجية، الترحيلات، مسح الربط، والاستيراد/المسح." : "أدوات الإعداد ظاهرة لأن هذه ليست نسخة إنتاجية أو لأن متغيرات البناء سمحت بها."}
            badge={{ text: productionMode ? "محمي" : "Setup", color: productionMode ? C.green : C.amber }} />
        </div>
      </Section>

      {!firebaseEnabled && (
        <Section title="ربط Firebase من الهاتف">
          <div style={card()}>
            <div style={{ fontSize:13, color:C.steel, marginBottom:8 }}>من Firebase Console افتح Project settings ← Web app، ثم انسخ كائن firebaseConfig والصقه هنا. لا تحتاج لإعادة بناء APK إذا استخدمت هذه الطريقة.</div>
            <textarea value={configText} onChange={(e)=>setConfigText(e.target.value)} placeholder={'const firebaseConfig = {\n  apiKey: "...",\n  authDomain: "...",\n  projectId: "...",\n  storageBucket: "...",\n  messagingSenderId: "...",\n  appId: "..."\n};'} style={{ ...inputStyle(), minHeight:180, direction:"ltr", fontFamily:"monospace", fontSize:12 }} />
            <Btn bg={C.green} onClick={saveConfig} style={{ width:"100%", padding:12, marginTop:8 }}>حفظ إعدادات Firebase</Btn>
          </div>
        </Section>
      )}

      {firebaseEnabled && (
        <Section title="الحساب الحالي">
          <div style={card()}>
            <Row main={firebaseUser?.email || "—"} sub={(firebaseProfile?.uid || firebaseUser?.uid || "") + " · " + (firebaseProfile?.isOwner ? "مالك النظام" : "مستخدم")} badge={{ text: role, color: role === "مدير" ? C.green : C.blue }} />
            <div style={{ display:"flex", gap:8, marginTop:10 }}>
              <Btn bg={C.red} onClick={()=>firebaseServices && signOutFirebase(firebaseServices)} style={{ flex:1 }}>تسجيل خروج</Btn>
              {canUseDangerousTools && <Btn bg={C.steel} onClick={()=>{ if(confirm("مسح ربط Firebase من هذا الجهاز؟ استخدمها فقط في بيئة اختبار أو عند تغيير المشروع.")){ clearRuntimeFirebaseConfig(); alert("تم مسح إعدادات Firebase من هذا الجهاز."); location.reload(); } }} style={{ flex:1 }}>مسح الربط</Btn>}
            </div>
            {productionMode && !canUseDangerousTools && <div style={{ fontSize:11.5, color:C.steel, marginTop:8 }}>تم إخفاء زر مسح الربط في وضع الإنتاج حتى لا يفقد المستخدم اتصال Firebase بالخطأ.</div>}
          </div>
        </Section>
      )}

      {firebaseEnabled && (
        <Section title="تخزين Firestore كمستندات مستقلة">
          <div style={{ ...card(), borderRightColor:C.blue }}>
            <Row main="Record-per-document مفعّل" sub="الأصول وأوامر العمل وحركات المخزون والقراءات والفنيون وباقي السجلات تُحفظ في مسار مستقل: cmms/main/records/{entity}/items/{id}." badge={{ text:"Schema v2", color:C.blue }} />
            <div style={{ fontSize:12, color:C.steel, lineHeight:1.8, marginTop:8 }}>
              هذا يقلل خطر حد حجم المستند الواحد، ويسمح بقواعد صلاحيات أدق على مستوى السجل بدل حفظ كل قسم كمصفوفة كبيرة.
            </div>
            {canUseSetupTools && <Btn bg={C.green} onClick={migrateRecords} style={{ width:"100%", padding:12, marginTop:10 }}>{migrating ? "جارٍ الترحيل…" : "ترحيل/تحديث كل البيانات إلى مستندات مستقلة"}</Btn>}
          </div>
        </Section>
      )}

      {firebaseEnabled && (
        <Section title="تخزين Firebase Storage">
          <div style={{ ...card(), borderRightColor:C.purple }}>
            <Row main="Storage للصور والمرفقات" sub={"Bucket: " + (firebaseServices?.config?.storageBucket || "—") + " · الصور الجديدة تحفظ كرابط Storage بدل Base64."} badge={{ text:"Media", color:C.purple }} />
            {canUseSetupTools && <Btn bg={C.purple} onClick={()=>ctx.migrateLocalMediaToStorage?.()} style={{ width:"100%", padding:12, marginTop:10 }}>ترحيل الصور القديمة إلى Storage</Btn>}
          </div>
        </Section>
      )}

      <Section title="ما الذي أصبح Backend-Enforced؟">
        <div style={{ ...card(), fontSize:13, color:C.steel, lineHeight:1.8 }}>
          <b style={{ color:C.ink }}>المهم:</b> لم يعد اختيار الدور من القائمة هو مصدر الصلاحية عند تفعيل Firebase. القراءة والكتابة تمر عبر Firebase Auth و Firestore Security Rules. القواعد الموجودة في ملف <b>firestore.rules</b> تمنع المستخدم غير المصرح من كتابة سجلات لا يملكها حتى لو عدّل ملف APK. النسخة الجديدة تحفظ كل سجل في مستند مستقل، وليس كمصفوفة كبيرة داخل مستند واحد.
        </div>
      </Section>
    </>
  );
}

export function FirebaseUsersPanel({ ctx }) {
  const { firebaseEnabled, firebaseServices, db, can } = ctx;
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const load = async () => {
    if (!firebaseServices) return;
    setLoading(true); setErr("");
    try { setUsers(await listFirebaseUsers(firebaseServices)); }
    catch (e) { console.error(e); setErr("تعذر تحميل المستخدمين. تأكد أن دورك مدير/مشرف وأن Firestore Rules منشورة."); }
    setLoading(false);
  };
  useEffect(() => { if (firebaseEnabled && can.review) load(); }, [firebaseEnabled, can.review]);
  const patchUser = async (u, patch) => {
    try {
      await updateFirebaseUserProfile(firebaseServices, u.uid, patch);
      await load();
    } catch (e) {
      console.error(e);
      alert("رفض Firebase التعديل. تأكد أن حسابك مدير وأن القواعد منشورة.");
    }
  };
  if (!firebaseEnabled) return <Empty text="فعّل Firebase أولًا من شاشة Firebase والصلاحيات." />;
  if (!can.review) return <Empty text="هذه الشاشة للمدير أو المشرف فقط." />;
  return (
    <>
      <Section title="المستخدمون والصلاحيات">
        <div style={{ ...card(), fontSize:13, color:C.steel }}>أنشئ المستخدم من شاشة تسجيل الدخول، ثم اربطه هنا بدور وفني. دور المدير يستطيع تغيير الأدوار، والمشرف يستطيع القراءة حسب القواعد.</div>
        {err && <div style={{ ...card(), color:C.red }}>{err}</div>}
        <Btn bg={C.blue} onClick={load} style={{ width:"100%", padding:10, marginBottom:8 }}>{loading ? "جارٍ التحميل…" : "تحديث القائمة"}</Btn>
        {users.length === 0 && !loading && <Empty text="لا يوجد مستخدمون بعد." />}
        {users.map((u) => (
          <div key={u.uid} style={card()}>
            <Row main={u.email || u.uid} sub={(u.displayName || "بدون اسم") + " · " + (u.uid || "")} badge={{ text:u.role || "—", color:u.role === "مدير" ? C.green : C.steel }} />
            {can.admin && <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginTop:10 }}>
              <Field label="الدور"><select value={u.role || "طالب خدمة"} onChange={(e)=>patchUser(u, { role:e.target.value })} style={inputStyle()}>{ROLES.map((r)=><option key={r}>{r}</option>)}</select></Field>
              <Field label="ربط بفني"><select value={u.technicianId || ""} onChange={(e)=>patchUser(u, { technicianId:e.target.value })} style={inputStyle()}><option value="">— بدون —</option>{db.technicians.map((t)=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field>
            </div>}
          </div>
        ))}
      </Section>
    </>
  );
}


/* ───────────────────────── واجهة حديثة للتبويبات والمزيد ───────────────────────── */
