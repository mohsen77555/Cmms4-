import { useState } from "react";
import { ACTIVE_STATES, C, WO_COLORS, addDateDays, dateKey, daysUntil, fmt, money, now, pad2, parseDateValue, today, uid } from "../core/appCore";
import { Btn, Chip, Empty, Field, Row, Section, Stat, card, input, inputStyle } from "../components/ui";

export function workOrderEstimatedHoursV39(w) {
  const ops = Array.isArray(w?.operations) ? w.operations : [];
  const opHours = ops.reduce((sum, op) => {
    const minutes = Number(op?.minutes || op?.plannedMinutes || 0);
    const hours = minutes ? minutes / 60 : Number(op?.plannedHours || op?.estimatedHours || op?.actualHours || 0);
    return sum + (Number.isFinite(hours) ? hours : 0);
  }, 0);
  const direct = Number(w?.estimatedHours || w?.estimatedDuration || w?.durationHours || w?.plannedHours || 0);
  const finalHours = opHours || direct || 2;
  return Math.max(0.25, Math.round(finalHours * 4) / 4);
}
export function workOrderRequiredWorkCenterV39(db, w) {
  const opWc = (w?.operations || []).find((o) => o?.workCenterId)?.workCenterId || "";
  const asset = (db.assets || []).find((a) => a.id === w?.assetId) || {};
  return w?.workCenterId || opWc || asset.workCenterId || asset.defaultWorkCenterId || "";
}
export function priorityScoreV39(w) {
  const p = String(w?.priority || "");
  if (p.includes("طارئ") || p.includes("حرج") || p.includes("Critical")) return 40;
  if (p.includes("عالية") || p.includes("High")) return 28;
  if (p.includes("متوسطة") || p.includes("Medium")) return 16;
  return 8;
}
export function workOrderMaterialStateV39(ctx, w) {
  try {
    const label = ctx.materialStatusOf ? String(ctx.materialStatusOf(w) || "") : "";
    const shortages = ctx.woShortages ? (ctx.woShortages(w) || []) : [];
    const waiting = shortages.length > 0 || /انتظار|نقص|Waiting|Short|غير متاح/i.test(label);
    return { label: label || (waiting ? "نقص مواد" : "متاح"), waiting, shortages };
  } catch {
    return { label: "غير مفحوص", waiting: false, shortages: [] };
  }
}
export function assignedTechniciansV39(ctx, w) {
  try {
    const ids = ctx.woAssignedTechIds ? ctx.woAssignedTechIds(w) : [];
    return [...new Set([...(ids || []), ...((w?.assignments || []).map((a) => a.technicianId).filter(Boolean)), ...((w?.operations || []).map((o) => o.assigneeId).filter(Boolean))])];
  } catch { return []; }
}
export function technicianUnavailableV39(db, tech, date) {
  const wc = tech?.workCenterId || "";
  return (db.resourceExceptions || []).some((e) => {
    const sameDate = dateKey(e.date, "") === date;
    if (!sameDate) return false;
    if (e.technicianId && e.technicianId === tech.id) return true;
    if (wc && e.workCenterId && e.workCenterId === wc) return true;
    return false;
  });
}
export function buildAdvancedScheduleEngineV39(ctx, options = {}) {
  const db = ctx.db || {};
  const horizonDays = Math.max(1, Math.min(45, Number(options.horizonDays || 7)));
  const dailyCapacity = Math.max(1, Math.min(24, Number(options.dailyCapacity || 8)));
  const startDate = dateKey(options.startDate || today(), today());
  const dates = Array.from({ length: horizonDays }, (_x, i) => addDateDays(startDate, i));
  const open = (db.workOrders || []).filter((w) => ACTIVE_STATES.includes(w.status) && !["مغلق", "ملغي", "مكتمل"].includes(w.status));
  const technicians = (db.technicians || []).filter((t) => t.active !== false && !t.inactiveOn);
  const load = new Map();
  const addLoad = (techId, date, hours) => {
    if (!techId || !date) return;
    const key = techId + "|" + date;
    load.set(key, (load.get(key) || 0) + Number(hours || 0));
  };
  open.forEach((w) => {
    const date = dateKey(w.plannedStart || w.plannedEnd || "", "");
    if (!date) return;
    const assigned = assignedTechniciansV39(ctx, w);
    if (!assigned.length) return;
    const share = workOrderEstimatedHoursV39(w) / assigned.length;
    assigned.forEach((id) => addLoad(id, date, share));
  });

  const conflicts = [];
  technicians.forEach((t) => dates.forEach((d) => {
    const used = load.get(t.id + "|" + d) || 0;
    if (used > dailyCapacity + 0.01) conflicts.push({ id: uid(), type:"Over Capacity", severity:"عال", technicianId:t.id, technicianName:t.name, date:d, usedHours:Math.round(used*10)/10, capacity:dailyCapacity, reason:"تجاوز طاقة الفني اليومية" });
    if (technicianUnavailableV39(db, t, d)) conflicts.push({ id: uid(), type:"Resource Exception", severity:"متوسط", technicianId:t.id, technicianName:t.name, date:d, usedHours:Math.round(used*10)/10, capacity:dailyCapacity, reason:"الفني/مركز العمل عليه استثناء أو توقف" });
  }));

  const unscheduled = open.filter((w) => !w.plannedStart || !assignedTechniciansV39(ctx, w).length || w.status === "مسودة" || w.status === "مُصدر" || w.status === "جاهز" || (w.plannedEnd && daysUntil(w.plannedEnd) < 0));
  const recommendations = [];
  const blocked = [];
  const simulated = new Map(load);
  const readSim = (techId, date) => simulated.get(techId + "|" + date) || 0;
  const writeSim = (techId, date, h) => simulated.set(techId + "|" + date, readSim(techId, date) + h);
  const ordered = [...unscheduled].sort((a, b) => (priorityScoreV39(b) - priorityScoreV39(a)) || (daysUntil(a.plannedEnd || today()) - daysUntil(b.plannedEnd || today())));

  ordered.forEach((w) => {
    const est = workOrderEstimatedHoursV39(w);
    const material = workOrderMaterialStateV39(ctx, w);
    const requiredWorkCenterId = workOrderRequiredWorkCenterV39(db, w);
    const requiredWorkCenterName = requiredWorkCenterId ? ((db.workCenters || []).find((x) => x.id === requiredWorkCenterId)?.name || requiredWorkCenterId) : "غير محدد";
    const blockers = [];
    if (!w.assetId) blockers.push("لا يوجد أصل مرتبط");
    if (material.waiting) blockers.push("المواد غير مكتملة");
    const qualified = technicians.filter((t) => !requiredWorkCenterId || !t.workCenterId || t.workCenterId === requiredWorkCenterId || String(t.specialty || "").includes(String(w.type || "")));
    if (!qualified.length) blockers.push("لا يوجد فني مؤهل أو مركز عمل مناسب");
    let best = null;
    qualified.forEach((t) => dates.forEach((d, dayIndex) => {
      if (technicianUnavailableV39(db, t, d)) return;
      const used = readSim(t.id, d);
      const remaining = dailyCapacity - used;
      if (remaining < est) return;
      const sameWc = requiredWorkCenterId && t.workCenterId === requiredWorkCenterId;
      const duePenalty = w.plannedEnd && daysUntil(w.plannedEnd) < 0 ? 25 : 0;
      const dayPenalty = dayIndex * 2.5;
      const loadPenalty = (used / dailyCapacity) * 12;
      const materialBonus = material.waiting ? -30 : 10;
      const score = 50 + priorityScoreV39(w) + duePenalty + (sameWc ? 18 : 4) + materialBonus - dayPenalty - loadPenalty;
      if (!best || score > best.score) best = { tech:t, date:d, used, remaining, score, sameWc };
    }));
    if (!best || blockers.includes("المواد غير مكتملة")) {
      blocked.push({ id: uid(), workOrderId:w.id, workOrderNumber:w.number, title:w.title, assetId:w.assetId, assetName:(db.assets || []).find((a)=>a.id===w.assetId)?.name || "—", estimatedHours:est, requiredWorkCenterId, requiredWorkCenterName, materialStatus:material.label, blockers: blockers.length ? blockers : ["لا توجد سعة متاحة ضمن أفق الجدولة"] });
      conflicts.push({ id:uid(), type:"Blocked Work Order", severity:"عال", workOrderId:w.id, workOrderNumber:w.number, date:w.plannedStart || today(), reason:(blockers.length ? blockers : ["لا توجد سعة متاحة"]).join("، ") });
      return;
    }
    writeSim(best.tech.id, best.date, est);
    const confidence = Math.max(35, Math.min(98, Math.round(best.score)));
    recommendations.push({
      id: uid(), status:"مقترح", source:"Advanced Scheduling Engine v39", workOrderId:w.id, workOrderNumber:w.number, title:w.title,
      assetId:w.assetId, assetName:(db.assets || []).find((a)=>a.id===w.assetId)?.name || "—", technicianId:best.tech.id, technicianName:best.tech.name,
      date:best.date, plannedStart:best.date, plannedEnd:best.date, estimatedHours:est, dailyCapacity, usedBefore:Math.round(best.used*10)/10,
      remainingAfter:Math.round((best.remaining - est)*10)/10, score:Math.round(best.score*10)/10, confidence,
      requiredWorkCenterId, requiredWorkCenterName, materialStatus:material.label,
      reasons:[best.sameWc ? "مطابقة مركز العمل" : "أقرب فني متاح", material.waiting ? "يوجد نقص مواد" : "المواد مقبولة", w.plannedEnd && daysUntil(w.plannedEnd)<0 ? "أمر متأخر" : "ضمن الأفق"].filter(Boolean),
      createdAt: now()
    });
  });

  const capacityRows = technicians.map((t) => {
    const total = dates.reduce((s, d) => s + (simulated.get(t.id + "|" + d) || 0), 0);
    const cap = dailyCapacity * dates.length;
    return { technicianId:t.id, technicianName:t.name, workCenterId:t.workCenterId || "", workCenterName:(db.workCenters || []).find((w)=>w.id===t.workCenterId)?.name || "—", usedHours:Math.round(total*10)/10, capacityHours:cap, utilization:cap ? Math.round((total/cap)*100) : 0 };
  }).sort((a,b)=>b.utilization-a.utilization);

  const stats = {
    horizonDays, dailyCapacity, openOrders:open.length, candidateOrders:unscheduled.length, recommendations:recommendations.length,
    blocked:blocked.length, conflicts:conflicts.length, totalRecommendedHours:Math.round(recommendations.reduce((s, r)=>s+Number(r.estimatedHours||0),0)*10)/10,
    avgUtilization:capacityRows.length ? Math.round(capacityRows.reduce((s, r)=>s+r.utilization,0)/capacityRows.length) : 0
  };
  return { dates, recommendations, blocked, conflicts, capacityRows, stats };
}

/* ───────────────────────── الإشراف المتقدم — Supervision Workbench ───────────────────────── */
export function Supervision({ ctx, openWO }) {
  const { db, save, update, nameOf, woCost, woAssignedTechIds, materialStatusOf, setWOStatus, can, setTab } = ctx;
  const [view, setView] = useState("العمل اليومي");
  const [filter, setFilter] = useState("الكل");
  const [selectedTech, setSelectedTech] = useState("");
  const [searchName, setSearchName] = useState("");
  const [scheduleHorizon, setScheduleHorizon] = useState(7);
  const [scheduleCapacity, setScheduleCapacity] = useState(8);
  const [scheduleMessage, setScheduleMessage] = useState("");
  const open = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const byFilter = (w) => filter === "الكل" || w.status === filter || w.priority === filter || w.type === filter;
  const visible = open.filter(byFilter).filter((w) => !selectedTech || woAssignedTechIds(w).includes(selectedTech) || (w.operations || []).some((o)=>o.assigneeId === selectedTech));
  const technicianLoad = db.technicians.map((t) => {
    const orders = open.filter((w) => woAssignedTechIds(w).includes(t.id) || (w.operations || []).some((o)=>o.assigneeId === t.id && o.status !== "مكتملة"));
    const hours = orders.reduce((s, w) => s + (w.operations || []).filter((o)=>o.assigneeId === t.id && o.status !== "مكتملة").reduce((x, o)=>x + (Number(o.minutes || 0) / 60 || Number(o.actualHours || 0)), 0), 0);
    return { t, orders, hours };
  }).sort((a,b)=>b.orders.length-a.orders.length);
  const conflicts = [];
  const scheduleMap = {};
  open.forEach((w) => woAssignedTechIds(w).forEach((tid) => {
    const key = tid + "|" + (w.plannedStart || today());
    scheduleMap[key] = scheduleMap[key] || [];
    scheduleMap[key].push(w);
  }));
  Object.entries(scheduleMap).forEach(([key, list]) => {
    if (list.length > 1) {
      const [tid, date] = key.split("|");
      conflicts.push({ id:key, type:"تعارض جدول", technicianId:tid, date, orders:list });
    }
  });
  open.forEach((w) => (w.operations || []).forEach((op) => {
    if (!op.assigneeId) return;
    const tech = db.technicians.find((t)=>t.id === op.assigneeId);
    if (tech?.workCenterId && op.workCenterId && tech.workCenterId !== op.workCenterId) conflicts.push({ id:w.id+op.id, type:"تعارض تأهيل/مركز عمل", technicianId:tech.id, date:w.plannedStart || today(), orders:[w], operation:op.name });
  }));
  const materialWaiting = open.filter((w)=>w.status === "بانتظار مواد" || (materialStatusOf && String(materialStatusOf(w)).includes("Waiting")));
  const saveSearch = () => {
    if (!String(searchName).trim()) return alert("اكتب اسم البحث المحفوظ.");
    save({ ...db, supervisionSavedSearches:[...(db.supervisionSavedSearches || []), { id:uid(), name:searchName.trim(), filter, technicianId:selectedTech, createdAt:now() }] });
    setSearchName("");
  };
  const applySearch = (s) => { setFilter(s.filter || "الكل"); setSelectedTech(s.technicianId || ""); };
  const assignTech = (w, techId) => {
    const tech = db.technicians.find((t)=>t.id === techId);
    if (!tech) return;
    const assignments = [...(w.assignments || []).filter((a)=>a.technicianId !== techId), { id:uid(), technicianId:techId, role:tech.specialty || "Technician", status:"مسند", assignedAt:today(), assignedBy:"Supervision Workbench" }];
    const ops = (w.operations || []).map((op)=> op.assigneeId ? op : { ...op, assigneeId:techId });
    update("workOrders", w.id, { assignments, operations:ops, _cmmsAssignedTechIds:[...new Set(assignments.map((a)=>a.technicianId))], execLog:[...(w.execLog||[]), { action:"إسناد فني من لوحة المشرف: " + tech.name, at:now(), by:"مشرف" }] });
  };
  const makePlanSnapshot = () => {
    save({ ...db,
      supervisionAssignmentPlans:[...(db.supervisionAssignmentPlans || []), { id:uid(), at:now(), date:today(), openOrders:open.length, conflicts:conflicts.length, waitingMaterial:materialWaiting.length, createdBy:"Supervision Workbench" }],
      resourceCapacitySnapshots:[...(db.resourceCapacitySnapshots || []), ...technicianLoad.map((x)=>({ id:uid(), at:today(), technicianId:x.t.id, technicianName:x.t.name, assignedOrders:x.orders.length, estimatedHours:Math.round(x.hours*10)/10 }))],
      resourceScheduleConflicts:[...(db.resourceScheduleConflicts || []), ...conflicts.map((c)=>({ id:uid(), at:now(), type:c.type, technicianId:c.technicianId, date:c.date, workOrderNumbers:(c.orders||[]).map((w)=>w.number).join(", "), operation:c.operation || "" }))]
    });
  };
  const scheduleEngine = buildAdvancedScheduleEngineV39(ctx, { horizonDays:scheduleHorizon, dailyCapacity:scheduleCapacity });
  const saveScheduleEngineRun = () => {
    const runId = uid();
    save({ ...db,
      advancedScheduleRuns:[...(db.advancedScheduleRuns || []), { id:runId, at:now(), horizonDays:scheduleHorizon, dailyCapacity:scheduleCapacity, recommendations:scheduleEngine.recommendations.length, blocked:scheduleEngine.blocked.length, conflicts:scheduleEngine.conflicts.length, totalHours:scheduleEngine.stats.totalRecommendedHours, avgUtilization:scheduleEngine.stats.avgUtilization, createdBy:"Advanced Scheduling Engine v39" }],
      advancedScheduleRecommendations:[...(db.advancedScheduleRecommendations || []), ...scheduleEngine.recommendations.map((r)=>({ ...r, runId }))],
      workOrderScheduleConflicts:[...(db.workOrderScheduleConflicts || []), ...scheduleEngine.conflicts.map((c)=>({ ...c, runId, at:now(), status:"مفتوح", severity:c.severity || "تحذير" }))],
      resourceCapacitySnapshots:[...(db.resourceCapacitySnapshots || []), ...scheduleEngine.capacityRows.map((r)=>({ id:uid(), runId, at:today(), ...r }))]
    });
    setScheduleMessage("تم حفظ خطة الجدولة والتعارضات.");
  };
  const applyScheduleRecommendations = (rows) => {
    const selected = rows && rows.length ? rows : scheduleEngine.recommendations;
    if (!selected.length) return alert("لا توجد اقتراحات قابلة للتطبيق.");
    const byWo = new Map(selected.map((r)=>[r.workOrderId, r]));
    const nextOrders = db.workOrders.map((w) => {
      const r = byWo.get(w.id);
      if (!r) return w;
      const tech = db.technicians.find((t)=>t.id === r.technicianId);
      const existing = (w.assignments || []).filter((a)=>a.technicianId !== r.technicianId);
      const assignments = [...existing, { id:uid(), technicianId:r.technicianId, role:tech?.specialty || "Technician", status:"مسند", assignedAt:today(), assignedBy:"Advanced Scheduling Engine" }];
      const operations = (w.operations || []).map((op)=> op.assigneeId ? op : { ...op, assigneeId:r.technicianId });
      const assignedIds = [...new Set([...(w._cmmsAssignedTechIds || []), ...assignments.map((a)=>a.technicianId).filter(Boolean)])];
      return { ...w, plannedStart:r.plannedStart, plannedEnd:r.plannedEnd, assignments, operations, _cmmsAssignedTechIds:assignedIds, scheduleEngine:"v39", execLog:[...(w.execLog || []), { action:"تطبيق اقتراح الجدولة: " + (tech?.name || r.technicianName) + " في " + r.date, at:now(), by:"محرك الجدولة" }] };
    });
    save({ ...db,
      workOrders:nextOrders,
      advancedScheduleApplied:[...(db.advancedScheduleApplied || []), { id:uid(), at:now(), count:selected.length, horizonDays:scheduleHorizon, dailyCapacity:scheduleCapacity, by:"Advanced Scheduling Engine v39" }]
    });
    setScheduleMessage("تم تطبيق " + selected.length + " اقتراح/اقتراحات على أوامر العمل.");
  };
  const statusBuckets = ["الكل", "جاهز", "قيد التنفيذ", "بانتظار مواد", "بانتظار المراجعة", "مُعاد للتصحيح", "طارئ", "وقائي", "تصحيحي"];
  const views = ["العمل اليومي", "الجدولة", "محرك الجدولة", "الإسناد", "المواد", "المراجعة", "التعارضات", "البحوث"];
  return <>
    <div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:10}}>{views.map((v)=><Chip key={v} active={view===v} onClick={()=>setView(v)}>{v}</Chip>)}</div>
    <Section title="Supervision Workbench">
      <div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={open.length} label="Open" color={C.blue}/><Stat n={open.filter((w)=>w.plannedEnd && daysUntil(w.plannedEnd)<0).length} label="Past Due" color={C.red}/><Stat n={materialWaiting.length} label="Waiting Material" color={C.amber}/><Stat n={conflicts.length} label="Conflicts" color={conflicts.length?C.red:C.green}/></div>
      <div style={{...card(), display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}><Field label="فلتر"><select value={filter} onChange={(e)=>setFilter(e.target.value)} style={inputStyle()}>{statusBuckets.map((x)=><option key={x}>{x}</option>)}</select></Field><Field label="فني"><select value={selectedTech} onChange={(e)=>setSelectedTech(e.target.value)} style={inputStyle()}><option value="">كل الفنيين</option>{db.technicians.map((t)=><option key={t.id} value={t.id}>{t.name}</option>)}</select></Field></div>
      {can?.review && <Btn bg={C.purple} onClick={makePlanSnapshot} style={{width:"100%", padding:10, marginBottom:8}}>حفظ Snapshot للجدولة والتعارضات</Btn>}
    </Section>
    {view === "العمل اليومي" && <Section title={"أوامر العمل حسب الفلتر ("+visible.length+")"}>{visible.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={["Asset: "+nameOf("assets", w.assetId), "Planned: "+(w.plannedStart||"—"), "End: "+(w.plannedEnd||"—"), "Technicians: "+(woAssignedTechIds(w).map((id)=>nameOf("technicians", id)).join("، ")||"—"), "Cost: "+money(woCost(w).total)].join(" · ")} badge={{text:w.status, color:WO_COLORS[w.status]||C.steel}} /></div>)}{visible.length===0 && <Empty text="لا توجد أوامر ضمن الفلتر."/>}</Section>}
    {view === "الجدولة" && <><Section title="محرك الجدولة المتقدم"><div style={card()}><Row main="Capacity-aware Scheduling Engine" sub="يفحص السعة والورديات والمواد والتعارضات ويقترح فنيًا وموعدًا لكل أمر عمل." action={<Btn bg={C.purple} onClick={()=>setView("محرك الجدولة")}>فتح المحرك</Btn>} /></div></Section><Section title="Scheduling Board — اليوم والمتأخر">{["اليوم", "متأخر", "هذا الأسبوع"].map((bucket)=>{ const list = open.filter((w)=> bucket==="اليوم" ? (!w.plannedStart || daysUntil(w.plannedStart)===0) : bucket==="متأخر" ? (w.plannedEnd && daysUntil(w.plannedEnd)<0) : (w.plannedStart && daysUntil(w.plannedStart)>=0 && daysUntil(w.plannedStart)<=7)); return <div key={bucket} style={card()}><Row main={bucket+" — "+list.length} sub={list.map((w)=>w.number).join("، ") || "—"}/></div>; })}</Section><Section title="Resource Capacity / Technician Load">{technicianLoad.map((x)=><div key={x.t.id} style={{...card(), borderRightColor:x.orders.length>5?C.red:x.orders.length>2?C.amber:C.green}}><Row main={x.t.name} sub={x.orders.length+" أوامر · " + (Math.round(x.hours*10)/10) + " ساعة تقديرية · " + (nameOf("workCenters", x.t.workCenterId)||"بدون مركز")} badge={{text:x.orders.length>5?"Overload":"OK", color:x.orders.length>5?C.red:C.green}} /></div>)}</Section></>}
    {view === "محرك الجدولة" && <>
      <Section title="محرك الجدولة المتقدم — Capacity / Skills / Materials">
        <div style={{display:"flex", gap:8, marginBottom:8}}>
          <Stat n={scheduleEngine.stats.candidateOrders} label="مرشح" color={C.blue}/>
          <Stat n={scheduleEngine.stats.recommendations} label="اقتراح" color={C.green}/>
          <Stat n={scheduleEngine.stats.blocked} label="موقوف" color={scheduleEngine.stats.blocked?C.red:C.steel}/>
          <Stat n={scheduleEngine.stats.avgUtilization + "%"} label="استغلال" color={C.purple}/>
        </div>
        <div style={{...card(), display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
          <Field label="أفق الجدولة بالأيام"><input type="number" min="1" max="45" value={scheduleHorizon} onChange={(e)=>setScheduleHorizon(Number(e.target.value || 7))} style={inputStyle()} /></Field>
          <Field label="طاقة الفني/اليوم"><input type="number" min="1" max="24" step="0.5" value={scheduleCapacity} onChange={(e)=>setScheduleCapacity(Number(e.target.value || 8))} style={inputStyle()} /></Field>
        </div>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:8}}>
          <Btn bg={C.green} onClick={()=>applyScheduleRecommendations(scheduleEngine.recommendations)} style={{padding:10}}>تطبيق أفضل الاقتراحات</Btn>
          <Btn bg={C.purple} onClick={saveScheduleEngineRun} style={{padding:10}}>حفظ خطة وجدول التعارضات</Btn>
        </div>
        {scheduleMessage && <div style={{...card(), background:"#ECFDF5", borderRightColor:C.green, color:C.green, fontWeight:900}}>{scheduleMessage}</div>}
        <div style={{...card(), fontSize:12.5, color:C.steel, lineHeight:1.7}}>المحرك يحسب أولوية الأمر، التاريخ المطلوب، توفر المواد، مركز العمل، طاقة الفني اليومية، الاستثناءات، والتعارضات. لا يغلق أو يغيّر حالة الأمر تلقائيًا؛ فقط يحدد التاريخ والفني ويكتب سجل تنفيذ.</div>
      </Section>
      <Section title={"اقتراحات الجدولة ("+scheduleEngine.recommendations.length+")"}>
        {scheduleEngine.recommendations.map((r)=><div key={r.id} style={{...card(), borderRightColor:r.confidence>=75?C.green:r.confidence>=55?C.amber:C.red}}>
          <Row main={r.workOrderNumber+" — "+r.title} sub={["الأصل: "+r.assetName, "الفني: "+r.technicianName, "التاريخ: "+r.date, "المدة: "+r.estimatedHours+" ساعة", "مركز العمل: "+r.requiredWorkCenterName, "المواد: "+r.materialStatus].join(" · ")} badge={{text:r.confidence+"%", color:r.confidence>=75?C.green:r.confidence>=55?C.amber:C.red}} />
          <div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.blue} onClick={()=>openWO(r.workOrderId)}>فتح الأمر</Btn><Btn bg={C.green} onClick={()=>applyScheduleRecommendations([r])}>تطبيق هذا الاقتراح</Btn></div>
          <div style={{fontSize:12, color:C.steel, marginTop:8}}>الأسباب: {(r.reasons || []).join("، ") || "—"}</div>
        </div>)}
        {scheduleEngine.recommendations.length===0 && <Empty text="لا توجد اقتراحات قابلة للتطبيق ضمن الأفق الحالي."/>}
      </Section>
      <Section title={"الأوامر الموقوفة عن الجدولة ("+scheduleEngine.blocked.length+")"}>
        {scheduleEngine.blocked.map((b)=><div key={b.id} style={{...card(), borderRightColor:C.red}}><Row main={b.workOrderNumber+" — "+b.title} sub={["الأصل: "+b.assetName, "المدة: "+b.estimatedHours+" ساعة", "مركز العمل: "+b.requiredWorkCenterName, "المواد: "+b.materialStatus, "المانع: "+(b.blockers||[]).join("، ")].join(" · ")} badge={{text:"Blocked", color:C.red}} /></div>)}
        {scheduleEngine.blocked.length===0 && <Empty text="لا توجد أوامر موقوفة."/>}
      </Section>
      <Section title="سعة الفنيين خلال أفق الجدولة">
        {scheduleEngine.capacityRows.map((r)=><div key={r.technicianId} style={{...card(), borderRightColor:r.utilization>100?C.red:r.utilization>85?C.amber:C.green}}><Row main={r.technicianName} sub={["مركز العمل: "+r.workCenterName, "الساعات: "+r.usedHours+" / "+r.capacityHours, "استغلال: "+r.utilization+"%"].join(" · ")} badge={{text:r.utilization>100?"Over":r.utilization>85?"High":"OK", color:r.utilization>100?C.red:r.utilization>85?C.amber:C.green}} /></div>)}
      </Section>
      <Section title={"تعارضات الجدولة ("+scheduleEngine.conflicts.length+")"}>
        {scheduleEngine.conflicts.map((c)=><div key={c.id} style={{...card(), borderRightColor:c.severity==="عال"?C.red:C.amber}}><Row main={c.type+" — "+(c.workOrderNumber || c.technicianName || "")} sub={["التاريخ: "+(c.date||"—"), c.usedHours ? "تحميل: "+c.usedHours+"/"+c.capacity : "", "السبب: "+(c.reason||"—")].filter(Boolean).join(" · ")} badge={{text:c.severity||"تحذير", color:c.severity==="عال"?C.red:C.amber}} /></div>)}
        {scheduleEngine.conflicts.length===0 && <Empty text="لا توجد تعارضات ضمن أفق الجدولة."/>}
      </Section>
    </>}
    {view === "الإسناد" && <Section title="Assignment Drawer مبسط">{visible.map((w)=><div key={w.id} style={card()}><Row main={w.number+" — "+w.title} sub={"الحالي: "+(woAssignedTechIds(w).map((id)=>nameOf("technicians", id)).join("، ")||"غير مسند")} /><div style={{display:"grid", gridTemplateColumns:"1fr auto", gap:8, marginTop:8}}><select onChange={(e)=>e.target.value && assignTech(w, e.target.value)} defaultValue="" style={inputStyle()}><option value="">اختر فني للإسناد/إعادة الإسناد</option>{db.technicians.map((t)=><option key={t.id} value={t.id}>{t.name} — {t.specialty || "فني"}</option>)}</select><Btn bg={C.amber} onClick={()=>setWOStatus(w, "معلق")}>Hold</Btn></div><div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.blue} onClick={()=>update("workOrders", w.id, { priority:"طارئ" })}>Emergency</Btn><Btn bg={C.green} onClick={()=>setWOStatus(w, w.status === "مسودة" ? "مُصدر" : "جاهز")}>Release/Ready</Btn></div></div>)}</Section>}
    {view === "المواد" && <Section title="Waiting Material Orders">{materialWaiting.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={(w.materials||[]).map((m)=>nameOf("items", m.itemId)+": مطلوب "+m.qty+" · مصروف "+(m.issuedQty||0)+" · مستخدم "+(m.usedQty||0)).join(" | ") || "لا مواد"} badge={{text:"Material Review", color:C.amber}} /></div>)}{materialWaiting.length===0 && <Empty text="لا توجد أوامر بانتظار مواد."/>}</Section>}
    {view === "المراجعة" && <Section title="Completed Pending Review">{open.filter((w)=>w.status==="بانتظار المراجعة").map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={["Checklist", "Labor", "Materials", "Failure", "Photos", "Trial Run"].join(" · ")} badge={{text:"Supervisor Review", color:C.blue}} /><div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.green} onClick={()=>setWOStatus(w, "مغلق", { reviewNotes:"Approved from Supervision Workbench" })}>Approve / Close</Btn><Btn bg={C.red} onClick={()=>setWOStatus(w, "مُعاد للتصحيح", { reviewNotes:"Rejected from Supervision Workbench" })}>Reject</Btn></div></div>)}{open.filter((w)=>w.status==="بانتظار المراجعة").length===0 && <Empty text="لا توجد أوامر بانتظار المراجعة."/>}</Section>}
    {view === "التعارضات" && <Section title="Conflict Preview / Qualification Check">{conflicts.map((c)=><div key={c.id} style={{...card(), borderRightColor:C.red}}><Row main={c.type} sub={["Date: "+c.date, "Technician: "+nameOf("technicians", c.technicianId), "Orders: "+(c.orders||[]).map((w)=>w.number).join("، "), c.operation ? "Operation: "+c.operation : ""].filter(Boolean).join(" · ")} badge={{text:"Conflict", color:C.red}} /></div>)}{conflicts.length===0 && <Empty text="لا توجد تعارضات جدول أو تأهيل مكتشفة."/>}</Section>}
    {view === "البحوث" && <Section title="Saved Searches"><div style={{...card(), display:"grid", gridTemplateColumns:"1fr auto", gap:8}}><input value={searchName} onChange={(e)=>setSearchName(e.target.value)} placeholder="اسم البحث المحفوظ" style={inputStyle()}/><Btn bg={C.green} onClick={saveSearch}>حفظ</Btn></div>{(db.supervisionSavedSearches||[]).map((s)=><div key={s.id} style={card()} onClick={()=>applySearch(s)}><Row main={s.name} sub={["Filter: "+(s.filter||"الكل"), s.technicianId ? "Technician: "+nameOf("technicians", s.technicianId) : "كل الفنيين", s.createdAt].join(" · ")} /></div>)}</Section>}
  </>;
}

/* ───────────────────────── محرك الجدولة المتقدم — v39 ───────────────────────── */
export function AdvancedSchedulingEngine({ ctx, openWO }) {
  const { db, save, update, nameOf, woAssignedTechIds, materialStatusOf, can, availableQty } = ctx;
  const [view, setView] = useState("المحرك");
  const [horizonDays, setHorizonDays] = useState(14);
  const [hoursPerTech, setHoursPerTech] = useState(8);
  const [selectedWorkCenter, setSelectedWorkCenter] = useState("");
  const [includeWaitingMaterial, setIncludeWaitingMaterial] = useState(false);
  const [strategy, setStrategy] = useState("الأولوية والموعد");
  const latestPlan = (db.schedulingPlans || []).slice().sort((a,b)=>String(b.createdAt||"").localeCompare(String(a.createdAt||"")))[0] || null;
  const [selectedPlanId, setSelectedPlanId] = useState(latestPlan?.id || "");
  const activePlan = (db.schedulingPlans || []).find((p)=>p.id === selectedPlanId) || latestPlan;
  const planLines = activePlan ? (db.schedulingPlanLines || []).filter((l)=>l.planId === activePlan.id) : [];
  const planConflicts = activePlan ? (db.schedulingConflicts || []).filter((c)=>c.planId === activePlan.id) : [];
  const open = db.workOrders.filter((w)=>ACTIVE_STATES.includes(w.status));
  const candidateStatuses = ["مسودة", "مُصدر", "جاهز", "بانتظار مواد", "معلق", "مُعاد للتصحيح", "متأخر", "استثناء"];
  const dateList = Array.from({ length: Math.max(1, Number(horizonDays || 1)) }, (_, i) => addDateDays(today(), i));
  const priorityScore = (w) => ({ "طارئ": 120, "حرجة": 115, "عالية": 90, "High": 90, "متوسطة": 55, "Medium": 55, "منخفضة": 25, "Low": 25 }[w.priority] || (w.type === "طارئ" ? 110 : w.type === "تصحيحي" ? 70 : 45));
  const workCenterOf = (w) => w.workCenterId || db.assets.find((a)=>a.id === w.assetId)?.workCenterId || (w.operations || []).find((o)=>o.workCenterId)?.workCenterId || "";
  const estimateHours = (w) => {
    const opHours = (w.operations || []).reduce((s,o)=> s + (Number(o.minutes || 0) / 60 || Number(o.plannedHours || 0) || Number(o.actualHours || 0) || 0), 0);
    if (opHours > 0) return Math.max(0.25, Math.round(opHours * 10) / 10);
    const wd = db.workDefs.find((d)=>d.id === w.workDefId);
    return Math.max(0.25, Number(w.estimatedHours || wd?.estimatedHours || w.durationHours || 2));
  };
  const materialBlocked = (w) => {
    const status = String(materialStatusOf ? materialStatusOf(w) : "");
    if (status.includes("Waiting") || status.includes("نقص")) return true;
    return (w.materials || []).some((m)=> Number(availableQty ? availableQty(m.itemId, m.warehouseId) : 999999) < Number(m.qty || 0));
  };
  const dayName = (d) => {
    const n = parseDateValue(d)?.getDay?.();
    return ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"][Number.isFinite(n) ? n : 0];
  };
  const shiftCapacity = (tech, date) => {
    const stop = (db.resourceExceptions || []).find((e)=> e.date === date && e.exceptionType === "توقف" && (!e.workCenterId || e.workCenterId === tech.workCenterId));
    if (stop) return 0;
    const day = dayName(date);
    const shifts = (db.shifts || []).filter((s)=> !s.inactiveOn && (!s.days || String(s.days).includes(day)));
    let cap = Number(hoursPerTech || 8);
    if (shifts.length) {
      const s = shifts[0];
      const [sh, sm] = String(s.startTime || "08:00").split(":").map(Number);
      const [eh, em] = String(s.endTime || "17:00").split(":").map(Number);
      const h = ((eh || 17) + (em || 0) / 60) - ((sh || 8) + (sm || 0) / 60);
      if (h > 0 && h < 24) cap = Math.min(cap, h);
    } else if (["الجمعة"].includes(day)) cap = Math.min(cap, 0);
    const extra = (db.resourceExceptions || []).filter((e)=> e.date === date && e.exceptionType === "إتاحة إضافية" && (!e.workCenterId || e.workCenterId === tech.workCenterId));
    cap += extra.reduce((s,e)=> {
      const [sh, sm] = String(e.startTime || "").split(":").map(Number); const [eh, em] = String(e.endTime || "").split(":").map(Number);
      const h = ((eh || 0) + (em || 0) / 60) - ((sh || 0) + (sm || 0) / 60);
      return s + (h > 0 ? h : 1);
    }, 0);
    return Math.max(0, Math.round(cap * 10) / 10);
  };
  const timeFromHours = (h) => {
    const total = Math.max(0, Math.round(h * 60));
    return pad2(Math.floor(total / 60) % 24) + ":" + pad2(total % 60);
  };
  const buildSchedulingPlan = () => {
    if (!can.review && !can.admin) return alert("محرك الجدولة متاح للمشرف أو المدير فقط.");
    const planId = uid();
    const createdAt = now();
    const baseTechs = db.technicians.filter((t)=> t.active !== false);
    const load = {};
    const ensureLoad = (techId, date) => {
      const key = techId + "|" + date;
      if (!load[key]) load[key] = { hours:0, orders:[], capacity: shiftCapacity(baseTechs.find((t)=>t.id === techId) || {}, date) };
      return load[key];
    };
    const fixed = open.filter((w)=> w.status === "قيد التنفيذ" || w.status === "بانتظار المراجعة" || w.scheduleLocked);
    fixed.forEach((w)=> {
      const d = w.plannedStart || today();
      woAssignedTechIds(w).forEach((tid)=> { const l = ensureLoad(tid, d); l.hours += estimateHours(w); l.orders.push(w.number); });
    });
    const candidates = open
      .filter((w)=>candidateStatuses.includes(w.status))
      .filter((w)=>!selectedWorkCenter || workCenterOf(w) === selectedWorkCenter)
      .sort((a,b)=> {
        if (strategy === "أقرب موعد") return daysUntil(a.plannedEnd || a.plannedStart || today()) - daysUntil(b.plannedEnd || b.plannedStart || today());
        if (strategy === "أقل حمل") return estimateHours(a) - estimateHours(b);
        return (priorityScore(b) - priorityScore(a)) || (daysUntil(a.plannedEnd || a.plannedStart || today()) - daysUntil(b.plannedEnd || b.plannedStart || today()));
      });
    const lines = [];
    const conflicts = [];
    candidates.forEach((w) => {
      const duration = estimateHours(w);
      const wc = workCenterOf(w);
      const matBlocked = materialBlocked(w);
      const due = w.plannedEnd || w.plannedStart || addDateDays(today(), priorityScore(w) >= 100 ? 0 : priorityScore(w) >= 80 ? 2 : 7);
      const reasons = [];
      if (priorityScore(w) >= 100) reasons.push("أولوية طارئة");
      if (daysUntil(due) < 0) reasons.push("متأخر");
      if (matBlocked) reasons.push("مواد غير مكتملة");
      const currentTechIds = woAssignedTechIds(w);
      if (matBlocked && !includeWaitingMaterial) {
        const cid = uid();
        lines.push({ id:uid(), planId, workOrderId:w.id, workOrderNumber:w.number, assetId:w.assetId, workCenterId:wc, currentStart:w.plannedStart || "", suggestedStart:"", suggestedEnd:"", suggestedStartTime:"", suggestedEndTime:"", suggestedTechnicianId:"", durationHours:duration, priority:w.priority || "", status:"محجوب", materialStatus:materialStatusOf ? materialStatusOf(w) : "", reasons:[...reasons, "لم يتم تضمين أوامر انتظار المواد"].join(" · "), conflictId:cid, createdAt });
        conflicts.push({ id:cid, planId, workOrderId:w.id, type:"نقص مواد", severity:"عال", status:"مفتوح", message:"لا تتم جدولة الأمر قبل اكتمال/اعتماد المواد.", createdAt });
        return;
      }
      const techPool = baseTechs.filter((t)=> !wc || !t.workCenterId || t.workCenterId === wc || currentTechIds.includes(t.id));
      const pool = techPool.length ? techPool : baseTechs;
      let best = null;
      const searchDates = dateList.slice().sort((a,b)=> {
        const da = Math.abs(daysUntil(a) - Math.max(0, daysUntil(due))); const dbb = Math.abs(daysUntil(b) - Math.max(0, daysUntil(due)));
        return da - dbb;
      });
      pool.forEach((tech)=> searchDates.forEach((date)=> {
        const l = ensureLoad(tech.id, date);
        const cap = Math.max(0, l.capacity || 0);
        const available = cap - l.hours;
        const wcMatch = !wc || !tech.workCenterId || tech.workCenterId === wc;
        const skillMatch = !w.type || String(tech.specialty || "").includes("كهرب") === String((w.operations||[]).map((o)=>o.name).join(" ")).includes("كهرب") || true;
        let score = 0;
        score += priorityScore(w);
        score += wcMatch ? 25 : -35;
        score += skillMatch ? 8 : 0;
        score += Math.max(-25, 25 - Math.abs(daysUntil(date) - Math.max(0, daysUntil(due))) * 3);
        score += Math.max(-50, available * 4);
        if (currentTechIds.includes(tech.id)) score += 12;
        if (available < duration) score -= (duration - available) * 20;
        if (cap <= 0) score -= 100;
        const option = { tech, date, load:l, cap, available, score, overload: Math.max(0, duration - available), wcMatch };
        if (!best || option.score > best.score) best = option;
      }));
      if (!best || !best.tech) {
        const cid = uid();
        lines.push({ id:uid(), planId, workOrderId:w.id, workOrderNumber:w.number, assetId:w.assetId, workCenterId:wc, currentStart:w.plannedStart || "", suggestedStart:"", suggestedEnd:"", suggestedTechnicianId:"", durationHours:duration, priority:w.priority || "", status:"بلا فني", reasons:"لا يوجد فني متاح ضمن الأفق", conflictId:cid, createdAt });
        conflicts.push({ id:cid, planId, workOrderId:w.id, type:"لا يوجد فني", severity:"عال", status:"مفتوح", message:"لا يوجد فني متاح/مؤهل ضمن أفق الجدولة.", createdAt });
        return;
      }
      const startHour = 8 + best.load.hours;
      best.load.hours += duration;
      best.load.orders.push(w.number);
      const lineStatus = best.overload > 0 || !best.wcMatch || best.cap <= 0 ? "تعارض" : "مقترح";
      const cid = lineStatus === "تعارض" ? uid() : "";
      const line = { id:uid(), planId, workOrderId:w.id, workOrderNumber:w.number, assetId:w.assetId, workCenterId:wc, currentStart:w.plannedStart || "", suggestedStart:best.date, suggestedEnd:best.date, suggestedStartTime:timeFromHours(startHour), suggestedEndTime:timeFromHours(startHour + duration), suggestedTechnicianId:best.tech.id, suggestedTechnicianName:best.tech.name, durationHours:duration, priority:w.priority || "", score:Math.round(best.score), status:lineStatus, materialStatus:materialStatusOf ? materialStatusOf(w) : "", capacityHours:best.cap, loadAfterHours:Math.round(best.load.hours * 10) / 10, reasons:[...reasons, best.wcMatch ? "مركز عمل مناسب" : "تعارض مركز عمل", "السعة المتاحة " + Math.round(best.available * 10) / 10 + "س"].join(" · "), conflictId:cid, createdAt };
      lines.push(line);
      if (cid) conflicts.push({ id:cid, planId, workOrderId:w.id, technicianId:best.tech.id, date:best.date, type:best.overload > 0 ? "تجاوز سعة" : "تأهيل/مركز عمل", severity:best.overload > 2 ? "عال" : "متوسط", status:"مفتوح", message:(best.overload > 0 ? "العمل يتجاوز سعة اليوم بـ " + Math.round(best.overload * 10) / 10 + " ساعة." : "الفني ليس من نفس مركز العمل."), createdAt });
    });
    const capacityRows = [];
    Object.entries(load).forEach(([key, v]) => {
      const [techId, date] = key.split("|"); const tech = baseTechs.find((t)=>t.id === techId);
      capacityRows.push({ id:uid(), planId, at:date, technicianId:techId, technicianName:tech?.name || "", workCenterId:tech?.workCenterId || "", capacityHours:Math.round((v.capacity || 0) * 10) / 10, scheduledHours:Math.round((v.hours || 0) * 10) / 10, utilizationPct:v.capacity ? Math.round((v.hours / v.capacity) * 100) : 0, orders:(v.orders || []).join(", ") });
    });
    const plan = { id:planId, name:"خطة جدولة " + today(), createdAt, createdBy:"Scheduling Engine", status:"مسودة", horizonDays:Number(horizonDays || 0), hoursPerTech:Number(hoursPerTech || 0), strategy, workCenterId:selectedWorkCenter, totalOrders:candidates.length, proposed:lines.filter((l)=>l.status === "مقترح").length, blocked:lines.filter((l)=>l.status === "محجوب").length, conflicts:conflicts.length };
    save({ ...db,
      schedulingPlans:[...(db.schedulingPlans || []), plan],
      schedulingPlanLines:[...(db.schedulingPlanLines || []).filter((l)=>l.planId !== planId), ...lines],
      schedulingConflicts:[...(db.schedulingConflicts || []).filter((c)=>c.planId !== planId), ...conflicts],
      resourceCapacitySnapshots:[...(db.resourceCapacitySnapshots || []), ...capacityRows],
      supervisionScheduleSnapshots:[...(db.supervisionScheduleSnapshots || []), { id:uid(), at:today(), horizonDays:Number(horizonDays || 0), total:candidates.length, conflicts:conflicts.length, createdBy:"Advanced Scheduling Engine", planId }]
    });
    setSelectedPlanId(planId);
  };
  const applyPlan = (onlyLineId = "") => {
    const selected = onlyLineId ? planLines.filter((l)=>l.id === onlyLineId) : planLines.filter((l)=>l.status === "مقترح");
    if (!selected.length) return alert("لا توجد أسطر مقترحة قابلة للتطبيق.");
    const byId = Object.fromEntries(selected.map((l)=>[l.workOrderId, l]));
    const appliedAt = now();
    const nextWos = db.workOrders.map((w)=> {
      const l = byId[w.id];
      if (!l) return w;
      const techId = l.suggestedTechnicianId;
      const assignments = techId ? [...(w.assignments || []).filter((a)=>a.technicianId !== techId), { id:uid(), technicianId:techId, role:"فني", status:"مسند", assignedAt:l.suggestedStart, assignedBy:"Scheduling Engine" }] : (w.assignments || []);
      const ops = (w.operations || []).map((op)=> op.assigneeId ? op : { ...op, assigneeId:techId, scheduledDate:l.suggestedStart });
      return { ...w, plannedStart:l.suggestedStart, plannedEnd:l.suggestedEnd || l.suggestedStart, plannedStartTime:l.suggestedStartTime, plannedEndTime:l.suggestedEndTime, workCenterId:w.workCenterId || l.workCenterId, scheduleStatus:"مجدول آليًا", scheduleScore:l.score || 0, schedulePlanId:l.planId, assignments, operations:ops, _cmmsAssignedTechIds:[...new Set([...(w._cmmsAssignedTechIds || []), ...assignments.map((a)=>a.technicianId)].filter(Boolean))], execLog:[...(w.execLog || []), { action:"تطبيق خطة الجدولة: " + (l.suggestedTechnicianName || nameOf("technicians", techId)) + " في " + l.suggestedStart, at:appliedAt, by:"Scheduling Engine" }] };
    });
    const appliedAssignments = selected.map((l)=>({ id:uid(), planId:l.planId, workOrderId:l.workOrderId, technicianId:l.suggestedTechnicianId, scheduledDate:l.suggestedStart, startTime:l.suggestedStartTime, endTime:l.suggestedEndTime, durationHours:l.durationHours, appliedAt }));
    save({ ...db,
      workOrders: nextWos,
      schedulingPlans:(db.schedulingPlans || []).map((p)=>p.id === activePlan?.id ? { ...p, status:"مطبق", appliedAt, appliedLines:selected.length } : p),
      schedulingPlanLines:(db.schedulingPlanLines || []).map((l)=> selected.some((x)=>x.id === l.id) ? { ...l, status:"مطبق", appliedAt } : l),
      schedulingAssignments:[...(db.schedulingAssignments || []), ...appliedAssignments],
      workOrderScheduleConflicts:[...(db.workOrderScheduleConflicts || []), ...planConflicts.map((c)=>({ id:uid(), planId:c.planId, workOrderId:c.workOrderId, type:c.type, severity:c.severity, status:c.status, message:c.message, at:appliedAt }))]
    });
  };
  const resolveConflict = (c, status) => {
    save({ ...db, schedulingConflicts:(db.schedulingConflicts || []).map((x)=>x.id === c.id ? { ...x, status, resolvedAt:now(), resolvedBy:"Supervisor" } : x) });
  };
  const exportPlanCsv = () => {
    const headers = ["WO", "Asset", "Technician", "Date", "Start", "End", "Hours", "Status", "Reasons"];
    const rows = planLines.map((l)=>[l.workOrderNumber, nameOf("assets", l.assetId), l.suggestedTechnicianName || nameOf("technicians", l.suggestedTechnicianId), l.suggestedStart, l.suggestedStartTime, l.suggestedEndTime, l.durationHours, l.status, l.reasons]);
    const csv = "\uFEFF" + [headers, ...rows].map((r)=>r.map((x)=>'"'+String(x||"").replace(/"/g,'""')+'"').join(",")).join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type:"text/csv;charset=utf-8" })); a.download = "cmms-schedule-plan-" + today() + ".csv"; a.click();
  };
  const capacityByTech = db.technicians.map((t)=> {
    const linesForTech = planLines.filter((l)=>l.suggestedTechnicianId === t.id && ["مقترح", "مطبق", "تعارض"].includes(l.status));
    const hours = linesForTech.reduce((s,l)=>s + Number(l.durationHours || 0), 0);
    return { t, orders:linesForTech.length, hours:Math.round(hours * 10) / 10, cap:Math.round(dateList.reduce((s,d)=>s + shiftCapacity(t, d), 0) * 10) / 10 };
  }).sort((a,b)=>b.hours-a.hours);
  const scheduleByDate = dateList.map((d)=>({ date:d, lines:planLines.filter((l)=>l.suggestedStart === d) })).filter((x)=>x.lines.length);
  const tabs = ["المحرك", "الخطة", "السعة", "التعارضات", "السجل"];
  return <>
    <div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:10}}>{tabs.map((t)=><Chip key={t} active={view===t} onClick={()=>setView(t)}>{t}</Chip>)}</div>
    <Section title="Advanced Scheduling Engine">
      <div style={{display:"flex", gap:8, marginBottom:10}}><Stat n={open.length} label="أوامر مفتوحة" color={C.blue}/><Stat n={planLines.filter((l)=>l.status === "مقترح").length} label="مقترح" color={C.green}/><Stat n={planConflicts.filter((c)=>c.status !== "مغلق").length} label="تعارض" color={planConflicts.length?C.red:C.green}/><Stat n={capacityByTech.filter((x)=>x.cap && x.hours > x.cap).length} label="Overload" color={C.amber}/></div>
      <div style={{...card(), display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
        <Field label="أفق الجدولة بالأيام"><input type="number" min="1" max="60" value={horizonDays} onChange={(e)=>setHorizonDays(Number(e.target.value || 1))} style={inputStyle()} /></Field>
        <Field label="سعة الفني اليومية"><input type="number" min="1" max="24" value={hoursPerTech} onChange={(e)=>setHoursPerTech(Number(e.target.value || 8))} style={inputStyle()} /></Field>
        <Field label="مركز العمل"><select value={selectedWorkCenter} onChange={(e)=>setSelectedWorkCenter(e.target.value)} style={inputStyle()}><option value="">كل مراكز العمل</option>{db.workCenters.map((wc)=><option key={wc.id} value={wc.id}>{wc.name}</option>)}</select></Field>
        <Field label="استراتيجية الجدولة"><select value={strategy} onChange={(e)=>setStrategy(e.target.value)} style={inputStyle()}><option>الأولوية والموعد</option><option>أقرب موعد</option><option>أقل حمل</option></select></Field>
      </div>
      <label style={{...card(), display:"flex", alignItems:"center", gap:8, fontWeight:900}}><input type="checkbox" checked={includeWaitingMaterial} onChange={(e)=>setIncludeWaitingMaterial(e.target.checked)} /> تضمين أوامر انتظار المواد كخطة مشروطة</label>
      <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}><Btn bg={C.purple} onClick={buildSchedulingPlan} style={{padding:12}}>تحليل وبناء خطة</Btn><Btn bg={C.green} onClick={()=>applyPlan()} disabled={!planLines.some((l)=>l.status === "مقترح")} style={{padding:12}}>تطبيق الخطة المقترحة</Btn></div>
      {activePlan && <div style={{...card(), marginTop:10}}><Row main={activePlan.name || "خطة جدولة"} sub={["الحالة: "+activePlan.status, "الأفق: "+activePlan.horizonDays+" يوم", "المقترح: "+activePlan.proposed, "المحجوب: "+activePlan.blocked, "التعارضات: "+activePlan.conflicts].join(" · ")} action={<Btn bg={C.steel} onClick={exportPlanCsv}>CSV</Btn>} /></div>}
    </Section>
    {view === "الخطة" && <>
      <Section title="خطة الجدولة حسب اليوم">
        {scheduleByDate.map((g)=><div key={g.date} style={{...card(), borderRightColor:g.lines.some((l)=>l.status==="تعارض")?C.red:C.green}}>
          <Row main={fmt(g.date)+" — "+g.lines.length+" أوامر"} sub={g.lines.map((l)=>[l.suggestedStartTime, l.workOrderNumber, l.suggestedTechnicianName || nameOf("technicians", l.suggestedTechnicianId), l.durationHours+"س", l.status].filter(Boolean).join(" · ")).join(" | ")} />
        </div>)}
        {planLines.length===0 && <Empty text="اضغط تحليل وبناء خطة لإنشاء خطة جدولة."/>}
      </Section>
      <Section title="تفاصيل الأسطر">
        {planLines.map((l)=><div key={l.id} style={{...card(), borderRightColor:l.status==="مقترح"?C.green:l.status==="مطبق"?C.blue:l.status==="محجوب"?C.amber:C.red}} onClick={()=>l.workOrderId && openWO(l.workOrderId)}>
          <Row main={(l.workOrderNumber || "WO")+" — "+(nameOf("assets", l.assetId)||"")}
            sub={["فني: "+(l.suggestedTechnicianName || nameOf("technicians", l.suggestedTechnicianId)), "موعد: "+(l.suggestedStart||"—")+" "+(l.suggestedStartTime||""), "مدة: "+l.durationHours+"س", "Score: "+(l.score||0), l.reasons].filter(Boolean).join(" · ")}
            badge={{text:l.status, color:l.status==="مقترح"?C.green:l.status==="مطبق"?C.blue:l.status==="محجوب"?C.amber:C.red}}
            action={l.status === "مقترح" ? <Btn bg={C.green} onClick={()=>applyPlan(l.id)}>تطبيق</Btn> : null} />
        </div>)}
      </Section>
    </>}
    {view === "السعة" && <Section title="Capacity / Utilization Matrix">{capacityByTech.map((x)=><div key={x.t.id} style={{...card(), borderRightColor:x.cap && x.hours > x.cap ? C.red : x.hours > x.cap * .8 ? C.amber : C.green}}><Row main={x.t.name} sub={[nameOf("workCenters", x.t.workCenterId), "أوامر: "+x.orders, "ساعات مجدولة: "+x.hours, "السعة: "+x.cap, "الاستخدام: "+(x.cap?Math.round((x.hours/x.cap)*100):0)+"%"].join(" · ")} badge={{text:x.cap && x.hours > x.cap ? "Over" : "OK", color:x.cap && x.hours > x.cap ? C.red : C.green}} /></div>)}</Section>}
    {view === "التعارضات" && <Section title="Conflict Preview / Constraint Violations">{planConflicts.map((c)=><div key={c.id} style={{...card(), borderRightColor:c.status==="مغلق"?C.green:C.red}}><Row main={c.type+" — "+(c.severity || "")} sub={[c.message, c.date ? "التاريخ: "+c.date : "", c.technicianId ? "الفني: "+nameOf("technicians", c.technicianId) : "", c.workOrderId ? "الأمر: "+((db.workOrders.find((w)=>w.id===c.workOrderId)||{}).number || c.workOrderId) : "", "الحالة: "+c.status].filter(Boolean).join(" · ")} action={<div style={{display:"flex", gap:6}}><Btn bg={C.green} onClick={()=>resolveConflict(c, "مغلق")}>إغلاق</Btn><Btn bg={C.amber} onClick={()=>resolveConflict(c, "استثناء معتمد")}>استثناء</Btn></div>} /></div>)}{planConflicts.length===0 && <Empty text="لا توجد تعارضات في الخطة الحالية."/>}</Section>}
    {view === "السجل" && <Section title="سجل خطط الجدولة">{(db.schedulingPlans || []).slice().sort((a,b)=>String(b.createdAt||"").localeCompare(String(a.createdAt||""))).map((p)=><div key={p.id} style={{...card(), borderRightColor:p.status==="مطبق"?C.green:C.purple}} onClick={()=>setSelectedPlanId(p.id)}><Row main={p.name || "خطة جدولة"} sub={[p.createdAt, "Status: "+p.status, "Horizon: "+p.horizonDays, "Proposed: "+p.proposed, "Conflicts: "+p.conflicts].filter(Boolean).join(" · ")} badge={{text:selectedPlanId===p.id?"محدد":p.status, color:selectedPlanId===p.id?C.blue:(p.status==="مطبق"?C.green:C.steel)}} /></div>)}</Section>}
  </>;
}


/* ───────────────────────── توقعات الصيانة المتقدمة ───────────────────────── */
export function Forecast({ ctx, programDue, generateWO }) {
  const { db, save, nameOf, programAssets, ltd, utilRate, can } = ctx;
  const [horizon, setHorizon] = useState(30);
  const [view, setView] = useState("التوقعات");
  const addDays = (base, n) => addDateDays(base || today(), Number(n || 0));
  const forecastForProgram = (p) => {
    const assets = programAssets(p);
    const info = programDue(p);
    const rows = [];
    if (!assets.length) rows.push({ program:p, asset:null, status:"Invalid", reason:"لا توجد أصول متأثرة", dueDate:info.nextDate || today(), remaining:null });
    assets.forEach((asset) => {
      let dueDate = info.nextDate || today(); let remaining = null; let currentMeter = null; let dueAt = null;
      let alert = info.soon ? "Maintenance due soon" : "OK";
      if (p.method === "فاصل عداد") {
        const am = db.assetMeters.find((m)=>m.id === p.assetMeterId) || db.assetMeters.find((m)=>m.assetId === asset.id && (!p.assetMeterId || m.id === p.assetMeterId));
        if (am) {
          currentMeter = ltd ? ltd(am) : 0;
          dueAt = Number(p.lastMeterValue || 0) + Number(p.interval || 0);
          remaining = Math.max(0, dueAt - currentMeter);
          const rate = Number(utilRate ? utilRate(am) : 0) || Number(am.estDailyRate || 0) || 1;
          dueDate = addDays(today(), Math.ceil(remaining / Math.max(rate, 0.01)));
          alert = remaining <= Number(p.interval || 0) * 0.1 ? "Maintenance due soon" : "OK";
        } else alert = "Invalid: meter missing";
      }
      const dLeft = daysUntil(dueDate);
      const status = alert.startsWith("Invalid") ? "Invalid" : dLeft <= 0 ? "Due" : dLeft <= Number(horizon) ? "Forecast" : "Future";
      rows.push({ id:"FC-"+p.id+"-"+asset.id+"-"+dueDate, program:p, asset, programId:p.id, assetId:asset.id, workDefId:p.workDefId || "", programName:p.name, assetName:asset.name, dueDate, remaining, currentMeter, dueAt, alert, status, risk: asset.critical || dLeft <= 0 ? "عال" : dLeft <= 7 ? "متوسط" : "منخفض" });
    });
    return rows;
  };
  const allLines = db.programs.flatMap(forecastForProgram).sort((a,b)=>String(a.dueDate).localeCompare(String(b.dueDate)));
  const visible = allLines.filter((l)=> l.status !== "Future");
  const validations = [];
  allLines.forEach((l)=>{
    if (!l.assetId) validations.push({ id:uid(), programId:l.programId || l.program?.id, assetId:"", severity:"حرج", message:l.reason || "لا توجد أصول للبرنامج" });
    if (l.program && !l.program.workDefId) validations.push({ id:uid(), programId:l.program.id, assetId:l.assetId || "", severity:"عال", message:"برنامج بدون Work Definition" });
    if (l.asset && (l.asset.active === false || l.asset.allowPrograms === false)) validations.push({ id:uid(), programId:l.program.id, assetId:l.asset.id, severity:"عال", message:"الأصل غير نشط أو لا يسمح بالبرامج" });
    if (l.program?.method === "فاصل عداد" && l.alert === "Invalid: meter missing") validations.push({ id:uid(), programId:l.program.id, assetId:l.assetId || "", severity:"حرج", message:"برنامج عداد بدون عداد صالح" });
    const dup = db.workOrders.some((w)=>ACTIVE_STATES.includes(w.status) && w.programId === l.programId && w.assetId === l.assetId);
    if (dup) validations.push({ id:uid(), programId:l.programId, assetId:l.assetId, severity:"متوسط", message:"يوجد أمر عمل مفتوح لنفس البرنامج والأصل" });
  });
  const saveForecast = () => { const runId = uid(); const rows = visible.map((l)=>({ id:l.id, runId, programId:l.programId, assetId:l.assetId, workDefId:l.workDefId, dueDate:l.dueDate, status:l.status, risk:l.risk, alert:l.alert, currentMeter:l.currentMeter, dueAt:l.dueAt, remaining:l.remaining, generatedAt:now(), suppressed:false })); save({ ...db, maintenanceForecasts:[...(db.maintenanceForecasts || []).filter((x)=>!rows.some((r)=>r.id===x.id)), ...rows], forecastRuns:[...(db.forecastRuns || []), { id:runId, at:now(), horizonDays:Number(horizon), lines:rows.length, due:rows.filter((x)=>x.status==="Due").length, warnings:validations.length }], forecastValidationIssues:[...(db.forecastValidationIssues || []), ...validations.map((v)=>({ ...v, runId, at:now() }))] }); };
  const suppress = (line, reason="Suppressed by planner") => save({ ...db, maintenanceForecasts:[...(db.maintenanceForecasts || []), { id:line.id, programId:line.programId, assetId:line.assetId, dueDate:line.dueDate, status:"Suppressed", risk:line.risk, alert:line.alert, suppressed:true, suppressReason:reason, generatedAt:now() }], forecastSuppressionRules:[...(db.forecastSuppressionRules || []), { id:uid(), programId:line.programId, assetId:line.assetId, dueDate:line.dueDate, reason, at:now() }] });
  const generateFromLine = (line) => { if (!line.program) return; if (db.workOrders.some((w)=>ACTIVE_STATES.includes(w.status) && w.programId === line.programId && w.assetId === line.assetId)) return alert("يوجد أمر عمل مفتوح لهذا البرنامج والأصل."); generateWO(line.program); };
  const tabs = ["التوقعات", "التحقق", "المحفوظة", "Merge/Suppress"];
  return <>
    <div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:10}}>{tabs.map((t)=><Chip key={t} active={view===t} onClick={()=>setView(t)}>{t}</Chip>)}</div>
    <Section title="Advanced Maintenance Forecast"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={visible.length} label="Forecast Lines" color={C.blue}/><Stat n={visible.filter((l)=>l.status==="Due").length} label="Due" color={C.red}/><Stat n={validations.length} label="Validation Issues" color={validations.length?C.amber:C.green}/><Stat n={(db.maintenanceForecasts||[]).length} label="Saved" color={C.purple}/></div><div style={{...card(), display:"grid", gridTemplateColumns:"1fr auto", gap:8}}><Field label="Forecast Horizon بالأيام"><input type="number" value={horizon} onChange={(e)=>setHorizon(Number(e.target.value||30))} style={inputStyle()}/></Field>{can?.manage && <Btn bg={C.green} onClick={saveForecast} style={{alignSelf:"end", marginBottom:11}}>Generate / Validate</Btn>}</div></Section>
    {view === "التوقعات" && <Section title="Forecast Lines">{visible.map((l)=><div key={l.id} style={{...card(), borderRightColor:l.status==="Due"?C.red:l.alert.includes("soon")?C.amber:C.green}}><Row main={(l.programName || l.program?.name || "Program") + " — " + (l.assetName || "No asset")} sub={["Due: "+fmt(l.dueDate), l.remaining != null ? "Remaining: "+l.remaining : "", l.currentMeter != null ? "Current Meter: "+l.currentMeter : "", l.dueAt != null ? "PM Due: "+l.dueAt : "", l.alert].filter(Boolean).join(" · ")} badge={{text:l.status, color:l.status==="Due"?C.red:l.status==="Forecast"?C.amber:C.steel}} action={l.status !== "Invalid" && <Btn bg={C.orange} onClick={()=>generateFromLine(l)}>Generate WO</Btn>} /></div>)}{visible.length===0 && <Empty text="لا توجد توقعات ضمن الأفق الحالي."/>}</Section>}
    {view === "التحقق" && <Section title="Forecast Validation">{validations.map((v)=><div key={v.id} style={{...card(), borderRightColor:v.severity==="حرج"?C.red:C.amber}}><Row main={v.message} sub={["Program: "+nameOf("programs", v.programId), v.assetId ? "Asset: "+nameOf("assets", v.assetId) : "No asset"].join(" · ")} badge={{text:v.severity, color:v.severity==="حرج"?C.red:C.amber}} /></div>)}{validations.length===0 && <Empty text="التحقق ناجح: لا توجد مشاكل في التوقعات الحالية."/>}</Section>}
    {view === "المحفوظة" && <><Section title="Forecast Runs">{(db.forecastRuns||[]).slice().reverse().map((r)=><div key={r.id} style={card()}><Row main={r.at} sub={"Horizon: "+r.horizonDays+" days · Lines: "+r.lines+" · Due: "+r.due+" · Warnings: "+r.warnings}/></div>)}{!(db.forecastRuns||[]).length && <Empty text="لم يتم حفظ أي تشغيل توقعات بعد."/>}</Section><Section title="Saved Maintenance Forecasts">{(db.maintenanceForecasts||[]).slice().reverse().map((f)=><div key={f.id} style={card()}><Row main={nameOf("programs", f.programId)+" — "+nameOf("assets", f.assetId)} sub={["Due: "+fmt(f.dueDate), f.status, f.suppressReason].filter(Boolean).join(" · ")} badge={{text:f.suppressed?"Suppressed":(f.status||"—"), color:f.suppressed?C.steel:C.blue}} /></div>)}</Section></>}
    {view === "Merge/Suppress" && <Section title="Suppress / Merge Controls">{visible.map((l)=><div key={l.id} style={card()}><Row main={(l.programName || "Program")+" — "+(l.assetName || "Asset")} sub={"Due: "+fmt(l.dueDate)+" · Risk: "+l.risk} /><div style={{display:"flex", gap:8, marginTop:8}}><Btn bg={C.steel} onClick={()=>suppress(l)}>Suppress</Btn><Btn bg={C.purple} onClick={()=>save({ ...db, forecastMergeGroups:[...(db.forecastMergeGroups||[]), { id:uid(), at:now(), programId:l.programId, assetId:l.assetId, dueDate:l.dueDate, rule:"Merge compatible PM lines for same asset/date" }] })}>Mark for Merge</Btn></div></div>)}</Section>}
  </>;
}

/* ───────────────────────── العمليات القياسية بخطوات (وثيقة التنفيذ §Standard Operation) ───────────────────────── */
/* ───────────────────────── مكتبة العمليات القياسية (ف7) ───────────────────────── */
