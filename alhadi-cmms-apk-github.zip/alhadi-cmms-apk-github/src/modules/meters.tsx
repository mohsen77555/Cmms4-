import { useState } from "react";
import { C, today } from "../core/appCore";
import { Btn, Chip, Empty, Field, Row, Section, Sheet, card, delBtn, input } from "../components/ui";
import { FormSheet } from "./crud";

export function Meters({ ctx }) {
  const { db, nameOf, add, update, remove, lastReading, ltd, currentValue, addReading, meterReadings, activeReadings, meterRows,
    calcUtilRate, utilRate, disableReading, can, pmCheckAfterReading, generateWO } = ctx;
  const [sub, setSub] = useState("meters");
  const [q, setQ] = useState("");
  const [tplForm, setTplForm] = useState(null); // null | "new" | tpl
  const [amForm, setAmForm] = useState(false);
  const [amSettings, setAmSettings] = useState(null);
  const [reading, setReading] = useState(null);
  const [history, setHistory] = useState(null);
  const [massTpl, setMassTpl] = useState(null);
  const tplLinked = (tplId) => db.assetMeters.filter((m) => m.templateId === tplId).length;
  const tplActive = (t) => (!t.startDate || t.startDate <= today()) && (!t.endDate || t.endDate >= today());
  const amActive = (m) => !m.endDate || m.endDate >= today();

  const tplSchema = (editing) => {
    const locked = editing && editing !== "new" && tplLinked(editing.id) > 0;
    return [
      { k: "name", label: "اسم القالب" }, { k: "code", label: "الكود (فريد)" },
      { k: "description", label: "الوصف" }, { k: "uom", label: "وحدة القياس (ساعة، كم، درجة…)" },
      { k: "meterType", label: "نوع العداد" + (locked ? " — مقفل (مرتبط بأصول)" : ""), type: "select", options: ["مستمر", "مقياس"] },
      { k: "readingType", label: "نوع القراءة" + (locked ? " — مقفل" : ""), type: "select", options: ["مطلق", "تغير"] },
      { k: "direction", label: "الاتجاه (المقياس = ثنائي)" + (locked ? " — مقفل" : ""), type: "select", options: ["تصاعدي", "تنازلي", "ثنائي"] },
      { k: "startDate", label: "بداية الفعالية", type: "date" }, { k: "endDate", label: "نهاية الفعالية", type: "date" },
      { k: "initial", label: "القيمة الابتدائية (تصبح أول قراءة عند الربط)", type: "number" },
      { k: "min", label: "حد أدنى (للتغير/المقياس)", type: "number" }, { k: "max", label: "حد أقصى (للتغير/المقياس)", type: "number" },
      { k: "recordAtWO", label: "التسجيل عند إكمال أمر العمل", type: "select", options: ["لا يسمح", "اختياري", "إلزامي"] },
      { k: "resetAllowed", label: "السماح بالتصفير (تصاعدي فقط)", type: "check" },
      { k: "resetValue", label: "قيمة التصفير (0 أو 1)", type: "number" },
      { k: "rolloverAllowed", label: "السماح بالتدوير Rollover (مستمر مطلق تصاعدي)", type: "check" },
      { k: "rolloverMax", label: "أقصى قيمة قبل التدوير", type: "number" },
      { k: "rolloverMin", label: "قيمة البداية بعد التدوير", type: "number" },
      { k: "allowSchedule", label: "يصلح لبرامج الصيانة (لا ينطبق على المقياس)", type: "check" },
      { k: "estDailyRate", label: "معدل الاستخدام اليومي المقدّر", type: "number" },
      { k: "readingsForRate", label: "عدد القراءات لحساب المعدل تلقائيًا (≥2)", type: "number" },
    ];
  };
  const validateTpl = (d, editing) => {
    if (!String(d.name || "").trim() || !String(d.code || "").trim()) return "الاسم والكود مطلوبان";
    if (db.meterTemplates.some((t) => t.code === d.code && t.id !== editing?.id)) return "الكود مستخدم — يجب أن يكون فريدًا";
    if (d.meterType === "مقياس") { d.direction = "ثنائي"; d.allowSchedule = false; d.resetAllowed = false; d.rolloverAllowed = false; }
    if (d.rolloverAllowed && !(d.meterType === "مستمر" && d.readingType === "مطلق" && d.direction === "تصاعدي"))
      return "التدوير: مستمر + مطلق + تصاعدي فقط (قاعدة ف5)";
    if (d.rolloverAllowed && !Number(d.rolloverMax)) return "حدد أقصى قيمة قبل التدوير";
    if (d.rolloverAllowed && d.resetAllowed && Number(d.rolloverMin || 0) !== Number(d.resetValue || 0))
      return "مع وجود تصفير: قيمة البداية بعد التدوير يجب أن تساوي قيمة التصفير";
    if (d.resetAllowed && d.direction !== "تصاعدي") return "التصفير للعدادات التصاعدية فقط";
    if (d.allowSchedule && d.direction !== "تصاعدي") return "يوصى ببرامج الصيانة للتصاعدي فقط — غيّر الاتجاه أو عطّل الخيار";
    if (editing && editing !== "new" && tplLinked(editing.id) > 0) {
      if (d.meterType !== editing.meterType || d.readingType !== editing.readingType || d.direction !== editing.direction)
        return "النوع/القراءة/الاتجاه مقفلة — القالب مرتبط بعدادات أصول";
    }
    return null;
  };
  const associate = (assetId, tpl, silent) => {
    if (db.assetMeters.some((m) => m.assetId === assetId && m.templateId === tpl.id && amActive(m))) return "موجود";
    const am = add("assetMeters", { assetId, templateId: tpl.id, initial: Number(tpl.initial || 0),
      recordAtWO: "", endDate: "", estDailyRate: "", readingsForRate: "" });
    if (tpl.initial !== "" && tpl.initial != null)
      add("readings", { assetMeterId: am.id, value: Number(tpl.initial), at: tpl.startDate || today(),
        source: "ربط", isReset: false, rollover: false, status: "أولية", comments: "قراءة أولية من القالب", workOrderId: "" });
    return "جديد";
  };

  const tpls = db.meterTemplates.filter((t) => !q ||
    ((t.name || "") + (t.code || "") + (t.description || "") + (t.uom || "") + (t.meterType || "") + (t.readingType || "")).includes(q));

  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        <Chip active={sub === "meters"} onClick={() => setSub("meters")}>عدادات الأصول</Chip>
        <Chip active={sub === "templates"} onClick={() => setSub("templates")}>القوالب</Chip>
      </div>

      {sub === "templates" && (<>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالكود/الاسم/الوصف/الوحدة/النوع…" style={{ ...input, marginBottom: 10 }} />
        {can.manage && <Btn bg={C.orange} onClick={() => setTplForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ قالب عداد</Btn>}
        {tpls.map((t) => (
          <div key={t.id} style={{ ...card(), opacity: tplActive(t) ? 1 : 0.6 }} onClick={() => can.manage && setTplForm(t)}>
            <Row main={(t.code ? t.code + " — " : "") + t.name + " (" + t.uom + ")"}
              badge={tplLinked(t.id) ? { text: tplLinked(t.id) + " أصل", color: C.blue } : undefined}
              sub={[t.meterType, t.readingType, t.direction, t.recordAtWO !== "لا يسمح" ? "عند الإكمال: " + t.recordAtWO : "",
                t.rolloverAllowed ? "تدوير عند " + t.rolloverMax : "", !tplActive(t) ? "غير فعّال" : ""].filter(Boolean).join(" · ")} />
            {can.manage && db.assetGroups.length > 0 && (
              <button onClick={(e) => { e.stopPropagation(); setMassTpl(t); }} style={{ ...delBtn, color: C.purple }}>ربط جماعي بمجموعة…</button>
            )}
          </div>
        ))}
        {tpls.length === 0 && <Empty text="أمثلة: عداد ساعات (مستمر/مطلق/تصاعدي)، عداد رحلة (+ تصفير)، حرارة (مقياس)." />}
      </>)}

      {sub === "meters" && (<>
        <Btn bg={C.orange} onClick={() => setAmForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ ربط عداد بأصل</Btn>
        {db.assetMeters.length === 0 && <Empty text="أنشئ قالبًا ثم اربطه — كل علاقة أصل×قالب لها تاريخ قراءات مستقل." />}
        {db.assetMeters.map((m) => {
          const tpl = db.meterTemplates.find((t) => t.id === m.templateId);
          const rows = meterRows(m);
          const last = rows[rows.length - 1];
          const cr = calcUtilRate(m), ur = utilRate(m);
          return (
            <div key={m.id} style={{ ...card(), opacity: amActive(m) ? 1 : 0.55 }}>
              <Row main={nameOf("assets", m.assetId) + " — " + (tpl?.name || "عداد")}
                badge={!amActive(m) ? { text: "معطل", color: C.steel } : undefined}
                sub={["المعروض: " + (last ? last.displayed : m.initial), "العمر LTD: " + ltd(m) + " " + (tpl?.uom || ""),
                  ur ? "معدل/يوم: " + (Math.round(ur * 100) / 100) + (cr != null ? " (محسوب)" : "") : ""].filter(Boolean).join(" · ")}
                action={amActive(m) ? <Btn bg={C.blue} onClick={() => setReading(m)}>قراءة</Btn> : null} />
              <div style={{ display: "flex", gap: 10, marginTop: 6, flexWrap: "wrap" }}>
                <button onClick={() => setHistory(m)} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>السجل ({activeReadings(m.id).length})</button>
                {can.manage && <button onClick={() => setAmSettings(m)} style={{ ...delBtn, color: C.purple, marginTop: 0 }}>إعدادات</button>}
                {can.admin && (
                  <button onClick={() => {
                    const ops = activeReadings(m.id).filter((r) => r.status !== "أولية");
                    if (ops.length) { alert("توجد قراءات تشغيلية — لا حذف؛ استخدم «إعدادات ← تاريخ نهاية» للتعطيل (قاعدة ف5)"); return; }
                    if (confirm("حذف عداد الأصل وقراءته الأولية؟")) {
                      meterReadings(m.id).forEach((r) => remove("readings", r.id));
                      remove("assetMeters", m.id);
                    }
                  }} style={{ ...delBtn, marginTop: 0 }}>حذف</button>
                )}
              </div>
            </div>
          );
        })}
      </>)}

      {tplForm && (
        <FormSheet title={tplForm === "new" ? "قالب عداد جديد" : "تعديل قالب — " + tplForm.name} onClose={() => setTplForm(null)} db={db}
          schema={tplSchema(tplForm)}
          initial={tplForm === "new"
            ? { meterType: "مستمر", readingType: "مطلق", direction: "تصاعدي", recordAtWO: "لا يسمح", resetAllowed: true, resetValue: 0, rolloverMin: 0, allowSchedule: true, startDate: today() }
            : tplForm}
          onDelete={tplForm !== "new" && can.admin && tplLinked(tplForm.id) === 0 ? () => { remove("meterTemplates", tplForm.id); setTplForm(null); } : undefined}
          onSave={(d) => {
            const err = validateTpl(d, tplForm);
            if (err) { alert(err); return; }
            tplForm === "new" ? add("meterTemplates", d) : update("meterTemplates", tplForm.id, d);
            setTplForm(null);
          }} />
      )}
      {amForm && (
        <FormSheet title="ربط عداد بأصل" onClose={() => setAmForm(false)} db={db}
          schema={[
            { k: "assetId", label: "الأصل", type: "select", from: "assets", fromLabel: (a) => a.number + " — " + a.name },
            { k: "templateId", label: "القالب (الفعّال فقط)", type: "select", from: "meterTemplates",
              fromLabel: (t) => t.code + " — " + t.name + (tplActive(t) ? "" : " (غير فعّال ✗)") },
          ]} initial={{}}
          onSave={(d) => {
            if (!d.assetId || !d.templateId) { alert("اختر الأصل والقالب"); return; }
            const tpl = db.meterTemplates.find((t) => t.id === d.templateId);
            if (!tplActive(tpl)) { alert("القالب غير فعّال — لا يُنشأ عداد منه"); return; }
            const res = associate(d.assetId, tpl);
            if (res === "موجود") { alert("الأصل مرتبط بهذا القالب مسبقًا — العلاقة فريدة (قاعدة ف5)"); return; }
            setAmForm(false);
          }} />
      )}
      {massTpl && (
        <FormSheet title={"ربط جماعي — " + massTpl.name} onClose={() => setMassTpl(null)} db={db}
          schema={[{ k: "groupId", label: "مجموعة الأصول", type: "select", from: "assetGroups", fromKey: "name" }]}
          initial={{}}
          onSave={(d) => {
            const g = db.assetGroups.find((x) => x.id === d.groupId);
            if (!g) { alert("اختر المجموعة"); return; }
            let added = 0, existed = 0;
            (g.assetIds || []).forEach((aid) => { associate(aid, massTpl) === "جديد" ? added++ : existed++; });
            alert("سجل الربط الجماعي:\n• أصول رُبطت حديثًا: " + added + "\n• مرتبطة مسبقًا: " + existed);
            setMassTpl(null);
          }} />
      )}
      {amSettings && (
        <FormSheet title={"إعدادات عداد — " + nameOf("assets", amSettings.assetId)} onClose={() => setAmSettings(null)} db={db}
          schema={[
            { k: "recordAtWO", label: "التسجيل عند إكمال الأمر (فارغ = من القالب)", type: "select", options: ["", "لا يسمح", "اختياري", "إلزامي"] },
            { k: "estDailyRate", label: "معدل الاستخدام اليومي المقدّر", type: "number" },
            { k: "readingsForRate", label: "عدد القراءات للمعدل المحسوب (≥2)", type: "number" },
            { k: "endDate", label: "تاريخ نهاية (تعطيل العداد مع حفظ التاريخ)", type: "date" },
          ]} initial={amSettings}
          onSave={(d) => {
            update("assetMeters", amSettings.id, d);
            const cr = calcUtilRate({ ...amSettings, ...d });
            setAmSettings(null);
            if (cr != null) alert("المعدل المحسوب الحالي: " + (Math.round(cr * 100) / 100) + "/يوم — سيُستخدم في التوقعات بدل المقدّر");
          }} />
      )}
      {reading && <ReadingSheet ctx={ctx} am={reading} onClose={() => setReading(null)} pmCheckAfterReading={pmCheckAfterReading} generateWO={generateWO} />}
      {history && <ReadingHistory ctx={ctx} am={history} onClose={() => setHistory(null)} />}
    </>
  );
}

/* إدخال قراءة: تدوير/تصفير/تاريخية/ملاحظات (ف5 §9) */
export function ReadingSheet({ ctx, am, onClose, pmCheckAfterReading, generateWO }) {
  const { db, nameOf, addReading, currentValue } = ctx;
  const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
  const [val, setVal] = useState(""); const [at, setAt] = useState(today());
  const [isReset, setIsReset] = useState(false); const [rollover, setRollover] = useState(false);
  const [historical, setHistorical] = useState(false); const [comments, setComments] = useState("");
  const [err, setErr] = useState("");
  const canReset = tpl.resetAllowed && tpl.direction === "تصاعدي" && tpl.meterType !== "مقياس";
  const canRoll = tpl.rolloverAllowed && tpl.meterType === "مستمر" && tpl.readingType === "مطلق" && tpl.direction === "تصاعدي";
  return (
    <Sheet title={"قراءة — " + tpl.name + " (المعروض: " + currentValue(am) + ")"} onClose={onClose}>
      <Field label={"القيمة الجديدة (" + (tpl.uom || "") + ")"}><input type="number" value={val} onChange={(e) => setVal(e.target.value)} style={input} /></Field>
      <Field label="تاريخ القراءة"><input type="date" value={at} onChange={(e) => setAt(e.target.value)} style={input} /></Field>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 10 }}>
        {canReset && (
          <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="checkbox" checked={isReset} onChange={(e) => { setIsReset(e.target.checked); setRollover(false); if (e.target.checked) setVal(String(tpl.resetValue ?? 0)); }} style={{ width: 20, height: 20 }} />
            <span style={{ fontSize: 14 }}>تصفير ← {tpl.resetValue ?? 0}</span>
          </label>
        )}
        {canRoll && (
          <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <input type="checkbox" checked={rollover} onChange={(e) => { setRollover(e.target.checked); setIsReset(false); }} style={{ width: 20, height: 20 }} />
            <span style={{ fontSize: 14 }}>تدوير (تجاوز {tpl.rolloverMax})</span>
          </label>
        )}
        <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <input type="checkbox" checked={historical} onChange={(e) => setHistorical(e.target.checked)} style={{ width: 20, height: 20 }} />
          <span style={{ fontSize: 14 }}>قراءة تاريخية (بين القراءات)</span>
        </label>
      </div>
      <Field label="ملاحظات"><input value={comments} onChange={(e) => setComments(e.target.value)} style={input} /></Field>
      {historical && <div style={{ fontSize: 12, color: C.amber, marginBottom: 8 }}>سيعاد حساب المعروض والعمر لكل القراءات اللاحقة تلقائيًا.</div>}
      {err && <div style={{ color: C.red, fontSize: 13, marginBottom: 8 }}>⚠ {err}</div>}
      <Btn bg={C.orange} style={{ width: "100%", padding: 12 }} onClick={() => {
        if (val === "") return setErr("أدخل قيمة");
        const alerts = (isReset || rollover) ? [] : pmCheckAfterReading(am, val);
        const e = addReading(am, val, at, { isReset, rollover, historical, comments });
        if (e) { setErr(e); return; }
        onClose();
        alerts.forEach((x) => {
          if (x.program) { if (confirm(x.msg + "؟")) generateWO(x.program); }
          else alert(x.msg);
        });
      }}>حفظ القراءة</Btn>
    </Sheet>
  );
}

/* سجل القراءات: Net/المعروض/العمر + الحالة + تعديل الأخيرة + تعطيل (ف5 §13) */
export function ReadingHistory({ ctx, am, onClose }) {
  const { db, nameOf, meterRows, meterReadings, update, disableReading, can } = ctx;
  const tpl = db.meterTemplates.find((t) => t.id === am.templateId) || {};
  const [editLatest, setEditLatest] = useState(false);
  const [v, setV] = useState(""); const [d, setD] = useState("");
  const rows = meterRows(am);
  const disabled = meterReadings(am.id).filter((r) => ["معطلة", "ملغاة"].includes(r.status));
  const latest = rows[rows.length - 1];
  const STATUS_COLOR = { "مسجلة": C.ink, "أولية": C.blue, "تصفير": C.amber, "تدوير": C.purple, "معدلة": C.steel, "معطلة": C.steel };
  return (
    <Sheet title={"سجل القراءات — " + tpl.name} onClose={onClose}>
      {rows.slice().reverse().map((r) => {
        const isLatest = latest && r.id === latest.id;
        return (
          <div key={r.id} style={{ ...card(), borderRightColor: STATUS_COLOR[r.status] || C.ink }}>
            <Row main={"المعروض: " + r.displayed + " · العمر: " + r.ltd}
              badge={{ text: r.status, color: STATUS_COLOR[r.status] || C.ink }}
              sub={[r.at, "القيمة: " + r.value, "التغير: " + (Math.round(r.net * 100) / 100), r.source,
                r.workOrderId ? db.workOrders.find((w) => w.id === r.workOrderId)?.number : "", r.comments].filter(Boolean).join(" · ")} />
            {can.manage && (
              <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                {isLatest && r.status !== "أولية" && <button onClick={() => { setEditLatest(r); setV(String(r.value)); setD(r.at); }} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>تعديل (الأخيرة فقط)</button>}
                {r.status !== "أولية" && <button onClick={() => { const e = disableReading(am, r); if (e) alert(e); }} style={{ ...delBtn, marginTop: 0 }}>تعطيل</button>}
              </div>
            )}
          </div>
        );
      })}
      {rows.length === 0 && <Empty text="لا قراءات فعالة." />}
      {disabled.length > 0 && (
        <Section title={"قراءات معطلة (" + disabled.length + ") — مستبعدة من الحساب"}>
          {disabled.map((r) => (
            <div key={r.id} style={{ ...card(), opacity: 0.5 }}>
              <Row main={"القيمة: " + r.value} sub={r.at + (r.comments ? " · " + r.comments : "")} badge={{ text: r.status, color: C.steel }} />
            </div>
          ))}
        </Section>
      )}
      {editLatest && (
        <Sheet title="تعديل آخر قراءة" onClose={() => setEditLatest(false)}>
          <Field label="القيمة"><input type="number" value={v} onChange={(e) => setV(e.target.value)} style={input} /></Field>
          <Field label="التاريخ"><input type="date" value={d} onChange={(e) => setD(e.target.value)} style={input} /></Field>
          <Btn bg={C.green} style={{ width: "100%", padding: 12 }} onClick={() => {
            update("readings", editLatest.id, { value: Number(v), at: d, status: "معدلة" });
            setEditLatest(false);
          }}>حفظ التعديل</Btn>
        </Sheet>
      )}
    </Sheet>
  );
}

/* ───────────────────────── منظمة الصيانة ───────────────────────── */
