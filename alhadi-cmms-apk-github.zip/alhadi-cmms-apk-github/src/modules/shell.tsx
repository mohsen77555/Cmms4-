import { useEffect, useRef, useState } from "react";
import { ACTIVE_STATES, C, TAB_META, WO_COLORS, daysUntil, entityTitle, fmt, uid } from "../core/appCore";
import { Btn, Chip, Empty, Field, Row, Section, Stat, card, input, inputStyle } from "../components/ui";

export function MiniMetric({ n, label, color }) {
  return <div style={{ background:"rgba(255,255,255,.86)", border:`1px solid ${C.line}`, borderRadius:16, padding:"8px 10px", minWidth:0 }}>
    <div style={{ fontSize:18, lineHeight:1, fontWeight:900, color }}>{n}</div>
    <div style={{ fontSize:10.5, color:C.steel, fontWeight:800, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{label}</div>
  </div>;
}

export function MoreHub({ items, setTab, db, can, role, productionMode, canUseDemoTools, canUseDangerousTools }) {
  const [q, setQ] = useState("");
  const [group, setGroup] = useState("الكل");
  const groups = {
    "تشغيل سريع": ["maintenance", "super", "mywork", "wo", "requests", "inventory", "invgov"],
    "التخطيط": ["programs", "forecast", "schedule", "stdops", "workdefs", "org", "techs"],
    "الأصول": ["assets", "qrlabels", "meters", "groups", "lh", "warranty"],
    "الرقابة": ["governance100", "governance", "invgov", "oracle", "reports", "failures", "data"],
    "النظام": ["firebase", "users", "media"]
  };
  const visibleIds = new Set(items.map(([id]) => id));
  const allIds = Object.values(groups).flat().filter((id) => visibleIds.has(id));
  const ordered = [...new Set([...allIds, ...items.map(([id]) => id)])];
  const filtered = ordered.filter((id) => {
    const meta = TAB_META[id] || { label:id, desc:"" };
    const inGroup = group === "الكل" || (groups[group] || []).includes(id);
    const term = q.trim().toLowerCase();
    const inSearch = !term || (meta.label + " " + meta.desc + " " + id).toLowerCase().includes(term);
    return visibleIds.has(id) && inGroup && inSearch;
  });
  const shortcuts = role === "فني" ? ["mywork", "wo", "assets"] : role === "مخزن" ? ["inventory", "invgov", "wo", "reports"] : ["maintenance", "super", "schedule", "qrlabels", "forecast", "governance100"];
  const stats = [
    ["أصول", db.assets.length, C.green],
    ["أوامر", db.workOrders.length, C.blue],
    ["طلبات", db.workRequests.length, C.orange],
    ["تقارير", (db.reportJobs || []).length + (db.savedReportOutputs || []).length, C.purple]
  ];
  return <>
    {productionMode && (
      <div style={{ ...card(), borderRightColor:C.green, background:"#ECFDF5" }}>
        <Row main="وضع الإنتاج مفعل" sub={canUseDemoTools || canUseDangerousTools ? "تم تفعيل بعض أدوات التدريب عبر متغيرات البناء." : "أدوات التجربة والحذف والاستيراد غير المحكوم مخفية في هذه النسخة."} badge={{ text:"Production", color:C.green }} />
      </div>
    )}
    <section style={{ background:`linear-gradient(135deg, ${C.ink}, #243247)`, color:"#fff", borderRadius:24, padding:16, marginBottom:12, boxShadow:"0 16px 36px rgba(15,23,42,.18)" }}>
      <div style={{ display:"flex", justifyContent:"space-between", gap:12, alignItems:"flex-start" }}>
        <div>
          <div style={{ fontSize:12, opacity:.75, fontWeight:900 }}>مركز التنقل</div>
          <div style={{ fontSize:24, fontWeight:900, lineHeight:1.15 }}>كل وحدات CMMS في مكان واحد</div>
          <div style={{ fontSize:12.5, opacity:.78, marginTop:4 }}>بحث سريع، مجموعات واضحة، واختصارات حسب دورك الحالي.</div>
        </div>
        <div style={{ background:"rgba(255,255,255,.12)", border:"1px solid rgba(255,255,255,.18)", borderRadius:18, padding:"8px 10px", fontSize:12, fontWeight:900, whiteSpace:"nowrap" }}>{role}</div>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginTop:14 }}>
        {stats.map(([label, n, color]) => <div key={label} style={{ background:"rgba(255,255,255,.10)", border:"1px solid rgba(255,255,255,.12)", borderRadius:16, padding:"9px 8px" }}><div style={{ color, fontSize:18, fontWeight:900 }}>{n}</div><div style={{ fontSize:10.5, opacity:.8 }}>{label}</div></div>)}
      </div>
    </section>

    <div style={{ display:"flex", gap:8, overflowX:"auto", marginBottom:10 }}>
      {shortcuts.filter((id)=>visibleIds.has(id)).map((id) => {
        const meta = TAB_META[id] || { label:id, icon:"•", color:C.ink };
        return <button key={id} onClick={()=>setTab(id)} style={{ border:`1px solid ${meta.color}`, background:"#fff", color:meta.color, borderRadius:999, padding:"8px 12px", fontSize:12, fontWeight:900, whiteSpace:"nowrap", display:"flex", gap:6, alignItems:"center" }}><span>{meta.icon}</span>{meta.label}</button>;
      })}
    </div>

    <div style={{ ...card(), borderRightColor:C.blue, padding:12 }}>
      <Field label="بحث في التبويبات"><input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="اكتب: أصل، أمر، تقرير، حوكمة…" style={inputStyle()} /></Field>
      <div style={{ display:"flex", gap:7, overflowX:"auto" }}>
        {["الكل", ...Object.keys(groups)].map((g) => <Chip key={g} active={group === g} onClick={()=>setGroup(g)}>{g}</Chip>)}
      </div>
    </div>

    {filtered.length === 0 && <Empty text="لا توجد تبويبات مطابقة للبحث." />}
    <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(158px, 1fr))", gap:10 }}>
      {filtered.map((id) => {
        const meta = TAB_META[id] || { label:id, icon:"•", desc:"", color:C.ink };
        return <button key={id} onClick={() => setTab(id)} style={{ ...card(), marginBottom:0, padding:14, textAlign:"right", borderRightColor:meta.color, minHeight:118, display:"flex", flexDirection:"column", justifyContent:"space-between", gap:12 }}>
          <div style={{ display:"flex", justifyContent:"space-between", gap:8, alignItems:"flex-start" }}>
            <div style={{ width:38, height:38, borderRadius:14, display:"grid", placeItems:"center", background:meta.color, color:"#fff", fontWeight:900, fontSize:18 }}>{meta.icon}</div>
            <span style={{ color:C.steel, fontSize:18 }}>‹</span>
          </div>
          <div>
            <div style={{ fontSize:14.5, fontWeight:900, color:C.ink }}>{meta.label}</div>
            <div style={{ fontSize:11.5, color:C.steel, lineHeight:1.45 }}>{meta.desc}</div>
          </div>
        </button>;
      })}
    </div>
  </>;
}


/* ───────────────────────── مركز التنبيهات وتجربة الدور ───────────────────────── */
export function buildNotifications(ctx) {
  const { db, can, role, myTechId, nameOf, programDue, woAssignedTechIds, availableQty } = ctx || {};
  const notes = [];
  const open = (db.workOrders || []).filter((w) => ACTIVE_STATES.includes(w.status));
  const myAssigned = (w) => !myTechId || ((woAssignedTechIds ? woAssignedTechIds(w) : (w.operations || []).map((o) => o.assigneeId)).includes(myTechId));
  const push = (n) => notes.push({ id: n.id || uid(), level: n.level || "info", ...n });

  open.filter((w) => (w.priority === "طارئ" || w.type === "طارئ") && (role !== "فني" || myAssigned(w))).slice(0, 10).forEach((w) => push({
    id: "em-" + w.id, level: "critical", title: "أمر طارئ", body: (w.number || "") + " — " + (w.title || "") + " · " + nameOf("assets", w.assetId), tab:"wo", woId:w.id
  }));
  open.filter((w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0 && (role !== "فني" || myAssigned(w))).slice(0, 10).forEach((w) => push({
    id: "od-" + w.id, level: "warning", title: "أمر متأخر", body: (w.number || "") + " متأخر منذ " + fmt(w.plannedEnd), tab:"wo", woId:w.id
  }));
  if (can?.review) (db.workOrders || []).filter((w) => w.status === "بانتظار المراجعة").slice(0, 12).forEach((w) => push({
    id: "rv-" + w.id, level: "info", title: "بانتظار اعتماد المشرف", body: (w.number || "") + " — " + (w.title || ""), tab:"super", woId:w.id
  }));
  if (role === "مخزن" || can?.warehouse) open.filter((w) => w.status === "بانتظار مواد" || (w.materials || []).some((m) => Number(m.qty || 0) > Number(m.issuedQty || 0))).slice(0, 12).forEach((w) => push({
    id: "mat-" + w.id, level: "warning", title: "مواد مطلوبة", body: (w.number || "") + " يحتاج مراجعة صرف/حجز المواد", tab:"inventory", woId:w.id
  }));
  if (role === "فني") open.filter((w) => myAssigned(w) && ["جاهز", "قيد التنفيذ", "مُعاد للتصحيح", "بانتظار مواد"].includes(w.status)).slice(0, 12).forEach((w) => push({
    id: "my-" + w.id, level: w.status === "مُعاد للتصحيح" ? "critical" : "info", title: "مهمة مسندة لك", body: (w.number || "") + " — " + (w.status || ""), tab:"mywork", woId:w.id
  }));
  if (can?.manage) (db.programs || []).filter((p) => {
    try { const r = programDue ? programDue(p) : {}; return r.due || r.soon; } catch { return false; }
  }).slice(0, 8).forEach((p) => {
    const r = programDue(p);
    push({ id:"pm-"+p.id, level:r.due?"critical":"warning", title:r.due?"صيانة وقائية مستحقة":"صيانة قريبة الاستحقاق", body:(p.name||"") + " · " + (r.label||""), tab:"forecast" });
  });
  if (can?.admin || role === "مدير") {
    const fails = (db.governanceControlTests || []).filter((t) => t.result === "Fail").length;
    const capaDue = (db.governanceCapaActions || []).filter((a) => a.status !== "مغلق" && a.dueDate && daysUntil(a.dueDate) < 0).length;
    if (fails) push({ id:"gov-fails", level:"critical", title:"ضوابط حوكمة فاشلة", body:fails + " ضابط يحتاج إجراء تصحيحي", tab:"governance100" });
    if (capaDue) push({ id:"capa-due", level:"warning", title:"CAPA متأخرة", body:capaDue + " إجراء تصحيحي تجاوز تاريخ الاستحقاق", tab:"governance100" });
  }
  (db.items || []).filter((i) => {
    try { return Number(availableQty ? availableQty(i.id) : 0) <= Number(i.min ?? i.minQty ?? 0); } catch { return false; }
  }).slice(0, 8).forEach((i) => push({ id:"stk-"+i.id, level:"warning", title:"مخزون منخفض", body:(i.name || i.code || "صنف") + " وصل للحد الأدنى", tab:"inventory" }));
  if (can?.warehouse || can?.review || can?.admin) (db.inventoryRequests || []).filter((r) => ["مفتوح", "بانتظار اعتماد"].includes(r.status)).slice(0, 12).forEach((r) => push({ id:"invreq-"+r.id, level:r.priority === "حرجة" ? "critical" : "warning", title:"طلب مخزون بانتظار إجراء", body:(r.number || "طلب") + " — " + (r.type || "") + " · " + (nameOf ? nameOf("items", r.itemId) : ""), tab:"invgov" }));
  if (ctx?.offlineStats?.conflict) push({ id:"offline-conflicts", level:"critical", title:"تعارضات مزامنة Offline", body:ctx.offlineStats.conflict + " تغيير يحتاج قرار: اعتمد نسخة الجهاز أو نسخة Firestore", tab:"sync" });
  if (ctx?.offlineStats?.pending) push({ id:"offline-pending", level:"warning", title:"تغييرات Offline معلقة", body:ctx.offlineStats.pending + " تغيير محفوظ محليًا بانتظار المزامنة", tab:"sync" });

  const rank = { critical:0, warning:1, info:2 };
  return notes.sort((a,b)=>(rank[a.level]??9)-(rank[b.level]??9)).slice(0, 50);
}
export function levelColor(level) { return level === "critical" ? C.red : level === "warning" ? C.amber : C.blue; }
export function NotificationsCenter({ ctx, openWO, openAsset, setTab }) {
  const notes = buildNotifications(ctx);
  const [filter, setFilter] = useState("الكل");
  const list = filter === "الكل" ? notes : notes.filter((n) => filter === "حرج" ? n.level === "critical" : filter === "تحذير" ? n.level === "warning" : n.level === "info");
  const go = (n) => {
    if (n.woId) return openWO(n.woId);
    if (n.assetId) return openAsset(n.assetId);
    if (n.tab) return setTab(n.tab);
  };
  return <>
    <Section title="مركز التنبيهات الداخلي">
      <div style={{ display:"flex", gap:8, marginBottom:10 }}>
        <Stat n={notes.filter((n)=>n.level==="critical").length} label="حرج" color={C.red}/>
        <Stat n={notes.filter((n)=>n.level==="warning").length} label="تحذير" color={C.amber}/>
        <Stat n={notes.filter((n)=>n.level==="info").length} label="معلومات" color={C.blue}/>
        <Stat n={notes.length} label="الإجمالي" color={C.ink}/>
      </div>
      <div style={{ display:"flex", gap:6, overflowX:"auto", marginBottom:10 }}>{["الكل","حرج","تحذير","معلومات"].map((x)=><Chip key={x} active={filter===x} onClick={()=>setFilter(x)}>{x}</Chip>)}</div>
      {list.length === 0 && <Empty text="لا توجد تنبيهات ضمن هذا التصنيف." />}
      {list.map((n)=><div key={n.id} style={{ ...card(), borderRightColor:levelColor(n.level) }} onClick={()=>go(n)}>
        <Row main={(n.level === "critical" ? "🚨 " : n.level === "warning" ? "⚠️ " : "ℹ️ ") + n.title} sub={n.body} badge={{ text:n.level === "critical" ? "حرج" : n.level === "warning" ? "تحذير" : "تنبيه", color:levelColor(n.level)}} />
      </div>)}
    </Section>
    <Section title="ملاحظات التشغيل"><div style={card()}><Row main="هذه تنبيهات داخلية محسوبة من بيانات النظام" sub="لا تحتاج Push Notifications الآن. يمكن لاحقًا ربطها بإشعارات أندرويد/Firebase Cloud Messaging." /></div></Section>
  </>;
}

export function OfflineSyncCenter({ ctx }) {
  const { offlineQueue = [], offlineHistory = [], offlineStats = {}, browserOnline, syncRunning, runOfflineSync, resolveOfflineConflict, clearOfflineDone, exportOfflineQueue, firebaseEnabled, firebaseUser, refreshOfflineState } = ctx;
  const [filter, setFilter] = useState("الكل");
  useEffect(() => { refreshOfflineState && refreshOfflineState(); }, []);
  const filtered = (offlineQueue || []).filter((x) => filter === "الكل" ||
    (filter === "معلقة" && ["pending","retry"].includes(x.status)) ||
    (filter === "تعارض" && x.status === "conflict") ||
    (filter === "مكتملة" && ["applied","dropped"].includes(x.status)) ||
    (filter === "فشل" && x.status === "failed"));
  const statusBadge = (x) => x.status === "conflict" ? { text:"تعارض", color:C.red }
    : ["pending","retry"].includes(x.status) ? { text:x.status === "retry" ? "إعادة محاولة" : "معلق", color:C.amber }
    : x.status === "applied" ? { text:"تم", color:C.green }
    : x.status === "dropped" ? { text:"تم تجاهله", color:C.steel }
    : { text:x.status || "—", color:C.steel };
  return <>
    <Section title="Offline Mode كامل — طابور المزامنة وحل التعارضات">
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:10 }}>
        <Stat n={offlineStats.pending || 0} label="معلقة" color={(offlineStats.pending||0)?C.amber:C.steel}/>
        <Stat n={offlineStats.conflict || 0} label="تعارض" color={(offlineStats.conflict||0)?C.red:C.green}/>
        <Stat n={offlineStats.applied || 0} label="تمت" color={C.green}/>
        <Stat n={browserOnline ? "Online" : "Offline"} label="الشبكة" color={browserOnline ? C.green : C.red} small/>
      </div>
      <div style={card()}>
        <Row main={firebaseEnabled && firebaseUser ? "Firebase جاهز للمزامنة" : "سجل الدخول إلى Firebase لتفعيل المزامنة"} sub="أي تعديل يفشل بسبب انقطاع الشبكة أو رفض مؤقت من Firestore يُحفظ محليًا ثم يُعاد رفعه. عند اختلاف نفس السجل بين الجهاز و Firestore يظهر تعارض يحتاج قرار." badge={{ text: syncRunning ? "جارٍ…" : (browserOnline ? "متصل" : "بدون إنترنت"), color: syncRunning ? C.blue : (browserOnline ? C.green : C.red) }} />
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginTop:10 }}>
          <Btn bg={C.blue} disabled={syncRunning || !firebaseEnabled || !firebaseUser} onClick={()=>runOfflineSync && runOfflineSync("manual")} style={{ padding:12 }}>{syncRunning ? "جارٍ المزامنة…" : "مزامنة الآن"}</Btn>
          <Btn bg={C.ink} onClick={exportOfflineQueue} style={{ padding:12 }}>تصدير الطابور</Btn>
          <Btn bg={C.steel} onClick={clearOfflineDone} style={{ padding:12 }}>تنظيف المكتمل</Btn>
          <Btn bg={C.purple} onClick={()=>refreshOfflineState && refreshOfflineState()} style={{ padding:12 }}>تحديث الشاشة</Btn>
        </div>
      </div>
      <div style={{ display:"flex", gap:6, overflowX:"auto", margin:"10px 0" }}>{["الكل","معلقة","تعارض","مكتملة","فشل"].map((x)=><Chip key={x} active={filter===x} onClick={()=>setFilter(x)}>{x}</Chip>)}</div>
      {filtered.length === 0 && <Empty text="لا توجد عناصر في هذا التصنيف." />}
      {filtered.slice().reverse().map((q)=><div key={q.id} style={{ ...card(), borderRightColor:statusBadge(q).color }}>
        <Row main={(q.changedKeys || []).map(entityTitle).join("، ") || "تغيير Offline"} sub={["أنشئ: " + fmt(q.createdAt), "محاولات: " + (q.attempts || 0), q.reason || q.error || ""].filter(Boolean).join(" · ")} badge={statusBadge(q)} />
        {q.conflicts?.length > 0 && <div style={{ marginTop:8, background:"#FEF2F2", border:"1px solid #FECACA", borderRadius:14, padding:10, fontSize:12.5, color:C.red }}>
          <b>التعارضات:</b>
          <ul style={{ margin:"6px 0 0", paddingRight:18 }}>{q.conflicts.slice(0,8).map((c,i)=><li key={i}>{entityTitle(c.entityKey)} {c.recordId ? "#" + c.recordId : ""} — {c.reason}</li>)}</ul>
        </div>}
        {q.status === "conflict" && <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginTop:10 }}>
          <Btn bg={C.green} onClick={()=>resolveOfflineConflict && resolveOfflineConflict(q.id, "local")}>اعتماد نسخة هذا الجهاز</Btn>
          <Btn bg={C.steel} onClick={()=>resolveOfflineConflict && resolveOfflineConflict(q.id, "remote")}>اعتماد نسخة Firestore</Btn>
        </div>}
      </div>)}
    </Section>
    <Section title="سجل المزامنة">
      {(offlineHistory || []).slice(0,25).map((h)=><div key={h.id} style={card()}><Row main={h.type || "حدث"} sub={[fmt(h.at), (h.changedKeys||[]).map(entityTitle).join("، "), h.reason || ""].filter(Boolean).join(" · ")} /></div>)}
      {!(offlineHistory || []).length && <Empty text="لا يوجد سجل مزامنة بعد." />}
    </Section>
  </>;
}

export function RoleDashboard({ ctx, setTab, openWO }) {
  const { db, role, can, myTechId, woAssignedTechIds, nameOf, availableQty } = ctx;
  const open = (db.workOrders || []).filter((w)=>ACTIVE_STATES.includes(w.status));
  const my = open.filter((w)=> role !== "فني" || !myTechId || (woAssignedTechIds ? woAssignedTechIds(w) : (w.operations || []).map((o)=>o.assigneeId)).includes(myTechId));
  const waitingReview = (db.workOrders || []).filter((w)=>w.status === "بانتظار المراجعة");
  const waitingMat = open.filter((w)=>w.status === "بانتظار مواد" || (w.materials || []).some((m)=>Number(m.qty||0)>Number(m.issuedQty||0)));
  const pastDue = open.filter((w)=>w.plannedEnd && daysUntil(w.plannedEnd)<0);
  const lowStock = (db.items || []).filter((i)=>{ try { return Number(availableQty ? availableQty(i.id) : 0) <= Number(i.min ?? i.minQty ?? 0); } catch { return false; } });
  const techLoad = (db.technicians || []).map((t)=>({ t, n:open.filter((w)=>(woAssignedTechIds ? woAssignedTechIds(w) : (w.operations||[]).map((o)=>o.assigneeId)).includes(t.id)).length })).sort((a,b)=>b.n-a.n).slice(0,4);
  if (role === "فني") return <Section title="واجهة الفني السريعة"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={my.filter((w)=>daysUntil(w.plannedStart)<=0).length} label="اليوم" color={C.blue}/><Stat n={my.filter((w)=>w.status==="قيد التنفيذ").length} label="قيد التنفيذ" color={C.amber}/><Stat n={my.filter((w)=>w.status==="مُعاد للتصحيح").length} label="تحتاج تصحيح" color={C.red}/><Stat n={my.length} label="مهامي" color={C.green}/></div><div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}><Btn bg={C.green} onClick={()=>setTab("mywork")} style={{padding:12}}>فتح أعمالي</Btn><Btn bg={C.ink} onClick={()=>setTab("assets")} style={{padding:12}}>بحث/QR أصل</Btn></div></Section>;
  if (role === "مخزن") return <Section title="واجهة المخزن السريعة"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={waitingMat.length} label="بانتظار مواد" color={waitingMat.length?C.amber:C.steel}/><Stat n={lowStock.length} label="تحت الحد" color={lowStock.length?C.red:C.green}/><Stat n={(db.stockTx||[]).length} label="حركات" color={C.blue}/><Stat n={(db.items||[]).length} label="أصناف" color={C.ink}/></div><div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}><Btn bg={C.amber} onClick={()=>setTab("inventory")} style={{padding:12}}>طلبات الصرف</Btn><Btn bg={C.blue} onClick={()=>setTab("wo")} style={{padding:12}}>أوامر تحتاج مواد</Btn></div></Section>;
  if (can?.review && !can?.admin) return <Section title="واجهة المشرف السريعة"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={waitingReview.length} label="مراجعة" color={C.purple}/><Stat n={pastDue.length} label="متأخر" color={pastDue.length?C.red:C.steel}/><Stat n={waitingMat.length} label="مواد" color={waitingMat.length?C.amber:C.steel}/><Stat n={open.length} label="مفتوح" color={C.blue}/></div><div style={{...card(), marginBottom:8}}>{techLoad.map(({t,n})=><div key={t.id} style={{display:"flex", justifyContent:"space-between", fontSize:13, padding:"3px 0"}}><b>{t.name}</b><span>{n} أمر</span></div>)}</div><Btn bg={C.purple} onClick={()=>setTab("super")} style={{width:"100%",padding:12}}>فتح لوحة الإشراف</Btn></Section>;
  if (role === "طالب خدمة") return <Section title="واجهة طالب الخدمة"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={(db.workRequests||[]).filter((r)=>r.status==="مفتوح").length} label="طلبات مفتوحة" color={C.orange}/><Stat n={(db.workRequests||[]).filter((r)=>r.status==="محوّل").length} label="محوّلة" color={C.blue}/></div><Btn bg={C.orange} onClick={()=>setTab("requests")} style={{width:"100%",padding:12}}>إنشاء / متابعة طلب عمل</Btn></Section>;
  return <Section title="واجهة الإدارة السريعة"><div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={open.length} label="أوامر مفتوحة" color={C.blue}/><Stat n={pastDue.length} label="متأخرة" color={pastDue.length?C.red:C.steel}/><Stat n={(db.governanceCapaActions||[]).filter((a)=>a.status!=="مغلق").length} label="CAPA" color={C.amber}/><Stat n={(db.assets||[]).filter((a)=>a.critical).length} label="أصول حرجة" color={C.red}/></div><div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}><Btn bg={C.ink} onClick={()=>setTab("governance100")} style={{padding:12}}>حوكمة 100%</Btn><Btn bg={C.blue} onClick={()=>setTab("reports")} style={{padding:12}}>التقارير</Btn></div></Section>;
}
export function parseAssetQrPayload(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    const obj = JSON.parse(raw);
    if (obj && typeof obj === "object") return String(obj.number || obj.assetNumber || obj.asset || obj.id || raw).trim();
  } catch {}
  const prefixed = raw.match(/(?:ASSET|CMMS-ASSET|asset|assetNumber|number)[:=]\s*([^\s&]+)/i);
  if (prefixed && prefixed[1]) return decodeURIComponent(prefixed[1]).trim();
  try {
    const u = new URL(raw);
    const params = u.searchParams;
    const fromParam = params.get("asset") || params.get("assetNumber") || params.get("number") || params.get("id");
    if (fromParam) return fromParam.trim();
    const last = u.pathname.split("/").filter(Boolean).pop();
    if (last) return decodeURIComponent(last).trim();
  } catch {}
  return raw;
}

export function AssetQuickLookup({ ctx, openAsset, setQ }) {
  const { db } = ctx;
  const [code, setCode] = useState("");
  const [scanning, setScanning] = useState(false);
  const [msg, setMsg] = useState("");
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const stop = () => {
    try { streamRef.current?.getTracks?.().forEach((t)=>t.stop()); } catch {}
    streamRef.current = null; setScanning(false);
  };
  useEffect(()=>()=>stop(), []);
  const findAsset = (value) => {
    const raw = parseAssetQrPayload(value);
    if (!raw) return setMsg("أدخل رقم الأصل أو امسح QR.");
    const asset = (db.assets || []).find((a) => [a.id, a.number, a.serial, a.name].some((x)=>String(x||"").trim().toLowerCase() === raw.toLowerCase())) ||
      (db.assets || []).find((a) => String(a.number||"").toLowerCase().includes(raw.toLowerCase()) || String(a.name||"").toLowerCase().includes(raw.toLowerCase()));
    if (asset) { setMsg(""); openAsset(asset.id); }
    else { setMsg("لم يتم العثور على أصل مطابق. تم تطبيق النص على البحث."); setQ?.(raw); }
  };
  const startScan = async () => {
    setMsg("");
    if (!("BarcodeDetector" in window)) return setMsg("الماسح التلقائي غير مدعوم على هذا الجهاز. اكتب الرقم يدويًا أو استخدم بحث الأصول.");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      setScanning(true);
      setTimeout(async () => {
        try {
          const video = videoRef.current;
          if (!video) return;
          video.srcObject = stream;
          await video.play();
          const detector = new (window as any).BarcodeDetector({ formats: ["qr_code", "code_128", "ean_13", "code_39"] });
          let done = false;
          const loop = async () => {
            if (done || !streamRef.current) return;
            try {
              const codes = await detector.detect(video);
              if (codes && codes[0]) { done = true; const val = codes[0].rawValue || ""; stop(); setCode(val); findAsset(val); return; }
            } catch {}
            requestAnimationFrame(loop);
          };
          loop();
        } catch (e) { setMsg("تعذر تشغيل الكاميرا: " + (e?.message || e)); stop(); }
      }, 80);
    } catch (e) { setMsg("تعذر فتح الكاميرا. تحقق من الإذن أو اكتب الرقم يدويًا."); }
  };
  return <div style={{...card(), borderRightColor:C.green, padding:12}}>
    <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:8}}><div><b>QR / Barcode للأصول</b><div style={{fontSize:11.5, color:C.steel}}>امسح ملصق الأصل أو أدخل رقم الأصل للوصول إلى Asset 360.</div></div><span style={{fontSize:22}}>▦</span></div>
    <div style={{display:"grid", gridTemplateColumns:"1fr auto auto", gap:6}}><input value={code} onChange={(e)=>setCode(e.target.value)} placeholder="ELA-01 / CC-01 / Serial" style={inputStyle()} /><Btn bg={C.green} onClick={()=>findAsset(code)}>فتح</Btn><Btn bg={C.ink} onClick={scanning?stop:startScan}>{scanning?"إيقاف":"مسح"}</Btn></div>
    {scanning && <video ref={videoRef} playsInline muted style={{width:"100%", maxHeight:220, marginTop:8, borderRadius:16, background:C.ink}} />}
    {msg && <div style={{fontSize:12, color:msg.includes("لم يتم")?C.amber:C.red, marginTop:8}}>{msg}</div>}
  </div>;
}

/* ───────────────────────── الرئيسية ───────────────────────── */
export function Home({ db, nameOf, programDue, generateWO, setTab, openWO, can, ctx }) {
  const open = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const overdue = open.filter((w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0);
  const pendingReview = db.workOrders.filter((w) => w.status === "بانتظار المراجعة");
  const emergency = open.filter((w) => w.priority === "طارئ" || w.type === "طارئ");
  const newReqs = db.workRequests.filter((r) => r.status === "مفتوح");
  const duePrograms = can.manage ? db.programs.filter((p) => programDue(p).due) : [];
  const soonPrograms = can.manage ? db.programs.filter((p) => { const i = programDue(p); return !i.due && i.soon; }) : [];
  return (
    <>
      <RoleDashboard ctx={ctx} setTab={setTab} openWO={openWO} />
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <Stat n={emergency.length} label="طارئ" color={emergency.length ? C.red : C.steel} />
        <Stat n={overdue.length} label="متأخر" color={overdue.length ? C.red : C.steel} />
        <Stat n={pendingReview.length} label="بانتظار المراجعة" color={pendingReview.length ? C.blue : C.steel} />
        <Stat n={open.length} label="مفتوح" color={C.ink} />
      </div>
      {buildNotifications(ctx).length > 0 && (
        <div style={{ ...card(), borderRightColor:C.red }} onClick={()=>setTab("notifications")}>
          <Row main={"🔔 لديك " + buildNotifications(ctx).length + " تنبيه"} sub="افتح مركز التنبيهات لمتابعة الطوارئ والمواد والاعتمادات." badge={{text:"فتح", color:C.red}} />
        </div>
      )}

      {soonPrograms.length > 0 && (
        <Section title="⏳ تنبيه: صيانة مستحقة قريبًا">
          {soonPrograms.map((p) => (
            <div key={p.id} style={{ ...card(), borderRightColor: C.amber }}>
              <Row main={p.name} sub={nameOf("assets", p.assetId) + " · " + programDue(p).label} />
            </div>
          ))}
        </Section>
      )}
      {duePrograms.length > 0 && (
        <Section title="برامج وقائية مستحقة">
          {duePrograms.map((p) => (
            <div key={p.id} style={card()}>
              <Row main={p.name} sub={nameOf("assets", p.assetId) + " · " + programDue(p).label}
                action={<Btn bg={C.orange} onClick={() => generateWO(p)}>إنشاء أمر عمل</Btn>} />
            </div>
          ))}
        </Section>
      )}

      <Section title="يحتاج انتباهك">
        {[...emergency, ...overdue, ...pendingReview, ...newReqs].length === 0 && <Empty text="لا شيء عاجل. كل شيء تحت السيطرة." />}
        {emergency.map((w) => (
          <div key={w.id} style={{ ...card(), borderRightColor: C.red }} onClick={() => openWO(w.id)}>
            <Row main={"🚨 " + w.number + " — " + w.title} sub={nameOf("assets", w.assetId)} badge={{ text: w.status, color: WO_COLORS[w.status] }} />
          </div>
        ))}
        {overdue.filter((w) => !emergency.includes(w)).map((w) => (
          <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
            <Row main={w.number + " — " + w.title} sub={"متأخر منذ " + fmt(w.plannedEnd)} badge={{ text: w.status, color: WO_COLORS[w.status] }} />
          </div>
        ))}
        {can.review && pendingReview.map((w) => (
          <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
            <Row main={w.number + " — " + w.title} sub="أكمله الفني — بانتظار اعتمادك" badge={{ text: "راجِع", color: C.blue }} />
          </div>
        ))}
        {newReqs.map((r) => (
          <div key={r.id} style={card()} onClick={() => setTab("requests")}>
            <Row main={"طلب: " + r.title} sub={nameOf("assets", r.assetId) + " · خطورة " + r.severity} badge={{ text: "مفتوح", color: C.amber }} />
          </div>
        ))}
      </Section>
    </>
  );
}

/* ───────────────────────── أعمالي / قائمة الإرسال (وثيقة التنفيذ §2,§5) ───────────────────────── */
