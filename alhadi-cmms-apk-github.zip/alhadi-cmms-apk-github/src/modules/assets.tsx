import { useState } from "react";
import { ASSET_OWNERSHIP, C, DEFAULT_WO_SUBTYPES, DOC_TYPES, GROUP_ATTRS, LOCATION_TYPES, RULE_USAGES, STANDARD_GROUPS, WO_COLORS, daysUntil, fmt, isStorageMedia, mediaSrc, money, now, today, uid } from "../core/appCore";
import { AddInline, Btn, Chip, Empty, Field, Row, Section, Sheet, Stat, card, delBtn, input } from "../components/ui";
import { FormSheet, assetSchema } from "./crud";
import { ExcelImport } from "./excelImport";
import { ServiceMappingForm } from "./organization";
import { AssetSingleQrLabel } from "./qrLabels";
import { AssetQuickLookup } from "./shell";

export function AssetGroups({ ctx }) {
  const { db, add, update, remove, nameOf, can, groupRule, groupActive, activeAssignments, canUseSetupTools } = ctx;
  const [sub, setSub] = useState("المجموعات");
  const [q, setQ] = useState("");
  const [ruleForm, setRuleForm] = useState(null);
  const [groupForm, setGroupForm] = useState(null);
  const [detail, setDetail] = useState(null);
  const stdRule = () => {
    let r = db.assetGroupRules.find((x) => x.code === "STD");
    if (!r) r = add("assetGroupRules", { name: "التصنيف القياسي", code: "STD", description: "", attributes: [], usages: ["عام (صيانة وبرامج)"], enforceUnique: false, inactiveOn: "" });
    return r;
  };
  const missing = STANDARD_GROUPS.filter(([code]) => !db.assetGroups.some((g) => g.code === code));
  const seed = () => {
    const r = stdRule();
    missing.forEach(([code, name], i) => add("assetGroups", { code, name, ruleId: r.id,
      number: "AG-" + String(100 + db.assetGroups.length + i + 1), description: "", attrValues: {},
      excludeFromRequests: false, excludeFromWO: false, inactiveOn: "", assignments: [], assetIds: [] }));
  };
  const ruleHasGroups = (rid) => db.assetGroups.some((g) => g.ruleId === rid);
  const ruleHasAssignments = (rid) => db.assetGroups.some((g) => g.ruleId === rid && (g.assignments || []).length > 0);
  const isStatusRule = (r) => (r.usages || []).includes("حالة الأصل (قاعدة تحقق)");

  const ruleSchema = (editing) => [
    { k: "name", label: "اسم القاعدة" }, { k: "code", label: "الكود (فريد)" },
    { k: "description", label: "الوصف", type: "textarea" },
    { k: "usages", label: "الاستخدامات", type: "multi-static", options: RULE_USAGES },
    { k: "attributes", label: "خصائص التجميع" + (editing && ruleHasGroups(editing.id) ? " — مقفلة (توجد مجموعات)" : ""), type: "multi-static", options: GROUP_ATTRS.map(([, l]) => l) },
    { k: "enforceUnique", label: "تعيين فريد (الأصل في مجموعة واحدة ضمن القاعدة)" + (editing && ruleHasAssignments(editing.id) ? " — مقفل (توجد تعيينات)" : ""), type: "check" },
    { k: "inactiveOn", label: "تعطيل اعتبارًا من (لا مجموعات جديدة بعده)", type: "date" },
  ];
  const attrKeyByLabel = (l) => GROUP_ATTRS.find(([, lab]) => lab === l)?.[0] || l;
  const validateRule = (d, editing) => {
    if (!String(d.name || "").trim() || !String(d.code || "").trim()) return "الاسم والكود مطلوبان";
    if (db.assetGroupRules.some((r) => r.code === d.code && r.id !== editing?.id)) return "الكود مستخدم";
    if (!(d.usages || []).length) return "اختر استخدامًا واحدًا على الأقل";
    if ((d.usages || []).includes("حالة الأصل (قاعدة تحقق)")) {
      if ((d.usages || []).length > 1) return "«حالة الأصل» لا يجتمع مع استخدامات أخرى (قاعدة ف4)";
      if ((d.attributes || []).length) return "«حالة الأصل»: خصائص التجميع معطلة — أي أصل يمكن تعيينه";
      d.enforceUnique = true; /* إجباري */
      if (db.assetGroupRules.some((r) => r.id !== editing?.id && (r.usages || []).includes("حالة الأصل (قاعدة تحقق)")))
        return "قاعدة واحدة فقط من نوع «حالة الأصل» مسموحة";
    }
    if (editing) {
      const oldAttrs = JSON.stringify((editing.attributes || []).slice().sort());
      if (JSON.stringify((d.attributes || []).slice().sort()) !== oldAttrs && ruleHasGroups(editing.id)) return "لا تغيّر خصائص التجميع — توجد مجموعات تحت القاعدة";
      if (!!d.enforceUnique !== !!editing.enforceUnique && ruleHasAssignments(editing.id)) return "لا تغيّر «التعيين الفريد» — توجد أصول معينة";
    }
    return null;
  };

  let groups = db.assetGroups.filter((g) => !q || ((g.name || "") + (g.number || "") + (g.code || "") + (groupRule(g)?.name || "")).includes(q));

  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        <Chip active={sub === "المجموعات"} onClick={() => setSub("المجموعات")}>المجموعات ({db.assetGroups.length})</Chip>
        <Chip active={sub === "القواعد"} onClick={() => setSub("القواعد")}>القواعد ({db.assetGroupRules.length})</Chip>
      </div>

      {sub === "القواعد" && (<>
        {can.manage && <Btn bg={C.orange} onClick={() => setRuleForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ قاعدة مجموعات جديدة</Btn>}
        {db.assetGroupRules.length === 0 && <Empty text="ابدأ بالقاعدة: «مركبات حسب الموقع» بخاصية الموقع، ثم أنشئ مجموعاتها." />}
        {db.assetGroupRules.map((r) => (
          <div key={r.id} style={{ ...card(), borderRightColor: isStatusRule(r) ? C.red : C.ink, opacity: (!r.inactiveOn || r.inactiveOn >= today()) ? 1 : 0.6 }}
            onClick={() => can.manage && setRuleForm(r)}>
            <Row main={r.code + " — " + r.name}
              badge={isStatusRule(r) ? { text: "حالة الأصل", color: C.red } : r.enforceUnique ? { text: "فريد", color: C.purple } : undefined}
              sub={[(r.attributes || []).length ? "خصائص: " + (r.attributes || []).join("، ") : "بلا خصائص",
                db.assetGroups.filter((g) => g.ruleId === r.id).length + " مجموعة",
                r.inactiveOn && r.inactiveOn < today() ? "معطلة" : ""].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {sub === "المجموعات" && (<>
        {canUseSetupTools && missing.length > 0 && (
          <div style={{ ...card(), borderRightColor: C.blue, marginBottom: 12 }}>
            <Row main="مجموعات المطاحن القياسية" sub={missing.length + " مجموعة جاهزة تحت قاعدة «التصنيف القياسي»"}
              action={<Btn bg={C.blue} onClick={seed}>إضافتها دفعة واحدة</Btn>} />
          </div>
        )}
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالرقم/الاسم/القاعدة…" style={{ ...input, marginBottom: 10 }} />
        {can.manage && <Btn bg={C.orange} onClick={() => {
          if (!db.assetGroupRules.length) { alert("أنشئ قاعدة أولًا — لا مجموعة بدون قاعدة (قاعدة ف4)"); setSub("القواعد"); return; }
          setGroupForm("new");
        }} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ مجموعة جديدة</Btn>}
        {groups.length === 0 && <Empty text="لا مجموعات مطابقة." />}
        {groups.map((g) => (
          <div key={g.id} style={{ ...card(), opacity: groupActive(g) ? 1 : 0.6 }} onClick={() => setDetail(g.id)}>
            <Row main={(g.number ? g.number + " — " : "") + g.name}
              badge={(g.excludeFromWO || g.excludeFromRequests) ? { text: "استبعاد ⛔", color: C.red } : !groupActive(g) ? { text: "معطلة", color: C.steel } : undefined}
              sub={[groupRule(g)?.name || "بدون قاعدة", activeAssignments(g).length + " أصل معين",
                Object.entries(g.attrValues || {}).filter(([, v]) => v).map(([k, v]) => (GROUP_ATTRS.find(([kk]) => kk === k)?.[1] || k) + ": " + (k === "workCenterId" ? nameOf("workCenters", v) : v)).join("، ")].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {ruleForm && (
        <RuleFormSheet ctx={ctx} schema={ruleSchema(ruleForm === "new" ? null : ruleForm)} initial={ruleForm === "new" ? { usages: ["عام (صيانة وبرامج)"], attributes: [] } : { ...ruleForm }}
          title={ruleForm === "new" ? "قاعدة جديدة" : "تعديل قاعدة"} onClose={() => setRuleForm(null)}
          onDelete={ruleForm !== "new" && can.admin && !ruleHasGroups(ruleForm.id) ? () => { remove("assetGroupRules", ruleForm.id); setRuleForm(null); } : undefined}
          deleteBlockedMsg={ruleForm !== "new" && ruleHasGroups(ruleForm?.id) ? "توجد مجموعات تحت القاعدة — لا حذف؛ استخدم التعطيل" : ""}
          onSave={(d) => {
            const err = validateRule(d, ruleForm === "new" ? null : ruleForm);
            if (err) { alert(err); return; }
            ruleForm === "new" ? add("assetGroupRules", d) : update("assetGroupRules", ruleForm.id, d);
            setRuleForm(null);
          }} />
      )}
      {groupForm && (
        <GroupForm ctx={ctx} g={groupForm === "new" ? null : groupForm} onClose={() => setGroupForm(null)} />
      )}
      {detail && <GroupDetail ctx={ctx} groupId={detail} onClose={() => setDetail(null)} onEdit={(g) => { setDetail(null); setGroupForm(g); }} />}
    </>
  );
}

/* نموذج قاعدة مع خيارات ثابتة multi-static */
export function RuleFormSheet({ ctx, schema, initial, title, onClose, onSave, onDelete, deleteBlockedMsg }) {
  const [f, setF] = useState(initial);
  const set = (k, v) => setF({ ...f, [k]: v });
  return (
    <Sheet title={title} onClose={onClose}>
      {schema.map((s) => (
        <Field key={s.k} label={s.label}>
          {s.type === "multi-static" && (
            <div style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, padding: 8, background: "#fff" }}>
              {s.options.map((o) => (
                <label key={o} style={{ display: "flex", gap: 8, alignItems: "center", padding: "4px 0" }}>
                  <input type="checkbox" checked={(f[s.k] || []).includes(o)}
                    onChange={(e) => set(s.k, e.target.checked ? [...(f[s.k] || []), o] : (f[s.k] || []).filter((x) => x !== o))} />
                  <span style={{ fontSize: 14 }}>{o}</span>
                </label>
              ))}
            </div>
          )}
          {s.type === "check" && <input type="checkbox" checked={!!f[s.k]} onChange={(e) => set(s.k, e.target.checked)} style={{ width: 22, height: 22 }} />}
          {s.type === "textarea" && <textarea value={f[s.k] || ""} onChange={(e) => set(s.k, e.target.value)} rows={2} style={{ ...input, resize: "vertical" }} />}
          {(!s.type || ["text", "date"].includes(s.type)) && <input type={s.type || "text"} value={f[s.k] ?? ""} onChange={(e) => set(s.k, e.target.value)} style={input} />}
        </Field>
      ))}
      {deleteBlockedMsg && <div style={{ fontSize: 12, color: C.steel, marginBottom: 8 }}>{deleteBlockedMsg}</div>}
      <div style={{ display: "flex", gap: 8 }}>
        <Btn bg={C.orange} style={{ flex: 1, padding: 13 }} onClick={() => onSave(f)}>حفظ</Btn>
        {onDelete && <Btn bg={C.red} style={{ padding: 13 }} onClick={onDelete}>حذف</Btn>}
      </div>
    </Sheet>
  );
}

/* إنشاء/تعديل مجموعة: القاعدة تحدد الخصائص المطلوب تعبئتها */
export function GroupForm({ ctx, g, onClose }) {
  const { db, add, update, nameOf, activeAssignments } = ctx;
  const [f, setF] = useState(g ? { ...g } : { ruleId: db.assetGroupRules[0]?.id || "", attrValues: {}, excludeFromRequests: false, excludeFromWO: false });
  const rule = db.assetGroupRules.find((r) => r.id === f.ruleId);
  const hasAssigned = g && activeAssignments(g).length > 0;
  const isStatus = (rule?.usages || []).includes("حالة الأصل (قاعدة تحقق)");
  const attrKey = (label) => GROUP_ATTRS.find(([, l]) => l === label)?.[0] || label;
  const set = (k, v) => setF({ ...f, [k]: v });
  return (
    <Sheet title={g ? "تعديل مجموعة" : "مجموعة جديدة"} onClose={onClose}>
      <Field label={"القاعدة" + (g ? " — لا تتغير" : "")}>
        <select value={f.ruleId} disabled={!!g} onChange={(e) => set("ruleId", e.target.value)} style={input}>
          {db.assetGroupRules.map((r) => {
            const inactive = r.inactiveOn && r.inactiveOn < today();
            return <option key={r.id} value={r.id} disabled={inactive}>{r.name}{inactive ? " (معطلة ✗)" : ""}</option>;
          })}
        </select>
      </Field>
      <Field label="اسم المجموعة"><input value={f.name || ""} onChange={(e) => set("name", e.target.value)} style={input} /></Field>
      <Field label="الوصف"><input value={f.description || ""} onChange={(e) => set("description", e.target.value)} style={input} /></Field>
      {(rule?.attributes || []).map((label) => {
        const k = attrKey(label);
        return (
          <Field key={k} label={"خاصية: " + label + (hasAssigned ? " — مقفلة (توجد أصول)" : "")}>
            {k === "workCenterId" ? (
              <select value={(f.attrValues || {})[k] || ""} disabled={hasAssigned}
                onChange={(e) => set("attrValues", { ...(f.attrValues || {}), [k]: e.target.value })} style={input}>
                <option value="">—</option>
                {db.workCenters.map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
              </select>
            ) : k === "type" ? (
              <select value={(f.attrValues || {})[k] || ""} disabled={hasAssigned}
                onChange={(e) => set("attrValues", { ...(f.attrValues || {}), [k]: e.target.value })} style={input}>
                <option value="">—</option>
                {["معدات", "مركبة", "مبنى", "أداة", "أخرى"].map((t) => <option key={t}>{t}</option>)}
              </select>
            ) : (
              <input value={(f.attrValues || {})[k] || ""} disabled={hasAssigned}
                onChange={(e) => set("attrValues", { ...(f.attrValues || {}), [k]: e.target.value })} style={input} />
            )}
          </Field>
        );
      })}
      {isStatus && (<>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <input type="checkbox" checked={!!f.excludeFromWO} disabled={hasAssigned} onChange={(e) => set("excludeFromWO", e.target.checked)} style={{ width: 20, height: 20 }} />
          <span style={{ fontSize: 14 }}>استبعاد أصول المجموعة من أوامر العمل{hasAssigned ? " (مقفل)" : ""}</span>
        </label>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
          <input type="checkbox" checked={!!f.excludeFromRequests} disabled={hasAssigned} onChange={(e) => set("excludeFromRequests", e.target.checked)} style={{ width: 20, height: 20 }} />
          <span style={{ fontSize: 14 }}>استبعاد أصول المجموعة من طلبات العمل{hasAssigned ? " (مقفل)" : ""}</span>
        </label>
      </>)}
      <Field label="تعطيل اعتبارًا من (لا تعيينات جديدة بعده)"><input type="date" value={f.inactiveOn || ""} onChange={(e) => set("inactiveOn", e.target.value)} style={input} /></Field>
      <Btn bg={C.orange} style={{ width: "100%", padding: 13 }} onClick={() => {
        if (!String(f.name || "").trim()) { alert("الاسم مطلوب"); return; }
        if (!f.ruleId) { alert("اختر القاعدة"); return; }
        const r = db.assetGroupRules.find((x) => x.id === f.ruleId);
        if (r?.inactiveOn && r.inactiveOn < today() && !g) { alert("القاعدة معطلة — لا مجموعات جديدة"); return; }
        for (const label of (r?.attributes || [])) {
          if (!((f.attrValues || {})[attrKey(label)])) { alert("أدخل قيمة خاصية «" + label + "» — إلزامية حسب القاعدة"); return; }
        }
        if (g) update("assetGroups", g.id, f);
        else add("assetGroups", { number: "AG-" + String(100 + db.assetGroups.length + 1), assignments: [], assetIds: [], code: "", ...f });
        onClose();
      }}>حفظ</Btn>
    </Sheet>
  );
}

/* تفاصيل المجموعة: التعيينات + إضافة المؤهلين + إعادة التحقق */
export function GroupDetail({ ctx, groupId, onClose, onEdit }) {
  const { db, update, remove, nameOf, can, groupRule, groupActive, activeAssignments, canAssignAsset, assignAsset, unassignAsset, revalidateGroup } = ctx;
  const g = db.assetGroups.find((x) => x.id === groupId);
  const [showEnded, setShowEnded] = useState(false);
  const [pick, setPick] = useState("");
  if (!g) return null;
  const rule = groupRule(g);
  const act = activeAssignments(g);
  const ended = (g.assignments || []).filter((x) => x.end);
  const eligible = db.assets.filter((a) => !canAssignAsset(a, g));
  return (
    <Sheet title={(g.number ? g.number + " — " : "") + g.name} onClose={onClose}>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        القاعدة: <b>{rule?.name || "—"}</b>{rule?.enforceUnique ? " · تعيين فريد" : ""}<br />
        {(rule?.attributes || []).length > 0 && <>الخصائص: <b>{Object.entries(g.attrValues || {}).filter(([, v]) => v).map(([k, v]) => (GROUP_ATTRS.find(([kk]) => kk === k)?.[1] || k) + " = " + (k === "workCenterId" ? nameOf("workCenters", v) : v)).join("، ")}</b><br /></>}
        {(g.excludeFromWO || g.excludeFromRequests) && <span style={{ color: C.red, fontWeight: 700 }}>⛔ تحقق: {[g.excludeFromWO ? "مستبعدة من أوامر العمل" : "", g.excludeFromRequests ? "مستبعدة من طلبات العمل" : ""].filter(Boolean).join(" و")}<br /></span>}
        {!groupActive(g) && <span style={{ color: C.steel }}>معطلة منذ {fmt(g.inactiveOn)} — لا تعيينات جديدة</span>}
      </div>
      {can.manage && (
        <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
          <Btn bg={C.blue} onClick={() => onEdit(g)}>تعديل</Btn>
          <Btn bg={C.amber} onClick={() => {
            const bad = revalidateGroup(g);
            alert(bad.length ? "⚠ أُنهيت تعيينات غير مطابقة:\n• " + bad.join("\n• ") : "✓ كل التعيينات مطابقة");
          }}>إعادة التحقق من التطابق</Btn>
          {can.admin && (act.length === 0
            ? <Btn bg={C.red} onClick={() => { if (confirm("حذف المجموعة؟")) { remove("assetGroups", g.id); onClose(); } }}>حذف</Btn>
            : <span style={{ fontSize: 12, color: C.steel, alignSelf: "center" }}>توجد أصول معينة — لا حذف</span>)}
        </div>
      )}
      <Section title={"الأصول المعينة (" + act.length + ")"}>
        {act.map((x) => {
          const a = db.assets.find((z) => z.id === x.assetId);
          return (
            <div key={x.id} style={card()}>
              <Row main={(a?.number ? a.number + " — " : "") + (a?.name || "أصل محذوف")} sub={"منذ " + fmt(x.start) + " · " + (x.by || "")}
                action={can.manage ? <Btn bg={C.red} onClick={() => unassignAsset(g, x.id, "إلغاء يدوي")}>إلغاء التعيين</Btn> : null} />
            </div>
          );
        })}
        {act.length === 0 && <Empty text="لا أصول معينة بعد." />}
        {can.manage && groupActive(g) && (
          <div style={{ display: "flex", gap: 8 }}>
            <select value={pick} onChange={(e) => setPick(e.target.value)} style={input}>
              <option value="">— الأصول المؤهلة فقط ({eligible.length}) —</option>
              {eligible.map((a) => <option key={a.id} value={a.id}>{a.number} — {a.name}</option>)}
            </select>
            <Btn bg={C.green} onClick={() => { if (!pick) return; const e = assignAsset(g, pick); if (e) alert(e); setPick(""); }}>تعيين</Btn>
          </div>
        )}
      </Section>
      {ended.length > 0 && (
        <Section title={"تعيينات منتهية (" + ended.length + ")"}>
          <button onClick={() => setShowEnded(!showEnded)} style={{ ...delBtn, color: C.blue }}>{showEnded ? "إخفاء" : "عرض"}</button>
          {showEnded && ended.map((x) => {
            const a = db.assets.find((z) => z.id === x.assetId);
            return (
              <div key={x.id} style={{ ...card(), opacity: 0.6 }}>
                <Row main={a?.name || "أصل"} sub={fmt(x.start) + " ← " + fmt(x.end) + " · السبب: " + (x.endReason || "—")} />
              </div>
            );
          })}
        </Section>
      )}
    </Sheet>
  );
}

export function normalizeSearchText(v) {
  return String(v || "").toLowerCase().replace(/[.\-_\/،,;:]+/g, " ").replace(/\s+/g, " ").trim();
}
export function parseSearchChip(chip) {
  const quoted = String(chip || "").match(/"([^"]+)"|“([^”]+)”/g);
  if (quoted?.length) return quoted.map((x) => x.replace(/["“”]/g, "").toLowerCase());
  return normalizeSearchText(chip).split(" ").filter(Boolean);
}
export function assetSearchBlob(a) {
  return normalizeSearchText([a.number, a.name, a.description, a.itemName, a.itemId, a.serial, a.lotNumber, a.location, a.locationType, a.type, a.ownership, a.customer, a.contact, a.project, a.task, a.countryOfOrigin, ...(a.flexfields || []).map((f) => f.name + " " + f.value)].join(" "));
}
export function smartAssetMatch(a, chips) {
  if (!chips.length) return true;
  const blob = assetSearchBlob(a);
  return chips.every((chip) => parseSearchChip(chip).some((term) => blob.includes(normalizeSearchText(term))));
}

export function Assets({ ctx, openAsset }) {
  const { db, nameOf, can, exportAssetsCSV, assetUsable } = ctx;
  const [q, setQ] = useState("");
  const [chips, setChips] = useState([]);
  const [wizard, setWizard] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [groupFilter, setGroupFilter] = useState("");
  const [showEnded, setShowEnded] = useState(false);
  const [includeChildren, setIncludeChildren] = useState(false);
  const [flag, setFlag] = useState("الكل");
  const addChip = () => { const v = q.trim(); if (v && !chips.includes(v)) setChips([...chips, v]); setQ(""); };
  let list = db.assets.filter((a) => smartAssetMatch(a, [...chips, ...(q.trim() ? [q] : [])]));
  if (groupFilter) {
    const g = db.assetGroups.find((x) => x.id === groupFilter);
    const ids = new Set(g?.assetIds || []);
    if (includeChildren) db.assets.filter((a) => ids.has(a.parentId)).forEach((a) => ids.add(a.id));
    list = list.filter((a) => ids.has(a.id));
  }
  if (!showEnded) list = list.filter((a) => assetUsable(a));
  if (flag === "أوامر مسموحة") list = list.filter((a) => a.allowWO !== false);
  if (flag === "برامج مسموحة") list = list.filter((a) => a.allowPrograms !== false);
  if (flag === "IoT") list = list.filter((a) => a.enableIoT);
  if (flag === "أصول عملاء") list = list.filter((a) => a.ownership === "عميل");
  if (flag === "أصول مؤسسة") list = list.filter((a) => a.ownership !== "عميل");
  return (
    <>
      <AssetQuickLookup ctx={ctx} openAsset={openAsset} setQ={setQ} />
      <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") addChip(); }}
          placeholder='🔍 بحث ذكي: اكتب كلمة أو "عبارة حرفية" ثم Enter' style={{ ...input, flex: 1 }} />
        <Btn bg={C.ink} onClick={addChip}>شريحة</Btn>
      </div>
      <div style={{ fontSize: 11.5, color: C.steel, marginBottom: 6 }}>البحث الذكي: OR داخل الشريحة الواحدة، AND بين الشرائح، ويبحث في الرقم/الوصف/الصنف/السيريال/الموقع/العميل/Flexfields.</div>
      {chips.length > 0 && (
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
          {chips.map((c) => <Chip key={c} active onClick={() => setChips(chips.filter((x) => x !== c))}>{c} ×</Chip>)}
        </div>
      )}
      {db.assetGroups.length > 0 && (
        <select value={groupFilter} onChange={(e) => setGroupFilter(e.target.value)} style={{ ...input, marginBottom: 10, padding: "8px 12px" }}>
          <option value="">كل المجموعات</option>
          {db.assetGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
        </select>
      )}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 8 }}>
        {["الكل", "أصول مؤسسة", "أصول عملاء", "أوامر مسموحة", "برامج مسموحة", "IoT"].map((f) => <Chip key={f} active={flag === f} onClick={() => setFlag(f)}>{f}</Chip>)}
      </div>
      <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12.5, marginBottom: 5 }}>
        <input type="checkbox" checked={showEnded} onChange={(e) => setShowEnded(e.target.checked)} /> إظهار الأصول المنتهية/الموقوفة
      </label>
      <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12.5, marginBottom: 8 }}>
        <input type="checkbox" checked={includeChildren} onChange={(e) => setIncludeChildren(e.target.checked)} /> عند فلترة مجموعة: تضمين الأصول الفرعية
      </label>
      {can.manage && (
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <Btn bg={C.orange} onClick={() => setWizard(true)} style={{ flex: 1, padding: 12 }}>+ تسجيل أصل (معالج)</Btn>
          <Btn bg={C.ink} onClick={() => setShowImport(true)} style={{ padding: 12 }}>📥 Excel</Btn>
          {can.admin && <Btn bg={C.green} onClick={() => ctx.setTab?.("qrlabels")} style={{ padding: 12 }}>ملصقات QR</Btn>}
          <Btn bg={C.blue} onClick={exportAssetsCSV} style={{ padding: 12 }}>CSV</Btn>
        </div>
      )}
      {list.length === 0 && <Empty text="لا أصول مطابقة." />}
      {list.map((a) => (
        <div key={a.id} style={card()} onClick={() => openAsset(a.id)}>
          <Row main={a.number + " — " + a.name}
            sub={[a.location, a.locationType && a.locationType !== "UNKNOWN" ? a.locationType : "", a.type, a.itemName ? "Item: " + a.itemName : "", a.ownership === "عميل" ? "عميل: " + (a.customer || "—") : "مؤسسة", Number(a.quantity) > 1 ? "كمية " + a.quantity : "",
              a.critical ? "⚠ حرج" : "", a.allowWO === false ? "🚫 أوامر" : "", a.enableIoT ? "📡 IoT" : "",
              a.parentId ? "تابع لـ " + nameOf("assets", a.parentId) : ""].filter(Boolean).join(" · ")}
            badge={!assetUsable(a) ? { text: a.endDate && a.endDate < today() ? "منتهٍ" : "موقوف", color: C.steel } : undefined} />
        </div>
      ))}
      {wizard && <AssetWizard ctx={ctx} onClose={() => setWizard(false)} />}
      {showImport && <ExcelImport ctx={ctx} onClose={() => setShowImport(false)} />}
    </>
  );
}

/* معالج إنشاء الأصل خطوة بخطوة (وثيقة الأصول §تدفق الإنشاء) */
export function AssetWizard({ ctx, onClose }) {
  const { db, save } = ctx;
  const [step, setStep] = useState(0);
  const [a, setA] = useState({ active: true, critical: false, type: "معدات", ownership:"مؤسسة", itemRequired:true, locationType:"UNKNOWN", quantity:1, allowWO:true, allowPrograms:true });
  const [meterTplId, setMeterTplId] = useState(""); const [meterInit, setMeterInit] = useState("0");
  const [partsText, setPartsText] = useState("");
  const [warr, setWarr] = useState({ supplier: "", start: "", end: "" });
  const set = (k, v) => setA({ ...a, [k]: v });
  const STEPS = ["الأساسيات والموقع", "التصنيف", "البيانات الفنية", "الهيكل", "العدادات", "قطع الغيار", "الضمان"];
  const next = () => {
    if (step === 0) {
      if (!String(a.name || "").trim()) return alert("أدخل اسم الأصل");
      if (!String(a.location || "").trim()) return alert("لا أصل بدون موقع (قاعدة النظام)");
      const err = ctx.assetSaveErrors(a, null);
      if (err) return alert(err);
    }
    setStep(step + 1);
  };
  const finish = () => {
    const err = ctx.assetSaveErrors(a, null);
    if (err) return alert(err);
    const parts = partsText.split("\n").filter(Boolean).map((l) => {
      const seg = l.includes("،") ? l.split("،") : l.split(",");
      return { id: uid(), name: (seg[0] || l).trim(), qty: (seg[1] || "1").trim(), itemId:"", uom:"" };
    });
    const groupId = a._groupId; const data = { ...a }; delete data._groupId;
    if (!String(data.number || "").trim()) data.number = ctx.nextAssetNumber();
    const created = { id: uid(), ...data, assetType: data.ownership === "عميل" ? "CUSTOMER" : "ENTERPRISE", parts, docs: [], photos: [], specs: data.specs || "",
      quantity: Number(data.quantity || 1), notes: [], flexfields: [], serviceRequests: [],
      history: [{ action: "إنشاء عبر المعالج", at: now(), by: ctx.role }] };
    let next = { ...db, assets: [...db.assets, created] };
    if (groupId) {
      next.assetGroups = db.assetGroups.map((g) => g.id === groupId ? { ...g, assetIds: [...(g.assetIds || []), created.id], assignments: [...(g.assignments || []), { id: uid(), assetId: created.id, start: today(), end:"", endReason:"", by: ctx.role }] } : g);
    }
    if (meterTplId) next.assetMeters = [...db.assetMeters, { id: uid(), assetId: created.id, templateId: meterTplId, initial: Number(meterInit || 0), recordAtWO:"", endDate:"", estDailyRate:"", readingsForRate:"" }];
    if (warr.supplier && warr.end) next.warranties = [...db.warranties, { id: uid(), assetId: created.id, ...warr }];
    if (created.enableIoT) next.assetIotSyncEvents = [...(db.assetIotSyncEvents || []), { id: uid(), assetId: created.id, at: now(), trigger:"إنشاء الأصل", status:"Queued", message:"مزامنة Digital Twin مطلوبة" }];
    save(next);
    alert("✓ أُنشئ ملف الأصل — جاهز للصيانة والتكاليف");
    onClose();
  };
  return (
    <Sheet title={"تسجيل أصل — " + (step + 1) + "/" + STEPS.length + ": " + STEPS[step]} onClose={onClose}>
      <div style={{ display: "flex", gap: 4, marginBottom: 14 }}>
        {STEPS.map((s, i) => <div key={s} style={{ flex: 1, height: 5, borderRadius: 3, background: i <= step ? C.orange : C.line }} />)}
      </div>
      {step === 0 && (<>
        <Field label="رقم الأصل (فارغ = توليد تلقائي)"><input value={a.number || ""} onChange={(e) => set("number", e.target.value)} placeholder="ELA-01" style={input} /></Field>
        <Field label="اسم الأصل"><input value={a.name || ""} onChange={(e) => set("name", e.target.value)} style={input} /></Field>
        <Field label="ملكية الأصل"><select value={a.ownership || "مؤسسة"} onChange={(e) => set("ownership", e.target.value)} style={input}>{ASSET_OWNERSHIP.map((x) => <option key={x}>{x}</option>)}</select></Field>
        {a.ownership === "عميل" && <Field label="العميل"><input value={a.customer || ""} onChange={(e) => set("customer", e.target.value)} placeholder="اسم العميل" style={input} /></Field>}
        <label style={{ display:"flex", gap:8, alignItems:"center", marginBottom:10 }}><input type="checkbox" checked={!!a.itemRequired} onChange={(e) => set("itemRequired", e.target.checked)} /> <span>الصنف Item مطلوب لهذا الأصل</span></label>
        {a.itemRequired && <Field label="Item / الصنف المرتبط"><input value={a.itemName || ""} onChange={(e) => set("itemName", e.target.value)} placeholder="مثال: Bucket Elevator Assembly" style={input} /></Field>}
        <Field label="منظمة التشغيل/الصيانة"><select value={a.operatingOrganizationId || ""} onChange={(e) => set("operatingOrganizationId", e.target.value)} style={input}><option value="">—</option>{db.maintenanceOrganizations.map((o) => <option key={o.id} value={o.id}>{o.name || o.code}</option>)}</select></Field>
        <Field label="نوع الموقع"><select value={a.locationType || "UNKNOWN"} onChange={(e) => set("locationType", e.target.value)} style={input}>{LOCATION_TYPES.map((x) => <option key={x}>{x}</option>)}</select></Field>
        <Field label="الموقع (إلزامي — المصنع/المنطقة)"><input value={a.location || ""} onChange={(e) => set("location", e.target.value)} placeholder="طابق الطحن — خط 1" style={input} /></Field>
      </>)}
      {step === 1 && (<>
        <Field label="نوع الأصل">
          <select value={a.type} onChange={(e) => set("type", e.target.value)} style={input}>
            {["معدات", "مركبة", "مبنى", "أداة", "أخرى"].map((t) => <option key={t}>{t}</option>)}
          </select>
        </Field>
        <div style={{ display:"flex", gap:8 }}><Field label="الكمية"><input type="number" value={a.quantity || 1} onChange={(e) => set("quantity", e.target.value)} style={input} /></Field><Field label="UOM"><input value={a.uom || ""} onChange={(e) => set("uom", e.target.value)} placeholder="EA" style={input} /></Field></div>
        <Field label="المجموعة (مصاعد قواديس، مراوح…)">
          <select value={a._groupId || ""} onChange={(e) => set("_groupId", e.target.value)} style={input}>
            <option value="">— بدون —</option>
            {db.assetGroups.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </Field>
        <Field label="SubType افتراضي لأمر العمل"><select value={a.defaultWOSubtype || ""} onChange={(e) => set("defaultWOSubtype", e.target.value)} style={input}>{DEFAULT_WO_SUBTYPES.map((x) => <option key={x}>{x}</option>)}</select></Field>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}><input type="checkbox" checked={!!a.critical} onChange={(e) => set("critical", e.target.checked)} style={{ width: 20, height: 20 }} /><span>أصل حرج</span></label>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}><input type="checkbox" checked={!!a.enableIoT} onChange={(e) => set("enableIoT", e.target.checked)} style={{ width: 20, height: 20 }} /><span>تفعيل IoT / Digital Twin</span></label>
        <label style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}><input type="checkbox" checked={!!a.competitorAsset} onChange={(e) => set("competitorAsset", e.target.checked)} style={{ width: 20, height: 20 }} /><span>أصل منافس لا يتوقع صيانته</span></label>
      </>)}
      {step === 2 && (<>
        <Field label="الرقم التسلسلي"><input value={a.serial || ""} onChange={(e) => set("serial", e.target.value)} style={input} /></Field>
        <Field label="المواصفات الفنية (سطر لكل مواصفة)">
          <textarea value={a.specs || ""} onChange={(e) => set("specs", e.target.value)} rows={4} placeholder={"القدرة: 15 kW\nالسرعة: 1450 rpm\nالمصنّع: Buhler"} style={{ ...input, resize: "vertical" }} />
        </Field>
      </>)}
      {step === 3 && (
        <Field label="الأصل الأب (الهيكل الفيزيائي)">
          <select value={a.parentId || ""} onChange={(e) => set("parentId", e.target.value)} style={input}>
            <option value="">— أصل رئيسي —</option>
            {db.assets.map((x) => <option key={x.id} value={x.id}>{x.number} — {x.name}</option>)}
          </select>
        </Field>
      )}
      {step === 4 && (<>
        <Field label="ربط عداد (اختياري)">
          <select value={meterTplId} onChange={(e) => setMeterTplId(e.target.value)} style={input}>
            <option value="">— بدون عداد —</option>
            {db.meterTemplates.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.uom})</option>)}
          </select>
        </Field>
        {meterTplId && <Field label="القراءة الابتدائية"><input type="number" value={meterInit} onChange={(e) => setMeterInit(e.target.value)} style={input} /></Field>}
        {db.meterTemplates.length === 0 && <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 10 }}>لا قوالب عدادات بعد — أنشئها من تبويب العدادات لاحقًا.</div>}
      </>)}
      {step === 5 && (
        <Field label="قطع الغيار (سطر لكل قطعة: الاسم، الكمية)">
          <textarea value={partsText} onChange={(e) => setPartsText(e.target.value)} rows={4} placeholder={"سير ناقل، 2\nمحمل 6205، 4\nشحم ليثيوم، 1"} style={{ ...input, resize: "vertical" }} />
        </Field>
      )}
      {step === 6 && (<>
        <Field label="مورد الضمان (اتركه فارغًا إن لا يوجد)"><input value={warr.supplier} onChange={(e) => setWarr({ ...warr, supplier: e.target.value })} style={input} /></Field>
        <div style={{ display: "flex", gap: 8 }}>
          <Field label="البداية"><input type="date" value={warr.start} onChange={(e) => setWarr({ ...warr, start: e.target.value })} style={input} /></Field>
          <Field label="النهاية"><input type="date" value={warr.end} onChange={(e) => setWarr({ ...warr, end: e.target.value })} style={input} /></Field>
        </div>
      </>)}
      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        {step > 0 && <Btn bg={C.steel} style={{ padding: 12 }} onClick={() => setStep(step - 1)}>السابق</Btn>}
        {step < STEPS.length - 1
          ? <Btn bg={C.orange} style={{ flex: 1, padding: 12 }} onClick={next}>التالي</Btn>
          : <Btn bg={C.green} style={{ flex: 1, padding: 12 }} onClick={finish}>✓ إنشاء ملف الأصل</Btn>}
      </div>
    </Sheet>
  );
}

export function AssetGroupJoin({ a, db, canAssignAsset, assignAsset }) {
  const [pick, setPick] = useState("");
  const eligible = db.assetGroups.filter((g) => !canAssignAsset(a, g));
  if (!eligible.length) return null;
  return (
    <div style={{ display: "flex", gap: 8 }}>
      <select value={pick} onChange={(e) => setPick(e.target.value)} style={input}>
        <option value="">— ضمّه لمجموعة مؤهلة ({eligible.length}) —</option>
        {eligible.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}
      </select>
      <Btn bg={C.green} onClick={() => { if (!pick) return; const g = db.assetGroups.find((x) => x.id === pick); const e = assignAsset(g, a.id); if (e) alert(e); setPick(""); }}>تعيين</Btn>
    </div>
  );
}

export function DocForm({ onAdd }) {
  const [name, setName] = useState(""); const [type, setType] = useState(DOC_TYPES[0]); const [url, setUrl] = useState("");
  return (
    <div style={card()}>
      <Field label="اسم المستند"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="دليل تشغيل المصعد" style={input} /></Field>
      <Field label="النوع">
        <select value={type} onChange={(e) => setType(e.target.value)} style={input}>{DOC_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
      </Field>
      <Field label="رابط الملف (Drive/سيرفر — اختياري)"><input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" style={input} /></Field>
      <Btn bg={C.ink} style={{ width: "100%" }} onClick={() => { if (name.trim()) { onAdd({ name, type, url }); setName(""); setUrl(""); } }}>+ إضافة مستند</Btn>
    </div>
  );
}

export function AssetDetail({ ctx, assetId, onClose, openWO }) {
  const { db, add, update, remove, save, nameOf, ltd, can, woCost, activeWarranty, activeAssignments, canAssignAsset, assignAsset, unassignAsset, copyAsset, splitAsset, assetSaveErrors, propagateLocation, logAsset, descendants, assetUsable, createMediaFromFile, deleteMediaFromStorage } = ctx;
  const a = db.assets.find((x) => x.id === assetId);
  const [sub, setSub] = useState("عام");
  const [edit, setEdit] = useState(false);
  const [assetPhotoUploading, setAssetPhotoUploading] = useState(false);
  if (!a) return null;
  const children = db.assets.filter((x) => x.parentId === a.id);
  const wos = db.workOrders.filter((w) => w.assetId === a.id);
  const meters = db.assetMeters.filter((m) => m.assetId === a.id);
  const warr = db.warranties.filter((w) => w.assetId === a.id);
  const aw = activeWarranty(a.id);
  const totalCost = wos.reduce((s, w) => s + woCost(w).total, 0);
  const failures = wos.filter((w) => w.failure);
  const TABS = ["Asset 360", "QR", "عام", "الهيكل", "قطع الغيار", "المستندات", "الصور", "التكاليف", "التاريخ", "ملاحظات", "Flexfields", "الأصل المالي", "الخدمة", "IoT"];
  const addDoc = (d) => update("assets", a.id, { docs: [...(a.docs || []), { id: uid(), ...d }] });
  const addPhoto = async (file) => {
    try {
      setAssetPhotoUploading(true);
      const photo = await createMediaFromFile(file, { entity:"assets", recordId:a.id, kind:"أصل", type:"أصل" });
      const nextAsset = { ...a, photos:[...(a.photos || []), photo] };
      save({ ...db, assets: db.assets.map((x)=>x.id===a.id ? nextAsset : x), mediaFiles:[...(db.mediaFiles || []), { ...photo, linkedEntity:"assets", linkedRecordId:a.id }] });
    }
    catch (e) { console.error(e); alert("تعذر معالجة أو رفع الصورة"); }
    finally { setAssetPhotoUploading(false); }
  };
  const removeAssetPhoto = async (p) => {
    await deleteMediaFromStorage?.(p);
    save({ ...db, assets: db.assets.map((x)=>x.id===a.id ? { ...a, photos:(a.photos||[]).filter((y)=>y.id!==p.id) } : x), mediaFiles:(db.mediaFiles||[]).filter((x)=>x.id!==p.id) });
  };
  return (
    <Sheet title={a.number} onClose={onClose}>
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontWeight: 800, fontSize: 18 }}>{a.name} {a.critical && <span style={{ color: C.red }}>⚠</span>}</div>
        <div style={{ fontSize: 13, color: C.steel }}>
          {[a.type, a.location, a.serial ? "تسلسلي " + a.serial : ""].filter(Boolean).join(" · ")}
        </div>
        {aw && <div style={{ fontSize: 13, color: C.green, fontWeight: 700, marginTop: 4 }}>🛡 تحت ضمان «{aw.supplier}» حتى {fmt(aw.end)} — راجعه قبل أي إصلاح داخلي</div>}
        {!assetUsable(a) && <div style={{ fontSize: 13, color: C.steel, fontWeight: 700, marginTop: 4 }}>⛔ {a.endDate && a.endDate < today() ? "أصل منتهٍ منذ " + fmt(a.endDate) : "موقوف"} — لا أوامر ولا برامج</div>}
        {can.manage && (
          <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
            <Btn bg={C.blue} onClick={() => setEdit(true)}>تعديل</Btn>
            <Btn bg={C.purple} onClick={() => {
              const withMeters = db.assetMeters.some((m) => m.assetId === a.id) && confirm("نسخ عدادات الأصل أيضًا؟ (بقراءة ابتدائية 0)");
              const c = copyAsset(a, withMeters);
              alert("✓ أُنشئت النسخة " + c.number);
            }}>نسخ</Btn>
            {!a.serial && Number(a.quantity || 1) > 1 && (
              <Btn bg={C.amber} onClick={() => {
                if (!confirm("تقسيم الأصل إلى " + a.quantity + " وحدات مستقلة (كمية كل وحدة = 1)؟")) return;
                const e = splitAsset(a);
                alert(e ? "⛔ " + e : "✓ تم التقسيم — راجع قائمة الأصول");
              }}>تقسيم ({a.quantity})</Btn>
            )}
            <Btn bg={a.active === false ? C.green : C.steel} onClick={() => update("assets", a.id, { active: a.active === false })}>
              {a.active === false ? "تفعيل" : "إيقاف"}
            </Btn>
            {can.admin && <Btn bg={C.red} onClick={() => { remove("assets", a.id); onClose(); }}>حذف</Btn>}
          </div>
        )}
      </div>
      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 10 }}>
        {TABS.map((t) => <Chip key={t} active={sub === t} onClick={() => setSub(t)}>{t}</Chip>)}
      </div>

      {sub === "Asset 360" && (
        <Section title="Asset 360 — مؤشرات وروابط الأصل">
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8, marginBottom:10 }}>
            <Stat n={wos.length} label="أوامر عمل" color={C.blue} />
            <Stat n={children.length} label="أصول فرعية" color={C.purple} />
            <Stat n={meters.length} label="عدادات" color={C.green} />
            <Stat n={money(totalCost)} label="تكلفة" color={C.orange} small />
          </div>
          <div style={card()}>
            <Row main="الارتباطات" sub={[aw ? "ضمان فعال" : "لا ضمان فعال", "مجموعات: " + db.assetGroups.filter((g) => (g.assetIds || []).includes(a.id)).length, a.fixedAssetNumber ? "أصل مالي: " + a.fixedAssetNumber : "لا أصل مالي", a.enableIoT ? "IoT مفعل" : "IoT غير مفعل"].filter(Boolean).join(" · ")} />
          </div>
          <div style={{ fontSize:12.5, color:C.steel }}>هذا التبويب يجمع روابط الفصل 3: أوامر العمل، المجموعات، العقود، التاريخ، التكاليف، العدادات، والهيكل.</div>
        </Section>
      )}

      {sub === "QR" && <AssetSingleQrLabel ctx={ctx} asset={a} />}

      {sub === "عام" && (<>
        <Section title="البيانات الفنية">
          <div style={card()}>
            {(a.specs || "").split("\n").filter(Boolean).map((l, i) => <div key={i} style={{ fontSize: 14, marginBottom: 3 }}>{l}</div>)}
            {!a.specs && <span style={{ color: C.steel, fontSize: 13 }}>لا مواصفات مسجلة — عدّل الأصل لإضافتها.</span>}
          </div>
        </Section>
        <Section title={"العدادات (" + meters.length + ")"}>
          {meters.map((m) => (
            <div key={m.id} style={card()}>
              <Row main={nameOf("meterTemplates", m.templateId)} sub={"إجمالي العمر: " + ltd(m) + " " + nameOf("meterTemplates", m.templateId, "uom")} />
            </div>
          ))}
          {meters.length === 0 && <Empty text="لا عدادات — اربطها من تبويب العدادات." />}
        </Section>
        <Section title={"الضمانات (" + warr.length + ")"}>
          {warr.map((w) => (
            <div key={w.id} style={card()}>
              <Row main={w.supplier} sub={(daysUntil(w.end) >= 0 ? "ساري حتى " : "منتهي منذ ") + fmt(w.end)}
                badge={{ text: daysUntil(w.end) >= 0 ? "ساري" : "منتهي", color: daysUntil(w.end) >= 0 ? C.green : C.red }} />
            </div>
          ))}
          {warr.length === 0 && <Empty text="لا ضمانات مسجلة." />}
        </Section>
        <Section title="مجموعات هذا الأصل">
          {db.assetGroups.filter((g) => activeAssignments(g).some((x) => x.assetId === a.id)).map((g) => {
            const asn = activeAssignments(g).find((x) => x.assetId === a.id);
            return (
              <div key={g.id} style={card()}>
                <Row main={g.name} sub={"منذ " + fmt(asn.start)}
                  badge={(g.excludeFromWO || g.excludeFromRequests) ? { text: "تحقق ⛔", color: C.red } : undefined}
                  action={can.manage ? <Btn bg={C.red} onClick={() => unassignAsset(g, asn.id, "إلغاء يدوي")}>إلغاء</Btn> : null} />
              </div>
            );
          })}
          {db.assetGroups.filter((g) => activeAssignments(g).some((x) => x.assetId === a.id)).length === 0 && <Empty text="غير معين لأي مجموعة." />}
          {can.manage && (
            <AssetGroupJoin a={a} db={db} canAssignAsset={canAssignAsset} assignAsset={assignAsset} />
          )}
        </Section>
      </>)}

      {sub === "الهيكل" && (
        <Section title="الهرمية المادية — الفرع يرث موقع الأب الأعلى">
          {a.parentId && <div style={card()}><Row main={"⬆ الأب: " + nameOf("assets", a.parentId)}
            action={can.manage ? <Btn bg={C.steel} onClick={() => { update("assets", a.id, { parentId: "" }); logAsset(a.id, "فصل عن الأب"); }}>فصل</Btn> : null} /></div>}
          {children.map((c) => (
            <div key={c.id} style={card()}>
              <Row main={"⬇ " + c.number + " — " + c.name} sub={c.location} />
              {can.manage && (
                <div style={{ display: "flex", gap: 10, marginTop: 4, alignItems: "center", flexWrap: "wrap" }}>
                  <button onClick={() => update("assets", c.id, { parentId: "" })} style={{ ...delBtn, marginTop: 0 }}>إزالة من الهيكل</button>
                  <select defaultValue="" onChange={(e) => { if (e.target.value) { update("assets", c.id, { parentId: e.target.value, location: db.assets.find((x) => x.id === e.target.value)?.location || c.location }); e.target.value = ""; } }} style={{ ...input, width: "auto", padding: "4px 8px", fontSize: 12 }}>
                    <option value="">نقل تحت أب آخر…</option>
                    {db.assets.filter((x) => x.id !== c.id && x.id !== a.id && !descendants(c.id).some((d) => d.id === x.id)).map((x) => <option key={x.id} value={x.id}>{x.number} — {x.name}</option>)}
                  </select>
                </div>
              )}
            </div>
          ))}
          {!a.parentId && children.length === 0 && <Empty text="أصل مستقل — لا أب ولا مكونات تابعة." />}
          {can.manage && (<>
            <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
              <select defaultValue="" id={"addch-" + a.id} onChange={(e) => {
                if (!e.target.value) return;
                const child = db.assets.find((x) => x.id === e.target.value);
                update("assets", child.id, { parentId: a.id, location: a.location || child.location });
                logAsset(a.id, "إضافة فرع: " + child.number);
                e.target.value = "";
              }} style={input}>
                <option value="">+ إضافة أصل موجود كفرع (يرث الموقع)…</option>
                {db.assets.filter((x) => x.id !== a.id && x.parentId !== a.id && !descendants(a.id).some((d) => d.id === x.id) && x.id !== a.parentId).map((x) => <option key={x.id} value={x.id}>{x.number} — {x.name}</option>)}
              </select>
            </div>
            <AddInline placeholder="+ إنشاء فرع جديد سريع (الاسم فقط)" onAdd={(t) => {
              add("assets", { number: ctx.nextAssetNumber(), name: t, type: a.type, location: a.location, parentId: a.id,
                parts: [], docs: [], photos: [], specs: "", allowWO: true, allowPrograms: true, quantity: 1, active: true,
                notes: [], history: [{ action: "إنشاء كفرع لـ " + a.number, at: now(), by: ctx.role }] });
            }} />
          </>)}
        </Section>
      )}

      {sub === "قطع الغيار" && (
        <Section title={"قطع الغيار المرتبطة (" + (a.parts || []).length + ")"}>
          {(a.parts || []).map((p) => (
            <div key={p.id} style={card()}>
              <Row main={p.name} sub={"الكمية الموصى بها: " + p.qty}
                action={can.manage ? <Btn bg={C.red} onClick={() => update("assets", a.id, { parts: a.parts.filter((x) => x.id !== p.id) })}>حذف</Btn> : null} />
            </div>
          ))}
          {can.manage && <AddInline placeholder="اسم القطعة، الكمية (محمل 6205، 4)" onAdd={(t) => {
            const seg = t.includes("،") ? t.split("،") : t.split(",");
            update("assets", a.id, { parts: [...(a.parts || []), { id: uid(), name: (seg[0] || t).trim(), qty: (seg[1] || "1").trim() }] });
          }} />}
        </Section>
      )}

      {sub === "المستندات" && (
        <Section title={"المستندات (" + (a.docs || []).length + ")"}>
          {(a.docs || []).map((d) => (
            <div key={d.id} style={card()}>
              <Row main={"📄 " + d.name} sub={d.type + (d.url ? "" : " · بدون رابط")}
                action={d.url ? <Btn bg={C.blue} onClick={() => window.open(d.url, "_blank")}>فتح</Btn> : null} />
              {can.manage && <button onClick={() => update("assets", a.id, { docs: a.docs.filter((x) => x.id !== d.id) })} style={delBtn}>حذف</button>}
            </div>
          ))}
          {can.manage && <DocForm onAdd={addDoc} />}
        </Section>
      )}

      {sub === "الصور" && (
        <Section title={"صور الأصل (" + (a.photos || []).length + ")"}>
          {can.manage && (
            <div style={{ ...card() }}>
              <input type="file" accept="image/*" capture="environment" disabled={assetPhotoUploading} onChange={(e) => e.target.files[0] && addPhoto(e.target.files[0])} style={{ fontSize: 14 }} />
              <div style={{ fontSize:11.5, color:assetPhotoUploading ? C.amber : C.steel, marginTop:4 }}>{assetPhotoUploading ? "جارٍ الرفع…" : (ctx.firebaseEnabled ? "ستُرفع إلى Firebase Storage." : "Firebase غير مفعّل: حفظ داخلي مؤقت.")}</div>
            </div>
          )}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {(a.photos || []).map((p) => (
              <div key={p.id} style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, overflow: "hidden", background: "#fff" }}>
                <img src={mediaSrc(p)} alt="" style={{ width: "100%", display: "block" }} />
                <div style={{ display: "flex", justifyContent: "space-between", padding: "4px 8px", fontSize: 12 }}>
                  <span style={{ color: C.steel }}>{fmt(p.at)}</span><span style={{ color: isStorageMedia(p) ? C.green : C.amber }}>{isStorageMedia(p) ? "Storage" : "محلي"}</span>
                  {can.manage && <button onClick={() => removeAssetPhoto(p)} style={{ ...delBtn, marginTop: 0 }}>حذف</button>}
                </div>
              </div>
            ))}
          </div>
          {(a.photos || []).length === 0 && <Empty text="لا صور للأصل بعد." />}
        </Section>
      )}

      {sub === "التكاليف" && (
        <Section title="سجل التكاليف">
          <div style={{ ...card(), fontSize: 15, fontWeight: 800 }}>إجمالي تكلفة صيانة هذا الأصل: {money(totalCost)}</div>
          {wos.filter((w) => woCost(w).total > 0).map((w) => (
            <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
              <Row main={w.number + " — " + w.title} sub={w.type + " · " + fmt(w.completedAt || w.plannedStart)}
                badge={{ text: money(woCost(w).total), color: C.orange }} />
            </div>
          ))}
        </Section>
      )}

      {sub === "التاريخ" && (<>
        <Section title={"تاريخ الصيانة (" + wos.length + ")"}>
          {wos.slice().reverse().map((w) => (
            <div key={w.id} style={card()} onClick={() => openWO(w.id)}>
              <Row main={w.number + " — " + w.title} sub={w.type + " · " + fmt(w.plannedStart)} badge={{ text: w.status, color: WO_COLORS[w.status] }} />
            </div>
          ))}
          {wos.length === 0 && <Empty text="لا أوامر عمل على هذا الأصل." />}
        </Section>
        <Section title={"تاريخ الأعطال (" + failures.length + ")"}>
          {failures.map((w) => (
            <div key={w.id} style={{ ...card(), borderRightColor: C.red }} onClick={() => openWO(w.id)}>
              <Row main={w.failure.mode} sub={w.failure.cause + " · " + w.failure.downtime + " د توقف"} />
            </div>
          ))}
          {failures.length === 0 && <Empty text="لا أعطال مسجلة لهذا الأصل." />}
        </Section>
        <Section title={"سجل تغييرات الأصل (" + (a.history || []).length + ")"}>
          {(a.history || []).slice().reverse().map((h, i) => (
            <div key={i} style={{ fontSize: 13, color: C.steel, marginBottom: 4, borderBottom: `1px dashed ${C.line}`, paddingBottom: 4 }}>
              <b style={{ color: C.ink }}>{h.action}</b> — {h.at} — {h.by}
            </div>
          ))}
          {(a.history || []).length === 0 && <Empty text="لا تغييرات مسجلة." />}
        </Section>
      </>)}

      {sub === "ملاحظات" && (
        <Section title={"ملاحظات الأصل (" + (a.notes || []).length + ")"}>
          {(a.notes || []).slice().reverse().map((n) => (
            <div key={n.id} style={card()}>
              <Row main={n.text} sub={n.at + " · " + n.by}
                action={can.manage ? <Btn bg={C.red} onClick={() => update("assets", a.id, { notes: a.notes.filter((x) => x.id !== n.id) })}>حذف</Btn> : null} />
            </div>
          ))}
          {(a.notes || []).length === 0 && <Empty text="لا ملاحظات." />}
          {can.execute && <AddInline placeholder="ملاحظة جديدة…" onAdd={(t) =>
            update("assets", a.id, { notes: [...(a.notes || []), { id: uid(), text: t, at: now(), by: ctx.role }] })} />}
        </Section>
      )}

      {sub === "Flexfields" && (
        <Section title="Flexfields / معلومات إضافية مرنة">
          {(a.flexfields || []).map((f) => <div key={f.id} style={card()}><Row main={f.name} sub={f.value} action={can.manage ? <Btn bg={C.red} onClick={() => update("assets", a.id, { flexfields: a.flexfields.filter((x) => x.id !== f.id) })}>حذف</Btn> : null} /></div>)}
          {(a.flexfields || []).length === 0 && <Empty text="لا حقول إضافية." />}
          {can.manage && <AddInline placeholder="اسم الحقل = القيمة" onAdd={(t) => { const [name, ...rest] = t.split("="); update("assets", a.id, { flexfields: [...(a.flexfields || []), { id: uid(), name: (name || "حقل").trim(), value: rest.join("=").trim() }] }); }} />}
        </Section>
      )}

      {sub === "الأصل المالي" && (
        <Section title="Fixed Assets — الربط المالي">
          <div style={card()}><Row main={a.fixedAssetNumber || "غير مربوط بأصل مالي"} sub={[a.fixedAssetBook ? "دفتر: " + a.fixedAssetBook : "", a.countryOfOrigin ? "بلد المنشأ: " + a.countryOfOrigin : "", a.project ? "مشروع: " + a.project : ""].filter(Boolean).join(" · ")} /></div>
          {can.manage && <Btn bg={C.blue} onClick={() => setEdit(true)}>تعديل الربط من شاشة تعديل الأصل</Btn>}
        </Section>
      )}

      {sub === "الخدمة" && (
        <Section title="Service Logistics / B2B Service / Service Mapping">
          <div style={card()}><Row main="آخر عملية بيع / خدمة" sub={a.lastSalesOrderDetails || "لا توجد بيانات مبيعات/خدمة محفوظة"} /></div>
          {(db.assetServiceMappings || []).filter((m) => m.assetId === a.id).map((m) => <div key={m.id} style={card()}><Row main={m.source + " → " + m.targetField} sub={m.rule || "—"} /></div>)}
          {can.manage && <ServiceMappingForm db={db} assetId={a.id} save={ctx.save} />}
        </Section>
      )}

      {sub === "IoT" && (
        <Section title="IoT / Digital Twin Sync Events">
          <div style={card()}><Row main={a.enableIoT ? "IoT مفعل" : "IoT غير مفعل"} sub="تغيير Item / Serial / Enable IoT / Location يحفز سجل مزامنة" /></div>
          {(db.assetIotSyncEvents || []).filter((e) => e.assetId === a.id).slice().reverse().map((e) => <div key={e.id} style={card()}><Row main={e.trigger + " — " + e.status} sub={e.at + " · " + (e.message || "")} /></div>)}
          {can.manage && <Btn bg={C.purple} onClick={() => ctx.save({ ...db, assetIotSyncEvents: [...(db.assetIotSyncEvents || []), { id: uid(), assetId:a.id, at:now(), trigger:"مزامنة يدوية", status:"Queued", message:"طلب مزامنة من شاشة الأصل" }] })}>+ تسجيل حدث مزامنة</Btn>}
        </Section>
      )}

      {edit && (
        <FormSheet title="تعديل الأصل" onClose={() => setEdit(false)} db={db} schema={assetSchema()}
          initial={a} onSave={(d) => {
            const err = assetSaveErrors(d, a.id);
            if (err) { alert(err); return; }
            if (!String(d.number || "").trim()) d.number = ctx.nextAssetNumber();
            const locChanged = d.location !== a.location;
            update("assets", a.id, { ...d, history: [...(a.history || []), { action: "تعديل البيانات" + (locChanged ? " (الموقع ← " + d.location + ")" : ""), at: now(), by: ctx.role }] });
            setEdit(false);
            if (locChanged) {
              const n = propagateLocation(a.id, d.location);
              if (n > 0) alert("ℹ حُدّث موقع " + n + " أصل تابع (وراثة موقع الأب الأعلى)");
            }
          }} />
      )}
    </Sheet>
  );
}

/* ───────────────────────── العدادات ───────────────────────── */
/* ───────────────────────── العدادات (ف5) ───────────────────────── */
