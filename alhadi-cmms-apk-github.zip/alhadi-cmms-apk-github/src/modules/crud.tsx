import { useState } from "react";
import { ASSET_OWNERSHIP, C, DEFAULT_WO_SUBTYPES, LOCATION_TYPES } from "../core/appCore";
import { Btn, Empty, Field, Row, Sheet, card, input } from "../components/ui";

export function assetSchema() {
  return [
    { k: "number", label: "رقم الأصل (فارغ = توليد تلقائي)" }, { k: "name", label: "اسم الأصل" },
    { k: "ownership", label: "الملكية", type: "select", options: ASSET_OWNERSHIP },
    { k: "customer", label: "العميل (لأصل العميل)" },
    { k: "customerAccountId", label: "حساب العميل" },
    { k: "type", label: "النوع", type: "select", options: ["معدات", "مركبة", "مبنى", "أداة", "أخرى"] },
    { k: "itemRequired", label: "Item مطلوب", type: "check" },
    { k: "itemName", label: "Item / الصنف المرتبط" },
    { k: "fullLifecycleTracked", label: "Full Lifecycle Tracked", type: "check" },
    { k: "customerAssetTracking", label: "Customer Asset Tracking", type: "check" },
    { k: "operatingOrganizationId", label: "منظمة التشغيل/الصيانة", type: "select", from: "maintenanceOrganizations", fromKey: "name" },
    { k: "locationType", label: "نوع الموقع", type: "select", options: LOCATION_TYPES },
    { k: "location", label: "الموقع (إلزامي)" }, { k: "serial", label: "الرقم التسلسلي (فريد داخل المنظمة)" },
    { k: "lotNumber", label: "Lot Number" },
    { k: "quantity", label: "الكمية (غير المسلسل يقبل >1 ثم تقسيم)", type: "number" },
    { k: "uom", label: "UOM" }, { k: "secondaryQuantity", label: "Secondary Quantity", type: "number" },
    { k: "specs", label: "المواصفات الفنية (سطر لكل مواصفة)", type: "textarea" },
    { k: "parentId", label: "الأصل الأب", type: "select", from: "assets", fromKey: "name" },
    { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
    { k: "contact", label: "جهة الاتصال/المسؤول" },
    { k: "shipmentDate", label: "Shipment Date", type: "date" },
    { k: "installedDate", label: "Installed Date", type: "date" },
    { k: "inServiceDate", label: "In-Service Date", type: "date" },
    { k: "defaultWOType", label: "نوع أمر العمل الافتراضي", type: "select", options: ["", "تصحيحي", "وقائي", "طارئ"] },
    { k: "defaultWOSubtype", label: "Subtype افتراضي", type: "select", options: DEFAULT_WO_SUBTYPES },
    { k: "allowWO", label: "يسمح بأوامر العمل", type: "check" },
    { k: "allowPrograms", label: "يسمح ببرامج الصيانة", type: "check" },
    { k: "enableIoT", label: "تفعيل IoT (توأم رقمي)", type: "check" },
    { k: "competitorAsset", label: "Competitor Asset", type: "check" },
    { k: "critical", label: "أصل حرج", type: "check" }, { k: "active", label: "نشط", type: "check" },
    { k: "project", label: "Project" }, { k: "task", label: "Task" }, { k: "countryOfOrigin", label: "Country of Origin" },
    { k: "fixedAssetNumber", label: "Fixed Asset Number" }, { k: "fixedAssetBook", label: "Fixed Asset Book" },
    { k: "lastSalesOrderDetails", label: "Last Sales Order / Service Details", type: "textarea" },
    { k: "useBomForInitialHierarchy", label: "استخدام BOM لإنشاء هيكل أولي", type: "check" },
    { k: "endDate", label: "تاريخ إنهاء الأصل (ينهي الصيانة والاستخدام)", type: "date" },
  ];
}

export function Crud({ ctx, entity, title, schema, render, badge, validate, validateDelete }) {
  const { db, add, update, remove, can } = ctx;
  const [form, setForm] = useState(null);
  const rows = db[entity];
  return (
    <>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ إضافة — {title}</Btn>}
      {rows.length === 0 && <Empty text={"لا سجلات في " + title + " بعد."} />}
      {rows.map((r) => {
        const [main, sub] = render(r);
        return (
          <div key={r.id} style={card()} onClick={() => can.manage && setForm(r)}>
            <Row main={main} sub={sub} badge={badge ? badge(r) : undefined} />
          </div>
        );
      })}
      {form && (
        <FormSheet title={form === "new" ? "إضافة — " + title : "تعديل"} onClose={() => setForm(null)} db={db}
          schema={schema} initial={form === "new" ? { active: true } : form}
          onDelete={form !== "new" && can.admin ? () => { const err = validateDelete?.(form); if (err) { alert(err); return; } remove(entity, form.id); setForm(null); } : undefined}
          onSave={(d) => { const err = validate?.(d, form === "new" ? null : form); if (err) { alert(err); return; } form === "new" ? add(entity, d) : update(entity, form.id, d); setForm(null); }} />
      )}
    </>
  );
}

export function FormSheet({ title, schema, db, initial = {}, onSave, onClose, onDelete }) {
  const [f, setF] = useState(initial);
  const set = (k, v) => setF({ ...f, [k]: v });
  const first = schema[0].k;
  return (
    <Sheet title={title} onClose={onClose}>
      {schema.map((s) => (
        <Field key={s.k} label={s.label}>
          {s.type === "select" && (
            <select value={f[s.k] || ""} onChange={(e) => set(s.k, e.target.value)} style={input}>
              <option value="">—</option>
              {(s.options || db[s.from] || []).map((o) =>
                typeof o === "string"
                  ? <option key={o} value={o}>{o}</option>
                  : <option key={o.id} value={o.id}>{s.fromLabel ? s.fromLabel(o) : o[s.fromKey]}</option>)}
            </select>
          )}
          {s.type === "multi" && (
            <div style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, padding: 8, maxHeight: 140, overflowY: "auto", background: "#fff" }}>
              {(db[s.from] || []).length === 0 && <div style={{ color: C.steel, fontSize: 13 }}>لا عناصر متاحة بعد</div>}
              {(db[s.from] || []).map((o) => (
                <label key={o.id} style={{ display: "flex", gap: 8, alignItems: "center", padding: "4px 0" }}>
                  <input type="checkbox" checked={(f[s.k] || []).includes(o.id)}
                    onChange={(e) => set(s.k, e.target.checked ? [...(f[s.k] || []), o.id] : (f[s.k] || []).filter((x) => x !== o.id))} />
                  <span style={{ fontSize: 14 }}>{o[s.fromKey]}</span>
                </label>
              ))}
            </div>
          )}
          {s.type === "check" && <input type="checkbox" checked={!!f[s.k]} onChange={(e) => set(s.k, e.target.checked)} style={{ width: 22, height: 22 }} />}
          {s.type === "textarea" && <textarea value={f[s.k] || ""} onChange={(e) => set(s.k, e.target.value)} rows={3} style={{ ...input, resize: "vertical" }} />}
          {(!s.type || ["text", "number", "date"].includes(s.type)) && (
            <input type={s.type || "text"} value={f[s.k] ?? ""} onChange={(e) => set(s.k, e.target.value)} style={input} />
          )}
        </Field>
      ))}
      <div style={{ display: "flex", gap: 8 }}>
        <Btn bg={C.orange} style={{ flex: 1, padding: 13, fontSize: 15, opacity: String(f[first] || "").trim() ? 1 : 0.5 }}
          onClick={() => String(f[first] || "").trim() && onSave(f)}>حفظ</Btn>
        {onDelete && <Btn bg={C.red} style={{ padding: 13 }} onClick={onDelete}>حذف</Btn>}
      </div>
    </Sheet>
  );
}

