import { useState } from "react";
import { Sheet, Btn, Field, Section, Row, Empty, Chip, Badge, Stat, card, input } from "../components/ui";
import { C, uid, today } from "../core/appCore";
import { Crud } from "./crud";

/* ───────────────────────── المشتريات (المرحلة 1 — داخلية) ─────────────────────────
   • نواقص المخزون → اختيار عدة أصناف → طلب شراء/عرض أسعار موحّد بضغطة.
   • الموردون المعتمدون (Crud).
   • طلبات الشراء متعددة الأصناف: إدخال العروض، مقارنتها، اعتماد عرض → اعتماد للتسليم
     → تسجيل التسليم لكل سطر (تسليم جزئي) → مستلم بالكامل.
   ملاحظة: بوابة المورّد الخارجية ودور المورّد = المرحلة 2 (تحتاج عزل قراءة لكل مورّد).
   استلام المخزون الفعلي (stockTx) يبقى من اختصاص المخزن (صلاحية منفصلة). */

const statusColor = (s) => s === "معتمد للتسليم" ? C.green : s === "مستلم" ? C.blue : s === "مستلم جزئيًا" ? C.amber : s === "ملغي" ? C.steel : C.orange;

// توافق: طلب قديم بصنف واحد يُقرأ كسطر واحد
const linesOf = (po) => po.lines && po.lines.length ? po.lines
  : [{ id: po.id + "-L1", itemId: po.itemId, itemName: po.itemName, qty: po.qty, receivedQty: po.receivedQty || 0 }];

function POSheet({ ctx, po, onClose }) {
  const { db, save, add, nameOf } = ctx;
  const [supplierId, setSupplierId] = useState("");
  const [price, setPrice] = useState("");
  const [leadDays, setLeadDays] = useState("");
  const [notes, setNotes] = useState("");
  const [recv, setRecv] = useState({}); // lineId -> كمية مستلمة الآن

  const offers = (db.supplierOffers || []).filter((o) => o.poId === po.id);
  const suppliers = (db.suppliers || []).filter((s) => s.approved !== "لا");
  const lines = linesOf(po);

  const addOffer = () => {
    if (!supplierId) return alert("اختر المورّد");
    if (!price) return alert("أدخل السعر الإجمالي للعرض");
    add("supplierOffers", { poId: po.id, supplierId, price: Number(price), leadDays: Number(leadDays || 0), notes, status: "مقدّم", createdAt: today() });
    setSupplierId(""); setPrice(""); setLeadDays(""); setNotes("");
  };

  const acceptOffer = (offer) => {
    save({
      ...db,
      purchaseOrders: db.purchaseOrders.map((p) => p.id === po.id ? { ...p, status: "معتمد للتسليم", supplierId: offer.supplierId, acceptedOfferId: offer.id } : p),
      supplierOffers: db.supplierOffers.map((o) => o.poId === po.id ? { ...o, status: o.id === offer.id ? "مقبول" : "مرفوض" } : o),
    });
    onClose();
  };

  const applyReceipt = () => {
    const newLines = lines.map((ln) => {
      const add2 = Number(recv[ln.id] || 0);
      const got = Math.min(Number(ln.qty || 0), Number(ln.receivedQty || 0) + add2);
      return { ...ln, receivedQty: got };
    });
    const allDone = newLines.every((ln) => Number(ln.receivedQty || 0) >= Number(ln.qty || 0));
    const anyDone = newLines.some((ln) => Number(ln.receivedQty || 0) > 0);
    const status = allDone ? "مستلم" : anyDone ? "مستلم جزئيًا" : po.status;
    save({ ...db, purchaseOrders: db.purchaseOrders.map((p) => p.id === po.id ? { ...p, lines: newLines, status, receivedAt: allDone ? today() : p.receivedAt } : p) });
    onClose();
  };

  const cheapest = offers.length ? Math.min(...offers.map((o) => Number(o.price || 0))) : 0;
  const canReceive = po.status === "معتمد للتسليم" || po.status === "مستلم جزئيًا";
  const canQuote = po.status === "طلب عرض أسعار" || po.status === "بانتظار الاعتماد";

  return (
    <Sheet title={po.number} onClose={onClose}>
      <div style={{ ...card(), borderRightColor: statusColor(po.status) }}>
        <Row main={"أصناف: " + lines.length + (po.supplierId ? " · " + nameOf("suppliers", po.supplierId) : "")} sub={"إجمالي الكميات: " + lines.reduce((a, l) => a + Number(l.qty || 0), 0)} badge={{ text: po.status, color: statusColor(po.status) }} />
      </div>

      <Section title="أصناف الطلب">
        {lines.map((ln) => (
          <div key={ln.id} style={card()}>
            <Row main={ln.itemName || nameOf("items", ln.itemId)} sub={"المطلوب: " + ln.qty + " · المستلم: " + (ln.receivedQty || 0)} badge={Number(ln.receivedQty || 0) >= Number(ln.qty || 0) ? { text: "مكتمل", color: C.green } : null} />
            {canReceive && Number(ln.receivedQty || 0) < Number(ln.qty || 0) && (
              <div style={{ marginTop: 6 }}>
                <Field label={"استلام الآن (متبقٍ " + (Number(ln.qty || 0) - Number(ln.receivedQty || 0)) + ")"}>
                  <input type="number" value={recv[ln.id] || ""} onChange={(e) => setRecv({ ...recv, [ln.id]: e.target.value })} style={input} />
                </Field>
              </div>
            )}
          </div>
        ))}
        {canReceive && <Btn bg={C.blue} onClick={applyReceipt} style={{ width: "100%", padding: 10 }}>📦 تسجيل التسليم</Btn>}
      </Section>

      {canQuote && (
        <Section title="إدخال عرض مورّد (سعر إجمالي للطلب)">
          <Field label="المورّد">
            <select value={supplierId} onChange={(e) => setSupplierId(e.target.value)} style={input}>
              <option value="">— اختر مورّدًا معتمدًا —</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </Field>
          <div style={{ display: "flex", gap: 8 }}>
            <Field label="السعر الإجمالي"><input type="number" value={price} onChange={(e) => setPrice(e.target.value)} style={input} /></Field>
            <Field label="مدة التوريد (يوم)"><input type="number" value={leadDays} onChange={(e) => setLeadDays(e.target.value)} style={input} /></Field>
          </div>
          <Field label="ملاحظات"><input value={notes} onChange={(e) => setNotes(e.target.value)} style={input} /></Field>
          <Btn bg={C.ink} onClick={addOffer} style={{ width: "100%", padding: 10 }}>+ إضافة العرض</Btn>
        </Section>
      )}

      <Section title={"العروض المستلمة (" + offers.length + ")"}>
        {offers.length === 0 && canQuote && <Empty text="لا عروض بعد. أدخل عروض الموردين لمقارنتها." />}
        {offers.map((o) => (
          <div key={o.id} style={{ ...card(), borderRightColor: o.status === "مقبول" ? C.green : Number(o.price) === cheapest ? C.blue : C.line }}>
            <Row
              main={nameOf("suppliers", o.supplierId) + " — " + o.price + (Number(o.price) === cheapest ? " (الأرخص)" : "")}
              sub={"التوريد: " + (o.leadDays || 0) + " يوم" + (o.notes ? " · " + o.notes : "")}
              badge={o.status !== "مقدّم" ? { text: o.status, color: o.status === "مقبول" ? C.green : C.steel } : null}
            />
            {canQuote && o.status === "مقدّم" && (
              <Btn bg={C.green} onClick={() => acceptOffer(o)} style={{ width: "100%", padding: 8, marginTop: 6 }}>✓ اعتماد هذا العرض وإصدار الطلب</Btn>
            )}
          </div>
        ))}
      </Section>
    </Sheet>
  );
}

export function Procurement({ ctx }) {
  const { db, add, nameOf, onHand } = ctx;
  const [sub, setSub] = useState("po");
  const [openPO, setOpenPO] = useState(null);
  const [picked, setPicked] = useState({}); // itemId -> bool

  const lowStock = (db.items || []).filter((i) => {
    const min = Number(i.min ?? i.minQty ?? 0);
    return min > 0 && Number(onHand(i.id) || 0) <= min;
  });
  const openItemIds = new Set((db.purchaseOrders || []).filter((p) => !["مستلم", "ملغي"].includes(p.status)).flatMap((p) => linesOf(p).map((l) => l.itemId)));

  const createRFQ = () => {
    const chosen = lowStock.filter((i) => picked[i.id]);
    if (!chosen.length) return alert("اختر صنفًا واحدًا على الأقل");
    const lines = chosen.map((i) => {
      const min = Number(i.min ?? i.minQty ?? 0);
      return { id: uid(), itemId: i.id, itemName: i.name || i.code || "صنف", qty: Math.max(min * 2 - Number(onHand(i.id) || 0), 1), receivedQty: 0 };
    });
    add("purchaseOrders", {
      number: "PO-" + (1000 + (db.purchaseOrders || []).length + 1),
      lines, status: "طلب عرض أسعار", supplierId: "", acceptedOfferId: "", createdAt: today(),
    });
    setPicked({}); setSub("po");
  };

  const pos = db.purchaseOrders || [];

  return (
    <>
      <div style={{ display: "flex", gap: 6, marginBottom: 12, overflowX: "auto" }}>
        {[["po", "طلبات الشراء"], ["low", "نواقص المخزون"], ["suppliers", "الموردون"]].map(([k, l]) =>
          <Chip key={k} active={sub === k} onClick={() => setSub(k)}>{l}</Chip>)}
      </div>

      {sub === "po" && (
        <Section title="طلبات الشراء">
          <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
            <Stat n={pos.filter((p) => p.status === "طلب عرض أسعار").length} label="طلب عرض" color={C.orange} />
            <Stat n={pos.filter((p) => p.status === "معتمد للتسليم" || p.status === "مستلم جزئيًا").length} label="قيد التسليم" color={C.green} />
            <Stat n={pos.filter((p) => p.status === "مستلم").length} label="مستلم" color={C.blue} />
          </div>
          {pos.length === 0 && <Empty text="لا طلبات شراء. أنشئها من تبويب «نواقص المخزون»." />}
          {pos.slice().reverse().map((p) => {
            const ls = linesOf(p);
            return (
              <div key={p.id} style={{ ...card(), borderRightColor: statusColor(p.status), cursor: "pointer" }} onClick={() => setOpenPO(p)}>
                <Row main={p.number + " — " + ls.length + " صنف"} sub={(ls[0] ? (ls[0].itemName || nameOf("items", ls[0].itemId)) + (ls.length > 1 ? " +" + (ls.length - 1) : "") : "") + (p.supplierId ? " · " + nameOf("suppliers", p.supplierId) : "")} badge={{ text: p.status, color: statusColor(p.status) }} />
              </div>
            );
          })}
        </Section>
      )}

      {sub === "low" && (
        <Section title="أصناف تحت الحد الأدنى">
          {lowStock.length === 0 && <Empty text="لا توجد أصناف تحت الحد الأدنى حاليًا." />}
          {lowStock.map((i) => {
            const min = Number(i.min ?? i.minQty ?? 0);
            const inPO = openItemIds.has(i.id);
            return (
              <div key={i.id} style={{ ...card(), borderRightColor: inPO ? C.steel : C.red }}>
                <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: inPO ? "default" : "pointer" }}>
                  {!inPO && <input type="checkbox" checked={!!picked[i.id]} onChange={(e) => setPicked({ ...picked, [i.id]: e.target.checked })} />}
                  <div style={{ flex: 1 }}>
                    <Row main={(i.code ? i.code + " — " : "") + (i.name || "صنف")} sub={"الرصيد: " + Number(onHand(i.id) || 0) + " / الحد: " + min} badge={inPO ? { text: "في طلب مفتوح", color: C.steel } : null} />
                  </div>
                </label>
              </div>
            );
          })}
          {lowStock.some((i) => picked[i.id]) && (
            <Btn bg={C.orange} onClick={createRFQ} style={{ width: "100%", padding: 12 }}>＋ إنشاء طلب عرض أسعار موحّد ({lowStock.filter((i) => picked[i.id]).length})</Btn>
          )}
        </Section>
      )}

      {sub === "suppliers" && (
        <Crud ctx={ctx} entity="suppliers" title="الموردون المعتمدون" schema={[
          { k: "code", label: "كود المورّد" },
          { k: "name", label: "اسم المورّد" },
          { k: "category", label: "الفئة (قطع/خدمات…)" },
          { k: "contact", label: "جهة الاتصال (هاتف/بريد)" },
          { k: "approved", label: "معتمد", type: "select", options: ["نعم", "لا"] },
        ]} />
      )}

      {openPO && <POSheet ctx={ctx} po={openPO} onClose={() => setOpenPO(null)} />}
    </>
  );
}
