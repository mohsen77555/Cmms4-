import { useState } from "react";
import { Sheet, Btn, Field, Section, Row, Empty, card, input } from "../components/ui";
import { C, uid, today, now } from "../core/appCore";

/* ───────────────────────── مستورد نموذج الصيانة (Excel) ─────────────────────────
   يقرأ ملف عُدّة الصيانة (13 ورقة) ويبني تلقائيًا:
   • أصلًا واحدًا مع بياناته الفنية (ورقة 01) ومراجعه.
   • قطع غيار الأصل asset.parts (ورقة 07) — تظهر في تبويب «قطع الغيار».
   • خطة صيانة: برنامج (program) + قالب عمل (workDef) لكل تكرار (ورقة 05 + التشحيم 04)
     — البرامج المرتبطة بالأصل تولّد التوقعات وأوامر العمل.
   • يسجّل دفعة الاستيراد في assetImportBatches.
   تصميم آمن: يعرض معاينة أولًا، ولا يُنشئ أي شيء قبل ضغط «تأكيد الاستيراد».
*/

const FREQ_DAYS = (f) => {
  const s = String(f || "");
  if (s.includes("يومي")) return 1;
  if (s.includes("أسبوع")) return 7;
  if (s.includes("ربع")) return 90;
  if (s.includes("نصف")) return 180;
  if (s.includes("سنوي")) return 365;
  if (s.includes("شهري")) return 30;
  return 30;
};

const cell = (v) => (v == null ? "" : String(v).trim());

// يطابق الأوراق برقمها الأول (01,05,07…) ليكون متينًا أمام اختلاف الأسماء العربية
function sheetByPrefix(wb, XLSX, prefix) {
  const name = wb.SheetNames.find((n) => n.trim().startsWith(prefix));
  if (!name) return [];
  return XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: "" });
}

function buildPlanFromWorkbook(wb, XLSX) {
  const tech = sheetByPrefix(wb, XLSX, "01").slice(1);          // [band, value]
  const lube = sheetByPrefix(wb, XLSX, "04").slice(1);          // [pos, type, qty, interval, notes]
  const plan = sheetByPrefix(wb, XLSX, "05").slice(1);          // [freq, task]
  const proc = sheetByPrefix(wb, XLSX, "06").slice(1);          // [proc, steps, safety]
  const parts = sheetByPrefix(wb, XLSX, "07").slice(1);         // [pos, code, desc, stock]
  const faults = sheetByPrefix(wb, XLSX, "08").slice(1);        // [symptom, causes, action]
  const safety = sheetByPrefix(wb, XLSX, "11").slice(1);        // [item, action]
  const startup = sheetByPrefix(wb, XLSX, "02").slice(1);       // [step, desc]

  // اسم الأصل من الموديل
  const modelRow = tech.find((r) => cell(r[0]).includes("موديل") || cell(r[0]).toLowerCase().includes("model"));
  const model = modelRow ? cell(modelRow[1]) : "";
  const assetName = model ? `${model}` : "أصل مستورد";

  // البيانات الفنية → specs + مراجع
  const techLines = tech.filter((r) => cell(r[0]) || cell(r[1])).map((r) => `${cell(r[0])}: ${cell(r[1])}`);
  const section = (title, lines) => (lines.length ? [`— ${title} —`, ...lines, ""] : []);
  const specs = [
    ...techLines, "",
    ...section("التشحيم", lube.map((r) => `${cell(r[0])}: ${cell(r[1])} — ${cell(r[2])} — ${cell(r[3])} — ${cell(r[4])}`)),
    ...section("إجراءات الصيانة", proc.map((r) => `${cell(r[0])}: ${cell(r[1])}${cell(r[2]) ? " (سلامة: " + cell(r[2]) + ")" : ""}`)),
    ...section("الأعطال والحلول", faults.map((r) => `${cell(r[0])} ⇐ ${cell(r[1])} ⇒ ${cell(r[2])}`)),
    ...section("بدء التشغيل", startup.map((r) => `${cell(r[0])}) ${cell(r[1])}`)),
    ...section("السلامة", safety.map((r) => `${cell(r[0])}: ${cell(r[1])}`)),
  ].join("\n").trim();

  // قطع الغيار → asset.parts {id,name,qty}
  const partRecords = parts
    .filter((r) => cell(r[1]) || cell(r[2]))
    .map((r) => {
      const pos = cell(r[0]), code = cell(r[1]), desc = cell(r[2]), stock = cell(r[3]);
      const name = [code && code !== "—" ? code : "", desc].filter(Boolean).join(" — ") + (pos ? ` (Pos ${pos})` : "");
      return { id: uid(), name: name.trim() || "قطعة", qty: stock || "1" };
    });

  // الخطة → مجموعات تكرار → workDef + program لكل تكرار
  const byFreq = {};
  plan.filter((r) => cell(r[0]) && cell(r[1])).forEach((r) => {
    const f = cell(r[0]); (byFreq[f] = byFreq[f] || []).push(cell(r[1]));
  });
  // أضف التشحيم كمهمة ضمن أقرب تكرار «نصف سنوي» إن لم يوجد
  const lubeTasks = lube.map((r) => `تشحيم ${cell(r[0])}: ${cell(r[2])} — ${cell(r[3])}`).filter((t) => t.length > 8);
  if (lubeTasks.length) {
    const halfKey = Object.keys(byFreq).find((k) => k.includes("نصف")) || "نصف سنوي/تشحيم";
    byFreq[halfKey] = [...(byFreq[halfKey] || []), ...lubeTasks];
  }

  const plans = Object.entries(byFreq).map(([freq, tasks]) => ({
    freq, tasks, days: FREQ_DAYS(freq),
  }));

  return { assetName, model, specs, techCount: techLines.length, partRecords, plans };
}

export function ExcelImport({ ctx, onClose }) {
  const { db, save, can } = ctx;
  const [preview, setPreview] = useState(null);
  const [assetName, setAssetName] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState("");

  const onFile = async (file) => {
    if (!file) return;
    setErr(""); setBusy(true);
    try {
      const XLSX = await import("xlsx");                 // تحميل كسول — لا يثقل بدء التطبيق
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const p = buildPlanFromWorkbook(wb, XLSX);
      setPreview(p); setAssetName(p.assetName);
    } catch (e) {
      console.error(e); setErr("تعذّرت قراءة الملف. تأكد أنه ملف Excel صحيح (.xlsx).");
    } finally { setBusy(false); }
  };

  const doImport = () => {
    if (!preview) return;
    if (!can.manage && !can.admin) { setErr("الاستيراد يحتاج صلاحية مدير أو مشرف."); return; }
    const name = (assetName || preview.assetName || "أصل مستورد").trim();

    const assetId = uid();
    const number = "AST-" + String(2000 + db.assets.length + 1);
    const asset = {
      id: assetId, number, name, model: preview.model, type: "معدات", ownership: "مؤسسة",
      assetType: "ENTERPRISE", location: "Unknown", locationType: "UNKNOWN", serial: "",
      itemName: "", itemRequired: false, quantity: 1, specs: preview.specs,
      parts: preview.partRecords, docs: [], photos: [],
      notes: [], history: [{ action: "استيراد Excel", at: now(), by: "استيراد" }],
      allowWO: true, allowPrograms: true, active: true,
    };

    const workDefs = [];
    const programs = [];
    preview.plans.forEach(({ freq, tasks, days }) => {
      const wdId = uid();
      workDefs.push({
        id: wdId, name: `PM ${freq} — ${name}`,
        description: tasks.join("\n"), opIds: [], materials: "", resources: "",
        estimatedHours: 1,
      });
      programs.push({
        id: uid(), name: `خطة ${freq} — ${name}`, targetType: "أصل واحد",
        assetId, assetGroupId: "", workDefId: wdId, method: "فاصل أيام",
        interval: days, startDate: today(), lastMeterValue: 0, active: true,
      });
    });

    const batch = {
      id: uid(), at: now(), source: "Excel — " + name,
      imported: 1, skipped: 0,
      notes: `${preview.partRecords.length} قطعة غيار · ${programs.length} برنامج صيانة`,
    };

    save({
      ...db,
      assets: [...db.assets, asset],
      workDefs: [...(db.workDefs || []), ...workDefs],
      programs: [...(db.programs || []), ...programs],
      assetImportBatches: [...(db.assetImportBatches || []), batch],
    });
    setDone(`تم إنشاء الأصل «${name}» مع ${preview.partRecords.length} قطعة غيار و${programs.length} برنامج صيانة.`);
  };

  return (
    <Sheet title="استيراد أصل من ملف Excel" onClose={onClose}>
      {done ? (
        <>
          <div style={{ ...card(), borderRightColor: C.green, color: C.ink }}>✓ {done}</div>
          <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 10 }}>
            افتح الأصل لرؤية «قطع الغيار» و«البيانات الفنية»، وتبويب الجدولة/التوقعات لرؤية خطة الصيانة.
          </div>
          <Btn bg={C.ink} onClick={onClose} style={{ width: "100%", padding: 12 }}>تم</Btn>
        </>
      ) : !preview ? (
        <>
          <div style={{ ...card(), fontSize: 13, color: C.steel }}>
            ارفع ملف عُدّة الصيانة (Excel). سنقرأ البيانات الفنية، قطع الغيار، وخطة الصيانة،
            ونعرض معاينة قبل الإنشاء. لا يُنشأ شيء قبل تأكيدك.
          </div>
          <input type="file" accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            disabled={busy} onChange={(e) => onFile(e.target.files?.[0])} style={{ fontSize: 14, marginTop: 8 }} />
          {busy && <div style={{ fontSize: 12.5, color: C.amber, marginTop: 8 }}>جارٍ قراءة الملف…</div>}
          {err && <div style={{ fontSize: 12.5, color: C.red, marginTop: 8 }}>{err}</div>}
        </>
      ) : (
        <>
          <Field label="اسم الأصل">
            <input value={assetName} onChange={(e) => setAssetName(e.target.value)} style={input} />
          </Field>
          <Section title="معاينة ما سيُنشأ">
            <div style={card()}><Row main={"الأصل: " + (assetName || preview.assetName)} sub={"البيانات الفنية: " + preview.techCount + " سطر"} /></div>
            <div style={card()}><Row main={"قطع الغيار: " + preview.partRecords.length} sub="ستُضاف إلى تبويب «قطع الغيار» للأصل" /></div>
            <div style={card()}><Row main={"خطة الصيانة: " + preview.plans.length + " برنامج"} sub={preview.plans.map((p) => p.freq + " (كل " + p.days + " يوم، " + p.tasks.length + " مهمة)").join(" · ")} /></div>
            {preview.plans.length === 0 && <Empty text="لم يتم العثور على مهام خطة صيانة في الورقة 05." />}
          </Section>
          {err && <div style={{ fontSize: 12.5, color: C.red, marginBottom: 8 }}>{err}</div>}
          <div style={{ display: "flex", gap: 8 }}>
            <Btn bg={C.steel} onClick={() => setPreview(null)} style={{ flex: 1, padding: 12 }}>إلغاء</Btn>
            <Btn bg={C.green} onClick={doImport} style={{ flex: 2, padding: 12 }}>تأكيد الاستيراد</Btn>
          </div>
        </>
      )}
    </Sheet>
  );
}
