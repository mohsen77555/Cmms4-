import { useState } from "react";
import QRCode from "qrcode";
import { today } from "../core/appCore";

export function AssetQrLabels({ ctx, openAsset }) {
  const { db, nameOf, can } = ctx;
  const [q, setQ] = useState("");
  const [location, setLocation] = useState("");
  const [groupId, setGroupId] = useState("");
  const [criticalOnly, setCriticalOnly] = useState(false);
  const [activeOnly, setActiveOnly] = useState(true);
  const [includeLocation, setIncludeLocation] = useState(true);
  const [includeType, setIncludeType] = useState(true);
  const [includeSerial, setIncludeSerial] = useState(false);
  const [cols, setCols] = useState(3);
  const [labelMode, setLabelMode] = useState("A4");
  const [selected, setSelected] = useState({});
  const [qrMap, setQrMap] = useState({});
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const locations = Array.from(new Set((db.assets || []).map((a)=>String(a.location || "").trim()).filter(Boolean))).sort((a,b)=>a.localeCompare(b, "ar"));
  const filtered = (db.assets || []).filter((a) => {
    const term = q.trim().toLowerCase();
    const groupOk = !groupId || ((db.assetGroups || []).find((g)=>g.id === groupId)?.assetIds || []).includes(a.id);
    const locationOk = !location || String(a.location || "") === location;
    const criticalOk = !criticalOnly || !!a.critical;
    const activeOk = !activeOnly || a.active !== false;
    const text = [a.number, a.name, a.serial, a.location, a.type, a.itemName, a.customer].map((x)=>String(x || "").toLowerCase()).join(" ");
    return groupOk && locationOk && criticalOk && activeOk && (!term || text.includes(term));
  });
  const selectedIds = Object.keys(selected).filter((id)=>selected[id]);
  const selectedAssets = filtered.filter((a)=>selectedIds.includes(a.id));
  const effectiveAssets = selectedAssets.length ? selectedAssets : filtered;
  const qrPayload = (a) => String(a.number || a.id || "").trim();
  const labelTitle = (a) => String(a.number || "بدون رقم");
  const labelSub = (a) => [a.name, includeLocation ? a.location : "", includeType ? a.type : "", includeSerial && a.serial ? "S/N: " + a.serial : ""].filter(Boolean).join(" · ");

  const toggle = (id) => setSelected((prev)=>({ ...prev, [id]: !prev[id] }));
  const selectFiltered = () => {
    const next = { ...selected };
    filtered.forEach((a)=>{ next[a.id] = true; });
    setSelected(next);
  };
  const clearSelection = () => setSelected({});

  const ensureQr = async (assets) => {
    const next = { ...qrMap };
    const todo = assets.filter((a)=>!next[a.id]);
    if (!todo.length) return next;
    setBusy(true); setMsg("جارٍ توليد رموز QR…");
    try {
      for (const a of todo) {
        next[a.id] = await QRCode.toDataURL(qrPayload(a), { errorCorrectionLevel:"M", margin:1, width:260 });
      }
      setQrMap(next);
      setMsg("تم توليد " + todo.length + " رمز QR.");
      return next;
    } catch (e) {
      setMsg("تعذر توليد QR: " + (e?.message || e));
      throw e;
    } finally { setBusy(false); }
  };

  const escapeHtml = (v) => String(v ?? "").replace(/[&<>\"]/g, (ch)=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[ch]));
  const buildPrintHtml = (assets, map) => {
    const columnCount = Number(cols || 3);
    const mode = labelMode === "TAG" ? "tag" : "a4";
    const labelMin = mode === "tag" ? "64mm" : "38mm";
    const qrSize = mode === "tag" ? "34mm" : "27mm";
    const rows = assets.map((a)=>`<div class="label ${a.critical ? "critical" : ""}">
      <div class="top"><div class="brand">Alhadi CMMS</div><div class="kind">${a.critical ? "CRITICAL" : "ASSET"}</div></div>
      <div class="body"><img class="qr" src="${map[a.id] || ""}"/><div class="info"><div class="num">${escapeHtml(labelTitle(a))}</div><div class="name">${escapeHtml(a.name || "")}</div><div class="meta">${escapeHtml(labelSub(a))}</div></div></div>
      <div class="payload">${escapeHtml(qrPayload(a))}</div>
    </div>`).join("\n");
    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>Asset QR Labels</title><style>
      @page { size: A4; margin: 8mm; }
      *{box-sizing:border-box} body{font-family:Arial,'Tahoma',sans-serif;margin:0;color:#111827;background:#fff}.toolbar{position:sticky;top:0;background:#111827;color:white;padding:10px;display:flex;gap:8px;align-items:center;justify-content:space-between}.toolbar button{border:0;border-radius:10px;background:#16A34A;color:white;padding:8px 12px;font-weight:700}.sheet{padding:8mm;display:grid;grid-template-columns:repeat(${columnCount},1fr);gap:4mm;direction:rtl}.label{border:1px solid #111827;border-radius:3mm;min-height:${labelMin};padding:2.5mm;break-inside:avoid;page-break-inside:avoid;display:flex;flex-direction:column;justify-content:space-between}.label.critical{border-width:2px;border-color:#DC2626}.top{display:flex;justify-content:space-between;gap:4px;align-items:center;font-size:8.5px;color:#64748B;font-weight:700}.kind{color:#DC2626}.body{display:flex;gap:2.5mm;align-items:center;direction:ltr}.qr{width:${qrSize};height:${qrSize};object-fit:contain;flex:0 0 auto}.info{min-width:0;flex:1;text-align:right;direction:rtl}.num{font-size:17px;font-weight:900;line-height:1.1}.name{font-size:11.5px;font-weight:700;margin-top:2px}.meta{font-size:9.5px;color:#475569;margin-top:2px;line-height:1.35}.payload{font-size:8px;color:#64748B;text-align:center;direction:ltr;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border-top:1px dashed #CBD5E1;padding-top:1.5mm;margin-top:1.5mm}@media print{.toolbar{display:none}.sheet{padding:0}}
    </style></head><body><div class="toolbar"><b>Asset QR Labels — ${assets.length} label(s)</b><button onclick="window.print()">طباعة / حفظ PDF</button></div><main class="sheet">${rows}</main></body></html>`;
  };

  const printLabels = async () => {
    const assets = effectiveAssets;
    if (!assets.length) return alert("لا توجد أصول للطباعة.");
    const win = window.open("", "_blank");
    try {
      const map = await ensureQr(assets);
      const html = buildPrintHtml(assets, map);
      if (!win) return downloadHtml(html, "asset-qr-labels-" + today() + ".html");
      win.document.open(); win.document.write(html); win.document.close();
      setTimeout(()=>{ try { win.focus(); win.print(); } catch {} }, 500);
    } catch { try { win?.close?.(); } catch {} }
  };
  const downloadHtml = (html, name) => {
    const blob = new Blob([html], { type:"text/html;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; a.click(); URL.revokeObjectURL(a.href);
  };
  const downloadSheet = async () => {
    const assets = effectiveAssets;
    if (!assets.length) return alert("لا توجد أصول.");
    const map = await ensureQr(assets);
    downloadHtml(buildPrintHtml(assets, map), "asset-qr-labels-" + today() + ".html");
  };
  const downloadCsv = () => {
    const assets = effectiveAssets;
    const head = "asset_number,asset_name,location,type,serial,qr_payload";
    const rows = assets.map((a)=>[a.number, a.name, a.location, a.type, a.serial, qrPayload(a)].map((x)=>'"'+String(x||"").replace(/"/g,'""')+'"').join(","));
    const blob = new Blob(["\uFEFF" + [head, ...rows].join("\n")], { type:"text/csv;charset=utf-8" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "asset-qr-register-" + today() + ".csv"; a.click(); URL.revokeObjectURL(a.href);
  };

  return <>
    <Section title="ملصقات QR للأصول">
      <div style={{...card(), borderRightColor:C.green}}>
        <Row main="توليد وطباعة ملصقات QR للأصول" sub="يمسح الفني الملصق من شاشة الأصول، فيفتح Asset 360 مباشرة. payload الافتراضي هو رقم الأصل لضمان التوافق مع ماسح التطبيق." badge={{text:"QR Labels", color:C.green}} />
      </div>
      <div style={{display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8}}>
        <Stat n={filtered.length} label="مطابق" color={C.blue} small />
        <Stat n={selectedAssets.length || filtered.length} label="للطباعة" color={C.green} small />
        <Stat n={Object.keys(qrMap).length} label="QR جاهز" color={C.purple} small />
        <Stat n={cols + " أعمدة"} label="التخطيط" color={C.ink} small />
      </div>
    </Section>

    <Section title="الفلاتر والتنسيق">
      <div style={{...card(), display:"grid", gridTemplateColumns:"1fr", gap:8}}>
        <Field label="بحث"><input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="رقم الأصل، الاسم، الموقع، السيريال…" style={inputStyle()} /></Field>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
          <Field label="الموقع"><select value={location} onChange={(e)=>setLocation(e.target.value)} style={inputStyle()}><option value="">كل المواقع</option>{locations.map((x)=><option key={x} value={x}>{x}</option>)}</select></Field>
          <Field label="المجموعة"><select value={groupId} onChange={(e)=>setGroupId(e.target.value)} style={inputStyle()}><option value="">كل المجموعات</option>{(db.assetGroups||[]).map((g)=><option key={g.id} value={g.id}>{g.name}</option>)}</select></Field>
        </div>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
          <Field label="عدد الأعمدة"><select value={cols} onChange={(e)=>setCols(Number(e.target.value))} style={inputStyle()}><option value={2}>2</option><option value={3}>3</option><option value={4}>4</option></select></Field>
          <Field label="نوع الملصق"><select value={labelMode} onChange={(e)=>setLabelMode(e.target.value)} style={inputStyle()}><option value="A4">A4 Sheet</option><option value="TAG">Asset Tag أكبر</option></select></Field>
        </div>
        <div style={{display:"flex", gap:8, flexWrap:"wrap"}}>
          <label style={{fontSize:12.5, display:"flex", alignItems:"center", gap:6}}><input type="checkbox" checked={activeOnly} onChange={(e)=>setActiveOnly(e.target.checked)} /> الأصول النشطة فقط</label>
          <label style={{fontSize:12.5, display:"flex", alignItems:"center", gap:6}}><input type="checkbox" checked={criticalOnly} onChange={(e)=>setCriticalOnly(e.target.checked)} /> الأصول الحرجة فقط</label>
          <label style={{fontSize:12.5, display:"flex", alignItems:"center", gap:6}}><input type="checkbox" checked={includeLocation} onChange={(e)=>setIncludeLocation(e.target.checked)} /> إظهار الموقع</label>
          <label style={{fontSize:12.5, display:"flex", alignItems:"center", gap:6}}><input type="checkbox" checked={includeType} onChange={(e)=>setIncludeType(e.target.checked)} /> إظهار النوع</label>
          <label style={{fontSize:12.5, display:"flex", alignItems:"center", gap:6}}><input type="checkbox" checked={includeSerial} onChange={(e)=>setIncludeSerial(e.target.checked)} /> إظهار السيريال</label>
        </div>
        <div style={{display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:8}}>
          <Btn bg={C.green} onClick={()=>ensureQr(effectiveAssets)} style={{padding:12}} disabled={busy}>{busy ? "جارٍ التوليد…" : "توليد QR"}</Btn>
          <Btn bg={C.blue} onClick={printLabels} style={{padding:12}}>طباعة / حفظ PDF</Btn>
          <Btn bg={C.purple} onClick={downloadSheet} style={{padding:12}}>تحميل HTML</Btn>
          <Btn bg={C.ink} onClick={downloadCsv} style={{padding:12}}>CSV للملصقات</Btn>
        </div>
        {msg && <div style={{fontSize:12, color: msg.includes("تعذر") ? C.red : C.green, fontWeight:800}}>{msg}</div>}
      </div>
    </Section>

    <Section title="اختيار الأصول">
      <div style={{display:"flex", gap:8, marginBottom:8}}><Btn bg={C.blue} onClick={selectFiltered}>تحديد كل المطابق</Btn><Btn bg={C.steel} onClick={clearSelection}>مسح التحديد</Btn></div>
      {filtered.slice(0,80).map((a)=><div key={a.id} style={{...card(), borderRightColor:selected[a.id]?C.green:C.line}}>
        <div style={{display:"grid", gridTemplateColumns:"auto 1fr auto", gap:8, alignItems:"center"}}>
          <input type="checkbox" checked={!!selected[a.id]} onChange={()=>toggle(a.id)} />
          <Row main={(a.number || "—") + " — " + (a.name || "أصل")} sub={[a.location, a.type, a.serial ? "S/N " + a.serial : "", a.critical ? "حرج" : ""].filter(Boolean).join(" · ")} badge={{text:qrMap[a.id]?"QR جاهز":"غير مولد", color:qrMap[a.id]?C.green:C.steel}} />
          <Btn bg={C.ink} onClick={()=>openAsset(a.id)}>فتح</Btn>
        </div>
        {qrMap[a.id] && <div style={{display:"flex", gap:10, alignItems:"center", marginTop:8}}><img src={qrMap[a.id]} alt="QR" style={{width:76, height:76, border:`1px solid ${C.line}`, borderRadius:12}} /><div style={{fontSize:12, color:C.steel}}>Payload: <b style={{color:C.ink}}>{qrPayload(a)}</b><br/>هذا النص هو ما سيقرأه ماسح QR داخل التطبيق.</div></div>}
      </div>)}
      {filtered.length > 80 && <div style={{fontSize:12, color:C.steel, textAlign:"center", padding:8}}>تم عرض أول 80 أصل للمعاينة. الطباعة تشمل كل المطابق أو كل المحدد حسب اختيارك.</div>}
      {!filtered.length && <Empty text="لا توجد أصول مطابقة للفلاتر." />}
    </Section>
  </>;
}


export function AssetSingleQrLabel({ ctx, asset }) {
  const [qr, setQr] = useState("");
  const [busy, setBusy] = useState(false);
  const [includeLocation, setIncludeLocation] = useState(true);
  const [includeType, setIncludeType] = useState(true);
  const payload = String(asset?.number || asset?.id || "").trim();
  const makeQr = async () => {
    setBusy(true);
    try {
      const dataUrl = await QRCode.toDataURL(payload, { errorCorrectionLevel:"M", margin:1, width:360 });
      setQr(dataUrl);
      return dataUrl;
    } catch (e) {
      alert("تعذر توليد QR: " + (e?.message || e));
      return "";
    } finally { setBusy(false); }
  };
  const printOne = async () => {
    const dataUrl = qr || await makeQr();
    if (!dataUrl) return;
    const safe = (v) => String(v ?? "").replace(/[&<>\"]/g, (ch)=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[ch]));
    const meta = [includeLocation ? asset.location : "", includeType ? asset.type : "", asset.serial ? "S/N " + asset.serial : ""].filter(Boolean).join(" · ");
    const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>QR ${safe(asset.number || asset.id)}</title><style>@page{size:A4;margin:10mm}*{box-sizing:border-box}body{font-family:Arial,Tahoma,sans-serif;margin:0;color:#111827}.toolbar{padding:10px;background:#111827;color:#fff;display:flex;justify-content:center}.toolbar button{border:0;border-radius:10px;background:#16A34A;color:#fff;padding:9px 14px;font-weight:800}.sheet{display:grid;place-items:center;min-height:220mm}.label{width:90mm;min-height:50mm;border:1.5px solid #111827;border-radius:4mm;padding:3mm;display:grid;grid-template-columns:32mm 1fr;gap:3mm;align-items:center}.label.critical{border-color:#DC2626;border-width:2px}.qr{width:32mm;height:32mm}.brand{font-size:8px;font-weight:900;color:#64748B}.num{font-size:20px;font-weight:900;direction:ltr;text-align:right}.name{font-size:12px;font-weight:800}.meta{font-size:10px;color:#475569;margin-top:3px}.criticalText{color:#DC2626;font-size:10px;font-weight:900;margin-top:4px}@media print{.toolbar{display:none}}</style></head><body><div class="toolbar"><button onclick="window.print()">طباعة / حفظ PDF</button></div><main class="sheet"><div class="label ${asset.critical ? "critical" : ""}"><img class="qr" src="${dataUrl}"/><div><div class="brand">Alhadi CMMS</div><div class="num">${safe(asset.number || asset.id)}</div><div class="name">${safe(asset.name || "")}</div><div class="meta">${safe(meta)}</div>${asset.critical ? `<div class="criticalText">أصل حرج</div>` : ""}</div></div></main></body></html>`;
    const w = window.open("", "_blank");
    if (!w) {
      const blob = new Blob([html], { type:"text/html;charset=utf-8" });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "asset-qr-" + (asset.number || asset.id || "asset") + ".html"; a.click(); URL.revokeObjectURL(a.href); return;
    }
    w.document.open(); w.document.write(html); w.document.close(); setTimeout(()=>{ try { w.focus(); w.print(); } catch {} }, 500);
  };
  const downloadPng = async () => {
    const dataUrl = qr || await makeQr(); if (!dataUrl) return;
    const a = document.createElement("a"); a.href = dataUrl; a.download = String(asset.number || asset.id || "asset").replace(/[^a-z0-9_-]+/gi,"-") + "-qr.png"; a.click();
  };
  return <Section title="ملصق QR لهذا الأصل">
    <div style={{ ...card(), borderRightColor: asset.critical ? C.red : C.green }}>
      <Row main={(asset.number || asset.id) + " — " + (asset.name || "أصل")} sub="يمكن مسح الرمز من تبويب الأصول للوصول مباشرة إلى Asset 360." badge={{ text:"QR", color:C.green }} />
      <div style={{ display:"flex", gap:10, alignItems:"center", marginTop:10 }}>
        <div style={{ width:118, height:118, border:`1px solid ${C.line}`, borderRadius:16, display:"grid", placeItems:"center", background:C.soft, overflow:"hidden" }}>{qr ? <img src={qr} alt="QR" style={{ width:108, height:108 }} /> : <span style={{ color:C.steel, fontSize:12 }}>لم يولد بعد</span>}</div>
        <div style={{ flex:1, minWidth:0, fontSize:12.5, color:C.steel }}>
          <b style={{ color:C.ink }}>Payload:</b> <span style={{ direction:"ltr", unicodeBidi:"plaintext" }}>{payload}</span><br/>
          أفضل ممارسة: لا تغيّر رقم الأصل بعد طباعة الملصق إلا بعد إعادة الطباعة.
        </div>
      </div>
      <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginTop:10 }}>
        <Btn bg={C.green} onClick={makeQr} disabled={busy}>{busy ? "جارٍ…" : "توليد QR"}</Btn>
        <Btn bg={C.blue} onClick={printOne}>طباعة الملصق</Btn>
        <Btn bg={C.purple} onClick={downloadPng}>تحميل QR PNG</Btn>
      </div>
      <div style={{ display:"flex", gap:10, flexWrap:"wrap", marginTop:8, fontSize:12.5 }}>
        <label><input type="checkbox" checked={includeLocation} onChange={(e)=>setIncludeLocation(e.target.checked)} /> الموقع</label>
        <label><input type="checkbox" checked={includeType} onChange={(e)=>setIncludeType(e.target.checked)} /> النوع</label>
      </div>
    </div>
  </Section>;
}

