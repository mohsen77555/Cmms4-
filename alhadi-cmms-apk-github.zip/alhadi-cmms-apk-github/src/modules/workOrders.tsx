import { useMemo, useState } from "react";
import { deleteCmmsStorageFile } from "../firebaseCmms";
import { ACTIVE_STATES, C, EXECUTION_PHOTO_TYPES, FAILURE_MODES, MAINTENANCE_ENTITY_KEYS, MAINTENANCE_PERMISSIONS, MAINTENANCE_REPORTS, MAINTENANCE_RULES, SAFETY_DEFAULTS, WO_COLORS, WO_EXTRA, WO_FLOW, buildCmmsMediaRecord, daysUntil, fmt, mediaIsRemote, mediaSrc, money, normalizeDb, now, today, uid } from "../core/appCore";
import { AddInline, Badge, Btn, Chip, Empty, Field, Row, Section, Sheet, Stat, card, delBtn, input } from "../components/ui";
import { FormSheet } from "./crud";

export function MyWork({ ctx, openWO }) {
  const { db, nameOf, role, myTechId } = ctx;
  const [view, setView] = useState("اليوم");
  const isTech = role === "فني";
  let wos = useMemo(() => db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status) && !["مسودة", "مُصدر"].includes(w.status)), [db.workOrders]);
  /* الفني لا يرى غير المسند إليه (قاعدة) */
  if (isTech && myTechId) wos = wos.filter((w) => (ctx.woAssignedTechIds ? ctx.woAssignedTechIds(w) : (w.operations || []).map((o) => o.assigneeId)).includes(myTechId));
  const VIEWS = {
    "اليوم": (w) => !w.plannedStart || daysUntil(w.plannedStart) <= 0,
    "متأخر": (w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0,
    "طارئ": (w) => w.priority === "طارئ" || w.type === "طارئ",
    "قيد التنفيذ": (w) => w.status === "قيد التنفيذ",
    "بانتظار مواد": (w) => w.status === "بانتظار مواد",
    "مُعاد للتصحيح": (w) => w.status === "مُعاد للتصحيح",
    "بانتظار المراجعة": (w) => w.status === "بانتظار المراجعة",
  };
  const list = wos.filter(VIEWS[view]);
  return (
    <>
      {isTech && !myTechId && <Empty text="اختر اسمك من القائمة في الأعلى لعرض مهامك." />}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {Object.keys(VIEWS).map((v) => {
          const n = wos.filter(VIEWS[v]).length;
          return <Chip key={v} active={view === v} onClick={() => setView(v)}>{v}{n > 0 ? " (" + n + ")" : ""}</Chip>;
        })}
      </div>
      {list.length === 0 && <Empty text={"لا مهام في «" + view + "»."} />}
      {list.map((w) => <TaskCard key={w.id} w={w} ctx={ctx} onClick={() => openWO(w.id)} />)}
    </>
  );
}

/* بطاقة المهمة (وثيقة التنفيذ §بطاقة المهمة) */
export function TaskCard({ w, ctx, onClick }) {
  const { nameOf, activeWarranty, materialStatusOf, woAssignedTechIds } = ctx;
  const matStatus = materialStatusOf ? "المواد: " + materialStatusOf(w) : ((w.materials || []).length === 0 ? "" :
    (w.materials || []).every((m) => Number(m.issuedQty || 0) > 0) ? "المواد: متوفرة" : "المواد: ناقصة");
  const assignees = (woAssignedTechIds ? woAssignedTechIds(w) : []).map((id) => nameOf("technicians", id)).filter((x) => x !== "—").join("، ");
  return (
    <div style={{ ...card(), borderRightColor: w.priority === "طارئ" ? C.red : C.ink }} onClick={onClick}>
      <Row main={w.number + " — " + w.title} badge={{ text: w.status, color: WO_COLORS[w.status] }}
        sub={[nameOf("assets", w.assetId), w.type, "أولوية " + w.priority,
          w.plannedStart ? "البدء " + fmt(w.plannedStart) : "", assignees ? "الفني: " + assignees : "غير مسند", matStatus,
          w.safetyRequired ? "🔒 سلامة" : "", activeWarranty(w.assetId) ? "🛡 ضمان" : ""].filter(Boolean).join(" · ")} />
      {w.status === "مُعاد للتصحيح" && w.reviewNotes && (
        <div style={{ fontSize: 12.5, color: C.red, marginTop: 4 }}>ملاحظات المشرف: {w.reviewNotes}</div>
      )}
    </div>
  );
}

/* ───────────────────────── أوامر العمل ───────────────────────── */
export function WorkOrders({ ctx, openWO }) {
  const { db, nameOf, can, createWO } = ctx;
  const [form, setForm] = useState(false);
  const [filter, setFilter] = useState("الكل");
  const [q, setQ] = useState("");
  const list = useMemo(() => db.workOrders.filter((w) =>
    (filter === "الكل" || w.status === filter) && (!q || (w.title + w.number).includes(q))), [db.workOrders, filter, q]);
  return (
    <>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث…" style={{ ...input, marginBottom: 10 }} />
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {["الكل", ...WO_FLOW, ...WO_EXTRA].map((s) => <Chip key={s} active={filter === s} onClick={() => setFilter(s)}>{s}</Chip>)}
      </div>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ أمر عمل جديد</Btn>}
      {list.length === 0 && <Empty text="لا توجد أوامر عمل هنا." />}
      {list.map((w) => <TaskCard key={w.id} w={w} ctx={ctx} onClick={() => openWO(w.id)} />)}
      {form && (
        <FormSheet title="أمر عمل جديد" onClose={() => setForm(false)} db={db}
          schema={[
            { k: "title", label: "وصف العمل" },
            { k: "assetId", label: "الأصل (إلزامي)", type: "select", from: "assets", fromKey: "name" },
            { k: "type", label: "النوع", type: "select", options: ["تصحيحي", "وقائي", "طارئ"] },
            { k: "priority", label: "الأولوية", type: "select", options: ["منخفضة", "عادية", "عالية", "طارئ"] },
            { k: "workDefId", label: "تعريف العمل (ينسخ عملياته)", type: "select", from: "workDefs", fromKey: "name" },
            { k: "assignedTechnicianId", label: "الفني الرئيسي (مطلوب قبل الإصدار)", type: "select", from: "technicians", fromKey: "name" },
            { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
            { k: "externalSupplier", label: "مورد خارجي عند الحاجة" },
            { k: "plannedStart", label: "البدء المخطط", type: "date" }, { k: "plannedEnd", label: "الانتهاء المخطط", type: "date" },
            { k: "safetyRequired", label: "يتطلب قائمة فحص سلامة (LOTO)", type: "check" },
            { k: "photoRequired", label: "صور قبل/بعد إلزامية", type: "check" },
          ]} initial={{ type: "تصحيحي", priority: "عادية", plannedStart: today(), safetyRequired: true }}
          onSave={(d) => {
            if (!d.assetId) { alert("لا أمر عمل بدون أصل (قاعدة النظام)"); return; }
            createWO(d); setForm(false);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── تفاصيل أمر العمل — قلب التنفيذ ───────────────────────── */
export function WODetail({ ctx, woId, onClose, openAsset }) {
  const { db, nameOf, update, can, role, myTechId, woCost, completionGaps, setWOStatus, log, activeWarranty, availableQty, onHand, addTx, woShortages, activeContracts, contractEffectiveEnd, generateEntitlements } = ctx;
  const wo = db.workOrders.find((w) => w.id === woId);
  const [sub, setSub] = useState("عام");
  const [opForm, setOpForm] = useState(false);
  const [matForm, setMatForm] = useState(false);
  const [failForm, setFailForm] = useState(false);
  const [completing, setCompleting] = useState(null);
  const [reviewing, setReviewing] = useState(false);
  const [excText, setExcText] = useState("");
  if (!wo) return null;
  const cost = woCost(wo);
  const gaps = completionGaps(wo);
  const isTech = role === "فني";
  const mineOnly = (op) => !isTech || !myTechId || op.assigneeId === myTechId;
  const aw = activeWarranty(wo.assetId);

  const patchOps = (ops) => update("workOrders", wo.id, { operations: ops });
  const patchLog = (action, extra = {}) => update("workOrders", wo.id, { execLog: log(wo, action), ...extra });

  const TABS = ["عام", "الإسناد", "العمليات", "المواد", "السلامة", "العطل", "الصور", "الضمان", "السجل"];

  return (
    <Sheet title={wo.number} onClose={onClose}>
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontWeight: 800, fontSize: 17 }}>{wo.title}</div>
        <div style={{ fontSize: 13, color: C.steel }}>
          <span style={{ textDecoration: "underline" }} onClick={() => wo.assetId && openAsset(wo.assetId)}>{nameOf("assets", wo.assetId)}</span>
          {" · "}{wo.type} · أولوية {wo.priority} · {fmt(wo.plannedStart)} ← {fmt(wo.plannedEnd)}
        </div>
        {aw && ["تصحيحي", "طارئ"].includes(wo.type) && (
          <div style={{ fontSize: 13, color: C.green, fontWeight: 700, marginTop: 4 }}>
            🛡 الأصل تحت ضمان «{aw.supplier}» حتى {fmt(aw.end)} — راجع الضمان قبل تكلفة إصلاح داخلي
          </div>
        )}
        {cost.total > 0 && <div style={{ fontSize: 13, marginTop: 4 }}>التكلفة: <b>{money(cost.total)}</b> (عمالة {money(cost.labor)} + مواد {money(cost.material)})</div>}

        {/* أزرار الحالة حسب الدور والمرحلة */}
        <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
          <Badge text={wo.status} color={WO_COLORS[wo.status]} />
          {wo.status === "مسودة" && can.manage && <Btn bg={C.blue} onClick={() => {
            const sh = woShortages(wo);
            if (sh.length && !confirm("نقص مواد:\n" + sh.map((m) => "• " + nameOf("items", m.itemId) + " (مطلوب " + m.qty + "، المتاح " + Math.max(0, availableQty(m.itemId)) + ")").join("\n") + "\n\nإصدار كـ«بانتظار مواد»؟")) return;
            setWOStatus(wo, sh.length ? "بانتظار مواد" : "مُصدر");
          }}>إصدار (فحص المواد)</Btn>}
          {wo.status === "مُصدر" && can.manage && <Btn bg={C.purple} onClick={() => setWOStatus(wo, "جاهز")}>جاهز للتنفيذ</Btn>}
          {wo.status === "جاهز" && can.execute && (
            <Btn bg={C.green} onClick={() => {
              if (wo.safetyRequired && (wo.checklist || []).some((c) => !c.done)) { alert("لا بدء قبل إكمال قائمة فحص السلامة"); setSub("السلامة"); return; }
              setWOStatus(wo, "قيد التنفيذ", { actualStart: today() });
            }}>▶ بدء العمل</Btn>
          )}
          {wo.status === "قيد التنفيذ" && can.execute && (
            <>
              <Btn bg={C.steel} onClick={() => patchLog("⏸ إيقاف مؤقت")}>⏸ إيقاف</Btn>
              <Btn bg={C.green} onClick={() => {
                if (gaps.length) { alert("لا يمكن طلب الإكمال:\n• " + gaps.join("\n• ")); return; }
                setWOStatus(wo, "بانتظار المراجعة");
              }}>✓ طلب الإكمال</Btn>
            </>
          )}
          {wo.status === "مُعاد للتصحيح" && can.execute && <Btn bg={C.amber} onClick={() => setWOStatus(wo, "قيد التنفيذ")}>استئناف التصحيح</Btn>}
          {wo.status === "بانتظار المراجعة" && can.review && <Btn bg={C.blue} onClick={() => setReviewing(true)}>مراجعة المشرف</Btn>}
          {["جاهز", "قيد التنفيذ"].includes(wo.status) && can.manage && (
            <>
              <Btn bg={C.steel} onClick={() => setWOStatus(wo, "معلق")}>تعليق</Btn>
              <Btn bg={C.amber} onClick={() => setWOStatus(wo, "بانتظار مواد")}>بانتظار مواد</Btn>
            </>
          )}
          {["معلق", "بانتظار مواد"].includes(wo.status) && can.manage && <Btn bg={C.green} onClick={() => setWOStatus(wo, "قيد التنفيذ")}>استئناف</Btn>}
          {!["مغلق", "ملغي"].includes(wo.status) && can.manage && <Btn bg={C.red} onClick={() => setWOStatus(wo, "ملغي")}>إلغاء</Btn>}
        </div>
        {wo.status === "قيد التنفيذ" && gaps.length > 0 && (
          <div style={{ fontSize: 12, color: C.amber, marginTop: 6 }}>قبل الإكمال: {gaps.join(" · ")}</div>
        )}
        {wo.reviewNotes && wo.status === "مُعاد للتصحيح" && (
          <div style={{ fontSize: 13, color: C.red, marginTop: 6, fontWeight: 700 }}>ملاحظات المشرف: {wo.reviewNotes}</div>
        )}
      </div>

      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 10 }}>
        {TABS.map((t) => <Chip key={t} active={sub === t} onClick={() => setSub(t)}>{t}</Chip>)}
      </div>

      {sub === "الإسناد" && (
        <Section title="الإسناد والجدولة">
          <div style={card()}>
            <Field label="الفني الرئيسي / Assigned Technician">
              <select value={(wo.assignments || [])[0]?.technicianId || ""} disabled={!can.manage || ["مغلق", "ملغي"].includes(wo.status)} onChange={(e) => {
                const techId = e.target.value;
                const assignments = techId ? [{ id: (wo.assignments || [])[0]?.id || uid(), technicianId: techId, role: "فني رئيسي", status: "مسند", assignedAt: today(), assignedBy: role }] : [];
                update("workOrders", wo.id, {
                  assignments,
                  _cmmsAssignedTechIds: assignments.map((a) => a.technicianId),
                  operations: (wo.operations || []).map((op, i) => i === 0 && techId ? { ...op, assigneeId: techId } : op),
                  execLog: log(wo, "إسناد الفني الرئيسي: " + (techId ? nameOf("technicians", techId) : "إلغاء")),
                });
              }} style={input}>
                <option value="">— غير مسند —</option>
                {db.technicians.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.specialty || "عام"})</option>)}
              </select>
            </Field>
            <Field label="الفريق / Team"><input value={wo.team || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { team:e.target.value, execLog: log(wo, "تحديث الفريق") })} style={input} /></Field>
            <Field label="مركز العمل / Work Center"><select value={wo.workCenterId || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { workCenterId:e.target.value, execLog: log(wo, "تحديث مركز العمل") })} style={input}><option value="">—</option>{db.workCenters.map((wcx)=><option key={wcx.id} value={wcx.id}>{wcx.name}</option>)}</select></Field>
            <Field label="المورد الخارجي / External Supplier"><input value={wo.externalSupplier || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { externalSupplier:e.target.value, execLog: log(wo, "تحديث المورد الخارجي") })} style={input} /></Field>
            <Field label="بداية مخططة"><input type="date" value={wo.plannedStart || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { plannedStart:e.target.value, execLog: log(wo, "تعديل الجدولة") })} style={input} /></Field>
            <Field label="نهاية مخططة"><input type="date" value={wo.plannedEnd || ""} disabled={!can.manage} onChange={(e)=>update("workOrders", wo.id, { plannedEnd:e.target.value, execLog: log(wo, "تعديل تاريخ الاستحقاق") })} style={input} /></Field>
          </div>
        </Section>
      )}

      {/* ───── عام: معاينة العمل ───── */}
      {sub === "عام" && (
        <>
        {(wo.routeAssets || []).length > 0 && (
          <Section title={"أصول المسار (" + wo.routeAssets.filter((x) => x.status !== "معلق").length + "/" + wo.routeAssets.length + ")"}>
            {(() => { const h = db.logicalHierarchies.find((x) => x.id === wo.routeId); return wo.routeAssets.map((x) => {
              const ast = db.assets.find((z) => z.id === x.assetId);
              return (
                <div key={x.assetId} style={{ ...card(), borderRightColor: x.status === "تم" ? C.green : x.status === "تخطي" ? C.amber : C.ink }}>
                  <Row main={(ast?.number ? ast.number + " — " : "") + (ast?.name || "أصل")} sub={ast?.location}
                    badge={{ text: x.status, color: x.status === "تم" ? C.green : x.status === "تخطي" ? C.amber : C.steel }}
                    action={x.status === "معلق" && can.execute && wo.status === "قيد التنفيذ" ? (
                      <div style={{ display: "flex", gap: 4 }}>
                        <Btn bg={C.green} onClick={() => update("workOrders", wo.id, { routeAssets: wo.routeAssets.map((y) => y.assetId === x.assetId ? { ...y, status: "تم" } : y), execLog: log(wo, "مسار: تم — " + (ast?.name || "")) })}>تم</Btn>
                        {(h?.allowSkip) && <Btn bg={C.amber} onClick={() => update("workOrders", wo.id, { routeAssets: wo.routeAssets.map((y) => y.assetId === x.assetId ? { ...y, status: "تخطي" } : y), execLog: log(wo, "مسار: تخطي — " + (ast?.name || "")) })}>تخطي</Btn>}
                      </div>
                    ) : null} />
                </div>
              );
            }); })()}
          </Section>
        )}
          <Section title="معاينة العمل">
            <div style={card()}>
              <div style={{ fontSize: 13.5, lineHeight: 1.9 }}>
                الأصل: <b>{nameOf("assets", wo.assetId)}</b><br />
                آخر صيانة لهذا الأصل: <b>{(() => {
                  const prev = db.workOrders.filter((x) => x.assetId === wo.assetId && x.id !== wo.id && x.status === "مغلق").slice(-1)[0];
                  return prev ? prev.completedAt + " (" + prev.title + ")" : "لا يوجد";
                })()}</b><br />
                السلامة: <b>{wo.safetyRequired ? "تصريح عزل طاقة مطلوب" : "غير مطلوب"}</b> ·
                الصور: <b>{wo.photoRequired ? "قبل/بعد إلزامية" : "اختيارية"}</b>
              </div>
            </div>
          </Section>
          <Section title="ملاحظات الإكمال والنتيجة">
            <textarea value={wo.executionNotes || ""} disabled={!can.execute || ["مغلق", "ملغي"].includes(wo.status)} onChange={(e)=>update("workOrders", wo.id, { executionNotes:e.target.value, execLog: log(wo, "إضافة/تحديث ملاحظة تنفيذ") })} placeholder="اكتب نتيجة الفحص، Trial run result، أو ملاحظات الفني قبل طلب الإكمال…" style={{ ...input, minHeight:80, resize:"vertical" }} />
          </Section>
          <Section title={"الاستثناءات (" + (wo.exceptions || []).length + ")"}>
            {(wo.exceptions || []).map((e, i) => (
              <div key={i} style={{ ...card(), borderRightColor: C.amber }}><Row main={e.text} sub={e.at} /></div>
            ))}
            {can.execute && (
              <div style={{ display: "flex", gap: 8 }}>
                <input value={excText} onChange={(e) => setExcText(e.target.value)} placeholder="نقص مادة، عدم توفر فني…" style={input} />
                <Btn bg={C.amber} onClick={() => { if (excText.trim()) { update("workOrders", wo.id, { exceptions: [...(wo.exceptions || []), { text: excText, at: today() }], execLog: log(wo, "استثناء: " + excText) }); setExcText(""); } }}>تسجيل</Btn>
              </div>
            )}
          </Section>
        </>
      )}

      {/* ───── العمليات ───── */}
      {sub === "العمليات" && (
        <Section title={"العمليات (" + wo.operations.length + ")"}>
          {wo.operations.slice().sort((a, b) => a.seq - b.seq).map((op) => (
            <div key={op.id} style={{ ...card(), opacity: mineOnly(op) ? 1 : 0.55 }}>
              <Row main={op.seq + " — " + op.name + (op.opType === "خارجية" ? " (خارجية)" : "")}
                sub={[op.opType === "خارجية" ? "المورد: " + (op.supplier || "—") : (op.assigneeId ? "الفني: " + nameOf("technicians", op.assigneeId) : "غير مُسند"),
                  op.chargeType ? "تحميل " + op.chargeType : "",
                  op.status === "مكتملة" ? op.actualHours + " ساعة فعلية" : op.minutes ? op.minutes + " د مخطط" : ""].filter(Boolean).join(" · ")}
                action={op.status === "مكتملة"
                  ? <Badge text="مكتملة" color={C.green} />
                  : wo.status === "قيد التنفيذ" && can.execute && mineOnly(op)
                    ? <Btn bg={C.green} onClick={() => setCompleting(op)}>إكمال</Btn> : null} />
              {(op.attachments || []).length > 0 && (
                <div style={{ display: "flex", gap: 8, marginTop: 4, flexWrap: "wrap" }}>
                  {(op.attachments || []).map((a) => a.type === "رابط" && a.value
                    ? <button key={a.id} onClick={(e) => { e.stopPropagation(); window.open(a.value, "_blank"); }} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>🔗 {a.name}</button>
                    : <span key={a.id} style={{ fontSize: 12, color: C.steel }}>📝 {a.name}{a.value ? ": " + a.value : ""}</span>)}
                </div>
              )}
              {(op.repairReason || op.workDone || op.repairTx) && (
                <div style={{ fontSize: 12, color: C.steel, marginTop: 2 }}>أكواد الإصلاح: {[op.repairReason, op.repairTx, op.workDone].filter(Boolean).join(" / ")}</div>
              )}
              {op.status !== "مكتملة" && can.manage && (
                <select value={op.assigneeId || ""} onChange={(e) => {
                  patchOps(wo.operations.map((o) => o.id === op.id ? { ...o, assigneeId: e.target.value } : o));
                }} style={{ ...input, marginTop: 6, padding: "6px 10px", fontSize: 13 }}>
                  <option value="">— إسناد لفني —</option>
                  {db.technicians.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.specialty || "عام"})</option>)}
                </select>
              )}
            </div>
          ))}
          {["مسودة", "مُصدر"].includes(wo.status) && can.manage && <Btn bg={C.ink} onClick={() => setOpForm(true)} style={{ width: "100%" }}>+ إضافة عملية</Btn>}
        </Section>
      )}

      {/* ───── المواد: صرف ← استخدام ← إرجاع (وثيقة التنفيذ §8) ───── */}
      {sub === "المواد" && (
        <Section title="المواد — مطلوب ← حجز ← تجهيز ← صرف ← استخدام ← إرجاع">
          {(wo.materials || []).length === 0 && <Empty text="أضف المواد المطلوبة من ماستر الأصناف — لا صرف بدون أمر عمل." />}
          {(wo.materials || []).map((m) => {
            const issued = Number(m.issuedQty || 0);
            const ret = Math.max(0, issued - Number(m.usedQty || 0));
            const av = m.itemId ? availableQty(m.itemId) + (m.reserved && !issued ? Number(m.qty || 0) : 0) : null;
            const stage = issued ? (m.returned ? "أُرجع الفائض" : "مصروف") : m.picked ? "جاهز للصرف" : m.reserved ? "محجوز" : "مطلوب";
            return (
              <div key={m.id} style={{ ...card(), borderRightColor: issued ? C.green : m.reserved ? C.blue : C.ink }}>
                <Row main={(m.itemId ? nameOf("items", m.itemId) : m.name) + " ×" + (m.qty || m.issuedQty)}
                  badge={{ text: stage, color: issued ? C.green : m.picked ? C.purple : m.reserved ? C.blue : C.steel }}
                  sub={[m.itemId && !issued ? "المتاح: " + Math.max(0, av) : "", issued ? "مصروف " + issued + " × " + money(m.unitCost) : ""].filter(Boolean).join(" · ")} />
                {/* مخزن: حجز ← تأكيد تجهيز ← صرف */}
                {!issued && !["مغلق", "ملغي"].includes(wo.status) && (
                  <div style={{ display: "flex", gap: 6, marginTop: 6, flexWrap: "wrap" }}>
                    {!m.reserved && m.itemId && can.warehouse && (
                      <Btn bg={C.blue} onClick={() => {
                        if (Number(m.qty || 0) > availableQty(m.itemId)) { alert("المتاح غير كافٍ (" + Math.max(0, availableQty(m.itemId)) + ") — حدّث الرصيد باستلام أو خفّض الكمية"); return; }
                        update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, reserved: true } : x), execLog: log(wo, "حجز: " + nameOf("items", m.itemId) + " ×" + m.qty) });
                      }}>حجز</Btn>
                    )}
                    {m.reserved && !m.picked && can.warehouse && (
                      <Btn bg={C.purple} onClick={() => update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, picked: true } : x), execLog: log(wo, "تأكيد تجهيز: " + nameOf("items", m.itemId)) })}>تأكيد التجهيز</Btn>
                    )}
                    {m.reserved && m.picked && can.warehouse && (
                      <Btn bg={C.green} onClick={() => {
                        const item = db.items.find((i) => i.id === m.itemId);
                        addTx({ type: "صرف لأمر عمل", itemId: m.itemId, qty: Number(m.qty || 0), workOrderId: wo.id });
                        update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, issuedQty: Number(m.qty || 0), unitCost: Number(item?.unitCost || 0), usedQty: "" } : x), execLog: log(wo, "صرف: " + nameOf("items", m.itemId) + " ×" + m.qty) });
                      }}>صرف للأمر</Btn>
                    )}
                    {can.manage && <Btn bg={C.red} onClick={() => update("workOrders", wo.id, { materials: wo.materials.filter((x) => x.id !== m.id) })}>إزالة</Btn>}
                  </div>
                )}
                {/* فني: تأكيد المستخدم ← إرجاع الفائض */}
                {issued > 0 && (
                  <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 6, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 13 }}>المستخدم فعليًا:</span>
                    <input type="number" value={m.usedQty ?? ""} disabled={!can.execute || m.returned || ["مغلق", "ملغي"].includes(wo.status)}
                      onChange={(e) => update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, usedQty: e.target.value } : x) })}
                      style={{ ...input, width: 80, padding: "6px 10px" }} />
                    <span style={{ fontSize: 12.5, color: C.steel }}>يُرجَع: {ret} · التكلفة: {money(Number(m.usedQty || 0) * Number(m.unitCost || 0))}</span>
                    {!m.returned && ret > 0 && m.usedQty !== "" && m.usedQty != null && can.warehouse && (
                      <Btn bg={C.amber} onClick={() => {
                        addTx({ type: "إرجاع من أمر عمل", itemId: m.itemId, qty: ret, workOrderId: wo.id });
                        update("workOrders", wo.id, { materials: wo.materials.map((x) => x.id === m.id ? { ...x, returned: true } : x), execLog: log(wo, "إرجاع فائض: ×" + ret) });
                      }}>إرجاع الفائض للمخزن</Btn>
                    )}
                  </div>
                )}
              </div>
            );
          })}
          {can.manage && !["مغلق", "ملغي"].includes(wo.status) && db.items.length > 0 && (
            <Btn bg={C.ink} onClick={() => setMatForm(true)} style={{ width: "100%" }}>+ مادة مطلوبة (من الأصناف)</Btn>
          )}
          {db.items.length === 0 && <div style={{ fontSize: 12.5, color: C.steel, marginTop: 6 }}>أنشئ الأصناف أولًا من «المخزون ← الأصناف».</div>}
        </Section>
      )}

      {/* ───── السلامة (وثيقة التنفيذ §4) ───── */}
      {sub === "السلامة" && (
        <Section title="قائمة فحص السلامة">
          {!wo.safetyRequired && (wo.checklist || []).length === 0 && <Empty text="هذا الأمر لا يتطلب قائمة سلامة." />}
          {(wo.checklist || []).map((c) => (
            <label key={c.id} style={{ ...card(), display: "flex", gap: 10, alignItems: "center" }}>
              <input type="checkbox" checked={c.done} disabled={!can.execute || ["مغلق", "ملغي"].includes(wo.status)}
                onChange={(e) => update("workOrders", wo.id, {
                  checklist: wo.checklist.map((x) => x.id === c.id ? { ...x, done: e.target.checked } : x),
                  execLog: log(wo, (e.target.checked ? "✓ " : "✗ ") + c.text),
                })}
                style={{ width: 22, height: 22 }} />
              <span style={{ fontSize: 14.5, textDecoration: c.done ? "line-through" : "none" }}>{c.text}</span>
            </label>
          ))}
          {can.manage && !["مغلق", "ملغي"].includes(wo.status) && (
            <AddInline placeholder="بند فحص إضافي…" onAdd={(t) =>
              update("workOrders", wo.id, { checklist: [...(wo.checklist || []), { id: uid(), text: t, done: false }] })} />
          )}
        </Section>
      )}

      {/* ───── العطل (وثيقة التنفيذ §10) ───── */}
      {sub === "العطل" && (
        <Section title="تسجيل العطل">
          {["تصحيحي", "طارئ"].includes(wo.type) && !wo.failure &&
            <div style={{ fontSize: 13, color: C.red, marginBottom: 8 }}>⚠ إلزامي قبل الإكمال لأوامر التصحيح والطوارئ.</div>}
          {wo.failure ? (
            <div style={{ ...card(), borderRightColor: C.red }}>
              <div style={{ fontSize: 14, lineHeight: 2 }}>
                <b>نمط العطل:</b> {wo.failure.mode}{wo.failure.repeated ? " (متكرر ⚠)" : ""}<br />
                <b>السبب:</b> {wo.failure.cause}<br />
                <b>الأثر:</b> {wo.failure.effect}<br />
                <b>الإجراء المتخذ:</b> {wo.failure.action}<br />
                <b>زمن التوقف:</b> {wo.failure.downtime} دقيقة<br />
                {wo.failure.rootCause && <><b>السبب الجذري:</b> {wo.failure.rootCause}</>}
              </div>
              {can.execute && !["مغلق", "ملغي"].includes(wo.status) && <Btn bg={C.blue} onClick={() => setFailForm(true)} style={{ marginTop: 8 }}>تعديل</Btn>}
            </div>
          ) : (
            can.execute && !["مغلق", "ملغي"].includes(wo.status)
              ? <Btn bg={C.red} onClick={() => setFailForm(true)} style={{ width: "100%", padding: 12 }}>+ تسجيل عطل</Btn>
              : <Empty text="لا عطل مسجل." />
          )}
        </Section>
      )}

      {/* ───── الصور (وثيقة التنفيذ §11) ───── */}
      {sub === "الصور" && <PhotosTab ctx={ctx} wo={wo} />}

      {/* ───── سجل التنفيذ والحالات ───── */}
      {/* ───── ضمان المورد (ف6 §22) ───── */}
      {sub === "الضمان" && (() => {
        const cs = activeContracts(wo.assetId);
        const woEnts = db.entitlements.filter((e) => e.workOrderId === wo.id);
        const woClaims = db.claims.filter((c) => c.workOrderId === wo.id);
        return (<>
          {can.manage && (
            <div style={{ ...card(), display: "flex", gap: 16, flexWrap: "wrap" }}>
              <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input type="checkbox" checked={!!wo.warrantyRepair} disabled={["مغلق", "ملغي"].includes(wo.status) && woEnts.length > 0}
                  onChange={(e) => update("workOrders", wo.id, { warrantyRepair: e.target.checked, execLog: log(wo, "إصلاح ضمان: " + (e.target.checked ? "نعم" : "لا")) })} style={{ width: 20, height: 20 }} />
                <span style={{ fontSize: 14 }}>إصلاح ضمان</span>
              </label>
              <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <input type="checkbox" checked={!!wo.matchCodes}
                  onChange={(e) => update("workOrders", wo.id, { matchCodes: e.target.checked })} style={{ width: 20, height: 20 }} />
                <span style={{ fontSize: 14 }}>مطابقة أكواد الإصلاح</span>
              </label>
            </div>
          )}
          <Section title={"العقود الفعالة للأصل وأصوله المرتبطة (" + cs.length + ")"}>
            {cs.length === 0 && <Empty text="لا عقود فعالة — وجود الأيقونة 🛡 لا يعني تغطية نهائية؛ القرار حسب الشروط والأكواد." />}
            {cs.map((c) => (
              <div key={c.id} style={{ ...card(), borderRightColor: C.green }}>
                <Row main={c.number + " — " + nameOf("coverages", c.coverageId)}
                  sub={[nameOf("assets", c.assetId) !== nameOf("assets", wo.assetId) ? "أصل مرتبط: " + nameOf("assets", c.assetId) : "",
                    "ينتهي " + fmt(contractEffectiveEnd(c))].filter(Boolean).join(" · ")} />
              </div>
            ))}
          </Section>
          {can.manage && ["بانتظار المراجعة", "مغلق"].includes(wo.status) && (
            <Btn bg={C.purple} style={{ width: "100%", padding: 12, marginBottom: 12 }} onClick={() => generateEntitlements(wo)}>
              ⚙ توليد استحقاقات الضمان وتجميعها في مطالبة
            </Btn>
          )}
          {wo.status !== "مغلق" && wo.status !== "بانتظار المراجعة" && (
            <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 10 }}>يفضّل توليد الاستحقاقات بعد إكمال الأمر واكتمال التكلفة (قاعدة ف6).</div>
          )}
          <Section title={"استحقاقات هذا الأمر (" + woEnts.length + ")"}>
            {woEnts.map((e) => (
              <div key={e.id} style={{ ...card(), borderRightColor: e.included ? C.green : C.steel }}>
                <Row main={e.type + " — " + e.description} badge={e.included ? { text: "ضمن مطالبة", color: C.green } : { text: "مستبعد", color: C.steel }}
                  sub={e.qty + " × " + money(e.unitCost) + " = " + money(e.total)} />
              </div>
            ))}
            {woEnts.length === 0 && <Empty text="لا استحقاقات بعد." />}
          </Section>
          {woClaims.length > 0 && (
            <Section title="مطالبات هذا الأمر">
              {woClaims.map((c) => (
                <div key={c.id} style={card()}>
                  <Row main={c.number + " — " + nameOf("warrantyProviders", c.providerId)}
                    badge={{ text: c.status, color: { "قيد المراجعة": C.amber, "مُقدمة": C.blue, "محلولة": C.green, "مرفوضة": C.red }[c.status] || C.steel }}
                    sub="تُدار من: المزيد ← الضمانات ← المطالبات" />
                </div>
              ))}
            </Section>
          )}
        </>);
      })()}

      {sub === "السجل" && (
        <>
          <Section title="سجل التنفيذ (Audit)">
            {(wo.execLog || []).slice().reverse().map((h, i) => (
              <div key={i} style={{ fontSize: 13, color: C.steel, marginBottom: 4, borderBottom: `1px dashed ${C.line}`, paddingBottom: 4 }}>
                <b style={{ color: C.ink }}>{h.action}</b> — {h.at} — {h.by}
              </div>
            ))}
          </Section>
          <Section title="سجل الحالات">
            {(wo.history || []).map((h, i) => (
              <div key={i} style={{ fontSize: 13, color: C.steel, marginBottom: 3 }}>
                {h.at} — {h.from ? h.from + " ← " : ""}<b style={{ color: C.ink }}>{h.to}</b>
              </div>
            ))}
          </Section>
        </>
      )}

      {/* نوافذ فرعية */}
      {opForm && (
        <FormSheet title="إضافة عملية" onClose={() => setOpForm(false)} db={db}
          schema={[
            { k: "seq", label: "التسلسل", type: "number" }, { k: "name", label: "اسم العملية" },
            { k: "workCenterId", label: "مركز العمل", type: "select", from: "workCenters", fromKey: "name" },
            { k: "minutes", label: "الدقائق المخططة", type: "number" },
            { k: "assigneeId", label: "الفني", type: "select", from: "technicians", fromKey: "name" },
          ]} initial={{ seq: (wo.operations.length + 1) * 10 }}
          onSave={(d) => { patchOps([...wo.operations, { id: uid(), status: "معلقة", actualHours: 0, ...d }]); setOpForm(false); }} />
      )}
      {matForm && (
        <FormSheet title="مادة مطلوبة" onClose={() => setMatForm(false)} db={db}
          schema={[
            { k: "itemId", label: "الصنف (لا قطعة غيار بدون ماستر الأصناف)", type: "select", from: "items", fromLabel: (i) => i.code + " — " + i.name + " (متاح " + Math.max(0, availableQty(i.id)) + ")" },
            { k: "qty", label: "الكمية المطلوبة", type: "number" },
          ]} initial={{ qty: 1 }}
          onSave={(d) => {
            if (!d.itemId) { alert("اختر الصنف"); return; }
            update("workOrders", wo.id, { materials: [...(wo.materials || []), { id: uid(), ...d, reserved: false, picked: false, issuedQty: 0, usedQty: "", returned: false, unitCost: Number(db.items.find((i) => i.id === d.itemId)?.unitCost || 0) }], execLog: log(wo, "مادة مطلوبة: " + nameOf("items", d.itemId) + " ×" + d.qty) });
            setMatForm(false);
          }} />
      )}
      {failForm && (
        <FormSheet title="بيانات العطل" onClose={() => setFailForm(false)} db={db}
          schema={[
            { k: "mode", label: "نمط العطل", type: "select", options: FAILURE_MODES },
            { k: "cause", label: "السبب" }, { k: "effect", label: "الأثر (توقف الخط…)" },
            { k: "action", label: "الإجراء المتخذ" },
            { k: "downtime", label: "زمن التوقف (دقيقة)", type: "number" },
            { k: "rootCause", label: "السبب الجذري", type: "textarea" },
            { k: "repeated", label: "عطل متكرر؟", type: "check" },
          ]} initial={wo.failure || { mode: FAILURE_MODES[0] }}
          onSave={(d) => { update("workOrders", wo.id, { failure: d, execLog: log(wo, "تسجيل عطل: " + d.mode) }); setFailForm(false); }} />
      )}
      {completing && <CompleteOpSheet ctx={ctx} wo={wo} op={completing} onClose={() => setCompleting(null)}
        onComplete={(d) => {
          patchOps(wo.operations.map((o) => o.id === completing.id
            ? { ...o, status: "مكتملة", completedAt: today(), actualHours: Number(d.hours || 0) } : o));
          setCompleting(null);
        }} />}
      {reviewing && <ReviewSheet ctx={ctx} wo={wo} onClose={() => setReviewing(false)} />}
    </Sheet>
  );
}

/* مراجعة المشرف (وثيقة التنفيذ §13): اعتماد / رفض / أمر متابعة */
export function ReviewSheet({ ctx, wo, onClose }) {
  const { db, nameOf, setWOStatus, createWO, woCost } = ctx;
  const [notes, setNotes] = useState("");
  const hours = (wo.operations || []).reduce((s, o) => s + Number(o.actualHours || 0), 0);
  return (
    <Sheet title={"مراجعة " + wo.number} onClose={onClose}>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        <b>قائمة السلامة:</b> {(wo.checklist || []).every((c) => c.done) ? "✓ مكتملة" : "✗ ناقصة"}<br />
        <b>العمليات:</b> {(wo.operations || []).filter((o) => o.status === "مكتملة").length}/{(wo.operations || []).length} مكتملة<br />
        <b>ساعات العمل:</b> {hours} ساعة<br />
        <b>المواد المستخدمة:</b> {(wo.materials || []).map((m) => m.name + " ×" + (m.usedQty || 0)).join("، ") || "لا شيء"}<br />
        <b>العطل:</b> {wo.failure ? wo.failure.mode + " — " + wo.failure.cause : "غير مسجل"}<br />
        <b>الصور:</b> {(wo.photos || []).length} صورة<br />
        <b>التكلفة:</b> {money(woCost(wo).total)}
      </div>
      <Field label="ملاحظات المراجعة">
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} style={{ ...input, resize: "vertical" }} />
      </Field>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        <Btn bg={C.green} style={{ padding: 13, fontSize: 15 }} onClick={() => { setWOStatus(wo, "مغلق", { reviewNotes: notes, supervisorApproved: true }); onClose(); }}>
          ✓ اعتماد وإغلاق نهائي
        </Btn>
        <Btn bg={C.red} style={{ padding: 13 }} onClick={() => {
          if (!notes.trim()) { alert("اكتب سبب الرفض للفني"); return; }
          setWOStatus(wo, "مُعاد للتصحيح", { reviewNotes: notes }); onClose();
        }}>✗ رفض — إعادة للفني مع ملاحظات</Btn>
        <Btn bg={C.purple} style={{ padding: 13 }} onClick={() => {
          createWO({ title: "متابعة — " + wo.title, assetId: wo.assetId, type: "تصحيحي", priority: "عالية",
            plannedStart: today(), safetyRequired: true, followUpOf: wo.number });
          setWOStatus(wo, "مغلق", { reviewNotes: (notes ? notes + " · " : "") + "أُنشئ أمر متابعة", supervisorApproved: true }); onClose();
        }}>+ اعتماد مع أمر متابعة لعطل جديد</Btn>
      </div>
    </Sheet>
  );
}

/* تبويب الصور: قبل / أثناء / بعد / عطل / قطعة غيار */
export function PhotosTab({ ctx, wo }) {
  const { db, save, update, can, log, firebaseEnabled, firebaseServices } = ctx;
  const [type, setType] = useState("قبل");
  const [uploading, setUploading] = useState(false);
  const TYPES = EXECUTION_PHOTO_TYPES;
  const addPhoto = async (file) => {
    try {
      setUploading(true);
      const media = await buildCmmsMediaRecord(ctx, file, { ownerType:"workOrders", ownerId:wo.id, kind:type });
      const photo = { id: media.id, type, at: today(), name: media.name, url: media.url || "", downloadURL: media.downloadURL || "", storagePath: media.storagePath || "", storageProvider: media.storageProvider, data: media.data || "", contentType: media.contentType, size: media.size || media.originalSize || 0, uploadedAtIso: media.uploadedAtIso || media.createdAtIso };
      save({ ...db,
        workOrders: db.workOrders.map((w)=>w.id === wo.id ? { ...w, photos:[...(w.photos || []), photo], execLog: log(w, "صورة " + type) } : w),
        mediaFiles: [...(db.mediaFiles || []), { ...media, ownerType:"workOrders", ownerId:wo.id, ownerNumber:wo.number, kind:type, linkedEntity:"workOrders", linkedField:"photos" }]
      });
    } catch (e) { console.error(e); alert("تعذر معالجة أو رفع الصورة"); }
    finally { setUploading(false); }
  };
  const removePhoto = async (p) => {
    if (p?.storagePath && firebaseServices) { try { await deleteCmmsStorageFile(firebaseServices, p.storagePath); } catch (e) { console.warn("تعذر حذف الملف من Storage", e); } }
    save({ ...db,
      workOrders: db.workOrders.map((w)=>w.id === wo.id ? { ...w, photos:(w.photos || []).filter((x)=>x.id !== p.id), execLog: log(w, "حذف صورة " + (p.type || "")) } : w),
      mediaFiles: (db.mediaFiles || []).map((m)=>m.id === p.id || m.storagePath === p.storagePath ? { ...m, status:"محذوف", deletedAtIso:now() } : m)
    });
  };
  return (
    <Section title={"الصور (" + (wo.photos || []).length + ")" + (wo.photoRequired ? " — قبل/بعد إلزامية" : "")}>
      {can.execute && !["مغلق", "ملغي"].includes(wo.status) && (
        <div style={{ ...card() }}>
          <div style={{ display: "flex", gap: 5, marginBottom: 8, flexWrap: "wrap" }}>
            {TYPES.map((t) => <Chip key={t} active={type === t} onClick={() => setType(t)}>{t}</Chip>)}
          </div>
          <input type="file" accept="image/*" capture="environment" disabled={uploading} onChange={(e) => e.target.files?.[0] && addPhoto(e.target.files[0])} style={{ fontSize: 14 }} />
          <div style={{ fontSize: 11.5, color: uploading ? C.amber : C.steel, marginTop: 4 }}>{uploading ? "جارٍ رفع الصورة…" : (firebaseEnabled ? "ستُرفع الصورة إلى Firebase Storage ويحفظ النظام الرابط فقط." : "Firebase غير مفعّل: ستُحفظ الصورة مضغوطة داخل البيانات مؤقتًا.")}</div>
        </div>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {(wo.photos || []).map((p) => (
          <div key={p.id} style={{ border: `1.5px solid ${C.ink}`, borderRadius: 4, overflow: "hidden", background: "#fff" }}>
            {mediaSrc(p) ? <img src={mediaSrc(p)} alt={p.type} style={{ width: "100%", display: "block" }} /> : <div style={{padding:18, textAlign:"center", color:C.steel}}>لا توجد معاينة</div>}
            <div style={{ display: "flex", justifyContent: "space-between", gap:4, padding: "4px 8px", fontSize: 12, alignItems:"center" }}>
              <b>{p.type}</b><span style={{ color: mediaIsRemote(p) ? C.green : C.amber }}>{mediaIsRemote(p) ? "Storage" : "محلي"}</span><span style={{ color: C.steel }}>{fmt(p.at)}</span>
              {can.execute && <button onClick={() => removePhoto(p)} style={{ ...delBtn, marginTop: 0 }}>حذف</button>}
            </div>
          </div>
        ))}
      </div>
      {(wo.photos || []).length === 0 && <Empty text="لا صور بعد." />}
    </Section>
  );
}

export function CompleteOpSheet({ ctx, wo, op, onClose, onComplete }) {
  const { db, nameOf, addReading, currentValue, pmCheckAfterReading } = ctx;
  const [hours, setHours] = useState(op.minutes ? (op.minutes / 60).toFixed(1) : "1");
  const meters = db.assetMeters.filter((m) => m.assetId === wo.assetId && (!m.endDate || m.endDate >= today()));
  const isMand = (m) => (m.recordAtWO || db.meterTemplates.find((t) => t.id === m.templateId)?.recordAtWO) === "إلزامي";
  const mandPending = meters.filter((m) => isMand(m) && !db.readings.some((r) => r.workOrderId === wo.id && r.assetMeterId === m.id && !["معطلة", "ملغاة"].includes(r.status)));
  const [meterId, setMeterId] = useState(""); const [meterVal, setMeterVal] = useState(""); const [err, setErr] = useState("");
  return (
    <Sheet title={"إكمال: " + op.name} onClose={onClose}>
      <Field label="الساعات الفعلية"><input type="number" step="0.5" value={hours} onChange={(e) => setHours(e.target.value)} style={input} /></Field>
      {mandPending.length > 0 && (
        <div style={{ fontSize: 12.5, color: C.red, marginBottom: 8 }}>
          ⚠ عدادات إلزامية لم تُسجّل بعد: {mandPending.map((m) => nameOf("meterTemplates", m.templateId)).join("، ")} — لن يُقبل طلب الإكمال بدونها.
        </div>
      )}
      {meters.length > 0 && (
        <>
          <Field label="قراءة عداد عند الإكمال">
            <select value={meterId} onChange={(e) => { setMeterId(e.target.value); setErr(""); }} style={input}>
              <option value="">— بدون —</option>
              {meters.map((m) => <option key={m.id} value={m.id}>{(isMand(m) ? "⚠ إلزامي — " : "") + nameOf("meterTemplates", m.templateId)} (المعروض: {currentValue(m)})</option>)}
            </select>
          </Field>
          {meterId && <Field label="القراءة الجديدة"><input type="number" value={meterVal} onChange={(e) => setMeterVal(e.target.value)} style={input} /></Field>}
        </>
      )}
      {err && <div style={{ color: C.red, fontSize: 13, marginBottom: 8 }}>⚠ {err}</div>}
      <Btn bg={C.green} style={{ width: "100%", padding: 13, fontSize: 15 }} onClick={() => {
        if (meterId && meterVal !== "") {
          const am = db.assetMeters.find((m) => m.id === meterId);
          const alerts = pmCheckAfterReading(am, meterVal);
          const e = addReading(am, meterVal, today(), { source: "أمر عمل", workOrderId: wo.id });
          if (e) { setErr(e); return; }
          if (alerts.length) alert(alerts.map((x) => x.msg).join("\n"));
        }
        onComplete({ hours });
      }}>تأكيد إكمال العملية</Btn>
    </Sheet>
  );
}

/* ───────────────────────── تحليل الأعطال (Failure Analysis + MTTR) ───────────────────────── */
export function FailureAnalysis({ ctx, openWO }) {
  const { db, nameOf } = ctx;
  const failures = db.workOrders.filter((w) => w.failure).map((w) => ({ wo: w, f: w.failure }));
  const mttr = failures.length ? Math.round(failures.reduce((s, x) => s + Number(x.f.downtime || 0), 0) / failures.length) : 0;
  const totalDowntime = failures.reduce((s, x) => s + Number(x.f.downtime || 0), 0);
  /* الأعطال المتكررة: نفس النمط على نفس الأصل أكثر من مرة */
  const repeatMap = {};
  failures.forEach(({ wo, f }) => { const k = (wo.assetId || "؟") + "|" + f.mode; repeatMap[k] = (repeatMap[k] || 0) + 1; });
  const repeated = Object.entries(repeatMap).filter(([, n]) => n > 1)
    .map(([k, n]) => { const [assetId, mode] = k.split("|"); return { asset: nameOf("assets", assetId), mode, n }; });
  /* أكثر الأصول مشاكل (وثيقة الأصول §Top Problem Assets) */
  const probMap = {};
  failures.forEach(({ wo }) => { probMap[wo.assetId] = (probMap[wo.assetId] || 0) + 1; });
  const topProblem = Object.entries(probMap).map(([id, n]) => ({ name: nameOf("assets", id), n })).sort((a, b) => b.n - a.n).slice(0, 5);
  return (
    <>
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <Stat n={failures.length} label="أعطال مسجلة" color={C.red} />
        <Stat n={mttr + " د"} label="MTTR متوسط الإصلاح" color={C.amber} small />
        <Stat n={totalDowntime + " د"} label="إجمالي التوقف" color={C.ink} small />
      </div>
      {topProblem.length > 0 && (
        <Section title="أكثر الأصول مشاكل">
          <div style={card()}>
            {topProblem.map((x) => (
              <div key={x.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}>
                <span>{x.name}</span><b style={{ color: C.red }}>{x.n} عطل</b>
              </div>
            ))}
          </div>
        </Section>
      )}
      {repeated.length > 0 && (
        <Section title="⚠ أعطال متكررة — تحتاج سببًا جذريًا">
          {repeated.map((r, i) => (
            <div key={i} style={{ ...card(), borderRightColor: C.red }}>
              <Row main={r.mode + " — " + r.asset} sub={"تكرر " + r.n + " مرات"} />
            </div>
          ))}
        </Section>
      )}
      <Section title="سجل الأعطال">
        {failures.length === 0 && <Empty text="لا أعطال مسجلة بعد — تُسجّل من داخل أمر العمل (تبويب العطل)." />}
        {failures.slice().reverse().map(({ wo, f }) => (
          <div key={wo.id} style={card()} onClick={() => openWO(wo.id)}>
            <Row main={f.mode + " — " + nameOf("assets", wo.assetId)}
              sub={[f.cause, f.downtime + " د توقف", wo.number].join(" · ")}
              badge={f.repeated ? { text: "متكرر", color: C.red } : undefined} />
          </div>
        ))}
      </Section>
    </>
  );
}


/* ───────────────────────── إدارة الصيانة الشاملة — حسب المتطلبات ───────────────────────── */
export function MaintenanceManagementHub({ ctx, openWO, setTab }) {
  const { db, save, can, nameOf, programDue, generateWO, woAssignedTechIds, materialStatusOf, canUseDemoTools } = ctx;
  const [sub, setSub] = useState("الملخص");
  const open = db.workOrders.filter((w) => ACTIVE_STATES.includes(w.status));
  const todayWos = open.filter((w) => !w.plannedStart || daysUntil(w.plannedStart) <= 0);
  const pastDue = open.filter((w) => w.plannedEnd && daysUntil(w.plannedEnd) < 0);
  const waitingMat = open.filter((w) => w.status === "بانتظار مواد" || (materialStatusOf && materialStatusOf(w) === "Waiting Material"));
  const pendingReview = open.filter((w) => w.status === "بانتظار المراجعة");
  const emergency = open.filter((w) => w.priority === "طارئ" || w.type === "طارئ");
  const rejected = db.workOrders.filter((w) => w.status === "مُعاد للتصحيح");
  const seedDemo = () => {
    const next = normalizeDb(db);
    const getOrAdd = (key, pred, maker) => { let row = next[key].find(pred); if (!row) { row = { id: uid(), ...maker() }; next[key] = [...next[key], row]; } return row; };
    const org = getOrAdd("maintenanceOrganizations", (x) => x.code === "MAIN", () => ({ code:"MAIN", name:"Main Maintenance Organization", status:"عاملة", isMaintenanceEnabled:true }));
    const area = getOrAdd("workAreas", (x) => x.code === "MILL", () => ({ organizationId:org.id, code:"MILL", name:"Mill Maintenance Area" }));
    const wcMech = getOrAdd("workCenters", (x) => x.code === "MECH", () => ({ organizationId:org.id, workAreaId:area.id, code:"MECH", name:"Mechanical Workshop" }));
    const wcElec = getOrAdd("workCenters", (x) => x.code === "ELEC", () => ({ organizationId:org.id, workAreaId:area.id, code:"ELEC", name:"Electrical Workshop" }));
    getOrAdd("resources", (x) => x.code === "LAB-MECH", () => ({ code:"LAB-MECH", name:"Mechanical Technician", type:"عمالة", usageUom:"ساعة", workCenterId:wcMech.id, qty:4, available24h:false }));
    getOrAdd("resources", (x) => x.code === "LAB-ELEC", () => ({ code:"LAB-ELEC", name:"Electrical Technician", type:"عمالة", usageUom:"ساعة", workCenterId:wcElec.id, qty:3, available24h:false }));
    const ahmed = getOrAdd("technicians", (x) => x.name === "Ahmed", () => ({ name:"Ahmed", specialty:"ميكانيكي", workCenterId:wcMech.id, rate:50 }));
    const ali = getOrAdd("technicians", (x) => x.name === "Ali", () => ({ name:"Ali", specialty:"كهربائي", workCenterId:wcElec.id, rate:55 }));
    const ela = getOrAdd("assets", (x) => x.number === "ELA-01", () => ({ number:"ELA-01", name:"Bucket Elevator ELA-01", type:"معدات", location:"Mill / Elevator Line", locationType:"WORK_CENTER", workCenterId:wcMech.id, ownership:"مؤسسة", active:true, allowWO:true, allowPrograms:true, critical:true, parts:[], docs:[], photos:[], notes:[], history:[{ action:"إنشاء نموذج إدارة الصيانة", at:now(), by:"النظام" }] }));
    const fan = getOrAdd("assets", (x) => x.number === "SFN-01", () => ({ number:"SFN-01", name:"Silo Fan SFN-01", type:"معدات", location:"Silo Area", locationType:"WORK_CENTER", workCenterId:wcElec.id, ownership:"مؤسسة", active:true, allowWO:true, allowPrograms:true, critical:false, parts:[], docs:[], photos:[], notes:[], history:[] }));
    const cc = getOrAdd("assets", (x) => x.number === "CC-01", () => ({ number:"CC-01", name:"Chain Conveyor CC-01", type:"معدات", location:"Mill / Conveyor Line", locationType:"WORK_CENTER", workCenterId:wcMech.id, ownership:"مؤسسة", active:true, allowWO:true, allowPrograms:true, critical:true, parts:[], docs:[], photos:[], notes:[], history:[] }));
    const bucketGroup = getOrAdd("assetGroups", (x) => x.code === "ELV", () => ({ code:"ELV", number:"AG-ELV", name:"Bucket Elevators", description:"مصاعد القواديس", assetIds:[ela.id], assignments:[{ id:uid(), assetId:ela.id, start:today(), end:"" }] }));
    const fanGroup = getOrAdd("assetGroups", (x) => x.code === "SFN", () => ({ code:"SFN", number:"AG-SFN", name:"Silo Fans", description:"مراوح الصوامع", assetIds:[fan.id], assignments:[{ id:uid(), assetId:fan.id, start:today(), end:"" }] }));
    bucketGroup.assetIds = [...new Set([...(bucketGroup.assetIds||[]), ela.id])]; fanGroup.assetIds = [...new Set([...(fanGroup.assetIds||[]), fan.id])];
    const grease = getOrAdd("items", (x) => x.code === "GRS-001", () => ({ code:"GRS-001", name:"Grease", category:"زيوت وشحوم", unit:"kg", minQty:1, unitCost:25 }));
    const tools = getOrAdd("items", (x) => x.code === "CLN-TOOLS", () => ({ code:"CLN-TOOLS", name:"Cleaning tools", category:"أخرى", unit:"set", minQty:1, unitCost:10 }));
    const wh = getOrAdd("warehouses", (x) => x.name === "Main Store", () => ({ name:"Main Store" }));
    if (!next.stockTx.some((t) => t.itemId === grease.id && t.type === "استلام")) next.stockTx.push({ id:uid(), type:"استلام", itemId:grease.id, warehouseId:wh.id, qty:10, at:today() });
    const mkOp = (code, name, wc, minutes, steps) => getOrAdd("stdOps", (x) => x.code === code, () => ({ code, name, type:"داخلية", workCenterId:wc.id, minutes, steps, countPoint:true, resources:[], attachments:[] }));
    const bearing = mkOp("BRG-LUB", "Bearing Lubrication", wcMech, 30, "Safety isolation\nOpen guard\nClean bearing area\nApply grease\nCheck temperature\nTrial run\nRecord result");
    const inspectBelt = mkOp("ELV-BELT", "Inspect belt", wcMech, 20, "Inspect belt tension\nCheck belt alignment\nRecord observations");
    const inspectBuckets = mkOp("ELV-BUCKET", "Inspect buckets", wcMech, 15, "Inspect buckets\nTighten loose bolts\nRecord damaged buckets");
    const pulley = mkOp("ELV-PULLEY", "Check pulley alignment", wcMech, 20, "Check drive pulley\nCheck tail pulley\nRecord alignment");
    const sensors = mkOp("ELV-SENSOR", "Check sensors", wcElec, 20, "Check speed switch\nCheck bearing temperature sensor\nCheck safety interlock");
    const trial = mkOp("ELV-TRIAL", "Trial run", wcMech, 15, "Remove tools\nRun equipment\nRecord result");
    const def = getOrAdd("workDefs", (x) => x.name === "Bucket Elevator Monthly PM", () => ({ name:"Bucket Elevator Monthly PM", description:"Operations + Steps + Materials + Resources + Time + Safety", assetGroupId:bucketGroup.id, opIds:[inspectBelt.id, inspectBuckets.id, pulley.id, bearing.id, sensors.id, trial.id], materials:"Grease\nCleaning tools", resources:"Mechanical Technician\nElectrical Technician", estimatedHours:2 }));
    const tpl = getOrAdd("meterTemplates", (x) => x.code === "RUN-HOURS", () => ({ code:"RUN-HOURS", name:"Running Hours", uom:"ساعة", meterType:"مستمر", readingType:"مطلق", direction:"تصاعدي", allowSchedule:true, recordAtWO:"اختياري" }));
    const am = getOrAdd("assetMeters", (x) => x.assetId === fan.id && x.templateId === tpl.id, () => ({ assetId:fan.id, templateId:tpl.id, initial:0, estDailyRate:10 }));
    if (!next.readings.some((r) => r.assetMeterId === am.id && Number(r.value) === 485)) next.readings.push({ id:uid(), assetMeterId:am.id, assetId:fan.id, value:485, at:today(), status:"مسجلة", comments:"Current Meter 485 hours" });
    const prog = getOrAdd("programs", (x) => x.name === "Silo Fan PM", () => ({ name:"Silo Fan PM", targetType:"أصل واحد", assetId:fan.id, assetGroupId:fanGroup.id, workDefId:def.id, method:"فاصل عداد", interval:500, assetMeterId:am.id, lastMeterValue:0, startDate:today() }));
    getOrAdd("workRequests", (x) => x.title === "Abnormal sound in ELA-01", () => ({ title:"Abnormal sound in ELA-01", assetId:ela.id, severity:"حرجة", desc:"Operator notices abnormal sound in ELA-01", status:"مفتوح", createdAt:today(), requester:"Operator" }));
    if (!next.workOrders.some((w) => w.number === "WO-1001")) {
      const ops = [inspectBelt, inspectBuckets, pulley, bearing, sensors, trial].map((op, i) => ({ id:uid(), seq:(i+1)*10, stdOpId:op.id, name:op.name, workCenterId:op.workCenterId, minutes:op.minutes, status:"معلقة", assigneeId:i === 3 ? ahmed.id : (op.workCenterId === wcElec.id ? ali.id : ahmed.id), actualHours:0, steps:(op.steps||"").split("\n").filter(Boolean).map((text, idx)=>({ id:uid(), seq:idx+1, text, done:false })) }));
      next.workOrders.push({ id:uid(), number:"WO-1001", title:"Bucket Elevator Monthly PM", assetId:ela.id, type:"وقائي", priority:"عالية", status:"جاهز", plannedStart:today(), plannedEnd:today(), workDefId:def.id, programId:prog.id, workCenterId:wcMech.id, safetyRequired:true, photoRequired:true, materials:[{ id:uid(), itemId:grease.id, qty:1, reserved:true, picked:true, issuedQty:0, usedQty:"", returned:false, unitCost:25 }, { id:uid(), itemId:tools.id, qty:1, reserved:true, picked:true, issuedQty:0, usedQty:"", returned:false, unitCost:10 }], checklist:SAFETY_DEFAULTS.map((text)=>({ id:uid(), text, done:false })), operations:ops, photos:[], failure:null, exceptions:[], assignments:[{ id:uid(), technicianId:ahmed.id, role:"Mechanical Technician", status:"مسند", assignedAt:today() }, { id:uid(), technicianId:ali.id, role:"Electrical Technician", status:"مسند", assignedAt:today() }], _cmmsAssignedTechIds:[ahmed.id, ali.id], execLog:[{ action:"إنشاء نموذج WO-1001", at:now(), by:"النظام" }], history:[{ to:"جاهز", at:today() }], statusHistory:[{ id:uid(), from:"مسودة", to:"جاهز", at:today(), atText:now(), by:"النظام" }] });
    }
    next.standardOperationSteps = next.standardOperationSteps.length ? next.standardOperationSteps : (bearing.steps||"").split("\n").map((text, i)=>({ id:uid(), standardOperationId:bearing.id, seq:i+1, text }));
    next.workDefinitionOperations = next.workDefinitionOperations.length ? next.workDefinitionOperations : (def.opIds||[]).map((opId, i)=>({ id:uid(), workDefinitionId:def.id, operationId:opId, seq:(i+1)*10 }));
    next.workDefinitionMaterials = next.workDefinitionMaterials.length ? next.workDefinitionMaterials : [{ id:uid(), workDefinitionId:def.id, itemId:grease.id, qty:1 }, { id:uid(), workDefinitionId:def.id, itemId:tools.id, qty:1 }];
    next.workDefinitionResources = next.workDefinitionResources.length ? next.workDefinitionResources : [{ id:uid(), workDefinitionId:def.id, resourceName:"Mechanical Technician", hours:1.5 }, { id:uid(), workDefinitionId:def.id, resourceName:"Electrical Technician", hours:0.5 }];
    next.maintenanceProgramGroups = next.maintenanceProgramGroups.length ? next.maintenanceProgramGroups : [{ id:uid(), programId:prog.id, assetGroupId:fanGroup.id }];
    next.maintenanceForecasts = [{ id:uid(), programId:prog.id, assetId:fan.id, currentMeter:485, dueAt:500, remaining:15, alert:"Maintenance due soon", generatedAt:today() }];
    save(next); alert("تم إنشاء نموذج إدارة الصيانة الكامل.");
  };
  const ruleFindings = [];
  db.workOrders.forEach((w) => {
    if (!w.assetId) ruleFindings.push(["No Work Order without Asset", w.number]);
    if (w.type === "وقائي" && !w.programId && !w.workDefId) ruleFindings.push(["No PM Work Order without Maintenance Program or Work Definition", w.number]);
    if (!woAssignedTechIds(w).length) ruleFindings.push(["No work order without technicians assign", w.number]);
    if (["بانتظار المراجعة", "مغلق"].includes(w.status) && (w.checklist||[]).some((c)=>!c.done)) ruleFindings.push(["No technician completion without checklist", w.number]);
    if (w.status === "مغلق" && !w.supervisorApproved) ruleFindings.push(["No final close without supervisor approval", w.number]);
    if (["تصحيحي", "طارئ"].includes(w.type) && ["بانتظار المراجعة", "مغلق"].includes(w.status) && !w.failure) ruleFindings.push(["No corrective work completion without failure data", w.number]);
    if (w.photoRequired && ["بانتظار المراجعة", "مغلق"].includes(w.status)) { const types = (w.photos||[]).map((p)=>p.type); if (!types.includes("قبل") || !types.includes("بعد")) ruleFindings.push(["No photo-required work completion without photos", w.number]); }
    if (!(w.execLog||[]).length && !(w.statusHistory||[]).length) ruleFindings.push(["No status change without audit log", w.number]);
  });
  const techLoad = db.technicians.map((t)=>({ t, n: open.filter((w)=>woAssignedTechIds(w).includes(t.id)).length })).filter((x)=>x.n>0).sort((a,b)=>b.n-a.n);
  const dueForecasts = db.programs.map((p) => ({ p, info: programDue ? programDue(p) : { label:"—" } }));
  const tabs = ["الملخص", "التدفق", "التخطيط", "الإرسال", "تنفيذ الفني", "المراجعة", "القواعد", "التقارير", "الكيانات"];
  return <>
    <div style={{ display:"flex", gap:6, overflowX:"auto", marginBottom:12 }}>{tabs.map((t)=><Chip key={t} active={sub===t} onClick={()=>setSub(t)}>{t}</Chip>)}</div>
    {canUseDemoTools && <Btn bg={C.orange} onClick={seedDemo} style={{ width:"100%", padding:12, marginBottom:12 }}>+ إنشاء نموذج إدارة الصيانة الكامل</Btn>}
    {sub === "الملخص" && <>
      <div style={{ display:"flex", gap:8, marginBottom:16 }}><Stat n={todayWos.length} label="Today Work Orders" color={C.blue}/><Stat n={pastDue.length} label="Past Due" color={pastDue.length?C.red:C.steel}/><Stat n={waitingMat.length} label="Waiting Material" color={waitingMat.length?C.amber:C.steel}/><Stat n={pendingReview.length} label="Pending Review" color={C.purple}/></div>
      <Section title="Maintenance Management"><div style={card()}><Row main="Work Requests → Standard Operations → Work Definitions → Programs → Forecast → Work Orders → Scheduling → Assignment → Execution → Supervision → Closing → Reports" sub="هذه الشاشة تجمع دورة العمل التي طلبتها وتربطها بالشاشات الحالية." /></div></Section>
      <Section title="Supervisor see"><div style={card()}><Row main="Today / Past Due / Waiting Material / Completed Pending Review / Emergency / Rejected" sub={"اليوم "+todayWos.length+" · متأخر "+pastDue.length+" · مواد "+waitingMat.length+" · مراجعة "+pendingReview.length+" · طارئ "+emergency.length+" · مرفوض "+rejected.length}/></div><div style={card()}><Row main="Technician Load" sub={techLoad.map((x)=>x.t.name+": "+x.n).join(" · ") || "لا حمل"}/></div></Section>
    </>}
    {sub === "التدفق" && <Section title="Work Request to Work Order"><div style={card()}><Row main="Operator notices abnormal sound in ELA-01" sub="Creates Work Request → Supervisor reviews → Convert to Work Order" /></div>{db.workRequests.slice(-5).map((r)=><div key={r.id} style={card()}><Row main={r.title} sub={nameOf("assets", r.assetId)+" · "+r.status}/></div>)}</Section>}
    {sub === "التخطيط" && <><Section title="Standard Operation: Bearing Lubrication">{db.stdOps.filter((o)=>o.code==="BRG-LUB" || o.name.includes("Bearing")).map((o)=><div key={o.id} style={card()}><Row main={o.code+" — "+o.name} sub={(o.steps||"").split("\n").filter(Boolean).map((x,i)=>(i+1)+". "+x).join(" · ")}/></div>)}{!db.stdOps.some((o)=>o.code==="BRG-LUB") && <Empty text="اضغط إنشاء النموذج لإضافة العملية القياسية."/>}</Section><Section title="Work Definition: Bucket Elevator Monthly PM">{db.workDefs.filter((d)=>d.name.includes("Bucket Elevator")).map((d)=><div key={d.id} style={card()}><Row main={d.name} sub={[(d.opIds||[]).length+" Operations", d.materials, d.resources, d.estimatedHours?d.estimatedHours+" hours":""].filter(Boolean).join(" · ")}/></div>)}</Section><Section title="Maintenance Forecast">{dueForecasts.map(({p,info})=><div key={p.id} style={{...card(), borderRightColor:info.due?C.red:info.soon?C.amber:C.green}}><Row main={p.name} sub={info.label} action={info.due?<Btn bg={C.orange} onClick={()=>generateWO(p)}>Generate WO</Btn>:<Badge text={info.soon?"Maintenance due soon":"OK"} color={info.soon?C.amber:C.green}/>} /></div>)}</Section></>}
    {sub === "الإرسال" && <Section title="Maintenance Dispatch List">{open.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} badge={{text:w.status, color:WO_COLORS[w.status]||C.steel}} sub={["Asset: "+nameOf("assets", w.assetId), "Work Type: "+w.type, "Priority: "+w.priority, "Planned: "+(w.plannedStart||"—"), "Work Center: "+nameOf("workCenters", w.workCenterId), "Technician: "+(woAssignedTechIds(w).map((id)=>nameOf("technicians", id)).join("، ")||"—"), "Material Status: "+materialStatusOf(w), w.safetyRequired?"Safety Permit: Required":""].filter(Boolean).join(" · ")} /></div>)}{open.length===0 && <Empty text="لا توجد أوامر مفتوحة للإرسال."/>}</Section>}
    {sub === "تنفيذ الفني" && <Section title="My Maintenance Work / Technician Execution">{["New Assigned Tasks", "In Progress Tasks", "Emergency Tasks", "Tasks Waiting Materials", "Tasks Returned by Supervisor", "Completed Tasks"].map((b)=><div key={b} style={card()}><Row main={b} sub="Start Work · Pause · Resume · Add Note · Request Material · Record Failure · Upload Photo · Complete Work" /></div>)}<Btn bg={C.blue} onClick={()=>setTab("mywork")} style={{width:"100%"}}>فتح شاشة الفني</Btn></Section>}
    {sub === "المراجعة" && <Section title="Supervisor Review">{pendingReview.map((w)=><div key={w.id} style={card()} onClick={()=>openWO(w.id)}><Row main={w.number+" — "+w.title} sub={["Technician Notes", "Checklist", "Material Usage", "Labor Time", "Failure Data", "Photos", "Inspection Results", "Trial Run Result"].join(" · ")} badge={{text:"Review", color:C.blue}} /></div>)}{pendingReview.length===0 && <Empty text="لا أوامر بانتظار مراجعة المشرف."/>}</Section>}
    {sub === "القواعد" && <><Section title={"قواعد التنفيذ — ملاحظات حالية " + ruleFindings.length}>{MAINTENANCE_RULES.map((r)=><div key={r} style={{...card(), borderRightColor:ruleFindings.some(([x])=>x===r)?C.red:C.green}}><Row main={r} sub={ruleFindings.filter(([x])=>x===r).map(([,ref])=>ref).join("، ") || "مطبق"} badge={{text:ruleFindings.some(([x])=>x===r)?"تحقق":"✓", color:ruleFindings.some(([x])=>x===r)?C.red:C.green}}/></div>)}</Section><Section title="الصلاحيات"><div style={card()}>{MAINTENANCE_PERMISSIONS.map((p)=><span key={p} style={{display:"inline-block", fontSize:11, border:`1px solid ${C.line}`, borderRadius:999, padding:"3px 7px", margin:3}}>{p}</span>)}</div></Section></>}
    {sub === "التقارير" && <Section title="Maintenance Reports">{MAINTENANCE_REPORTS.map((r)=><div key={r} style={card()}><Row main={r} sub={r.includes("Cost")?"يعتمد على WorkOrderCosts + Material/Labor Transactions":r.includes("Failure")||r.includes("MTTR")||r.includes("MTBF")?"يعتمد على Failure Capture و Downtime":"متاح من بيانات أوامر العمل"}/></div>)}</Section>}
    {sub === "الكيانات" && <Section title="Data Model / Tables">{MAINTENANCE_ENTITY_KEYS.map((e)=><div key={e} style={card()}><Row main={e} sub={(db[e]||[]).length+" records"}/></div>)}</Section>}
  </>;
}


/* ───────────────────────── v39 محرك الجدولة المتقدم ───────────────────────── */
