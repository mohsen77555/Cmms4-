import { useState } from "react";
import { ACTIVE_STATES, API, C, GOVERNANCE100_DOMAINS, GOV_ACTIONS, GOV_CHANGE_STATUS, GOV_DATA_SEVERITY, GOV_POLICY_STATUS, GOV_POLICY_TYPES, GOV_PROCESSES, GOV_REQUEST_STATUS, GOV_REVIEW_FREQ, GOV_RISK_LEVELS, GOV_RISK_STATUS, ROLES, addDateDays, daysUntil, fmt, now, today, uid } from "../core/appCore";
import { Btn, Chip, Empty, Row, Section, Stat, card } from "../components/ui";
import { Crud } from "./crud";

export function GovernanceHub({ ctx }) {
  const { db, save, can, role, firebaseEnabled } = ctx;
  const [sub, setSub] = useState("dashboard");

  const plusDays = (n) => addDateDays(today(), Number(n || 0));
  const auditCount = (db.governanceAuditEvents || []).length
    + db.workOrders.reduce((n, w) => n + (w.execLog || []).length + (w.history || []).length, 0)
    + db.assets.reduce((n, a) => n + (a.history || []).length, 0);
  const orgReady = db.maintenanceOrganizations.length > 0 && db.workAreas.length > 0 && db.workCenters.length > 0;
  const activePolicies = (db.governancePolicies || []).filter((p) => p.status === "سارية");
  const activeApprovals = (db.approvalMatrix || []).filter((a) => a.active);
  const openApprovalRequests = (db.governanceApprovalRequests || []).filter((r) => r.status === "مفتوح");
  const highRisks = (db.governanceRisks || []).filter((r) => ["عال", "حرج"].includes(r.level) && r.status !== "مغلق").length;
  const overdueReviews = (db.governanceReviews || []).filter((r) => r.nextReview && daysUntil(r.nextReview) < 0 && r.status !== "مغلق").length;
  const overduePolicies = activePolicies.filter((p) => p.reviewDate && daysUntil(p.reviewDate) < 0).length;

  const duplicateAssetNumbers = db.assets
    .filter((a) => a.number)
    .filter((a, i, arr) => arr.findIndex((x) => x.number === a.number) !== i).length;
  const duplicateSerials = db.assets
    .filter((a) => a.serial && a.operatingOrganizationId)
    .filter((a, i, arr) => arr.findIndex((x) => x.serial === a.serial && x.operatingOrganizationId === a.operatingOrganizationId) !== i).length;

  const qualityFindings = [];
  if (!db.maintenanceOrganizations.length) qualityFindings.push({ severity:"حرج", area:"منظمة الصيانة", issue:"لا توجد Maintenance Organization", fix:"أنشئ منظمة صيانة ثم Work Area وWork Center." });
  if (db.maintenanceOrganizations.length && !db.workAreas.length) qualityFindings.push({ severity:"عال", area:"منظمة الصيانة", issue:"لا توجد Work Areas", fix:"أضف منطقة عمل واحدة على الأقل لكل منظمة تشغيلية." });
  if (db.workAreas.length && !db.workCenters.length) qualityFindings.push({ severity:"عال", area:"منظمة الصيانة", issue:"لا توجد Work Centers", fix:"أضف مركز عمل داخل منطقة العمل." });
  if (duplicateAssetNumbers) qualityFindings.push({ severity:"حرج", area:"الأصول", issue:"أرقام أصول مكررة: " + duplicateAssetNumbers, fix:"اجعل Asset Number فريدًا قبل التشغيل." });
  if (duplicateSerials) qualityFindings.push({ severity:"عال", area:"الأصول", issue:"Serial Number مكرر داخل نفس منظمة التشغيل: " + duplicateSerials, fix:"صحح الرقم التسلسلي أو منظمة التشغيل." });
  db.assets.forEach((a) => {
    const ref = a.number || a.name || "أصل بدون رقم";
    if (!a.number) qualityFindings.push({ severity:"عال", area:"الأصول", ref, issue:"أصل بدون Asset Number", fix:"أضف رقمًا أو استخدم التوليد التلقائي." });
    if (!a.location && a.locationType !== "UNKNOWN") qualityFindings.push({ severity:"متوسط", area:"الأصول", ref, issue:"نوع الموقع محدد لكن الموقع فارغ", fix:"أدخل الموقع أو اجعل Location Type = UNKNOWN بمبرر." });
    if (a.itemRequired && !a.itemName && !a.itemId) qualityFindings.push({ severity:"عال", area:"الأصول", ref, issue:"Item مطلوب وغير محدد", fix:"اربط الأصل بصنف أو ألغِ Item Required إذا كان مناسبًا." });
    if (a.allowWO !== false && a.assetType === "ENTERPRISE" && a.itemRequired && a.fullLifecycleTracked === false) qualityFindings.push({ severity:"متوسط", area:"الأصول", ref, issue:"أوامر العمل مسموحة مع Item غير Full Lifecycle", fix:"فعّل Full Lifecycle أو امنع أوامر العمل على هذا الأصل." });
    if (a.endDate && ACTIVE_STATES.some((s) => db.workOrders.some((w) => w.assetId === a.id && w.status === s))) qualityFindings.push({ severity:"عال", area:"الأصول", ref, issue:"أصل منتهي وله أمر عمل مفتوح", fix:"أغلق الأمر أو أعد تفعيل/تصحيح تاريخ الأصل." });
  });
  db.workOrders.forEach((w) => {
    const ref = w.number || w.title || "أمر عمل";
    if (!w.assetId) qualityFindings.push({ severity:"عال", area:"أوامر العمل", ref, issue:"أمر عمل بدون أصل", fix:"اربط الأمر بأصل صالح." });
    if (w.status === "مغلق" && !(w.history || []).some((h) => h.to === "مغلق")) qualityFindings.push({ severity:"منخفض", area:"أوامر العمل", ref, issue:"أمر مغلق بدون أثر حالة واضح", fix:"راجع سجل الحالة أو أعد الإغلاق عبر المسار النظامي." });
    if (["تصحيحي", "طارئ"].includes(w.type) && w.status === "مغلق" && !w.failure) qualityFindings.push({ severity:"متوسط", area:"أوامر العمل", ref, issue:"أمر تصحيحي/طارئ مغلق بدون Failure", fix:"سجل نمط العطل وزمن التوقف وسبب الإصلاح." });
    if (w.status === "بانتظار المراجعة" && !(w.execLog || []).length) qualityFindings.push({ severity:"متوسط", area:"أوامر العمل", ref, issue:"بانتظار مراجعة بدون سجل تنفيذ", fix:"راجع سجل التنفيذ قبل الاعتماد." });
  });
  db.resources.forEach((r) => { if (!r.workCenterId) qualityFindings.push({ severity:"متوسط", area:"الموارد", ref:r.name, issue:"مورد غير مربوط بمركز عمل", fix:"اربط المورد بمركز العمل المناسب." }); });
  db.stockTx.forEach((t) => { if (Number(t.qty || 0) <= 0) qualityFindings.push({ severity:"متوسط", area:"المخزون", ref:t.type, issue:"حركة مخزون بكمية غير صحيحة", fix:"صحح الكمية أو احذف الحركة الخاطئة." }); });
  db.assetMeters.forEach((m) => { if (!m.assetId || !m.templateId) qualityFindings.push({ severity:"متوسط", area:"العدادات", issue:"عداد أصل ناقص الربط", fix:"اربط العداد بأصل وقالب عداد." }); });

  const checks = [
    ["سياسات حوكمة موثقة", activePolicies.length >= 3, "أضف سياسات سارية للأصول، أوامر العمل، المخزون، البيانات."],
    ["مصفوفة اعتماد", activeApprovals.length >= 3, "عرّف من يعتمد الإغلاق، الحذف، التسوية، الاستيراد، وتغيير الصلاحيات."],
    ["طلبات اعتماد قابلة للتتبع", (db.governanceApprovalRequests || []).length > 0 || activeApprovals.length >= 3, "أضف طلبات اعتماد أو اربط المصفوفة بالإجراءات الحساسة."],
    ["سجل تدقيق", auditCount > 0, "التطبيق يسجل أوامر العمل والأصول؛ أضف أحداث حوكمة عامة."],
    ["إدارة مخاطر", (db.governanceRisks || []).length > 0, "أضف سجل مخاطر تشغيلية ومالكية لكل خطر."],
    ["مراجعات دورية", (db.governanceReviews || []).length > 0, "حدد مراجعة شهرية/ربع سنوية للبيانات والصلاحيات."],
    ["قواعد جودة بيانات", (db.governanceDataQualityRules || []).length > 0, "أضف قواعد جودة بيانات قابلة للمراجعة."],
    ["منظمة صيانة جاهزة", orgReady, "أنشئ Organization + Work Area + Work Center."],
    ["جودة بيانات الأصول", qualityFindings.filter((x) => ["عال", "حرج"].includes(x.severity)).length === 0, "صحح الملاحظات عالية الخطورة في تبويب جودة البيانات."],
    ["حوكمة Backend", firebaseEnabled || !String(API).includes("localhost"), "فعّل Firebase أو استخدم رابط API خارجي HTTPS بدل localhost."],
  ];
  const okCount = checks.filter((c) => c[1]).length;
  const penalty = highRisks * 4 + overdueReviews * 4 + overduePolicies * 4 + openApprovalRequests.length * 2;
  const score = Math.max(0, Math.min(100, Math.round((okCount / checks.length) * 100) - penalty));
  const scoreColor = score >= 85 ? C.green : score >= 65 ? C.amber : C.red;

  const addAudit = (action, area = "الحوكمة", extra = {}) => save({ ...db, governanceAuditEvents: [...(db.governanceAuditEvents || []), { id: uid(), at: now(), by: role, area, action, ...extra }] });
  const decideRequest = (r, status) => {
    save({ ...db,
      governanceApprovalRequests: (db.governanceApprovalRequests || []).map((x) => x.id === r.id ? { ...x, status, decisionBy:role, decisionAt:now() } : x),
      governanceAuditEvents: [...(db.governanceAuditEvents || []), { id:uid(), at:now(), by:role, area:r.area || "اعتماد", action:"قرار طلب اعتماد " + (r.number || r.title || "") + ": " + status }]
    });
  };
  const seed = () => {
    const todayDate = today();
    save({ ...db,
      governancePolicies: (db.governancePolicies || []).length ? db.governancePolicies : [
        { id:uid(), code:"GOV-AM-001", title:"سياسة إدارة الأصول", type:"سياسة", scope:"كل الأصول", ownerRole:"مدير", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(180), controlObjective:"ضمان إنشاء الأصول وتعديلها وتتبعها ضمن قواعد موحدة.", evidenceRequired:"سجل الأصل، سجل التغييرات، Asset 360" },
        { id:uid(), code:"GOV-WO-001", title:"سياسة أوامر العمل والاعتماد", type:"إجراء", scope:"أوامر العمل", ownerRole:"مشرف", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(180), controlObjective:"منع إغلاق أوامر العمل قبل اكتمال السلامة والعمليات والساعات والمواد.", evidenceRequired:"سجل التنفيذ، مراجعة المشرف" },
        { id:uid(), code:"GOV-INV-001", title:"سياسة صرف وتسوية المخزون", type:"ضابط رقابي", scope:"المخزون", ownerRole:"مخزن", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(90), controlObjective:"ربط الصرف بأمر عمل وتقليل التسويات غير المبررة.", evidenceRequired:"حركات المخزون وأمر العمل" },
        { id:uid(), code:"GOV-DATA-001", title:"سياسة جودة بيانات الأصول", type:"تعليمات تشغيل", scope:"بيانات الأصول", ownerRole:"مدير", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(90), controlObjective:"استكمال الموقع ونوع الموقع والرقم التسلسلي/الصنف للأصول المطلوبة.", evidenceRequired:"تقرير جودة الأصول" },
        { id:uid(), code:"GOV-SEC-001", title:"سياسة التحكم بالصلاحيات", type:"سياسة", scope:"الأدوار والمستخدمون", ownerRole:"مدير", status:"سارية", version:"1.0", effectiveDate:todayDate, reviewDate:plusDays(90), controlObjective:"تطبيق أقل صلاحية وفصل المسؤوليات بين التنفيذ والاعتماد والمخزون.", evidenceRequired:"مراجعة صلاحيات شهرية" },
      ],
      approvalMatrix: (db.approvalMatrix || []).length ? db.approvalMatrix : [
        { id:uid(), process:"أمر عمل", action:"إصدار", requesterRole:"مشرف", approverRole:"مشرف", minPriority:"عادي", amountLimit:"", requiresSecondApproval:false, active:true, notes:"إصدار أوامر العمل المخططة." },
        { id:uid(), process:"أمر عمل", action:"إغلاق", requesterRole:"فني", approverRole:"مشرف", minPriority:"عادي", amountLimit:"", requiresSecondApproval:false, active:true, notes:"لا إغلاق نهائي بدون مراجعة المشرف." },
        { id:uid(), process:"مخزون", action:"تسوية", requesterRole:"مخزن", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:true, active:true, notes:"التسويات تحتاج سبب واعتماد إداري." },
        { id:uid(), process:"أصل", action:"حذف", requesterRole:"مشرف", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:true, active:true, notes:"يفضل التعطيل بدل الحذف عند وجود تاريخ." },
        { id:uid(), process:"صلاحيات", action:"تغيير صلاحية", requesterRole:"مدير", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:false, active:true, notes:"مراجعة صلاحيات شهرية." },
        { id:uid(), process:"بيانات", action:"استيراد", requesterRole:"مدير", approverRole:"مدير", minPriority:"", amountLimit:"", requiresSecondApproval:true, active:true, notes:"استيراد البيانات أو مسحها يحتاج اعتمادًا وتوثيقًا." },
      ],
      governanceDataQualityRules: (db.governanceDataQualityRules || []).length ? db.governanceDataQualityRules : [
        { id:uid(), code:"DQ-ORG-001", title:"المنظمة التشغيلية مكتملة", entity:"maintenanceOrganizations", severity:"عال", ownerRole:"مدير", active:true, description:"Organization + Work Area + Work Center قبل التشغيل." },
        { id:uid(), code:"DQ-AST-001", title:"رقم الأصل فريد وموجود", entity:"assets", severity:"حرج", ownerRole:"مشرف", active:true, description:"لا يسمح بتكرار Asset Number أو تركه فارغًا." },
        { id:uid(), code:"DQ-AST-002", title:"موقع الأصل واضح", entity:"assets", severity:"متوسط", ownerRole:"مشرف", active:true, description:"الأصل التشغيلي يحتاج Location Type وموقع أو UNKNOWN مبرر." },
        { id:uid(), code:"DQ-WO-001", title:"بوابات إغلاق أمر العمل", entity:"workOrders", severity:"عال", ownerRole:"مشرف", active:true, description:"سلامة، عمليات، ساعات، مواد، قراءات، وفشل عند التصحيحي/الطارئ." },
        { id:uid(), code:"DQ-INV-001", title:"حركات المخزون بكمية صحيحة", entity:"stockTx", severity:"متوسط", ownerRole:"مخزن", active:true, description:"كل حركة مخزون يجب أن تكون بكمية موجبة وسبب واضح." },
      ],
      governanceRisks: (db.governanceRisks || []).length ? db.governanceRisks : [
        { id:uid(), area:"الصلاحيات", risk:"تغيير الدور من الواجهة لا يمثل تحكمًا أمنيًا حقيقيًا بدون تسجيل دخول Backend.", level:"حرج", owner:"مدير", mitigation:"إضافة Auth حقيقي وصلاحيات من الخادم.", status:"مفتوح", dueDate:plusDays(30) },
        { id:uid(), area:"البيانات", risk:"حفظ كل البيانات كـ JSON واحد مناسب مؤقتًا لكنه يصعب التدقيق والتحكم طويلًا.", level:"عال", owner:"مدير", mitigation:"تحويل الكيانات الأساسية إلى جداول PostgreSQL مستقلة.", status:"مفتوح", dueDate:plusDays(60) },
        { id:uid(), area:"المرفقات", risk:"تخزين الصور Base64 داخل البيانات يرفع الحجم ويصعب النسخ الاحتياطي.", level:"متوسط", owner:"مدير", mitigation:"نقل الصور إلى Storage وحفظ الروابط فقط.", status:"مفتوح", dueDate:plusDays(60) },
      ],
      governanceReviews: (db.governanceReviews || []).length ? db.governanceReviews : [
        { id:uid(), name:"مراجعة صلاحيات المستخدمين", frequency:"شهري", owner:"مدير", lastReview:"", nextReview:plusDays(30), status:"مفتوح", notes:"تأكد من أدوار المدير/المشرف/المخزن/الفني." },
        { id:uid(), name:"مراجعة جودة بيانات الأصول", frequency:"ربع سنوي", owner:"مشرف", lastReview:"", nextReview:plusDays(90), status:"مفتوح", notes:"الأصول بدون موقع أو نوع موقع أو رقم تسلسلي." },
        { id:uid(), name:"مراجعة التسويات وحركات المخزون", frequency:"شهري", owner:"مخزن", lastReview:"", nextReview:plusDays(30), status:"مفتوح", notes:"راجع التسويات والإتلاف والصرف بدون أمر عمل." },
        { id:uid(), name:"مراجعة المخاطر المفتوحة", frequency:"شهري", owner:"مدير", lastReview:"", nextReview:plusDays(30), status:"مفتوح", notes:"أغلق أو حدّث المخاطر المفتوحة." },
      ],
      governanceApprovalRequests: (db.governanceApprovalRequests || []).length ? db.governanceApprovalRequests : [
        { id:uid(), number:"APR-1001", title:"اعتماد تحويل الحوكمة للإنتاج", area:"Backend", requesterRole:"مدير", approverRole:"مدير", status:"مفتوح", riskLevel:"عال", requestedAt:now(), justification:"تأكيد جاهزية الصلاحيات والنسخ الاحتياطي قبل التشغيل." },
      ],
      governanceAuditEvents: [...(db.governanceAuditEvents || []), { id:uid(), at:now(), by:role, area:"الحوكمة", action:"إنشاء حزمة حوكمة افتراضية متقدمة" }]
    });
  };
  const tabs = [["dashboard","الملخص"],["policies","السياسات"],["approvals","المصفوفة"],["requests","طلبات الاعتماد"],["quality","جودة البيانات"],["risks","المخاطر"],["changes","التغييرات"],["reviews","المراجعات"],["audit","التدقيق"]];
  return (
    <>
      <div style={{ display:"flex", gap:8, overflowX:"auto", paddingBottom:8, marginBottom:12 }}>
        {tabs.map(([id, label]) => <Chip key={id} active={sub === id} onClick={() => setSub(id)}>{label}</Chip>)}
      </div>
      {sub === "dashboard" && (
        <>
          <div style={{ display:"flex", gap:8, marginBottom:16 }}>
            <Stat n={score + "%"} label="نضج الحوكمة" color={scoreColor} />
            <Stat n={highRisks} label="مخاطر عالية" color={highRisks ? C.red : C.green} />
            <Stat n={overdueReviews + overduePolicies} label="متأخر" color={(overdueReviews + overduePolicies) ? C.red : C.green} />
            <Stat n={auditCount} label="أحداث تدقيق" color={C.blue} small />
          </div>
          <Section title="تقييمي للحالة الحالية">
            <div style={{ ...card(), borderRightColor: scoreColor, fontSize:13, lineHeight:1.8 }}>
              الحوكمة الموجودة جيدة جدًا كنموذج MVP، لكنها لا تصل إلى ممتازة إنتاجيًا إلا بعد تفعيل Backend خارجي، مصادقة حقيقية، وربط الاعتمادات بالإجراءات الحساسة من الخادم. أضفت هنا طبقة أقوى: طلبات اعتماد، قواعد جودة بيانات، فحص آلي، ومراجعات دورية بجانب السياسات والمخاطر.
            </div>
          </Section>
          <Section title="حالة الحوكمة">
            {checks.map(([name, ok, hint]) => <div key={name} style={{ ...card(), borderRightColor: ok ? C.green : C.amber }}>
              <Row main={name} sub={ok ? "مكتمل / جيد" : hint} badge={{ text: ok ? "✓" : "تحسين", color: ok ? C.green : C.amber }} />
            </div>)}
            {ctx.canUseSetupTools && <Btn bg={C.orange} style={{ width:"100%", padding:12 }} onClick={seed}>+ إنشاء/تحديث حوكمة افتراضية متقدمة</Btn>}
          </Section>
          <Section title="مصفوفة صلاحيات مختصرة">
            {[
              ["مدير", "إعدادات، حوكمة، حذف، اعتماد عالي، نسخ واستيراد"],
              ["مشرف", "أوامر العمل، مراجعة، أصول، برامج، جودة بيانات"],
              ["فني", "تنفيذ الأعمال، ساعات، قراءات، صور، إكمال عمليات"],
              ["مخزن", "استلام، صرف، إرجاع، تجهيز مواد، مخزون"],
              ["طالب خدمة", "رفع طلبات عمل ومتابعتها فقط"],
            ].map(([r, desc]) => <div key={r} style={card()}><Row main={r} sub={desc} /></div>)}
          </Section>
        </>
      )}
      {sub === "policies" && <Crud ctx={ctx} entity="governancePolicies" title="سياسات الحوكمة" schema={[
        { k:"code", label:"الكود" }, { k:"title", label:"العنوان" },
        { k:"type", label:"النوع", type:"select", options:GOV_POLICY_TYPES },
        { k:"scope", label:"النطاق" }, { k:"ownerRole", label:"المالك", type:"select", options:[...ROLES, "السلامة", "المدقق"] },
        { k:"status", label:"الحالة", type:"select", options:GOV_POLICY_STATUS }, { k:"version", label:"الإصدار" },
        { k:"effectiveDate", label:"تاريخ السريان", type:"date" }, { k:"reviewDate", label:"تاريخ المراجعة", type:"date" },
        { k:"controlObjective", label:"هدف الضابط", type:"textarea" }, { k:"evidenceRequired", label:"الدليل المطلوب", type:"textarea" },
      ]} validate={(d, form) => !String(d.code||"").trim() ? "الكود مطلوب" : db.governancePolicies.some((x) => x.code === d.code && x.id !== form?.id) ? "كود السياسة مستخدم" : null}
      render={(p) => [p.code + " — " + p.title, [p.type, p.ownerRole, p.status, p.reviewDate ? "مراجعة: " + fmt(p.reviewDate) : ""].filter(Boolean).join(" · ")]} badge={(p) => ({ text:p.status || "—", color:p.status === "سارية" ? C.green : p.status === "مؤرشفة" ? C.steel : C.amber })} />}
      {sub === "approvals" && <Crud ctx={ctx} entity="approvalMatrix" title="مصفوفة الاعتماد" schema={[
        { k:"process", label:"العملية", type:"select", options:GOV_PROCESSES }, { k:"action", label:"الإجراء", type:"select", options:GOV_ACTIONS },
        { k:"requesterRole", label:"الدور الطالب", type:"select", options:ROLES }, { k:"approverRole", label:"الدور المعتمد", type:"select", options:ROLES },
        { k:"minPriority", label:"أدنى أولوية" }, { k:"amountLimit", label:"حد مبلغ/تكلفة" },
        { k:"requiresSecondApproval", label:"يتطلب اعتمادًا ثانيًا", type:"check" }, { k:"active", label:"نشط", type:"check" },
        { k:"notes", label:"ملاحظات", type:"textarea" },
      ]} validate={(d) => !d.process || !d.action || !d.approverRole ? "العملية والإجراء والمعتمد مطلوبة" : null}
      render={(a) => [a.process + " — " + a.action, ["الطالب: " + (a.requesterRole || "—"), "المعتمد: " + (a.approverRole || "—"), a.requiresSecondApproval ? "اعتماد ثانٍ" : ""].filter(Boolean).join(" · ")]} badge={(a) => ({ text:a.active ? "نشط" : "معطل", color:a.active ? C.green : C.steel })} />}
      {sub === "requests" && (
        <>
          <Crud ctx={ctx} entity="governanceApprovalRequests" title="طلبات الاعتماد" schema={[
            { k:"number", label:"رقم الطلب" }, { k:"title", label:"العنوان" },
            { k:"area", label:"المجال", type:"select", options:GOV_PROCESSES },
            { k:"requesterRole", label:"الطالب", type:"select", options:ROLES }, { k:"approverRole", label:"المعتمد", type:"select", options:ROLES },
            { k:"status", label:"الحالة", type:"select", options:GOV_REQUEST_STATUS }, { k:"riskLevel", label:"المخاطر", type:"select", options:GOV_RISK_LEVELS },
            { k:"requestedAt", label:"تاريخ الطلب" }, { k:"justification", label:"المبرر", type:"textarea" },
            { k:"decisionBy", label:"قرار بواسطة" }, { k:"decisionAt", label:"وقت القرار" },
          ]} validate={(d, form) => !String(d.number||"").trim() ? "رقم الطلب مطلوب" : db.governanceApprovalRequests.some((x) => x.number === d.number && x.id !== form?.id) ? "رقم الطلب مستخدم" : null}
          render={(r) => [r.number + " — " + r.title, [r.area, "طالب: " + (r.requesterRole || "—"), "معتمد: " + (r.approverRole || "—"), r.justification].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.status || "مفتوح", color:r.status === "معتمد" || r.status === "منفذ" ? C.green : r.status === "مرفوض" ? C.red : C.amber })} />
          <Section title="قرارات سريعة">
            {(db.governanceApprovalRequests || []).filter((r) => r.status === "مفتوح").map((r) => <div key={r.id} style={card()}><Row main={r.number + " — " + r.title} sub={[r.area, r.riskLevel, r.justification].filter(Boolean).join(" · ")} /><div style={{ display:"flex", gap:8, marginTop:8 }}><Btn bg={C.green} onClick={() => decideRequest(r, "معتمد")}>اعتماد</Btn><Btn bg={C.red} onClick={() => decideRequest(r, "مرفوض")}>رفض</Btn></div></div>)}
            {openApprovalRequests.length === 0 && <Empty text="لا توجد طلبات اعتماد مفتوحة." />}
          </Section>
        </>
      )}
      {sub === "quality" && (
        <>
          <Section title="قواعد جودة البيانات">
            <Crud ctx={ctx} entity="governanceDataQualityRules" title="قواعد جودة البيانات" schema={[
              { k:"code", label:"الكود" }, { k:"title", label:"اسم القاعدة" }, { k:"entity", label:"الكيان" },
              { k:"severity", label:"الخطورة", type:"select", options:GOV_DATA_SEVERITY }, { k:"ownerRole", label:"المالك", type:"select", options:ROLES },
              { k:"active", label:"نشطة", type:"check" }, { k:"description", label:"الوصف", type:"textarea" },
            ]} render={(r) => [r.code + " — " + r.title, [r.entity, r.ownerRole, r.description].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.active ? r.severity : "معطلة", color:r.active ? (["عال", "حرج"].includes(r.severity) ? C.red : r.severity === "متوسط" ? C.amber : C.green) : C.steel })} />
          </Section>
          <Section title={"فحص آلي حالي — " + qualityFindings.length + " ملاحظة"}>
            {qualityFindings.map((q, i) => <div key={i} style={{ ...card(), borderRightColor:["عال", "حرج"].includes(q.severity) ? C.red : q.severity === "متوسط" ? C.amber : C.steel }}><Row main={q.issue} sub={[q.area, q.ref, "الإجراء: " + q.fix].filter(Boolean).join(" · ")} badge={{ text:q.severity, color:["عال", "حرج"].includes(q.severity) ? C.red : q.severity === "متوسط" ? C.amber : C.steel }} /></div>)}
            {qualityFindings.length === 0 && <Empty text="لا توجد ملاحظات جودة بيانات ضمن الفحص الأساسي." />}
          </Section>
        </>
      )}
      {sub === "risks" && <Crud ctx={ctx} entity="governanceRisks" title="سجل مخاطر الحوكمة" schema={[
        { k:"area", label:"المجال" }, { k:"risk", label:"وصف الخطر", type:"textarea" },
        { k:"level", label:"المستوى", type:"select", options:GOV_RISK_LEVELS }, { k:"owner", label:"المالك", type:"select", options:[...ROLES, "السلامة", "المدقق"] },
        { k:"mitigation", label:"خطة المعالجة", type:"textarea" }, { k:"status", label:"الحالة", type:"select", options:GOV_RISK_STATUS },
        { k:"dueDate", label:"تاريخ مستهدف", type:"date" },
      ]} validate={(d) => !d.area || !d.risk ? "المجال ووصف الخطر مطلوبان" : null}
      render={(r) => [r.area + " — " + r.risk, [r.owner, r.status, r.dueDate ? "استحقاق: " + fmt(r.dueDate) : ""].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.level || "—", color:r.level === "حرج" ? C.red : r.level === "عال" ? C.amber : r.level === "متوسط" ? C.blue : C.green })} />}
      {sub === "changes" && <Crud ctx={ctx} entity="governanceChangeRequests" title="طلبات التغيير" schema={[
        { k:"number", label:"رقم الطلب" }, { k:"title", label:"العنوان" },
        { k:"area", label:"المجال", type:"select", options:GOV_PROCESSES }, { k:"requestedBy", label:"الطالب", type:"select", options:ROLES },
        { k:"status", label:"الحالة", type:"select", options:GOV_CHANGE_STATUS }, { k:"riskLevel", label:"مستوى الخطر", type:"select", options:GOV_RISK_LEVELS },
        { k:"impact", label:"الأثر", type:"textarea" }, { k:"approver", label:"المعتمد", type:"select", options:ROLES },
        { k:"plannedDate", label:"تاريخ التنفيذ المخطط", type:"date" }, { k:"notes", label:"ملاحظات", type:"textarea" },
      ]} validate={(d, form) => !String(d.number||"").trim() ? "رقم الطلب مطلوب" : db.governanceChangeRequests.some((x) => x.number === d.number && x.id !== form?.id) ? "رقم الطلب مستخدم" : null}
      render={(c) => [c.number + " — " + c.title, [c.area, c.requestedBy, c.approver ? "اعتماد: " + c.approver : "", c.plannedDate ? fmt(c.plannedDate) : ""].filter(Boolean).join(" · ")]} badge={(c) => ({ text:c.status || "—", color:c.status === "معتمد" || c.status === "منفذ" || c.status === "مغلق" ? C.green : c.status === "مرفوض" ? C.red : C.amber })} />}
      {sub === "reviews" && <Crud ctx={ctx} entity="governanceReviews" title="المراجعات الدورية" schema={[
        { k:"name", label:"اسم المراجعة" }, { k:"frequency", label:"التكرار", type:"select", options:GOV_REVIEW_FREQ },
        { k:"owner", label:"المالك", type:"select", options:[...ROLES, "السلامة", "المدقق"] }, { k:"lastReview", label:"آخر مراجعة", type:"date" },
        { k:"nextReview", label:"المراجعة القادمة", type:"date" }, { k:"status", label:"الحالة", type:"select", options:["مفتوح", "مكتمل", "متأخر", "مغلق"] },
        { k:"notes", label:"ملاحظات", type:"textarea" },
      ]} validate={(d) => !d.name ? "اسم المراجعة مطلوب" : null}
      render={(r) => [r.name, [r.frequency, r.owner, r.nextReview ? "القادمة: " + fmt(r.nextReview) : ""].filter(Boolean).join(" · ")]} badge={(r) => ({ text:r.nextReview && daysUntil(r.nextReview) < 0 && r.status !== "مغلق" ? "متأخر" : (r.status || "—"), color:r.nextReview && daysUntil(r.nextReview) < 0 && r.status !== "مغلق" ? C.red : r.status === "مكتمل" || r.status === "مغلق" ? C.green : C.amber })} />}
      {sub === "audit" && (
        <Section title="سجل تدقيق الحوكمة">
          {can.manage && <div style={card()}>
            <Btn bg={C.blue} style={{ width:"100%", padding:12 }} onClick={() => addAudit("مراجعة يدوية للحكومة والضوابط")}>+ تسجيل مراجعة يدوية الآن</Btn>
          </div>}
          {(db.governanceAuditEvents || []).slice().reverse().map((e) => <div key={e.id} style={card()}><Row main={e.action} sub={[e.area, e.by, e.at].filter(Boolean).join(" · ")} /></div>)}
          {(db.governanceAuditEvents || []).length === 0 && <Empty text="لا توجد أحداث حوكمة بعد. استخدم زر إنشاء الحوكمة الافتراضية أو سجل مراجعة يدوية." />}
          <div style={{ ...card(), fontSize:13, color:C.steel }}>ملاحظة: أوامر العمل والأصول لديها سجلات تنفيذ وتغييرات منفصلة. هذه الشاشة تضيف طبقة تدقيق إدارية عامة.</div>
        </Section>
      )}
    </>
  );
}



/* ───────────────────────── حوكمة CMMS 100% ───────────────────────── */
export function Governance100Hub({ ctx }) {
  const { db, save, can, role, firebaseEnabled, firebaseProfile, nameOf } = ctx;
  const [sub, setSub] = useState("dashboard");
  const [filter, setFilter] = useState("الكل");
  const tabs = [["dashboard","النضج"],["controls","الضوابط"],["tests","اختبار الضوابط"],["approvals","الاعتمادات"],["sod","SoD"],["raci","RACI"],["kpi","KPI/SLA"],["exceptions","الاستثناءات"],["capa","CAPA"],["readiness","الجاهزية"],["evidence","الأدلة"]];

  const roleLabel = role || "—";
  const openWos = (db.workOrders || []).filter((w)=>ACTIVE_STATES.includes(w.status));
  const closedWos = (db.workOrders || []).filter((w)=>w.status === "مغلق");
  const activePolicies = (db.governancePolicies || []).filter((p)=>p.status !== "ملغاة" && p.active !== false);
  const latestTests = (db.governanceControlTests || []).slice().reverse();
  const pass = latestTests.filter((t)=>t.result === "Pass" || t.result === "نجح" || t.result === "ناجح").length;
  const warn = latestTests.filter((t)=>t.result === "Warning" || t.result === "تحذير").length;
  const fail = latestTests.filter((t)=>t.result === "Fail" || t.result === "فشل").length;
  const testScore = latestTests.length ? Math.max(0, Math.round(((pass + warn * 0.5) / latestTests.length) * 100)) : 0;
  const foundationScore = Math.min(100, Math.round(
    (firebaseEnabled ? 15 : 0) +
    Math.min(15, (db.governanceControlLibrary || []).length * 0.75) +
    Math.min(10, (db.governanceSoDRules || []).length * 1.25) +
    Math.min(10, (db.governanceRaciMatrix || []).length * 0.8) +
    Math.min(10, (db.governanceKpiDefinitions || []).length) +
    ((db.governanceBackupPolicies || []).length ? 10 : 0) +
    ((db.governanceRetentionRules || []).length ? 5 : 0) +
    ((db.governanceAccessCertifications || []).length ? 5 : 0) +
    ((db.governanceReadinessChecklist || []).length ? 5 : 0) +
    ((db.governanceAuditEvents || []).length ? 5 : 0) +
    ((db.governanceReleaseGates || []).length ? 5 : 0) +
    (testScore ? 5 : 0)
  ));
  const maturity = Math.round((foundationScore * 0.45) + (testScore * 0.55));
  const maturityColor = maturity >= 90 ? C.green : maturity >= 70 ? C.amber : C.red;
  const readinessDone = (db.governanceReadinessChecklist || []).filter((x)=>x.status === "مكتمل" || x.status === "موافق").length;
  const readinessPct = (db.governanceReadinessChecklist || []).length ? Math.round(readinessDone / (db.governanceReadinessChecklist || []).length * 100) : 0;

  const addAudit = (action, area="حوكمة 100%", extra={}) => ({ id:uid(), at:now(), by:roleLabel, area, action, ...extra });
  const upsertMany = (rows, newRows, key="code") => {
    const existing = new Map((rows || []).map((r)=>[r[key], r]));
    const out = [...(rows || [])];
    newRows.forEach((nr)=>{ if (!existing.has(nr[key])) out.push(nr); });
    return out;
  };
  const defaultControls = () => ([
    ["CTRL-001","Firebase Auth مفعل ومستخدم","Access & RBAC","مسؤول النظام","مستمر","تلقائي","حرج","دليل تسجيل دخول وحالة Firestore"],
    ["CTRL-002","الأدوار مفروضة من Backend وليس من واجهة فقط","Access & RBAC","مسؤول النظام","شهري","شبه آلي","حرج","Firestore Rules + User Profiles"],
    ["CTRL-003","لا أمر عمل بدون أصل","Work Control","مشرف","يومي","تلقائي","حرج","فحص أوامر العمل"],
    ["CTRL-004","لا إصدار أمر عمل قبل فحص المواد","Inventory Control","مخزن","يومي","شبه آلي","عال","Material Availability Check"],
    ["CTRL-005","لا تنفيذ بدون قائمة سلامة عند الحاجة","Safety & Execution","مشرف","يومي","تلقائي","حرج","Safety Checklist Answers"],
    ["CTRL-006","لا إكمال فني قبل العمليات والمواد والعمالة","Safety & Execution","مشرف","يومي","تلقائي","حرج","Completion Gaps"],
    ["CTRL-007","لا إغلاق نهائي بدون موافقة مشرف","Approvals","مشرف","يومي","تلقائي","حرج","Supervisor Review"],
    ["CTRL-008","لا تكلفة مواد بدون حركة مخزون/استخدام","Financial Control","مخزن","أسبوعي","تلقائي","عال","Stock/Material Usage"],
    ["CTRL-009","لا تكلفة عمالة بدون Labor Transaction","Financial Control","مشرف","أسبوعي","تلقائي","عال","Labor Transactions"],
    ["CTRL-010","كل تغيير حالة له سجل تدقيق","Audit & Evidence","مسؤول النظام","يومي","تلقائي","حرج","Status History"],
    ["CTRL-011","الفني يرى وينفذ أعماله المسندة فقط","Segregation of Duties","مشرف","شهري","شبه آلي","حرج","Assignments + Rules"],
    ["CTRL-012","طالب الخدمة لا يحوّل أو يوافق على الطلبات","Segregation of Duties","مسؤول النظام","شهري","يدوي","عال","Role Matrix"],
    ["CTRL-013","المخزن يصرف ويرجع المواد ولا يغلق أوامر العمل","Segregation of Duties","مدير الصيانة","شهري","يدوي","عال","SoD Matrix"],
    ["CTRL-014","الصيانة الوقائية لها برنامج أو تعريف عمل","Forecast & Scheduling","مخطط الصيانة","أسبوعي","تلقائي","عال","PM Program/Work Definition"],
    ["CTRL-015","التوقعات مفحوصة قبل توليد أوامر PM","Forecast & Scheduling","مخطط الصيانة","أسبوعي","تلقائي","متوسط","Forecast Validation"],
    ["CTRL-016","الأصول الحرجة لها برنامج صيانة أو خطة فحص","Data Quality","مهندس موثوقية","شهري","شبه آلي","عال","Critical Assets Review"],
    ["CTRL-017","لا أرقام أصول مكررة أو فارغة","Data Quality","مالك بيانات الأصول","يومي","تلقائي","عال","Asset Registry Quality"],
    ["CTRL-018","التقارير المهمة لها مالك وجدولة","Reporting","مدير الصيانة","شهري","يدوي","متوسط","Report Schedules"],
    ["CTRL-019","نسخ احتياطي وخطة استعادة موثقة","Backup & Continuity","مسؤول النظام","شهري","يدوي","حرج","Backup Policy"],
    ["CTRL-020","سياسة احتفاظ وسجل قانوني للبيانات الحساسة","Retention","مسؤول النظام","سنوي","يدوي","عال","Retention Rules"],
    ["CTRL-021","مراجعة صلاحيات دورية","Access & RBAC","مسؤول النظام","شهري","يدوي","حرج","Access Certification"],
    ["CTRL-022","طلبات تغيير مؤثرة لها تقييم أثر واعتماد","Change Control","مدير الصيانة","عند الحاجة","يدوي","عال","Change Impact Assessment"],
    ["CTRL-023","كل فشل متكرر له CAPA أو RCA","Work Control","مهندس موثوقية","شهري","شبه آلي","عال","Failure Analysis/CAPA"],
    ["CTRL-024","قبل/بعد الصور إلزامية لأنواع العمل المحددة","Audit & Evidence","مشرف","يومي","تلقائي","متوسط","Photo Evidence"],
    ["CTRL-025","Go-Live Gate لا يغلق إلا بعد تحقق الضوابط الأساسية","Approvals","مدير","عند الإصدار","يدوي","حرج","Release Gate"],
  ]).map(([code,name,domain,ownerRole,frequency,automation,criticality,evidence])=>({ id:uid(), code, name, domain, ownerRole, frequency, automation, criticality, evidenceRequired:evidence, status:"نشط", lastTestedAt:"", lastResult:"لم يفحص" }));
  const seedGovernance100 = () => {
    if (!can?.admin && !can?.manage) return alert("هذه العملية للمدير أو المشرف فقط.");
    const controls = defaultControls();
    const sod = [
      ["SOD-001","منشئ أمر العمل لا يعتمد إغلاقه", "Create_WorkOrders", "Approve_WorkOrder_Completion", "حرج"],
      ["SOD-002","الفني لا يغلق أمر العمل نهائيًا", "Execute_WorkOrders", "Close_WorkOrders", "حرج"],
      ["SOD-003","طالب الخدمة لا يحوّل طلبه إلى أمر عمل", "Create_WorkRequests", "Convert_WorkRequest_To_WorkOrder", "عال"],
      ["SOD-004","المخزن لا يقرّر استخدام المواد الفعلي بدل الفني", "Material_Issue", "Record_Material_Usage", "عال"],
      ["SOD-005","من يعدّل أسعار المواد لا يعتمد التكلفة", "Manage_Items_Cost", "Approve_WorkOrder_Cost", "عال"],
      ["SOD-006","مراجع جودة البيانات لا يحذف السجلات محل الفحص", "Data_Quality_Review", "Delete_Master_Data", "متوسط"],
      ["SOD-007","من يغيّر الصلاحيات لا يعتمد مراجعته الخاصة", "Manage_Users", "Approve_Access_Review", "حرج"],
      ["SOD-008","من يرفع استثناء لا يوافق عليه", "Create_Exception", "Approve_Exception", "عال"],
    ].map(([code,name,permissionA,permissionB,risk])=>({ id:uid(), code, name, permissionA, permissionB, risk, status:"نشط", mitigation:"يتطلب اعتماد دور مستقل أو مدير أعلى" }));
    const raci = [
      ["إنشاء طلب عمل","طالب خدمة","مشرف","فني,مخزن","مدير"], ["تحويل طلب إلى أمر عمل","مشرف","مدير الصيانة","طالب خدمة,فني","مدير المصنع"],
      ["تخطيط أمر العمل","مشرف","مدير الصيانة","مخزن,فني","مدير المصنع"], ["إصدار أمر العمل","مشرف","مدير الصيانة","مخزن","مدير المصنع"],
      ["صرف المواد","مخزن","رئيس المخزن","فني,مشرف","مدير الصيانة"], ["تنفيذ العمل","فني","مشرف","مخزن","مدير الصيانة"],
      ["تسجيل العطل","فني","مشرف","مهندس موثوقية","مدير الصيانة"], ["اعتماد الإكمال","مشرف","مدير الصيانة","فني","مدير المصنع"],
      ["إغلاق أمر العمل","مدير الصيانة","مدير المصنع","مشرف","المالية/الإدارة"], ["تعديل الأصول","مالك بيانات الأصول","مدير الصيانة","مشرف","مدير المصنع"],
      ["مراجعة الصلاحيات","مسؤول النظام","مدير النظام","المديرون","الإدارة"], ["اعتماد الاستثناءات","مدير الصيانة","مدير المصنع","مسؤول النظام","الإدارة"],
    ].map(([process,responsible,accountable,consulted,informed])=>({ id:uid(), process, responsible, accountable, consulted, informed, status:"معتمد" }));
    const kpis = [
      ["KPI-001","PM Compliance","نسبة أوامر PM المغلقة في موعدها","%",">=90","شهري","مدير الصيانة"],
      ["KPI-002","Backlog by Criticality","الأوامر المفتوحة حسب الحرجية","WO","مراقبة","أسبوعي","مشرف"],
      ["KPI-003","Schedule Compliance","الالتزام بجدول اليوم","%",">=85","أسبوعي","مشرف"],
      ["KPI-004","MTTR","متوسط زمن الإصلاح","ساعة","تحسن مستمر","شهري","مهندس موثوقية"],
      ["KPI-005","MTBF","متوسط الزمن بين الأعطال","ساعة","تحسن مستمر","شهري","مهندس موثوقية"],
      ["KPI-006","Material Return Rate","نسبة المواد المصروفة غير المستخدمة","%","<=10","شهري","رئيس المخزن"],
      ["KPI-007","Data Quality Score","اكتمال بيانات الأصول وأوامر العمل","%",">=95","أسبوعي","مالك البيانات"],
      ["KPI-008","Supervisor Review Aging","عمر أوامر بانتظار المراجعة","يوم","<=2","يومي","مشرف"],
      ["KPI-009","Emergency Ratio","نسبة الأعمال الطارئة","%","اتجاه هابط","شهري","مدير الصيانة"],
      ["KPI-010","Governance Control Pass Rate","نسبة ضوابط الحوكمة الناجحة","%",">=95","شهري","مسؤول النظام"],
    ].map(([code,name,definition,uom,target,frequency,ownerRole])=>({ id:uid(), code, name, definition, uom, target, frequency, ownerRole, active:true }));
    const sla = [
      ["SLA-EMG","طارئ/حرج","15 دقيقة","4 ساعات","مدير الصيانة"], ["SLA-HIGH","عالية","2 ساعة","24 ساعة","مشرف"],
      ["SLA-NORMAL","عادية","1 يوم","5 أيام","مشرف"], ["SLA-LOW","منخفضة","3 أيام","15 يوم","مشرف"],
    ].map(([code,priority,responseTime,resolutionTarget,ownerRole])=>({ id:uid(), code, priority, responseTime, resolutionTarget, ownerRole, escalation:"تنبيه ثم تصعيد للمدير" }));
    const dataOwners = [
      ["الأصول","مالك بيانات الأصول","مشرف","رقم الأصل، الموقع، الحالة، الحرجية"], ["أوامر العمل","مشرف الصيانة","مدير الصيانة","الحالة، الفني، العمليات، الإغلاق"],
      ["المخزون","رئيس المخزن","مدير الصيانة","الأرصدة، الصرف، الإرجاع، التكلفة"], ["العدادات","مهندس موثوقية","مشرف","القراءات، المعايرة، تعطيل القراءة"],
      ["الضمانات","منسق الضمان","مدير الصيانة","العقود، المطالبات، الاستحقاقات"], ["الصلاحيات","مسؤول النظام","مدير المصنع","الأدوار، المراجعات، الإقرارات"],
    ].map(([domain,ownerRole,stewardRole,keyFields])=>({ id:uid(), domain, ownerRole, stewardRole, keyFields, reviewFrequency:"شهري" }));
    const authority = [
      ["AUTH-001","إغلاق أمر عمل عادي","0","مشرف","لا"], ["AUTH-002","إغلاق أمر عمل حرج أو طارئ","0","مدير الصيانة","نعم"],
      ["AUTH-003","تسوية مخزون","500","رئيس المخزن","نعم"], ["AUTH-004","مطالبة ضمان","0","مدير الصيانة","نعم"],
      ["AUTH-005","حذف أصل","0","مسؤول النظام","نعم"], ["AUTH-006","تغيير صلاحيات","0","مسؤول النظام","نعم"],
    ].map(([code,action,amountLimit,approverRole,eSignatureRequired])=>({ id:uid(), code, action, amountLimit, approverRole, eSignatureRequired, status:"نشط" }));
    const backup = [
      { id:uid(), code:"BKP-001", name:"تصدير يومي للبيانات الحرجة", scope:"Firestore + إعدادات Firebase + قواعد Firestore", frequency:"يومي", ownerRole:"مسؤول النظام", retention:"30 يوم", restoreTestFrequency:"شهري", status:"نشط" },
      { id:uid(), code:"BKP-002", name:"نسخة قبل أي تحديث APK أو قواعد", scope:"ZIP + APK + rules", frequency:"عند التغيير", ownerRole:"مسؤول النظام", retention:"12 شهر", restoreTestFrequency:"ربع سنوي", status:"نشط" },
    ];
    const retention = [
      ["RET-001","Work Orders / Execution History","7 سنوات","قفل بعد الإغلاق إلا باستثناء معتمد"], ["RET-002","Audit & Approvals","10 سنوات","غير قابل للحذف من المستخدمين"],
      ["RET-003","Photos & Attachments","3 سنوات","يحفظ الرابط والدليل لا الصورة الضخمة"], ["RET-004","Warranty Claims","10 سنوات","حسب سياسة المورد"],
      ["RET-005","User Access Reviews","5 سنوات","يدقق شهريًا"],
    ].map(([code,recordType,retentionPeriod,rule])=>({ id:uid(), code, recordType, retentionPeriod, rule, legalHold:false, status:"نشط" }));
    const readiness = [
      ["RDY-001","Firebase Auth مفعل والمستخدمون بأدوار صحيحة","مسؤول النظام","حرج"], ["RDY-002","Firestore Rules منشورة لأحدث نسخة","مسؤول النظام","حرج"],
      ["RDY-003","Backup/Restore مختبر","مسؤول النظام","حرج"], ["RDY-004","سجل الأصول مستورد ومراجع","مالك بيانات الأصول","عال"],
      ["RDY-005","الفنيون ومراكز العمل والموارد مكتملة","مشرف","عال"], ["RDY-006","برامج PM وتوقعاتها مفحوصة","مخطط الصيانة","عال"],
      ["RDY-007","المخزون والحدود الدنيا وحركات الصرف جاهزة","مخزن","عال"], ["RDY-008","التقارير الحرجة مجربة","مدير الصيانة","متوسط"],
      ["RDY-009","مراجعة صلاحيات أولية مكتملة","مسؤول النظام","حرج"], ["RDY-010","تدريب المستخدمين وتوثيق الإجراءات مكتمل","مدير الصيانة","متوسط"],
    ].map(([code,item,ownerRole,criticality])=>({ id:uid(), code, item, ownerRole, criticality, status:"غير مكتمل", evidence:"", dueDate:today() }));
    const gates = [
      ["GATE-001","Go-Live Technical Gate","Firebase + APK + Backup + Rules","مسؤول النظام"], ["GATE-002","Operations Gate","Assets + WO + PM + Supervision","مدير الصيانة"],
      ["GATE-003","Security Gate","Roles + SoD + Access Review","مسؤول النظام"], ["GATE-004","Data Gate","Asset/Inventory/Meter data quality","مالك البيانات"],
      ["GATE-005","Management Approval Gate","Final production approval","مدير المصنع"],
    ].map(([code,name,criteria,ownerRole])=>({ id:uid(), code, name, criteria, ownerRole, required:true, status:"مفتوح", approvedBy:"", approvedAt:"" }));
    save({
      ...db,
      governanceFrameworks: upsertMany(db.governanceFrameworks, [{ id:uid(), code:"GOV-FWK-100", name:"CMMS Governance Operating Model 100%", version:"1.0", ownerRole:"مدير", scope:"Maintenance, Assets, Inventory, Work Execution, Firebase, Reports", status:"نشط", approvedAt:now() }]),
      governanceControlLibrary: upsertMany(db.governanceControlLibrary, controls),
      governanceSoDRules: upsertMany(db.governanceSoDRules, sod),
      governanceRaciMatrix: upsertMany(db.governanceRaciMatrix, raci, "process"),
      governanceKpiDefinitions: upsertMany(db.governanceKpiDefinitions, kpis),
      governanceSlaRules: upsertMany(db.governanceSlaRules, sla),
      governanceDataOwners: upsertMany(db.governanceDataOwners, dataOwners, "domain"),
      governanceAuthorityLimits: upsertMany(db.governanceAuthorityLimits, authority),
      governanceBackupPolicies: upsertMany(db.governanceBackupPolicies, backup),
      governanceRetentionRules: upsertMany(db.governanceRetentionRules, retention),
      governanceReadinessChecklist: upsertMany(db.governanceReadinessChecklist, readiness),
      governanceReleaseGates: upsertMany(db.governanceReleaseGates, gates),
      governanceAccessCertifications: [...(db.governanceAccessCertifications||[]), { id:uid(), period:today().slice(0,7), ownerRole:"مسؤول النظام", status:"مفتوح", reviewedUsers:0, findings:0, dueDate:today(), notes:"مراجعة أولية لصلاحيات Firebase قبل التشغيل." }],
      governanceSecurityReviews: [...(db.governanceSecurityReviews||[]), { id:uid(), at:now(), reviewerRole:"مسؤول النظام", area:"Firestore Rules", status: firebaseEnabled ? "مقبول" : "إعداد مطلوب", findings: firebaseEnabled ? 0 : 1, notes: firebaseEnabled ? "Firebase مفعّل داخل التطبيق." : "يجب تفعيل Firebase قبل الإنتاج." }],
      governancePolicyAcknowledgements: [...(db.governancePolicyAcknowledgements||[]), { id:uid(), policy:"CMMS Governance Operating Model", role:roleLabel, userEmail:firebaseProfile?.email || "", acknowledgedAt:now(), status:"مقر" }],
      governanceAuditEvents: [...(db.governanceAuditEvents||[]), addAudit("إنشاء حوكمة CMMS 100% — ضوابط/RACI/SoD/KPI/Readiness")]
    });
  };
  const buildControlTests = () => {
    const assetNums = (db.assets||[]).map((a)=>String(a.number||"").trim()).filter(Boolean);
    const dupAssets = assetNums.filter((n,i)=>assetNums.indexOf(n)!==i);
    const woWithoutAsset = (db.workOrders||[]).filter((w)=>!w.assetId || !db.assets.some((a)=>a.id===w.assetId));
    const activeWithoutTech = openWos.filter((w)=>!(w.assigneeId || (w.operations||[]).some((o)=>o.assigneeId) || (db.workOrderAssignments||[]).some((a)=>a.workOrderId===w.id)));
    const closedWithoutReview = closedWos.filter((w)=>!(db.workOrderSupervisorReviews||[]).some((r)=>r.workOrderId===w.id && (r.decision==="Approve" || r.status==="معتمد" || r.decision==="اعتماد")) && !(db.workOrderApprovals||[]).some((a)=>a.workOrderId===w.id));
    const missingStatusHistory = (db.workOrders||[]).filter((w)=>w.status !== "مسودة" && !(db.workOrderStatusHistory||[]).some((h)=>h.workOrderId===w.id));
    const closedCorrectiveNoFailure = closedWos.filter((w)=>(w.type==="تصحيحي" || w.type==="طارئ") && !w.failure && !(db.workOrderFailures||[]).some((f)=>f.workOrderId===w.id) && !(db.workOrderFailureRecords||[]).some((f)=>f.workOrderId===w.id));
    const pmMissingProgram = (db.workOrders||[]).filter((w)=>w.type==="وقائي" && !w.programId && !w.workDefId);
    const criticalAssetsNoPm = (db.assets||[]).filter((a)=>a.critical && a.active !== false && !(db.programs||[]).some((p)=>p.assetId===a.id || (p.groupId && (db.assetGroups||[]).some((g)=>g.id===p.groupId && (g.assignments||[]).some((x)=>x.assetId===a.id && !x.end)))));
    const materialCostNoUsage = (db.workOrderCosts||[]).filter((c)=>Number(c.materialCost||c.material||0)>0 && !(db.workOrderMaterialUsage||[]).some((m)=>m.workOrderId===c.workOrderId) && !(db.stockTx||[]).some((t)=>t.workOrderId===c.workOrderId));
    const laborCostNoTx = (db.workOrderCosts||[]).filter((c)=>Number(c.laborCost||c.labor||0)>0 && !(db.workOrderLaborTransactions||[]).some((l)=>l.workOrderId===c.workOrderId) && !(db.laborCostTransactions||[]).some((l)=>l.workOrderId===c.workOrderId));
    const safetyWithoutChecklist = openWos.filter((w)=>w.safetyRequired && !(w.checklist||[]).length && !(db.workOrderSafetyChecklists||[]).some((c)=>c.workOrderId===w.id));
    const pendingReviewAging = (db.workOrders||[]).filter((w)=>w.status==="بانتظار المراجعة" && w.plannedEnd && daysUntil(w.plannedEnd)<-2);
    const reportOwnersMissing = (db.governanceKpiDefinitions||[]).filter((k)=>!k.ownerRole);
    const overdueCaps = (db.governanceCapaActions||[]).filter((c)=>c.dueDate && daysUntil(c.dueDate)<0 && c.status!=="مغلق" && c.status!=="مكتمل");
    const test = (controlCode, name, condition, issueCount, severity="متوسط", evidence="") => ({ id:uid(), runId:"RUN-"+Date.now(), controlCode, name, testedAt:now(), testedBy:roleLabel, result: condition ? "Pass" : (severity === "منخفض" ? "Warning" : "Fail"), issueCount:Number(issueCount||0), severity, status: condition ? "مغلق" : "مفتوح", evidence, recommendation: condition ? "لا إجراء" : "افتح CAPA أو أصلح البيانات ثم أعد الفحص" });
    return [
      test("CTRL-001", "Firebase Auth مفعل", !!firebaseEnabled, firebaseEnabled?0:1, "حرج", firebaseEnabled ? "firebaseEnabled=true" : "Firebase غير مفعل"),
      test("CTRL-002", "الدور الحالي من Firebase Profile", !firebaseEnabled || !!firebaseProfile?.role, (!firebaseEnabled || firebaseProfile?.role)?0:1, "حرج", roleLabel),
      test("CTRL-003", "لا أمر عمل بدون أصل", woWithoutAsset.length===0, woWithoutAsset.length, "حرج", woWithoutAsset.map((w)=>w.number).join(", ")),
      test("CTRL-004", "لا أمر نشط بدون فني/تعيين", activeWithoutTech.length===0, activeWithoutTech.length, "عال", activeWithoutTech.map((w)=>w.number).join(", ")),
      test("CTRL-005", "قوائم السلامة موجودة عند الحاجة", safetyWithoutChecklist.length===0, safetyWithoutChecklist.length, "حرج", safetyWithoutChecklist.map((w)=>w.number).join(", ")),
      test("CTRL-006", "الإغلاق النهائي له مراجعة مشرف", closedWithoutReview.length===0, closedWithoutReview.length, "حرج", closedWithoutReview.map((w)=>w.number).join(", ")),
      test("CTRL-007", "كل تغيير حالة له Audit", missingStatusHistory.length===0, missingStatusHistory.length, "حرج", missingStatusHistory.map((w)=>w.number).join(", ")),
      test("CTRL-008", "أوامر التصحيح/الطوارئ المغلقة لها Failure", closedCorrectiveNoFailure.length===0, closedCorrectiveNoFailure.length, "عال", closedCorrectiveNoFailure.map((w)=>w.number).join(", ")),
      test("CTRL-009", "PM WO مربوط ببرنامج أو تعريف عمل", pmMissingProgram.length===0, pmMissingProgram.length, "عال", pmMissingProgram.map((w)=>w.number).join(", ")),
      test("CTRL-010", "الأصول الحرجة لها PM", criticalAssetsNoPm.length===0, criticalAssetsNoPm.length, "عال", criticalAssetsNoPm.map((a)=>a.number||a.name).join(", ")),
      test("CTRL-011", "لا تكرار أرقام أصول", dupAssets.length===0, dupAssets.length, "عال", [...new Set(dupAssets)].join(", ")),
      test("CTRL-012", "تكلفة المواد لها حركة", materialCostNoUsage.length===0, materialCostNoUsage.length, "عال", materialCostNoUsage.map((c)=>c.workOrderId).join(", ")),
      test("CTRL-013", "تكلفة العمالة لها معاملة", laborCostNoTx.length===0, laborCostNoTx.length, "عال", laborCostNoTx.map((c)=>c.workOrderId).join(", ")),
      test("CTRL-014", "مراجعات المشرف لا تتراكم", pendingReviewAging.length===0, pendingReviewAging.length, "متوسط", pendingReviewAging.map((w)=>w.number).join(", ")),
      test("CTRL-015", "SoD Matrix مهيأة", (db.governanceSoDRules||[]).length>=8, Math.max(0, 8-(db.governanceSoDRules||[]).length), "حرج", (db.governanceSoDRules||[]).length+" قواعد"),
      test("CTRL-016", "RACI Matrix مهيأة", (db.governanceRaciMatrix||[]).length>=10, Math.max(0, 10-(db.governanceRaciMatrix||[]).length), "متوسط", (db.governanceRaciMatrix||[]).length+" صف"),
      test("CTRL-017", "Backup Policy موجودة", (db.governanceBackupPolicies||[]).length>0, (db.governanceBackupPolicies||[]).length?0:1, "حرج", (db.governanceBackupPolicies||[]).map((b)=>b.name).join("; ")),
      test("CTRL-018", "Retention Rules موجودة", (db.governanceRetentionRules||[]).length>0, (db.governanceRetentionRules||[]).length?0:1, "عال", (db.governanceRetentionRules||[]).map((r)=>r.recordType).join("; ")),
      test("CTRL-019", "Access Certification موجودة", (db.governanceAccessCertifications||[]).length>0, (db.governanceAccessCertifications||[]).length?0:1, "حرج", (db.governanceAccessCertifications||[]).map((r)=>r.period+":"+r.status).join("; ")),
      test("CTRL-020", "KPI Owners مكتملة", reportOwnersMissing.length===0 && (db.governanceKpiDefinitions||[]).length>=8, reportOwnersMissing.length, "متوسط", reportOwnersMissing.map((k)=>k.name).join(", ")),
      test("CTRL-021", "Release Gates مهيأة", (db.governanceReleaseGates||[]).length>=5, Math.max(0, 5-(db.governanceReleaseGates||[]).length), "حرج", (db.governanceReleaseGates||[]).map((g)=>g.code+":"+g.status).join("; ")),
      test("CTRL-022", "Readiness Checklist موجودة", (db.governanceReadinessChecklist||[]).length>=10, Math.max(0, 10-(db.governanceReadinessChecklist||[]).length), "حرج", readinessPct+"%"),
      test("CTRL-023", "سياسات الحوكمة فعالة", activePolicies.length>=5, Math.max(0, 5-activePolicies.length), "متوسط", activePolicies.map((p)=>p.name).join("; ")),
      test("CTRL-024", "سجل التدقيق غير فارغ", (db.governanceAuditEvents||[]).length>0, (db.governanceAuditEvents||[]).length?0:1, "متوسط", (db.governanceAuditEvents||[]).length+" حدث"),
      test("CTRL-025", "لا CAPA مفتوحة متأخرة", overdueCaps.length===0, overdueCaps.length, "عال", "CAPA Overdue")
    ];
  };
  const runControls = () => {
    if (!can?.review && !can?.admin) return alert("اختبار الضوابط للمشرف أو المدير فقط.");
    const tests = buildControlTests();
    const failures = tests.filter((t)=>t.result === "Fail");
    const cap = failures.slice(0, 10).map((t)=>({ id:uid(), sourceControl:t.controlCode, title:"CAPA — " + t.name, rootCause:"يحدد بعد التحقيق", action:"تصحيح: " + t.recommendation, ownerRole:t.severity==="حرج"?"مدير":"مشرف", priority:t.severity, dueDate:today(), status:"مفتوح", createdAt:now() }));
    const updatedControls = (db.governanceControlLibrary || []).map((c)=>{ const t = tests.find((x)=>x.controlCode===c.code); return t ? { ...c, lastTestedAt:t.testedAt, lastResult:t.result } : c; });
    save({ ...db, governanceControlTests:[...(db.governanceControlTests||[]), ...tests], governanceControlLibrary:updatedControls, governanceCapaActions:[...(db.governanceCapaActions||[]), ...cap], governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("تشغيل اختبار ضوابط حوكمة 100%", "Controls", { pass:tests.filter((t)=>t.result==="Pass").length, fail:failures.length })] });
  };
  const closeGate = (gate) => {
    if (!can?.admin && !can?.review) return;
    save({ ...db, governanceReleaseGates:(db.governanceReleaseGates||[]).map((g)=>g.id===gate.id?{...g,status:"معتمد",approvedBy:roleLabel,approvedAt:now()}:g), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("اعتماد بوابة إصدار: "+gate.name, "Release Gates")] });
  };
  const closeCapa = (capa) => save({ ...db, governanceCapaActions:(db.governanceCapaActions||[]).map((c)=>c.id===capa.id?{...c,status:"مكتمل",closedAt:now(),closedBy:roleLabel}:c), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("إغلاق CAPA: "+capa.title, "CAPA")] });
  const approveException = (ex, decision) => save({ ...db, governanceExceptionRegister:(db.governanceExceptionRegister||[]).map((e)=>e.id===ex.id?{...e,status:decision,approvedBy:roleLabel,approvedAt:now()}:e), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit(decision+" استثناء: "+ex.title, "Exceptions")] });
  const createException = () => {
    const title = prompt("عنوان الاستثناء") || "استثناء تشغيلي";
    const risk = prompt("سبب/مخاطر الاستثناء") || "يحدد لاحقًا";
    save({ ...db, governanceExceptionRegister:[...(db.governanceExceptionRegister||[]), { id:uid(), number:"EXC-"+String(1000+(db.governanceExceptionRegister||[]).length+1), title, risk, compensatingControl:"مراجعة مشرف + CAPA", ownerRole:roleLabel, status:"مفتوح", requestedAt:now(), expiresOn:"" }], governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("إنشاء استثناء حوكمة", "Exceptions")] });
  };
  const markReady = (item) => save({ ...db, governanceReadinessChecklist:(db.governanceReadinessChecklist||[]).map((x)=>x.id===item.id?{...x,status:x.status==="مكتمل"?"غير مكتمل":"مكتمل", evidence:x.evidence||"تم التحقق بواسطة "+roleLabel+" في "+now()}:x), governanceAuditEvents:[...(db.governanceAuditEvents||[]), addAudit("تحديث جاهزية: "+item.item, "Readiness")] });
  const exportEvidence = () => {
    const data = { generatedAt:now(), maturity, foundationScore, testScore, controls:db.governanceControlLibrary||[], tests:latestTests.slice(0,200), caps:db.governanceCapaActions||[], exceptions:db.governanceExceptionRegister||[], readiness:db.governanceReadinessChecklist||[], releaseGates:db.governanceReleaseGates||[] };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:"application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "cmms-governance-evidence-"+today()+".json"; a.click();
  };
  const resultColor = (r) => r === "Pass" || r === "نجح" || r === "ناجح" ? C.green : r === "Warning" || r === "تحذير" ? C.amber : C.red;
  const filteredTests = filter === "الكل" ? latestTests : latestTests.filter((t)=>t.result===filter || t.severity===filter);

  return <>
    <div style={{ display:"flex", gap:8, overflowX:"auto", marginBottom:12 }}>{tabs.map(([id,label])=><Chip key={id} active={sub===id} onClick={()=>setSub(id)}>{label}</Chip>)}</div>
    {sub === "dashboard" && <>
      <Section title="Governance 100% Dashboard">
        <div style={{display:"flex", gap:8, marginBottom:8}}><Stat n={maturity+"%"} label="نضج الحوكمة" color={maturityColor}/><Stat n={(db.governanceControlLibrary||[]).length} label="ضوابط" color={C.blue}/><Stat n={fail} label="فشل" color={fail?C.red:C.green}/><Stat n={readinessPct+"%"} label="الجاهزية" color={readinessPct>=90?C.green:C.amber}/></div>
        <div style={{...card(), borderRightColor:maturityColor, lineHeight:1.8, fontSize:13}}>
          <b>الهدف:</b> الوصول إلى حوكمة إنتاجية لا تعتمد على الواجهة فقط، بل على أدوار، ضوابط، أدلة، مراجعات، CAPA، SoD، RACI، نسخ احتياطي، وجاهزية تشغيل. النسبة ليست وعدًا قانونيًا بـ 100%، لكنها تقيس اكتمال عناصر الحوكمة داخل التطبيق.
        </div>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
          {ctx.canUseSetupTools && <Btn bg={C.green} onClick={seedGovernance100}>+ إنشاء/تحديث حوكمة CMMS 100%</Btn>}
          {can?.review && <Btn bg={C.blue} onClick={runControls}>تشغيل اختبار الضوابط الآن</Btn>}
          <Btn bg={C.ink} onClick={exportEvidence}>تصدير ملف الأدلة JSON</Btn>
          <Btn bg={C.orange} onClick={()=>setSub("readiness")}>فتح جاهزية الإنتاج</Btn>
        </div>
      </Section>
      <Section title="Domains Coverage">
        {GOVERNANCE100_DOMAINS.map((d)=>{ const count=(db.governanceControlLibrary||[]).filter((c)=>c.domain===d).length; return <div key={d} style={card()}><Row main={d} sub={count+" ضابط"} badge={{text:count?"مغطى":"ناقص", color:count?C.green:C.amber}} /></div>; })}
      </Section>
    </>}
    {sub === "controls" && <>
      <Section title="Control Library"><div style={{...card(), fontSize:13, color:C.steel}}>كل ضابط له مالك، دورية، دليل مطلوب، ونتيجة آخر اختبار. استخدم زر اختبار الضوابط لإنشاء Evidence وCAPA تلقائيًا.</div>{(db.governanceControlLibrary||[]).map((c)=><div key={c.id} style={{...card(), borderRightColor:resultColor(c.lastResult)}}><Row main={c.code+" — "+c.name} sub={[c.domain,c.ownerRole,c.frequency,c.automation,"Evidence: "+(c.evidenceRequired||"—")].filter(Boolean).join(" · ")} badge={{text:c.lastResult||c.status||"نشط", color:resultColor(c.lastResult)}} /></div>)}{!(db.governanceControlLibrary||[]).length && <Empty text="اضغط إنشاء حوكمة CMMS 100% لإضافة مكتبة الضوابط." />}</Section>
      <Crud ctx={ctx} entity="governanceControlLibrary" title="ضابط حوكمة" schema={[{k:"code",label:"Code"},{k:"name",label:"Name"},{k:"domain",label:"Domain",type:"select",options:GOVERNANCE100_DOMAINS},{k:"ownerRole",label:"Owner Role",type:"select",options:ROLES},{k:"frequency",label:"Frequency"},{k:"automation",label:"Automation",type:"select",options:["تلقائي","شبه آلي","يدوي"]},{k:"criticality",label:"Criticality",type:"select",options:["حرج","عال","متوسط","منخفض"]},{k:"evidenceRequired",label:"Evidence",type:"textarea"},{k:"status",label:"Status",type:"select",options:["نشط","معلق","متقاعد"]}]} render={(r)=>[r.code+" — "+r.name, [r.domain,r.ownerRole,r.frequency].join(" · ")]} badge={(r)=>({text:r.status||"نشط", color:r.status==="نشط"?C.green:C.steel})}/>
    </>}
    {sub === "tests" && <Section title="Control Test Results"><div style={{display:"flex", gap:6, overflowX:"auto", marginBottom:8}}>{["الكل","Pass","Fail","Warning","حرج","عال","متوسط"].map((x)=><Chip key={x} active={filter===x} onClick={()=>setFilter(x)}>{x}</Chip>)}</div>{filteredTests.map((t)=><div key={t.id} style={{...card(), borderRightColor:resultColor(t.result)}}><Row main={(t.controlCode||"")+" — "+t.name} sub={[t.testedAt,"Issues: "+t.issueCount,t.evidence,t.recommendation].filter(Boolean).join(" · ")} badge={{text:t.result, color:resultColor(t.result)}} /></div>)}{!filteredTests.length && <Empty text="لا نتائج اختبار بعد. شغّل اختبار الضوابط." />}</Section>}
    {sub === "approvals" && <>
      <Section title="Authority Limits / Approval Matrix">{(db.governanceAuthorityLimits||[]).map((a)=><div key={a.id} style={card()}><Row main={a.code+" — "+a.action} sub={["Approver: "+a.approverRole,"Limit: "+a.amountLimit,"E-Sign: "+a.eSignatureRequired].join(" · ")} badge={{text:a.status||"نشط", color:C.green}} /></div>)}{!(db.governanceAuthorityLimits||[]).length && <Empty text="أنشئ حوكمة 100% لإضافة حدود الاعتماد."/>}</Section>
      <Section title="Release Gates">{(db.governanceReleaseGates||[]).map((g)=><div key={g.id} style={{...card(), borderRightColor:g.status==="معتمد"?C.green:C.amber}}><Row main={g.code+" — "+g.name} sub={[g.criteria,"Owner: "+g.ownerRole,g.approvedAt].filter(Boolean).join(" · ")} badge={{text:g.status, color:g.status==="معتمد"?C.green:C.amber}} action={can?.review && g.status!=="معتمد"?<Btn bg={C.green} onClick={()=>closeGate(g)}>اعتماد</Btn>:null}/></div>)}</Section>
      <Crud ctx={ctx} entity="governanceERecords" title="E-Record / E-Sign Evidence" schema={[{k:"recordType",label:"Record Type"},{k:"recordId",label:"Record ID"},{k:"action",label:"Action"},{k:"signedByRole",label:"Signed By Role",type:"select",options:ROLES},{k:"signedAt",label:"Signed At"},{k:"meaning",label:"Meaning",type:"textarea"}]} render={(r)=>[r.recordType+" — "+r.action, [r.recordId,r.signedByRole,r.signedAt].filter(Boolean).join(" · ")]} />
    </>}
    {sub === "sod" && <Section title="Segregation of Duties Matrix">{(db.governanceSoDRules||[]).map((r)=><div key={r.id} style={{...card(), borderRightColor:r.risk==="حرج"?C.red:C.amber}}><Row main={r.code+" — "+r.name} sub={[r.permissionA,"vs",r.permissionB,r.mitigation].filter(Boolean).join(" · ")} badge={{text:r.risk, color:r.risk==="حرج"?C.red:C.amber}} /></div>)}{!(db.governanceSoDRules||[]).length && <Empty text="لا توجد قواعد SoD بعد." />}</Section>}
    {sub === "raci" && <><Section title="RACI Operating Model">{(db.governanceRaciMatrix||[]).map((r)=><div key={r.id} style={card()}><Row main={r.process} sub={["R: "+r.responsible,"A: "+r.accountable,"C: "+r.consulted,"I: "+r.informed].join(" · ")} badge={{text:r.status||"معتمد", color:C.green}} /></div>)}</Section><Section title="Data Owners">{(db.governanceDataOwners||[]).map((d)=><div key={d.id} style={card()}><Row main={d.domain} sub={["Owner: "+d.ownerRole,"Steward: "+d.stewardRole,"Fields: "+d.keyFields].join(" · ")} /></div>)}</Section></>}
    {sub === "kpi" && <><Section title="KPI Definitions">{(db.governanceKpiDefinitions||[]).map((k)=><div key={k.id} style={card()}><Row main={k.code+" — "+k.name} sub={[k.definition,"Target: "+k.target,"Owner: "+k.ownerRole,k.frequency].join(" · ")} badge={{text:k.uom||"KPI", color:C.blue}} /></div>)}</Section><Section title="SLA / Escalation Rules">{(db.governanceSlaRules||[]).map((s)=><div key={s.id} style={card()}><Row main={s.code+" — "+s.priority} sub={["Response: "+s.responseTime,"Resolution: "+s.resolutionTarget,"Owner: "+s.ownerRole,s.escalation].join(" · ")} /></div>)}</Section></>}
    {sub === "exceptions" && <Section title="Exception Register">{can?.manage && <Btn bg={C.orange} onClick={createException} style={{width:"100%",padding:12,marginBottom:8}}>+ طلب استثناء</Btn>}{(db.governanceExceptionRegister||[]).map((e)=><div key={e.id} style={{...card(), borderRightColor:e.status==="معتمد"?C.green:e.status==="مرفوض"?C.red:C.amber}}><Row main={(e.number||"")+" — "+e.title} sub={[e.risk,e.compensatingControl,"Owner: "+e.ownerRole,e.requestedAt].filter(Boolean).join(" · ")} badge={{text:e.status, color:e.status==="معتمد"?C.green:e.status==="مرفوض"?C.red:C.amber}} action={can?.review && e.status==="مفتوح"?<div style={{display:"flex",gap:4}}><Btn bg={C.green} onClick={()=>approveException(e,"معتمد")}>اعتماد</Btn><Btn bg={C.red} onClick={()=>approveException(e,"مرفوض")}>رفض</Btn></div>:null}/></div>)}{!(db.governanceExceptionRegister||[]).length && <Empty text="لا توجد استثناءات مفتوحة."/>}</Section>}
    {sub === "capa" && <><Section title="CAPA / Corrective Actions"><div style={{...card(), fontSize:13, color:C.steel}}>تُنشأ CAPA تلقائيًا عند فشل الضوابط. أغلقها بعد معالجة السبب الجذري وإعادة الفحص.</div>{(db.governanceCapaActions||[]).map((c)=><div key={c.id} style={{...card(), borderRightColor:c.status==="مكتمل"?C.green:C.red}}><Row main={c.title} sub={["Control: "+c.sourceControl,"Root Cause: "+c.rootCause,"Action: "+c.action,"Due: "+c.dueDate].filter(Boolean).join(" · ")} badge={{text:c.status, color:c.status==="مكتمل"?C.green:C.red}} action={c.status!=="مكتمل"&&can?.review?<Btn bg={C.green} onClick={()=>closeCapa(c)}>إغلاق</Btn>:null}/></div>)}{!(db.governanceCapaActions||[]).length && <Empty text="لا توجد CAPA بعد."/>}</Section><Crud ctx={ctx} entity="governanceIncidentReviews" title="Incident / RCA Review" schema={[{k:"number",label:"Number"},{k:"title",label:"Title"},{k:"assetId",label:"Asset",type:"select",from:"assets",fromKey:"name"},{k:"failureMode",label:"Failure Mode"},{k:"rootCause",label:"Root Cause",type:"textarea"},{k:"correctiveAction",label:"Corrective Action",type:"textarea"},{k:"ownerRole",label:"Owner Role",type:"select",options:ROLES},{k:"status",label:"Status",type:"select",options:["مفتوح","قيد التنفيذ","مكتمل"]}]} render={(r)=>[r.number+" — "+r.title, [nameOf("assets",r.assetId),r.failureMode,r.status].filter(Boolean).join(" · ")]} /></>}
    {sub === "readiness" && <><Section title="Production Readiness Checklist"><div style={{display:"flex",gap:8, marginBottom:8}}><Stat n={readinessPct+"%"} label="جاهزية" color={readinessPct>=90?C.green:C.amber}/><Stat n={(db.governanceReadinessChecklist||[]).length-readinessDone} label="متبقي" color={readinessDone===(db.governanceReadinessChecklist||[]).length?C.green:C.red}/><Stat n={(db.governanceReleaseGates||[]).filter((g)=>g.status==="معتمد").length+"/"+(db.governanceReleaseGates||[]).length} label="Gates" color={C.blue}/></div>{(db.governanceReadinessChecklist||[]).map((x)=><div key={x.id} style={{...card(), borderRightColor:x.status==="مكتمل"?C.green:C.amber}} onClick={()=>can?.review&&markReady(x)}><Row main={x.code+" — "+x.item} sub={["Owner: "+x.ownerRole,"Criticality: "+x.criticality,x.evidence].filter(Boolean).join(" · ")} badge={{text:x.status, color:x.status==="مكتمل"?C.green:C.amber}} /></div>)}</Section><Section title="Backup & Retention">{[...(db.governanceBackupPolicies||[]), ...(db.governanceRetentionRules||[])].map((x)=><div key={x.id} style={card()}><Row main={(x.code||"")+" — "+(x.name||x.recordType)} sub={[x.frequency,x.retention||x.retentionPeriod,x.ownerRole,x.rule].filter(Boolean).join(" · ")} /></div>)}</Section></>}
    {sub === "evidence" && <><Section title="Evidence Register">{(db.governanceEvidenceRegister||[]).map((e)=><div key={e.id} style={card()}><Row main={e.title} sub={[e.controlCode,e.source,e.createdAt,e.uri].filter(Boolean).join(" · ")} /></div>)}{!(db.governanceEvidenceRegister||[]).length && <Empty text="سيتم تصدير الأدلة كملف JSON، ويمكن إضافة Evidence URLs لاحقًا."/>}</Section><Section title="Training / Acknowledgements">{(db.governancePolicyAcknowledgements||[]).map((a)=><div key={a.id} style={card()}><Row main={a.policy} sub={[a.role,a.userEmail,a.acknowledgedAt].filter(Boolean).join(" · ")} badge={{text:a.status||"مقر", color:C.green}} /></div>)}{(db.governanceTrainingRecords||[]).map((t)=><div key={t.id} style={card()}><Row main={t.course||t.title||t.topic} sub={[t.userRole||t.roleName,t.completedAt,t.status].filter(Boolean).join(" · ")} /></div>)}</Section></>}
  </>;
}

/* ───────────────────────── التقارير ومحرك الوظائف + PDF/Excel ───────────────────────── */
