import { useState } from "react";
import { Bar, BarChart, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ACTIVE_STATES, C, MAINTENANCE_REPORTS, WO_EXTRA, WO_FLOW, dateKey, daysBetween, daysUntil, isStorageMedia, money, now, today, uid } from "../core/appCore";
import { Btn, Empty, Field, Row, Section, Sheet, Stat, card, input, inputStyle } from "../components/ui";
import { Forecast } from "./scheduling";

export function Reports({ ctx }) {
  const { db, save, woCost, nameOf, can, role } = ctx;
  const [reportName, setReportName] = useState(MAINTENANCE_REPORTS[0]);
  const [reportFrom, setReportFrom] = useState("");
  const [reportTo, setReportTo] = useState("");
  const [reportText, setReportText] = useState("");
  const [previewLimit, setPreviewLimit] = useState(25);
  const all = db.workOrders || [];
  const canExport = can?.review || can?.manage || can?.warehouse || can?.admin;
  const byStatus = [...WO_FLOW, ...WO_EXTRA].map((s) => ({ name: s, عدد: all.filter((w) => w.status === s).length })).filter((d) => d.عدد > 0);
  const byType = ["وقائي", "تصحيحي", "طارئ"].map((t) => ({ name: t, value: all.filter((w) => w.type === t).length })).filter((d) => d.value > 0);
  const costByAsset = (db.assets || []).map((a) => ({ name: a.name, تكلفة: all.filter((w) => w.assetId === a.id).reduce((s, w) => s + woCost(w).total, 0) })).filter((d) => d.تكلفة > 0).sort((a, b) => b.تكلفة - a.تكلفة).slice(0, 6);
  const techPerf = (db.technicians || []).map((t) => { let ops = 0, hours = 0; all.forEach((w) => (w.operations || []).forEach((o) => { if (o.assigneeId === t.id && o.status === "مكتملة") { ops++; hours += Number(o.actualHours || 0); } })); return { name: t.name, عمليات: ops, ساعات: hours }; }).filter((x) => x.عمليات > 0).sort((a, b) => b.عمليات - a.عمليات);
  const pm = all.filter((w) => w.type === "وقائي" && ["مغلق"].includes(w.status));
  const pmOnTime = pm.filter((w) => !w.plannedEnd || !w.completedAt || w.completedAt <= w.plannedEnd).length;
  const totalCost = all.reduce((s, w) => s + woCost(w).total, 0);
  const done = all.filter((w) => w.status === "مغلق").length;

  const valueText = (v) => {
    if (v === null || v === undefined) return "";
    if (typeof v === "number") return Number.isFinite(v) ? String(v) : "";
    if (typeof v === "boolean") return v ? "نعم" : "لا";
    if (Array.isArray(v)) return v.map(valueText).filter(Boolean).join(" | ");
    if (typeof v === "object") return JSON.stringify(v);
    return String(v);
  };
  const escapeHtml = (v) => valueText(v).replace(/[&<>'"]/g, (ch) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[ch] || ch));
  const escapeXml = (v) => valueText(v).replace(/[&<>'"]/g, (ch) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&apos;", '"':"&quot;" }[ch] || ch));
  const cleanFileName = (v) => valueText(v).replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, "-").slice(0, 90) || "report";
  const columnsOf = (rows) => {
    const cols = [...new Set((rows || []).flatMap((r) => Object.keys(r || {})))];
    return cols.length ? cols : ["النتيجة"];
  };
  const rowDateValue = (r) => r?.completedAt || r?.plannedEnd || r?.plannedStart || r?.dueDate || r?.generatedAt || r?.requestedAt || r?.at || r?.date || r?.createdAt || r?.closedAt || r?.submittedAt || "";
  const rowInRange = (r) => {
    const d = dateKey(rowDateValue(r));
    if (!d) return !reportFrom && !reportTo;
    if (reportFrom && d < reportFrom) return false;
    if (reportTo && d > reportTo) return false;
    return true;
  };
  const rowMatchesText = (r) => {
    const q = reportText.trim().toLowerCase();
    if (!q) return true;
    return Object.values(r || {}).map(valueText).join(" ").toLowerCase().includes(q);
  };
  const groupRows = (rows, keyFn) => {
    const map = new Map();
    rows.forEach((r) => { const key = keyFn(r) || "غير محدد"; map.set(key, [...(map.get(key) || []), r]); });
    return map;
  };
  const minutes = (v) => Number(v || 0);
  const failureRows = () => {
    const fromWo = all.filter((w) => w.failure).map((w) => ({
      number: w.number, asset: nameOf("assets", w.assetId), mode: w.failure?.mode || w.failure?.failureMode,
      cause: w.failure?.cause || w.failure?.failureCause, effect: w.failure?.effect, action: w.failure?.action || w.failure?.actionTaken,
      downtime: w.failure?.downtime || w.failure?.downtimeMinutes || 0, rootCause: w.failure?.rootCause, repeated: w.failure?.repeated ? "نعم" : "لا", completedAt: w.completedAt || w.plannedEnd, status: w.status
    }));
    const fromRecords = (db.workOrderFailureRecords || []).map((f) => ({
      number: nameOf("workOrders", f.workOrderId, "number"), asset: nameOf("assets", f.assetId), mode: f.failureMode || f.mode,
      cause: f.failureCause || f.cause, effect: f.failureEffect || f.effect, action: f.actionTaken || f.action,
      downtime: f.downtimeMinutes || f.downtime || 0, rootCause: f.rootCause, repeated: f.repeatedFailure ? "نعم" : "لا", completedAt: f.downtimeEnd || f.at || f.createdAt, status: "مسجل"
    }));
    return [...fromWo, ...fromRecords];
  };
  const materialRows = () => {
    const fromExec = (db.workOrderMaterialUsage || []).map((m) => ({ workOrder: nameOf("workOrders", m.workOrderId, "number"), item: nameOf("items", m.itemId), requestedQty: m.requestedQty, issuedQty: m.issuedQty, usedQty: m.usedQty, returnedQty: m.returnedQty, unitCost: m.unitCost, cost: Number(m.usedQty || 0) * Number(m.unitCost || 0), at: m.at || m.createdAt }));
    const fromWo = all.flatMap((w) => (w.materials || []).map((m) => ({ workOrder: w.number, item: nameOf("items", m.itemId), requestedQty: m.qty, issuedQty: m.issuedQty, usedQty: m.usedQty || m.actualQty, returnedQty: m.returnedQty, unitCost: m.unitCost || m.cost, cost: Number(m.usedQty || m.actualQty || 0) * Number(m.unitCost || m.cost || 0), at: w.completedAt || w.plannedEnd })));
    return [...fromExec, ...fromWo];
  };
  const laborRows = () => {
    const fromTx = (db.workOrderLaborTransactions || []).map((l) => ({ workOrder: nameOf("workOrders", l.workOrderId, "number"), technician: nameOf("technicians", l.technicianId), hours: l.hours || l.actualHours, rate: l.rate || l.hourlyRate, cost: Number(l.hours || l.actualHours || 0) * Number(l.rate || l.hourlyRate || 0), at: l.at || l.createdAt }));
    const fromOps = all.flatMap((w) => (w.operations || []).filter((o) => Number(o.actualHours || 0) > 0).map((o) => ({ workOrder: w.number, operation: o.name, technician: nameOf("technicians", o.assigneeId), hours: Number(o.actualHours || 0), rate: 0, cost: 0, at: w.completedAt || w.plannedEnd })));
    return [...fromTx, ...fromOps];
  };
  const reportRowsRaw = (name) => {
    if (name.includes("Open")) return all.filter((w)=>ACTIVE_STATES.includes(w.status)).map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), type:w.type, priority:w.priority, status:w.status, plannedStart:w.plannedStart, plannedEnd:w.plannedEnd, technician:(w.assignments||[]).map((a)=>nameOf("technicians", a.technicianId)).join("، ") }));
    if (name.includes("Past Due")) return all.filter((w)=>w.plannedEnd && daysUntil(w.plannedEnd)<0 && w.status !== "مغلق" && w.status !== "ملغي").map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), status:w.status, priority:w.priority, plannedEnd:w.plannedEnd, daysLate:Math.abs(daysUntil(w.plannedEnd)) }));
    if (name.includes("Completed")) return all.filter((w)=>w.status==="مغلق").map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), completedAt:w.completedAt, plannedEnd:w.plannedEnd, onTime:(!w.plannedEnd || !w.completedAt || w.completedAt <= w.plannedEnd)?"نعم":"لا", cost:woCost(w).total }));
    if (name.includes("Preventive")) return all.filter((w)=>w.type==="وقائي").map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), status:w.status, program:nameOf("programs", w.programId), workDefinition:nameOf("workDefs", w.workDefId), plannedEnd:w.plannedEnd, completedAt:w.completedAt, compliant:w.status==="مغلق" && (!w.plannedEnd || !w.completedAt || w.completedAt <= w.plannedEnd)?"نعم":"لا" }));
    if (name.includes("Corrective")) return all.filter((w)=>w.type==="تصحيحي").map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), priority:w.priority, status:w.status, failure:w.failure?.mode || "—", cause:w.failure?.cause || "—", downtime:w.failure?.downtime || w.failure?.downtimeMinutes || 0, completedAt:w.completedAt }));
    if (name.includes("Emergency")) return all.filter((w)=>w.type==="طارئ" || w.priority==="حرجة" || w.priority==="طارئة").map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), priority:w.priority, status:w.status, plannedStart:w.plannedStart, completedAt:w.completedAt, downtime:w.failure?.downtime || w.failure?.downtimeMinutes || 0 }));
    if (name.includes("Cost")) return all.map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), type:w.type, status:w.status, labor:woCost(w).labor, material:woCost(w).material, total:woCost(w).total, completedAt:w.completedAt })).filter((r)=>Number(r.total)>0 || name.includes("Work Order"));
    if (name.includes("Technician Performance")) return techPerf.map((t)=>({ technician:t.name, completedOperations:t.عمليات, actualHours:t.ساعات, productivity:t.ساعات ? Math.round((t.عمليات / t.ساعات) * 100) / 100 : "—" }));
    if (name.includes("Technician Workload")) return (db.technicians || []).map((t)=>({ technician:t.name, assigned: all.filter((w)=>(w.assignments||[]).some((a)=>a.technicianId===t.id) || (w.operations||[]).some((o)=>o.assigneeId===t.id)).length, inProgress: all.filter((w)=>w.status==="قيد التنفيذ" && ((w.assignments||[]).some((a)=>a.technicianId===t.id) || (w.operations||[]).some((o)=>o.assigneeId===t.id))).length, completedOps: techPerf.find((x)=>x.name===t.name)?.عمليات || 0 }));
    if (name.includes("Failure") || name.includes("MTTR") || name.includes("MTBF")) {
      const failures = failureRows();
      if (name.includes("Repeated")) {
        return Array.from(groupRows(failures, (f)=>[f.asset,f.mode,f.cause].join(" / ")).entries()).filter(([,arr])=>arr.length>1).map(([key, arr])=>({ pattern:key, count:arr.length, totalDowntime:arr.reduce((s,r)=>s+minutes(r.downtime),0), lastDate:arr.map((x)=>x.completedAt).filter(Boolean).sort().slice(-1)[0] || "—" }));
      }
      if (name.includes("MTTR")) return Array.from(groupRows(failures, (f)=>f.asset).entries()).map(([asset, arr])=>({ asset, failures:arr.length, mttrMinutes: arr.length ? Math.round(arr.reduce((s,r)=>s+minutes(r.downtime),0)/arr.length) : 0 }));
      if (name.includes("MTBF")) return Array.from(groupRows(failures.filter((f)=>dateKey(f.completedAt)), (f)=>f.asset).entries()).map(([asset, arr])=>{ const dates=arr.map((x)=>dateKey(x.completedAt)).sort(); const span=dates.length>1?Math.max(1, daysBetween(dates[0], dates[dates.length-1])):0; return { asset, failures:arr.length, mtbfDays: arr.length>1?Math.round(span/(arr.length-1)):"غير كافٍ", firstFailure:dates[0]||"—", lastFailure:dates[dates.length-1]||"—" }; });
      return failures;
    }
    if (name.includes("Asset Maintenance History")) return all.map((w)=>({ asset:nameOf("assets", w.assetId), number:w.number, title:w.title, type:w.type, status:w.status, plannedStart:w.plannedStart, completedAt:w.completedAt, cost:woCost(w).total }));
    if (name.includes("Forecast")) return (db.maintenanceForecasts||db.forecastRuns||[]).map((f)=>({ program:nameOf("programs", f.programId), asset:nameOf("assets", f.assetId), dueDate:f.dueDate || f.forecastDate, status:f.status, risk:f.risk, remaining:f.remaining }));
    if (name.includes("Material")) return materialRows();
    if (name.includes("Labor")) return laborRows();
    if (name.includes("Daily Maintenance Execution")) return all.filter((w)=>w.plannedStart===today() || w.completedAt===today() || w.status==="قيد التنفيذ").map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), status:w.status, plannedStart:w.plannedStart, completedAt:w.completedAt, technician:(w.assignments||[]).map((a)=>nameOf("technicians", a.technicianId)).join("، ") }));
    if (name.includes("Work Completion")) return all.map((w)=>({ number:w.number, status:w.status, operations:(w.operations||[]).length, completedOperations:(w.operations||[]).filter((o)=>o.status==="مكتملة").length, checklist:(w.checklist||[]).filter((c)=>c.done).length + "/" + (w.checklist||[]).length, completedAt:w.completedAt }));
    if (name.includes("Rejected")) return all.filter((w)=>w.status==="مُعاد للتصحيح" || w.status==="مرفوض" || w.status==="Rejected").map((w)=>({ number:w.number, asset:nameOf("assets", w.assetId), status:w.status, rejectionReason:w.rejectionReason || w.reviewNotes || "—", plannedEnd:w.plannedEnd }));
    if (name.includes("Before / After")) return all.flatMap((w)=>(w.photos||[]).map((p)=>({ workOrder:w.number, asset:nameOf("assets", w.assetId), type:p.type || p.kind, storage:isStorageMedia(p)?"Storage":"محلي", uploadedAt:p.uploadedAt || p.at || w.completedAt, note:p.note || "" })));
    if (name.includes("Supervisor Review")) return (db.workOrderSupervisorReviews||[]).map((r)=>({ workOrder:nameOf("workOrders", r.workOrderId, "number"), decision:r.decision || r.status, reviewer:r.reviewer || r.reviewerRole, reviewedAt:r.reviewedAt || r.at, notes:r.notes })).concat(all.filter((w)=>["بانتظار المراجعة","مغلق","مُعاد للتصحيح"].includes(w.status)).map((w)=>({ workOrder:w.number, decision:w.status, reviewer:"—", reviewedAt:w.completedAt || w.reviewedAt, notes:w.reviewNotes || "" })));
    return all.map((w)=>({ number:w.number, title:w.title, asset:nameOf("assets", w.assetId), type:w.type, priority:w.priority, status:w.status, plannedStart:w.plannedStart, plannedEnd:w.plannedEnd, completedAt:w.completedAt }));
  };
  const reportRows = (name) => reportRowsRaw(name).filter(rowInRange).filter(rowMatchesText);
  const rows = reportRows(reportName);
  const cols = columnsOf(rows.length ? rows : [{ "النتيجة":"لا توجد بيانات حسب الفلاتر الحالية" }]);
  const rowsForExport = rows.length ? rows : [{ "النتيجة":"لا توجد بيانات حسب الفلاتر الحالية" }];
  const reportSubtitle = [reportFrom ? "من " + reportFrom : "", reportTo ? "إلى " + reportTo : "", reportText ? "بحث: " + reportText : ""].filter(Boolean).join(" · ") || "كل البيانات";
  const downloadBlob = (blob, filename) => { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(a.href); a.remove(); }, 1000); };
  const logReportExport = (format, rowCount) => {
    const stamp = now();
    const job = { id:uid(), name:reportName, status:"Exported", format, requestedAt:stamp, completedAt:stamp, rowCount, requestedBy:role || "CMMS", filters:{ from:reportFrom, to:reportTo, text:reportText } };
    const out = { id:uid(), jobId:job.id, name:reportName, format, generatedAt:stamp, rowCount, summary:JSON.stringify(rowsForExport.slice(0, 5)), filters:{ from:reportFrom, to:reportTo, text:reportText } };
    save({ ...db, reportJobs:[...(db.reportJobs||[]), job], savedReportOutputs:[...(db.savedReportOutputs||[]), out] });
  };
  const buildReportHtml = (name, rows) => {
    const columns = columnsOf(rows);
    const bodyRows = rows.length ? rows : [{ "النتيجة":"لا توجد بيانات" }];
    const total = bodyRows.length;
    const table = `<table><thead><tr>${columns.map((c)=>`<th>${escapeHtml(c)}</th>`).join("")}</tr></thead><tbody>${bodyRows.map((r)=>`<tr>${columns.map((c)=>`<td>${escapeHtml(r[c])}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    return `<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"/><title>${escapeHtml(name)}</title><style>
      @page{size:A4;margin:12mm} body{font-family:Arial,Tahoma,sans-serif;color:#111827;margin:0;background:#fff;direction:rtl} .wrap{padding:12px}.head{border-bottom:3px solid #0f172a;padding-bottom:10px;margin-bottom:12px}.brand{font-size:22px;font-weight:800}.meta{font-size:12px;color:#64748b;line-height:1.8}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0}.card{border:1px solid #e5e7eb;border-radius:12px;padding:10px}.n{font-size:20px;font-weight:800}.l{font-size:11px;color:#64748b} table{width:100%;border-collapse:collapse;font-size:11px} th{background:#f1f5f9;color:#0f172a;text-align:right} th,td{border:1px solid #e5e7eb;padding:6px;vertical-align:top} tr:nth-child(even){background:#fafafa}.foot{margin-top:16px;font-size:10px;color:#64748b}@media print{.no-print{display:none}.wrap{padding:0}}
    </style></head><body><div class="wrap"><div class="head"><div class="brand">${escapeHtml(name)}</div><div class="meta">Alhadi CMMS · ${escapeHtml(reportSubtitle)} · تاريخ التوليد: ${escapeHtml(now())}</div></div><div class="cards"><div class="card"><div class="n">${total}</div><div class="l">عدد الصفوف</div></div><div class="card"><div class="n">${escapeHtml(all.length)}</div><div class="l">أوامر العمل</div></div><div class="card"><div class="n">${escapeHtml(done)}</div><div class="l">مغلق</div></div><div class="card"><div class="n">${escapeHtml(money(totalCost))}</div><div class="l">إجمالي التكلفة</div></div></div>${table}<div class="foot">تم توليد التقرير من نظام Alhadi CMMS. استخدم خيار Save as PDF من نافذة الطباعة لحفظ نسخة PDF.</div><script>setTimeout(function(){ window.focus(); window.print(); }, 450);</script></div></body></html>`;
  };
  const exportPdf = () => {
    const html = buildReportHtml(reportName, rowsForExport);
    const w = window.open("", "_blank");
    if (w) { w.document.open(); w.document.write(html); w.document.close(); }
    else downloadBlob(new Blob([html], { type:"text/html;charset=utf-8" }), cleanFileName(reportName) + "-PDF-print-" + today() + ".html");
    logReportExport("PDF/Print", rowsForExport.length);
  };
  const exportCsv = () => {
    const columns = columnsOf(rowsForExport);
    const csv = [columns.join(","), ...rowsForExport.map((r)=>columns.map((c)=>'"'+valueText(r[c]).replace(/"/g, '""')+'"').join(","))].join("\n");
    downloadBlob(new Blob(["\uFEFF" + csv], { type:"text/csv;charset=utf-8" }), cleanFileName(reportName) + "-" + today() + ".csv");
    logReportExport("CSV", rowsForExport.length);
  };
  const buildExcelXml = (sheets) => `<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" xmlns:html="http://www.w3.org/TR/REC-html40"><Styles><Style ss:ID="h"><Font ss:Bold="1"/><Interior ss:Color="#EEF2FF" ss:Pattern="Solid"/></Style></Styles>${sheets.map((sheet)=>{ const safeName=cleanFileName(sheet.name).replace(/[\[\]\*\?\/\\:]/g," ").slice(0,31) || "Report"; const data=sheet.rows.length?sheet.rows:[{ "النتيجة":"لا توجد بيانات" }]; const columns=columnsOf(data); return `<Worksheet ss:Name="${escapeXml(safeName)}"><Table><Row>${columns.map((c)=>`<Cell ss:StyleID="h"><Data ss:Type="String">${escapeXml(c)}</Data></Cell>`).join("")}</Row>${data.map((r)=>`<Row>${columns.map((c)=>`<Cell><Data ss:Type="String">${escapeXml(r[c])}</Data></Cell>`).join("")}</Row>`).join("")}</Table><WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><DisplayRightToLeft/></WorksheetOptions></Worksheet>`; }).join("")}</Workbook>`;
  const exportExcel = () => {
    const xml = buildExcelXml([{ name:reportName, rows:rowsForExport }]);
    downloadBlob(new Blob([xml], { type:"application/vnd.ms-excel;charset=utf-8" }), cleanFileName(reportName) + "-" + today() + ".xls");
    logReportExport("Excel XLS", rowsForExport.length);
  };
  const exportAllExcel = () => {
    const sheets = MAINTENANCE_REPORTS.map((name)=>({ name, rows: reportRows(name).slice(0, 5000) }));
    const xml = buildExcelXml(sheets);
    downloadBlob(new Blob([xml], { type:"application/vnd.ms-excel;charset=utf-8" }), "Alhadi-CMMS-Reports-" + today() + ".xls");
    logReportExport("Excel Workbook", sheets.reduce((s,x)=>s+x.rows.length,0));
  };
  const runReport = () => {
    const stamp = now();
    const job = { id:uid(), name:reportName, status:"Completed", requestedAt:stamp, completedAt:stamp, rowCount:rows.length, requestedBy:role || "CMMS", filters:{ from:reportFrom, to:reportTo, text:reportText } };
    const out = { id:uid(), jobId:job.id, name:reportName, generatedAt:stamp, rowCount:rows.length, format:"Saved", summary:JSON.stringify(rows.slice(0, 5)), filters:{ from:reportFrom, to:reportTo, text:reportText } };
    save({ ...db, reportJobs:[...(db.reportJobs||[]), job], savedReportOutputs:[...(db.savedReportOutputs||[]), out] });
  };
  return (<>
    <div style={{ display: "flex", gap: 8, marginBottom: 16 }}><Stat n={all.length} label="إجمالي الأوامر" color={C.ink} /><Stat n={done} label="مغلق" color={C.green} /><Stat n={pm.length ? Math.round((pmOnTime / pm.length) * 100) + "%" : "—"} label="التزام الوقائية" color={C.blue} small /><Stat n={money(totalCost)} label="التكلفة" color={C.orange} small /></div>
    <Section title="Report Job Engine + PDF / Excel">
      <div style={{...card(), display:"grid", gridTemplateColumns:"1fr", gap:8}}>
        <Field label="التقرير"><select value={reportName} onChange={(e)=>setReportName(e.target.value)} style={inputStyle()}>{MAINTENANCE_REPORTS.map((r)=><option key={r}>{r}</option>)}</select></Field>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:8}}>
          <Field label="من تاريخ"><input type="date" value={reportFrom} onChange={(e)=>setReportFrom(e.target.value)} style={inputStyle()} /></Field>
          <Field label="إلى تاريخ"><input type="date" value={reportTo} onChange={(e)=>setReportTo(e.target.value)} style={inputStyle()} /></Field>
        </div>
        <Field label="بحث داخل التقرير"><input value={reportText} onChange={(e)=>setReportText(e.target.value)} placeholder="رقم أمر، أصل، فني، حالة…" style={inputStyle()} /></Field>
        <div style={{display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:8}}>
          {canExport && <Btn bg={C.green} onClick={runReport}>تشغيل وحفظ</Btn>}
          {canExport && <Btn bg={C.blue} onClick={exportPdf}>PDF / طباعة</Btn>}
          {canExport && <Btn bg={C.purple} onClick={exportExcel}>Excel XLS</Btn>}
          {canExport && <Btn bg={C.ink} onClick={exportCsv}>CSV</Btn>}
        </div>
        {canExport && <Btn bg={C.orange} onClick={exportAllExcel}>Excel شامل لكل التقارير</Btn>}
        <div style={{fontSize:12, color:C.steel}}>الصفوف الحالية: {rows.length}. الفلاتر: {reportSubtitle}. PDF يفتح نافذة طباعة ويمكن حفظه كـ PDF، وExcel يتم تنزيله كملف XLS متوافق مع Excel/Sheets.</div>
      </div>
      <div style={{display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8, marginTop:8}}><Stat n={rows.length} label="صفوف التقرير" color={C.blue} small/><Stat n={(db.reportJobs||[]).length} label="Jobs" color={C.green} small/><Stat n={(db.savedReportOutputs||[]).length} label="Outputs" color={C.purple} small/></div>
      {(db.reportJobs||[]).slice().reverse().slice(0,5).map((j)=><div key={j.id} style={card()}><Row main={(j.format?j.format+" · ":"")+j.name} sub={(j.requestedAt||"")+" · "+(j.status||"Completed")+" · Rows: "+(j.rowCount||0)} badge={{text:j.format||j.status||"Report", color:j.format?C.purple:C.green}} /></div>)}
    </Section>
    <Section title="معاينة التقرير"><div style={{...card(), overflowX:"auto"}}><div style={{display:"flex", justifyContent:"space-between", alignItems:"center", gap:8, marginBottom:8}}><b>{reportName}</b><select value={previewLimit} onChange={(e)=>setPreviewLimit(Number(e.target.value))} style={{...inputStyle(), width:110}}><option value={10}>10 صفوف</option><option value={25}>25 صف</option><option value={50}>50 صف</option><option value={100}>100 صف</option></select></div><table style={{width:"100%", borderCollapse:"collapse", fontSize:11}}><thead><tr>{cols.map((c)=><th key={c} style={{textAlign:"right", borderBottom:"1px solid #e5e7eb", padding:6, whiteSpace:"nowrap"}}>{c}</th>)}</tr></thead><tbody>{rowsForExport.slice(0, previewLimit).map((r,i)=><tr key={i}>{cols.map((c)=><td key={c} style={{borderBottom:"1px solid #f1f5f9", padding:6, maxWidth:160, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{valueText(r[c])}</td>)}</tr>)}</tbody></table>{rows.length>previewLimit && <div style={{fontSize:12, color:C.steel, marginTop:8}}>المعاينة تعرض أول {previewLimit} صف فقط، أما التصدير فيشمل كل الصفوف المفلترة.</div>}</div></Section>
    {byStatus.length === 0 ? <Empty text="ستظهر الرسوم عند توفر أوامر عمل." /> : (<><Section title="أوامر العمل حسب الحالة"><div style={{ ...card(), height: 220, padding: 8 }}><ResponsiveContainer><BarChart data={byStatus}><XAxis dataKey="name" tick={{ fontSize: 10 }} /><YAxis allowDecimals={false} width={24} /><Tooltip /><Bar dataKey="عدد" fill={C.orange} /></BarChart></ResponsiveContainer></div></Section>{byType.length > 0 && <Section title="وقائي / تصحيحي / طارئ"><div style={{ ...card(), height: 220, padding: 8 }}><ResponsiveContainer><PieChart><Pie data={byType} dataKey="value" nameKey="name" outerRadius={70} label>{byType.map((d, i) => <Cell key={i} fill={[C.green, C.amber, C.red][i]} />)}</Pie><Legend /><Tooltip /></PieChart></ResponsiveContainer></div></Section>}{techPerf.length > 0 && <Section title="أداء الفنيين"><div style={card()}>{techPerf.map((t) => (<div key={t.name} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}><span>{t.name}</span><span>{t.عمليات} عملية · {t.ساعات} ساعة</span></div>))}</div></Section>}{costByAsset.length > 0 && <Section title="تكلفة الصيانة حسب الأصل (ر.س)"><div style={{ ...card(), height: 220, padding: 8 }}><ResponsiveContainer><BarChart data={costByAsset} layout="vertical"><XAxis type="number" /><YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="تكلفة" fill={C.blue} /></BarChart></ResponsiveContainer></div></Section>}</>)}
  </>);
}

/* ───────────────────────── البيانات والنسخ ───────────────────────── */


/* ───────────────────────── QR Labels للأصول ───────────────────────── */
