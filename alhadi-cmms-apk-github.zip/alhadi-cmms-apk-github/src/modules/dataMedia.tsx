import { C, EMPTY, MEDIA_KINDS, isLocalMedia, isStorageMedia, mediaBytes, mediaSize, mediaSrc, now, uid } from "../core/appCore";
import { Btn, Empty, Row, Section, Stat, card, input } from "../components/ui";
import { Assets } from "./assets";

export function MediaStorageCenter({ ctx }) {
  const { db, firebaseEnabled, firebaseServices, can, migrateLocalMediaToStorage } = ctx;
  const assetPhotos = (db.assets || []).flatMap((a)=> (a.photos || []).map((p)=>({ ...p, entity:"assets", recordId:a.id, owner:a.number || a.name, kind:p.type || "أصل" })));
  const woPhotos = (db.workOrders || []).flatMap((w)=> (w.photos || []).map((p)=>({ ...p, entity:"workOrders", recordId:w.id, owner:w.number || w.title, kind:p.type || "أمر عمل" })));
  const registry = db.mediaFiles || [];
  const all = [...registry, ...assetPhotos, ...woPhotos].filter((m, i, arr)=> arr.findIndex((x)=>String(x.id||"")===String(m.id||""))===i);
  const storageCount = all.filter(isStorageMedia).length;
  const localCount = all.filter(isLocalMedia).length;
  const bytes = all.reduce((s,m)=>s+mediaBytes(m),0);
  const byKind = MEDIA_KINDS.map((k)=>[k, all.filter((m)=>String(m.kind || m.type || "").includes(k) || String(m.type || "")===k).length]).filter(([,n])=>n);
  return (
    <>
      <Section title="Firebase Storage للصور والمرفقات">
        <div style={{ ...card(), borderRightColor: firebaseEnabled ? C.green : C.amber }}>
          <Row main={firebaseEnabled ? "Storage جاهز داخل إعدادات Firebase" : "Firebase غير مفعّل"}
            sub={firebaseEnabled ? "Bucket: " + (firebaseServices?.config?.storageBucket || "—") + " · الصور الجديدة تُرفع إلى Storage ويحفظ Firestore الرابط فقط." : "فعّل Firebase أولًا من شاشة Firebase والصلاحيات."}
            badge={{ text: firebaseEnabled ? "نشط" : "إعداد مطلوب", color: firebaseEnabled ? C.green : C.amber }} />
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8 }}>
          <Stat n={all.length} label="ملف" color={C.ink} small />
          <Stat n={storageCount} label="Storage" color={C.green} small />
          <Stat n={localCount} label="محلي/Base64" color={localCount ? C.amber : C.steel} small />
          <Stat n={mediaSize(bytes)} label="حجم تقريبي" color={C.purple} small />
        </div>
      </Section>

      {ctx.canUseSetupTools && <Section title="ترحيل الصور القديمة إلى Storage">
        <div style={card()}>
          <div style={{ fontSize:13, color:C.steel, lineHeight:1.8 }}>
            الصور القديمة التي ما زالت مخزنة كـ Base64 يمكن رفعها إلى Firebase Storage، ثم يُستبدل محتواها داخل Firestore برابط فقط. هذا يقلل حجم قاعدة البيانات ويسرّع تسجيل الدخول والمزامنة.
          </div>
          <Btn bg={C.green} onClick={migrateLocalMediaToStorage} style={{ width:"100%", padding:12, marginTop:10, opacity: firebaseEnabled && (can.admin || can.manage) ? 1 : .55 }}>رفع الصور المحلية إلى Firebase Storage</Btn>
        </div>
      </Section>}

      <Section title="توزيع الملفات حسب النوع">
        {byKind.length ? byKind.map(([k,n])=><div key={k} style={card()}><Row main={k} sub={n + " ملف"} badge={{text:String(n), color:C.blue}} /></div>) : <Empty text="لا توجد ملفات مصنفة بعد." />}
      </Section>

      <Section title="آخر الملفات">
        {all.slice().reverse().slice(0,30).map((m)=><div key={(m.id||m.storagePath||Math.random())} style={{...card(), borderRightColor:isStorageMedia(m)?C.green:C.amber}}>
          <Row main={(m.kind || m.type || "ملف") + " — " + (m.owner || m.name || m.originalName || "بدون اسم")}
            sub={[m.entity, m.recordId, mediaSize(mediaBytes(m)), m.uploadedAtIso || m.at, isStorageMedia(m)?"Firebase Storage":"محلي/Base64"].filter(Boolean).join(" · ")}
            badge={{text:isStorageMedia(m)?"Storage":"محلي", color:isStorageMedia(m)?C.green:C.amber}} />
          {mediaSrc(m) && String(m.contentType || "image").startsWith("image") && <img src={mediaSrc(m)} alt="" style={{ width:"100%", maxHeight:180, objectFit:"cover", borderRadius:14, marginTop:8 }} />}
        </div>)}
        {!all.length && <Empty text="لا توجد صور أو مرفقات بعد." />}
      </Section>
    </>
  );
}

export function DataTab({ exportData, importData, exportAssetsCSV, db, can, save, productionMode=false, canUseSetupTools=false, canUseDangerousTools=false }) {
  const counts = Object.values(db).filter(Array.isArray).reduce((a, v) => a + v.length, 0);
  const importAssetsCsv = (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      const lines = String(reader.result || "").split(/\r?\n/).filter((l) => l.trim());
      if (lines.length < 2) return alert("ملف CSV فارغ");
      const headers = lines[0].split(",").map((h) => h.trim());
      const rows = lines.slice(1).map((line) => {
        const cells = line.split(",");
        const r = {}; headers.forEach((h, i) => r[h] = (cells[i] || "").trim());
        return r;
      });
      const imported = []; const skipped = [];
      rows.forEach((r) => {
        const number = r.number || r.asset_number || r["رقم الأصل"] || "";
        const name = r.name || r.description || r["اسم الأصل"] || "";
        if (!name) { skipped.push(number || "بدون اسم"); return; }
        if (number && db.assets.some((a) => a.number === number)) { skipped.push(number + " مكرر"); return; }
        imported.push({ id:uid(), number: number || "AST-" + String(2000 + db.assets.length + imported.length + 1), name, location: r.location || r["الموقع"] || "Unknown", locationType: r.locationType || "UNKNOWN", type: r.type || "معدات", ownership: r.ownership || "مؤسسة", assetType: (r.ownership || "") === "عميل" ? "CUSTOMER" : "ENTERPRISE", serial: r.serial || "", itemName: r.itemName || r.item || "", itemRequired:false, quantity:Number(r.quantity || 1), parts:[], docs:[], photos:[], notes:[], history:[{ action:"استيراد CSV", at:now(), by:"استيراد" }], allowWO:true, allowPrograms:true, active:true });
      });
      save({ ...db, assets:[...db.assets, ...imported], assetImportBatches:[...(db.assetImportBatches || []), { id:uid(), at:now(), source:file.name, imported:imported.length, skipped:skipped.length, notes: skipped.join("; ") }] });
      alert("تم استيراد " + imported.length + " أصل. المتروك: " + skipped.length);
    };
    reader.readAsText(file);
  };
  return (
    <>
      <Section title="نسخة احتياطية">
        <div style={card()}>
          <div style={{ fontSize: 13, color: C.steel, marginBottom: 8 }}>
            لديك {counts} سجلًا. نزّل JSON أو استورده؛ البيانات الآن تُحفظ في الـ Backend عند توفره مع نسخة محلية احتياطية.
          </div>
          <Btn bg={C.blue} onClick={exportData} style={{ width: "100%", padding: 12, marginBottom: 8 }}>تنزيل نسخة احتياطية (JSON)</Btn>
          <Btn bg={C.purple} onClick={exportAssetsCSV} style={{ width: "100%", padding: 12 }}>تصدير سجل الأصول (CSV)</Btn>
        </div>
      </Section>
      {canUseSetupTools ? <>
        <Section title="استيراد">
          <div style={card()}>
            <input type="file" accept=".json" onChange={(e) => e.target.files[0] && importData(e.target.files[0])} style={{ fontSize: 14 }} />
          </div>
        </Section>
        <Section title="استيراد أصول CSV — فصل 3 Import Assets">
          <div style={{ ...card(), fontSize:13, color:C.steel }}>الأعمدة المقبولة: number,name,location,type,ownership,serial,itemName,quantity. يتم تجاهل الأرقام المكررة وتسجيل دفعة الاستيراد.</div>
          <input type="file" accept=".csv,text/csv" onChange={(e) => e.target.files[0] && importAssetsCsv(e.target.files[0])} />
          {(db.assetImportBatches || []).slice().reverse().map((b) => <div key={b.id} style={card()}><Row main={b.source + " — " + b.imported + " مستورد"} sub={b.at + " · متروك: " + b.skipped + (b.notes ? " · " + b.notes : "")} /></div>)}
        </Section>
      </> : <Section title="قفل الإنتاج">
        <div style={{ ...card(), borderRightColor: productionMode ? C.green : C.amber, fontSize:13, color:C.steel, lineHeight:1.8 }}>
          أدوات الاستيراد والترحيل مخفية في وضع الإنتاج. المتاح هنا هو التصدير والنسخ الاحتياطي فقط. لتفعيل أدوات الإعداد مؤقتًا استخدم بناء تدريب خاص بمتغير <b>VITE_CMMS_SHOW_SETUP_TOOLS=true</b>.
        </div>
      </Section>}
      {canUseDangerousTools && (
        <Section title="منطقة الخطر">
          <div style={{ ...card(), borderRightColor: C.red }}>
            <Btn bg={C.red} onClick={() => { if (confirm("حذف كل البيانات نهائيًا؟")) save({ ...EMPTY }); }} style={{ width: "100%", padding: 12 }}>مسح كل البيانات</Btn>
          </div>
        </Section>
      )}
    </>
  );
}

/* ───────────────────────── CRUD عام ───────────────────────── */
