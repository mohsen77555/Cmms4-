import { useState } from "react";
import { C, REQ_FLOW, today } from "../core/appCore";
import { Badge, Btn, Empty, Row, card, delBtn } from "../components/ui";
import { FormSheet } from "./crud";

export function Requests({ ctx, actRequest }) {
  const { db, nameOf, add, remove, can } = ctx;
  const [form, setForm] = useState(false);
  return (
    <>
      <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ طلب عمل جديد</Btn>
      {db.workRequests.length === 0 && <Empty text="لاحظ المشغّل صوتًا غير طبيعي؟ يرفع طلب عمل من هنا." />}
      {db.workRequests.map((r) => (
        <div key={r.id} style={card()}>
          <Row main={r.title} sub={nameOf("assets", r.assetId) + " · خطورة " + r.severity + (r.desc ? " · " + r.desc : "")}
            badge={{ text: r.status, color: { "مفتوح": C.amber, "مقبول": C.blue, "محوّل": C.green, "مرفوض": C.red }[r.status] }} />
          {can.manage && (
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              {(REQ_FLOW[r.status] || []).map((a) => (
                <Btn key={a} bg={a === "رفض" ? C.red : a === "قبول" ? C.blue : C.green} onClick={() => actRequest(r, a)}>{a}</Btn>
              ))}
              <button onClick={() => remove("workRequests", r.id)} style={delBtn}>حذف</button>
            </div>
          )}
        </div>
      ))}
      {form && (
        <FormSheet title="طلب عمل" onClose={() => setForm(false)} db={db}
          schema={[
            { k: "title", label: "وصف المشكلة (صوت غير طبيعي…)" },
            { k: "assetId", label: "الأصل", type: "select", from: "assets", fromKey: "name" },
            { k: "severity", label: "الخطورة", type: "select", options: ["منخفضة", "متوسطة", "حرجة"] },
            { k: "desc", label: "تفاصيل إضافية", type: "textarea" },
          ]} initial={{ severity: "متوسطة" }}
          onSave={(d) => {
            const exc = ctx.assetExclusion(d.assetId);
            if (exc.requests) { alert("⛔ الأصل مستبعد من طلبات العمل بواسطة مجموعة «" + exc.groupName + "»"); return; }
            add("workRequests", { status: "مفتوح", createdAt: today(), ...d }); setForm(false);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── البرامج الوقائية ───────────────────────── */
export function Programs({ ctx, programDue, generateWO }) {
  const { db, nameOf, add, remove, programAssets } = ctx;
  const [form, setForm] = useState(false);
  return (
    <>
      <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ متطلب صيانة وقائية</Btn>
      {db.programs.length === 0 && <Empty text="مثال: مراوح الصوامع — كل 500 ساعة تشغيل ← أمر عمل تلقائي." />}
      {db.programs.map((p) => {
        const info = programDue(p);
        return (
          <div key={p.id} style={{ ...card(), borderRightColor: info.due ? C.red : info.soon ? C.amber : C.ink }}>
            <Row main={p.name}
              sub={[(p.targetType === "مجموعة" ? "مجموعة " + nameOf("assetGroups", p.assetGroupId) + " (" + programAssets(p).length + " أصل)" : nameOf("assets", p.assetId)),
                p.method + " كل " + p.interval, info.label].join(" · ")}
              action={info.due
                ? <Btn bg={C.orange} onClick={() => generateWO(p)}>إنشاء</Btn>
                : <Badge text={info.soon ? "قريبًا ⏳" : "غير مستحق"} color={info.soon ? C.amber : C.steel} />} />
            <button onClick={() => remove("programs", p.id)} style={delBtn}>حذف</button>
          </div>
        );
      })}
      {form && (
        <FormSheet title="متطلب وقائي" onClose={() => setForm(false)} db={db}
          schema={[
            { k: "name", label: "اسم المتطلب (فحص شهري للمصاعد…)" },
            { k: "targetType", label: "يطبق على", type: "select", options: ["أصل واحد", "مجموعة"] },
            { k: "assetId", label: "الأصل (لو أصل واحد)", type: "select", from: "assets", fromKey: "name" },
            { k: "assetGroupId", label: "المجموعة (لو مجموعة)", type: "select", from: "assetGroups", fromKey: "name" },
            { k: "workDefId", label: "تعريف العمل (قالب PM)", type: "select", from: "workDefs", fromKey: "name" },
            { k: "method", label: "طريقة التوقع", type: "select", options: ["فاصل أيام", "فاصل عداد"] },
            { k: "interval", label: "الفاصل (أيام أو وحدات عداد)", type: "number" },
            { k: "assetMeterId", label: "عداد الأصل (لطريقة العداد — أصل واحد فقط)", type: "select", from: "assetMeters",
              fromLabel: (m) => nameOf("assets", m.assetId) + " / " + nameOf("meterTemplates", m.templateId) },
            { k: "startDate", label: "تاريخ البداية", type: "date" },
          ]} initial={{ targetType: "أصل واحد", method: "فاصل أيام", startDate: today() }}
          onSave={(d) => {
            if (d.targetType === "مجموعة" && d.method === "فاصل عداد") { alert("طريقة العداد تعمل مع أصل واحد فقط — استخدم فاصل الأيام للمجموعات"); return; }
            if (d.targetType === "مجموعة" && !d.assetGroupId) { alert("اختر المجموعة"); return; }
            add("programs", { lastMeterValue: 0, ...d }); setForm(false);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── الهرميات المنطقية ومسارات الأصول (ف3 §14) ───────────────────────── */
export function LogicalHierarchies({ ctx, openAsset }) {
  const { db, add, update, remove, nameOf, can, createWO, assetUsable } = ctx;
  const [form, setForm] = useState(null);
  const topmostOnly = (a) => !a.parentId; /* لا تضف فرعًا ماديًا — الأب الأعلى فقط */
  return (
    <>
      <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 8 }}>
        الهرمية المنطقية تجمع أصولًا عبر المواقع (مصنع، خط، أسطول). فعّل «مسار أصول» لصيانة المجموعة بأمر عمل واحد.
      </div>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ هرمية منطقية / مسار</Btn>}
      {db.logicalHierarchies.length === 0 && <Empty text="مثال مسار: «فحص طفايات المبنى أ» — كل الطفايات في قائمة أمر عمل واحد مع سماح بالتخطي." />}
      {db.logicalHierarchies.map((h) => (
        <div key={h.id} style={{ ...card(), borderRightColor: h.assetRoute ? C.purple : C.ink, opacity: h.disabled ? 0.6 : 1 }}>
          <Row main={(h.code ? h.code + " — " : "") + h.name}
            badge={h.assetRoute ? { text: "مسار أصول", color: C.purple } : h.disabled ? { text: "معطلة", color: C.steel } : undefined}
            sub={[(h.nodes || []).length + " أصل", h.allowSkip ? "يسمح بالتخطي" : ""].filter(Boolean).join(" · ")} />
          <div style={{ display: "flex", gap: 10, marginTop: 6, flexWrap: "wrap" }}>
            {can.manage && <button onClick={() => setForm(h)} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>تعديل</button>}
            {can.manage && h.assetRoute && !h.disabled && (h.nodes || []).length > 0 && (
              <Btn bg={C.purple} onClick={() => {
                const nodes = (h.nodes || []).filter((id) => assetUsable(db.assets.find((x) => x.id === id)));
                if (!nodes.length) { alert("لا أصول صالحة في المسار"); return; }
                createWO({ title: "مسار — " + h.name, assetId: nodes[0], type: "وقائي", priority: "عادية",
                  plannedStart: today(), safetyRequired: true, routeId: h.id,
                  routeAssets: nodes.map((id) => ({ assetId: id, status: "معلق" })) });
                alert("✓ أُنشئ أمر عمل المسار يشمل " + nodes.length + " أصل");
              }}>إنشاء أمر عمل للمسار</Btn>
            )}
            {can.admin && <button onClick={() => { if (confirm("حذف الهرمية؟")) remove("logicalHierarchies", h.id); }} style={{ ...delBtn, marginTop: 0 }}>حذف</button>}
          </div>
        </div>
      ))}
      {form && (
        <FormSheet title={form === "new" ? "هرمية منطقية جديدة" : "تعديل هرمية"} onClose={() => setForm(null)} db={db}
          schema={[
            { k: "name", label: "الاسم (خط الطحن 1، أسطول الرياض…)" }, { k: "code", label: "الكود (فريد)" },
            { k: "description", label: "الوصف", type: "textarea" },
            { k: "assetRoute", label: "مسار أصول (صيانة المجموعة بأمر واحد)", type: "check" },
            { k: "allowSkip", label: "السماح بتخطي أصل أثناء التنفيذ", type: "check" },
            { k: "disabled", label: "معطلة", type: "check" },
            { k: "nodes", label: "الأصول (الأب الأعلى فقط — لا فروع مادية)", type: "multi", from: "assets", fromKey: "name" },
          ]} initial={form === "new" ? { nodes: [] } : form}
          onSave={(d) => {
            if (!String(d.name || "").trim()) { alert("الاسم مطلوب"); return; }
            if (d.code && db.logicalHierarchies.some((x) => x.code === d.code && x.id !== form?.id)) { alert("الكود مستخدم"); return; }
            const bad = (d.nodes || []).map((id) => db.assets.find((a) => a.id === id)).filter((a) => a && a.parentId);
            if (bad.length) { alert("هذه الأصول فروع مادية — أضف الأب الأعلى فقط:\n• " + bad.map((a) => a.name).join("\n• ")); return; }
            form === "new" ? add("logicalHierarchies", d) : update("logicalHierarchies", form.id, d);
            setForm(null);
          }} />
      )}
    </>
  );
}

/* ───────────────────────── مركز ضمان المورد (ف6) ───────────────────────── */
