import { useState } from "react";
import { C, CLAIM_STATUS, COV_TYPES, DUR_UOM, addDateDays, fmt, money, today, uid } from "../core/appCore";
import { AddInline, Badge, Btn, Chip, Empty, Field, Row, Section, Sheet, card, delBtn, input } from "../components/ui";
import { Crud, FormSheet } from "./crud";

export function WarrantyHub({ ctx, openWO }) {
  const { db, add, update, remove, nameOf, can, contractState, contractEffectiveEnd, contractCalcExpiration } = ctx;
  const [sub, setSub] = useState("العقود");
  const [covDetail, setCovDetail] = useState(null);
  const [claimDetail, setClaimDetail] = useState(null);
  const [contractForm, setContractForm] = useState(false);
  const SUBS = ["العقود", "التغطيات", "المطالبات", "الاستحقاقات", "أسعار العمالة", "أزمنة الإصلاح", "الموردون"];
  const stateColor = { "جاهز": C.green, "مسودة": C.steel, "منتهٍ": C.red };
  return (
    <>
      <div style={{ display: "flex", gap: 6, overflowX: "auto", marginBottom: 12 }}>
        {SUBS.map((s) => <Chip key={s} active={sub === s} onClick={() => setSub(s)}>{s}</Chip>)}
      </div>

      {sub === "الموردون" && (
        <Crud ctx={ctx} entity="warrantyProviders" title="موردو الضمان" schema={[
          { k: "name", label: "اسم مورد الضمان / OEM" }, { k: "number", label: "رقم المورد" },
        ]} render={(p) => [p.name, p.number || ""]} />
      )}

      {sub === "أسعار العمالة" && (
        <Crud ctx={ctx} entity="laborRates" title="أسعار تعويض العمالة" schema={[
          { k: "providerId", label: "مورد الضمان", type: "select", from: "warrantyProviders", fromKey: "name" },
          { k: "hourlyRate", label: "سعر الساعة (ر.س)", type: "number" },
          { k: "startDate", label: "بداية السريان (≤ بداية العقد)", type: "date" },
          { k: "endDate", label: "نهاية السريان", type: "date" },
          { k: "active", label: "نشط", type: "check" },
        ]} render={(r) => [nameOf("warrantyProviders", r.providerId) + " — " + money(r.hourlyRate) + "/ساعة",
          fmt(r.startDate) + " ← " + (r.endDate ? fmt(r.endDate) : "مفتوح")]}
          badge={(r) => ({ text: r.active === false ? "موقوف" : "نشط", color: r.active === false ? C.steel : C.green })} />
      )}

      {sub === "أزمنة الإصلاح" && (
        <Crud ctx={ctx} entity="repairTimes" title="أزمنة الإصلاح القياسية" schema={[
          { k: "providerId", label: "مورد الضمان", type: "select", from: "warrantyProviders", fromKey: "name" },
          { k: "stdOpId", label: "العملية القياسية", type: "select", from: "stdOps", fromLabel: (o) => o.code + " — " + o.name },
          { k: "hours", label: "ساعات الإصلاح القابلة للتعويض", type: "number" },
          { k: "startDate", label: "بداية السريان", type: "date" },
          { k: "active", label: "نشط", type: "check" },
        ]} render={(t) => [nameOf("stdOps", t.stdOpId, "name") + " — " + t.hours + " ساعة",
          nameOf("warrantyProviders", t.providerId)]} />
      )}

      {sub === "التغطيات" && (<>
        {can.manage && <Btn bg={C.orange} onClick={() => setCovDetail("new")} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ قالب تغطية جديد</Btn>}
        {db.coverages.length === 0 && <Empty text="التغطية قالب reusable: المدة و/أو فاصل عداد + شروط التعويض + أكواد الإصلاح المغطاة." />}
        {db.coverages.map((v) => (
          <div key={v.id} style={{ ...card(), borderRightColor: v.status === "جاهز" ? C.green : C.steel }} onClick={() => setCovDetail(v.id)}>
            <Row main={v.code + " — " + v.name} badge={{ text: v.status, color: v.status === "جاهز" ? C.green : C.steel }}
              sub={[nameOf("warrantyProviders", v.providerId), v.duration ? v.duration + " " + v.durationUom : "",
                (v.meters || []).length ? (v.meters || []).length + " عداد" : "",
                db.contracts.filter((c) => c.coverageId === v.id).length + " عقد"].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {sub === "العقود" && (<>
        {can.manage && <Btn bg={C.orange} onClick={() => setContractForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ عقد ضمان لأصل</Btn>}
        {db.contracts.length === 0 && <Empty text="العقد ينشأ من تغطية «جاهز» لأصل محدد — وينتهي بالمدة أو العداد أيهما أقرب." />}
        {db.contracts.map((c) => {
          const st = contractState(c);
          const calc = contractCalcExpiration(c);
          return (
            <div key={c.id} style={{ ...card(), borderRightColor: stateColor[st] }}>
              <Row main={c.number + " — " + nameOf("assets", c.assetId)} badge={{ text: st, color: stateColor[st] }}
                sub={[nameOf("coverages", c.coverageId), "يبدأ " + fmt(c.startDate),
                  c.endDate ? "ينتهي " + fmt(c.endDate) : "", calc ? "متوقع بالعداد: " + fmt(calc) : ""].filter(Boolean).join(" · ")} />
              {can.manage && (
                <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
                  {c.status === "مسودة" && <Btn bg={C.green} onClick={() => update("contracts", c.id, { status: "جاهز" })}>جاهز</Btn>}
                  <button onClick={() => { if (confirm("حذف العقد؟")) remove("contracts", c.id); }} style={delBtn}>حذف</button>
                </div>
              )}
            </div>
          );
        })}
      </>)}

      {sub === "المطالبات" && (<>
        {db.claims.length === 0 && <Empty text="المطالبات تُنشأ من زر «توليد الاستحقاقات» داخل أمر العمل ← تبويب الضمان." />}
        {db.claims.map((cl) => {
          const ents = db.entitlements.filter((e) => e.claimId === cl.id);
          const total = ents.reduce((s, e) => s + Number(e.total || 0), 0) + (cl.adjustments || []).reduce((s, a) => s + Number(a.amount || 0), 0);
          return (
            <div key={cl.id} style={card()} onClick={() => setClaimDetail(cl.id)}>
              <Row main={cl.number + " — " + nameOf("warrantyProviders", cl.providerId)}
                badge={{ text: cl.status, color: { "قيد المراجعة": C.amber, "مُقدمة": C.blue, "محلولة": C.green, "مرفوضة": C.red }[cl.status] || C.steel }}
                sub={[db.workOrders.find((w) => w.id === cl.workOrderId)?.number, ents.length + " استحقاق", money(total)].filter(Boolean).join(" · ")} />
            </div>
          );
        })}
      </>)}

      {sub === "الاستحقاقات" && (<>
        {db.entitlements.length === 0 && <Empty text="الاستحقاق = نفقة مادة/مورد/إصلاح قياسي قابلة أو غير قابلة للتعويض." />}
        {db.entitlements.slice().reverse().map((e) => (
          <div key={e.id} style={{ ...card(), borderRightColor: e.included ? C.green : C.steel }}>
            <Row main={e.type + " — " + e.description} badge={e.included ? { text: "ضمن مطالبة", color: C.green } : { text: "مستبعد", color: C.steel }}
              sub={[e.qty + " × " + money(e.unitCost) + " = " + money(e.total),
                db.workOrders.find((w) => w.id === e.workOrderId)?.number,
                e.contractId ? db.contracts.find((c) => c.id === e.contractId)?.number : "بدون عقد (لا مطابقة)"].filter(Boolean).join(" · ")} />
          </div>
        ))}
      </>)}

      {covDetail && <CoverageDetail ctx={ctx} covId={covDetail} onClose={() => setCovDetail(null)} />}
      {claimDetail && <ClaimDetail ctx={ctx} claimId={claimDetail} onClose={() => setClaimDetail(null)} openWO={openWO} />}
      {contractForm && (
        <FormSheet title="عقد ضمان جديد" onClose={() => setContractForm(false)} db={db}
          schema={[
            { k: "assetId", label: "الأصل", type: "select", from: "assets", fromLabel: (a) => a.number + " — " + a.name },
            { k: "coverageId", label: "التغطية (جاهز فقط)", type: "select", from: "coverages", fromLabel: (v) => v.code + " — " + v.name + (v.status !== "جاهز" ? " (مسودة ✗)" : "") },
            { k: "startDate", label: "بداية التغطية", type: "date" },
            { k: "extRef", label: "مرجع خارجي (رقم أمر الشراء…)" },
            { k: "notes", label: "ملاحظات العقد", type: "textarea" },
          ]} initial={{ startDate: today() }}
          onSave={(d) => {
            if (!d.assetId || !d.coverageId) { alert("اختر الأصل والتغطية"); return; }
            const cov = db.coverages.find((v) => v.id === d.coverageId);
            if (cov.status !== "جاهز") { alert("التغطية مسودة — يجب أن تكون «جاهز» لإنشاء عقود (قاعدة ف6)"); return; }
            let endDate = "";
            if (cov.duration) {
              endDate = addDateDays(d.startDate || today(), Number(cov.duration || 0) * (DUR_UOM[cov.durationUom] || 1));
            }
            /* عدادات التغطية يجب أن تطابق عدادات الأصل، وإلا يبقى العقد مسودة للمراجعة */
            const meters = (cov.meters || []).filter((m) => m.enabled !== false).map((m) => ({ ...m }));
            const mismatch = meters.some((m) => !db.assetMeters.some((am) => am.assetId === d.assetId && am.templateId === m.templateId));
            add("contracts", { number: "CW-" + String(1000 + db.contracts.length + 1), status: mismatch ? "مسودة" : "جاهز",
              endDate, meters, ...d });
            if (mismatch) alert("⚠ عدادات التغطية لا تطابق عدادات الأصل — أُنشئ العقد كمسودة للمراجعة");
            setContractForm(false);
          }} />
      )}
    </>
  );
}

export function CoverageDetail({ ctx, covId, onClose }) {
  const { db, add, update, nameOf, can } = ctx;
  const isNew = covId === "new";
  const v = isNew ? null : db.coverages.find((x) => x.id === covId);
  const [f, setF] = useState(isNew ? { status: "مسودة", durationUom: "شهر", laborReimb: true, partsReimb: true, startDate: today() } : null);
  const hasContracts = v ? db.contracts.some((c) => c.coverageId === v.id) : false;
  if (isNew) {
    return (
      <FormSheet title="قالب تغطية — الأساسيات" onClose={onClose} db={db}
        schema={[
          { k: "code", label: "الكود (فريد، لا يتغير بعد الإنشاء)" }, { k: "name", label: "اسم التغطية" },
          { k: "description", label: "الوصف", type: "textarea" },
          { k: "providerId", label: "مورد الضمان (إلزامي)", type: "select", from: "warrantyProviders", fromKey: "name" },
          { k: "type", label: "نوع التغطية", type: "select", options: COV_TYPES },
          { k: "startDate", label: "بداية القالب", type: "date" }, { k: "endDate", label: "نهاية القالب (يمنع عقودًا جديدة)", type: "date" },
          { k: "duration", label: "مدة الضمان (اتركها فارغة لو عداد فقط)", type: "number" },
          { k: "durationUom", label: "وحدة المدة", type: "select", options: Object.keys(DUR_UOM) },
          { k: "laborReimb", label: "تعويض العمالة (الموارد تدخل المطالبة)", type: "check" },
          { k: "partsReimb", label: "تعويض القطع (المواد تدخل المطالبة)", type: "check" },
          { k: "terms", label: "شروط الخدمة (نص حر)", type: "textarea" },
        ]} initial={f}
        onSave={(d) => {
          if (!d.code || !d.name) { alert("الكود والاسم مطلوبان"); return; }
          if (db.coverages.some((x) => x.code === d.code)) { alert("الكود مستخدم"); return; }
          if (!d.providerId) { alert("مورد الضمان إلزامي"); return; }
          add("coverages", { status: "مسودة", meters: [], repairCodes: [], items: [], ...d });
          onClose();
        }} />
    );
  }
  if (!v) return null;
  return (
    <Sheet title={v.code + " — " + v.name} onClose={onClose}>
      <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
        <Badge text={v.status} color={v.status === "جاهز" ? C.green : C.steel} />
        {can.manage && v.status === "مسودة" && (
          <Btn bg={C.green} onClick={() => {
            if (!v.duration && !(v.meters || []).some((m) => m.enabled !== false)) { alert("«جاهز» يتطلب مدة أو فاصل عداد — العقد يحتاج طريقة انتهاء (قاعدة ف6)"); return; }
            update("coverages", v.id, { status: "جاهز" });
          }}>تحويل إلى جاهز</Btn>
        )}
        {can.manage && v.status === "جاهز" && !hasContracts && <Btn bg={C.steel} onClick={() => update("coverages", v.id, { status: "مسودة" })}>إرجاع لمسودة</Btn>}
        {hasContracts && <span style={{ fontSize: 12, color: C.steel, alignSelf: "center" }}>توجد عقود — لا رجوع لمسودة ولا حذف صفوف (عطّل بدلًا منه)</span>}
      </div>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        المورد: <b>{nameOf("warrantyProviders", v.providerId)}</b> · النوع: <b>{v.type || "—"}</b><br />
        المدة: <b>{v.duration ? v.duration + " " + v.durationUom : "—"}</b> · تعويض العمالة: <b>{v.laborReimb ? "نعم" : "لا"}</b> · تعويض القطع: <b>{v.partsReimb ? "نعم" : "لا"}</b>
        {v.terms && <><br />الشروط: {v.terms}</>}
      </div>
      <Section title={"عدادات الاستخدام (" + (v.meters || []).length + ") — ينتهي العقد بالأقرب"}>
        {(v.meters || []).map((m) => (
          <div key={m.id} style={{ ...card(), opacity: m.enabled === false ? 0.5 : 1 }}>
            <Row main={nameOf("meterTemplates", m.templateId)} sub={"من " + m.startValue + " + فاصل " + m.interval + " = نهاية " + (Number(m.startValue || 0) + Number(m.interval || 0))}
              action={can.manage && m.enabled !== false ? <Btn bg={C.steel} onClick={() => update("coverages", v.id, { meters: v.meters.map((x) => x.id === m.id ? { ...x, enabled: false } : x) })}>تعطيل</Btn> : m.enabled === false ? <Badge text="معطل" color={C.steel} /> : null} />
          </div>
        ))}
        {can.manage && <CovMeterForm ctx={ctx} onAdd={(m) => update("coverages", v.id, { meters: [...(v.meters || []), { id: uid(), enabled: true, ...m }] })} />}
      </Section>
      <Section title={"أكواد الإصلاح المغطاة (" + (v.repairCodes || []).length + ")"}>
        <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 6 }}>مثال: 013 فرامل ← 013-001 فرامل أمامية. الكود الأعلى يغطي ما تحته.</div>
        {(v.repairCodes || []).map((r) => (
          <div key={r.id} style={{ ...card(), opacity: r.enabled === false ? 0.5 : 1 }}>
            <Row main={r.code} sub={r.description}
              action={can.manage && r.enabled !== false ? <Btn bg={C.steel} onClick={() => update("coverages", v.id, { repairCodes: v.repairCodes.map((x) => x.id === r.id ? { ...x, enabled: false } : x) })}>تعطيل</Btn> : r.enabled === false ? <Badge text="معطل" color={C.steel} /> : null} />
          </div>
        ))}
        {can.manage && <AddInline placeholder="الكود، الوصف (ELV-BRG، محامل المصاعد)" onAdd={(t) => {
          const seg = t.includes("،") ? t.split("،") : t.split(",");
          update("coverages", v.id, { repairCodes: [...(v.repairCodes || []), { id: uid(), code: (seg[0] || t).trim(), description: (seg[1] || "").trim(), enabled: true }] });
        }} />}
      </Section>
      <Section title={"العقود المنشأة (" + db.contracts.filter((c) => c.coverageId === v.id).length + ")"}>
        {db.contracts.filter((c) => c.coverageId === v.id).map((c) => (
          <div key={c.id} style={card()}><Row main={c.number + " — " + nameOf("assets", c.assetId)} sub={"يبدأ " + fmt(c.startDate)} /></div>
        ))}
      </Section>
    </Sheet>
  );
}

export function CovMeterForm({ ctx, onAdd }) {
  const { db } = ctx;
  const [tpl, setTpl] = useState(""); const [start, setStart] = useState("0"); const [intv, setIntv] = useState("");
  return (
    <div style={card()}>
      <div style={{ display: "flex", gap: 8 }}>
        <Field label="قالب العداد">
          <select value={tpl} onChange={(e) => setTpl(e.target.value)} style={input}>
            <option value="">—</option>
            {db.meterTemplates.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.uom})</option>)}
          </select>
        </Field>
        <Field label="البداية"><input type="number" value={start} onChange={(e) => setStart(e.target.value)} style={input} /></Field>
        <Field label="الفاصل (5000…)"><input type="number" value={intv} onChange={(e) => setIntv(e.target.value)} style={input} /></Field>
      </div>
      <Btn bg={C.ink} style={{ width: "100%" }} onClick={() => {
        if (!tpl || !Number(intv)) { alert("اختر العداد وأدخل الفاصل"); return; }
        onAdd({ templateId: tpl, startValue: Number(start || 0), interval: Number(intv) });
        setTpl(""); setStart("0"); setIntv("");
      }}>+ إضافة فاصل عداد</Btn>
    </div>
  );
}

export function ClaimDetail({ ctx, claimId, onClose, openWO }) {
  const { db, update, remove, nameOf, can, woCost } = ctx;
  const cl = db.claims.find((x) => x.id === claimId);
  const [adj, setAdj] = useState("");
  if (!cl) return null;
  const wo = db.workOrders.find((w) => w.id === cl.workOrderId);
  const allEnts = db.entitlements.filter((e) => e.workOrderId === cl.workOrderId);
  const inc = allEnts.filter((e) => e.claimId === cl.id);
  const adjTotal = (cl.adjustments || []).reduce((s, a) => s + Number(a.amount || 0), 0);
  const total = inc.reduce((s, e) => s + Number(e.total || 0), 0) + adjTotal;
  const byType = {};
  inc.forEach((e) => { byType[e.type] = (byType[e.type] || 0) + Number(e.total || 0); });
  const woTotal = wo ? woCost(wo).total : 0;
  return (
    <Sheet title={"مطالبة " + cl.number} onClose={onClose}>
      <div style={{ ...card(), fontSize: 13.5, lineHeight: 2 }}>
        المورد: <b>{nameOf("warrantyProviders", cl.providerId)}</b> · الأمر: <b style={{ textDecoration: "underline" }} onClick={() => wo && openWO(wo.id)}>{wo?.number || "—"}</b><br />
        مبلغ المطالبة: <b>{money(total)}</b> · تكلفة الأمر: <b>{money(woTotal)}</b>
        {total !== woTotal && <span style={{ color: C.amber }}> (الفرق = معاملات لم تدخل المطالبة)</span>}
      </div>
      {can.manage && (<>
        <div style={{ display: "flex", gap: 8 }}>
          <Field label="حالة المطالبة">
            <select value={cl.status} onChange={(e) => update("claims", cl.id, { status: e.target.value, ...(e.target.value === "محلولة" ? { resolutionDate: today() } : {}) })} style={input}>
              {CLAIM_STATUS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="موعد التقديم"><input type="date" value={cl.submitBy || ""} onChange={(e) => update("claims", cl.id, { submitBy: e.target.value })} style={input} /></Field>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Field label="المسؤول"><input value={cl.assignedTo || ""} onChange={(e) => update("claims", cl.id, { assignedTo: e.target.value })} style={input} /></Field>
          <Field label="مبلغ التعويض الفعلي"><input type="number" value={cl.reimbursementAmount || ""} onChange={(e) => update("claims", cl.id, { reimbursementAmount: e.target.value })} style={input} /></Field>
        </div>
      </>)}
      <Section title={"الاستحقاقات — إدخال/إخراج (" + inc.length + "/" + allEnts.length + ")"}>
        {allEnts.map((e) => {
          const isIn = e.claimId === cl.id;
          return (
            <div key={e.id} style={{ ...card(), borderRightColor: isIn ? C.green : C.steel, opacity: isIn ? 1 : 0.65 }}>
              <Row main={e.type + " — " + e.description} sub={e.qty + " × " + money(e.unitCost) + " = " + money(e.total) + (e.contractId ? "" : " · بدون عقد")}
                action={can.manage ? (isIn
                  ? <Btn bg={C.steel} onClick={() => update("entitlements", e.id, { claimId: "", included: false })}>إخراج</Btn>
                  : <Btn bg={C.green} onClick={() => update("entitlements", e.id, { claimId: cl.id, included: true })}>إدخال</Btn>) : null} />
            </div>
          );
        })}
      </Section>
      <Section title="مراجعة المبالغ">
        <div style={card()}>
          {Object.entries(byType).map(([t, s]) => (
            <div key={t} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4 }}><span>{t}</span><b>{money(s)}</b></div>
          ))}
          {(cl.adjustments || []).map((a, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 14, marginBottom: 4, color: C.amber }}><span>تعديل: {a.desc}</span><b>{money(a.amount)}</b></div>
          ))}
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 15, borderTop: `1px solid ${C.line}`, paddingTop: 6, fontWeight: 800 }}>
            <span>الإجمالي</span><span>{money(total)}</span>
          </div>
        </div>
        {can.manage && (
          <div style={{ display: "flex", gap: 8 }}>
            <input type="number" value={adj} onChange={(e) => setAdj(e.target.value)} placeholder="مبلغ تعديل +/−" style={input} />
            <Btn bg={C.amber} onClick={() => { if (adj !== "") { update("claims", cl.id, { adjustments: [...(cl.adjustments || []), { desc: "تعديل يدوي", amount: Number(adj) }] }); setAdj(""); } }}>إضافة</Btn>
          </div>
        )}
      </Section>
      {can.admin && <Btn bg={C.red} style={{ width: "100%", padding: 12 }} onClick={() => { if (confirm("حذف المطالبة؟ (الاستحقاقات تبقى)")) { db.entitlements.filter((e) => e.claimId === cl.id).forEach((e) => update("entitlements", e.id, { claimId: "", included: false })); remove("claims", cl.id); onClose(); } }}>حذف المطالبة</Btn>}
    </Sheet>
  );
}

/* ───────────────────────── حوكمة المخزون والطلبات ───────────────────────── */
