# Modules folder

This folder is reserved for future domain modules. The current refactor moved shared constants, utility functions, and reusable UI primitives out of `App.tsx`.

Suggested next split:

- `modules/assets`
- `modules/work-orders`
- `modules/inventory`
- `modules/governance`
- `modules/reports`
- `modules/offline-sync`
- `modules/media`
