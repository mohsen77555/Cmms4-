import { useState } from "react";
import { ATTACH_TYPES, C, OP_ACTIVITY, OP_BASIS, OP_CHARGE, REPAIR_REASONS, WORK_DONE, WO_COLORS, daysUntil, today, uid } from "../core/appCore";
import { Badge, Btn, Chip, Empty, Field, Row, Section, Sheet, card, delBtn, input } from "../components/ui";
import { Crud, FormSheet } from "./crud";

export function StdOpsManager({ ctx }) {
  const { db, add, update, nameOf, can } = ctx;
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("الكل");
  const [showInactive, setShowInactive] = useState(false);
  const [form, setForm] = useState(false);
  const [detail, setDetail] = useState(null);
  /* الاستخدام: في تعريفات العمل أو أوامر العمل (يمنع الحذف وتغيير الكود) */
  const usage = (id) => ({
    defs: db.workDefs.filter((d) => (d.opIds || []).includes(id)),
    wos: db.workOrders.filter((w) => (w.operations || []).some((o) => o.stdOpId === id)),
  });
  const isInactive = (o) => o.inactiveOn && daysUntil(o.inactiveOn) <= 0;
  let list = db.stdOps.filter((o) =>
    (!q || (o.name + o.code + (o.description || "") + nameOf("workCenters", o.workCenterId)).includes(q)) &&
    (filter === "الكل" || (filter === "داخلية" && (o.type || "داخلية") === "داخلية") || (filter === "خارجية" && o.type === "خارجية")) &&
    (showInactive || !isInactive(o)));
  const opSchema = (editing) => [
    { k: "type", label: "نوع العملية", type: "select", options: ["داخلية", "خارجية"] },
    { k: "code", label: "الكود (فريد)" + (editing && (usage(editing.id).defs.length || usage(editing.id).wos.length) ? " — مقفل (مستخدمة)" : "") },
    { k: "name", label: "اسم العملية" },
    { k: "description", label: "الوصف", type: "textarea" },
    { k: "workCenterId", label: "مركز العمل" + (editing && (editing.resources || []).length ? " — مقفل (توجد موارد)" : ""), type: "select", from: "workCenters", fromKey: "name" },
    { k: "minutes", label: "المدة بالدقائق", type: "number" },
    { k: "steps", label: "الخطوات (سطر لكل خطوة)", type: "textarea" },
    { k: "countPoint", label: "نقطة عد (يجب الإبلاغ عن إكمالها صراحةً)", type: "check" },
    { k: "autoTransact", label: "تنفيذ تلقائي (لا يجتمع مع نقطة العد)", type: "check" },
    { k: "supplier", label: "المورد (للخارجية)" },
    { k: "supplierSite", label: "موقع المورد" },
    { k: "ospItemId", label: "صنف خدمة المورد — من ماستر الأصناف (إلزامي للخارجية)", type: "select", from: "items", fromLabel: (i) => i.code + " — " + i.name },
    { k: "inactiveOn", label: "تعطيل اعتبارًا من", type: "date" },
  ];
  const validate = (d, editing) => {
    if (!String(d.code || "").trim() || !String(d.name || "").trim()) return "الكود والاسم مطلوبان";
    if (db.stdOps.some((o) => o.code === d.code && o.id !== editing?.id)) return "الكود مستخدم — يجب أن يكون فريدًا";
    if (d.countPoint && d.autoTransact) return "نقطة العد والتنفيذ التلقائي لا يجتمعان (قاعدة ف7)";
    if (d.type === "خارجية" && !d.ospItemId) return "العملية الخارجية تتطلب صنف خدمة المورد";
    if (d.type === "خارجية" && (editing?.resources || []).length) return "العملية الخارجية لا تحمل موارد داخلية — احذف الموارد أولًا";
    if (editing) {
      const u = usage(editing.id);
      if (d.code !== editing.code && (u.defs.length || u.wos.length)) return "لا يمكن تغيير الكود — العملية مستخدمة";
      if (d.workCenterId !== editing.workCenterId && (editing.resources || []).length) return "لا يمكن تغيير مركز العمل مع وجود موارد";
    }
    return null;
  };
  return (
    <>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="🔍 بحث بالاسم/الكود/الوصف/مركز العمل…" style={{ ...input, marginBottom: 8 }} />
      <div style={{ display: "flex", gap: 6, marginBottom: 10, alignItems: "center", flexWrap: "wrap" }}>
        {["الكل", "داخلية", "خارجية"].map((f) => <Chip key={f} active={filter === f} onClick={() => setFilter(f)}>{f}</Chip>)}
        <label style={{ display: "flex", gap: 5, alignItems: "center", fontSize: 12.5 }}>
          <input type="checkbox" checked={showInactive} onChange={(e) => setShowInactive(e.target.checked)} /> إظهار غير النشطة
        </label>
      </div>
      {can.manage && <Btn bg={C.orange} onClick={() => setForm(true)} style={{ width: "100%", padding: 12, marginBottom: 12 }}>+ عملية قياسية جديدة</Btn>}
      {list.length === 0 && <Empty text="مكتبة قوالب: عرّف «تشحيم محامل» مرة واحدة واستخدمها في كل تعريفات وأوامر العمل." />}
      {list.map((o) => {
        const u = usage(o.id);
        return (
          <div key={o.id} style={{ ...card(), borderRightColor: isInactive(o) ? C.steel : o.type === "خارجية" ? C.purple : C.ink, opacity: isInactive(o) ? 0.6 : 1 }}
            onClick={() => setDetail(o.id)}>
            <Row main={o.code + " — " + o.name}
              badge={isInactive(o) ? { text: "غير نشطة", color: C.steel } : { text: o.type || "داخلية", color: o.type === "خارجية" ? C.purple : C.blue }}
              sub={[nameOf("workCenters", o.workCenterId) !== "—" ? nameOf("workCenters", o.workCenterId) : "",
                (o.resources || []).length + " مورد", (o.attachments || []).length ? (o.attachments || []).length + " مرفق" : "",
                u.defs.length + u.wos.length > 0 ? "مستخدمة في " + (u.defs.length + u.wos.length) : "",
                o.type === "خارجية" && o.supplier ? "مورد: " + o.supplier : ""].filter(Boolean).join(" · ")} />
          </div>
        );
      })}
      {form && (
        <FormSheet title="عملية قياسية جديدة" onClose={() => setForm(false)} db={db} schema={opSchema(null)}
          initial={{ type: "داخلية", countPoint: true, autoTransact: false }}
          onSave={(d) => {
            const err = validate(d, null);
            if (err) { alert(err); return; }
            add("stdOps", { resources: [], attachments: [], ...d }); setForm(false);
          }} />
      )}
      {detail && <StdOpDetail ctx={ctx} opId={detail} onClose={() => setDetail(null)} usage={usage} opSchema={opSchema} validate={validate} />}
    </>
  );
}

export function StdOpDetail({ ctx, opId, onClose, usage, opSchema, validate }) {
  const { db, update, remove, nameOf, can } = ctx;
  const o = db.stdOps.find((x) => x.id === opId);
  const [sub, setSub] = useState("عام");
  const [edit, setEdit] = useState(false);
  const [assetPhotoUploading, setAssetPhotoUploading] = useState(false);
  const [resForm, setResForm] = useState(null); // null | "new" | resource obj
  const [altFor, setAltFor] = useState(null);
  if (!o) return null;
  const u = usage(o.id);
  const used = u.defs.length + u.wos.length > 0;
  const TABS = ["عام", "الموارد", "المرفقات", "أكواد الإصلاح", "الاستخدام"];
  const wcResources = db.resources.filter((r) => !o.workCenterId || r.workCenterId === o.workCenterId);
  const patchRes = (rs) => update("stdOps", o.id, { resources: rs });
  const resSchema = [
    { k: "seq", label: "التسلسل (نفس الرقم = موارد متزامنة)", type: "number" },
    { k: "resourceId", label: "المورد (من نفس مركز العمل)", type: "select",
      from: "resources", fromLabel: (r) => r.name + (r.workCenterId === o.workCenterId ? "" : " ⚠ خارج المركز") },
    { k: "units", label: "الوحدات المخصصة", type: "number" },
    { k: "basis", label: "الأساس", type: "select", options: OP_BASIS },
    { k: "usage", label: "الاستخدام (ساعات/وحدة — أكبر من صفر)", type: "number" },
    { k: "chargeType", label: "نوع التحميل", type: "select", options: OP_CHARGE },
    { k: "activity", label: "النشاط", type: "select", options: OP_ACTIVITY },
    { k: "scheduled", label: "يدخل في الجدولة", type: "check" },
    { k: "principal", label: "مورد رئيسي (واحد فقط لكل تسلسل متزامن)", type: "check" },
  ];
  const validateRes = (d, editing) => {
    if (!d.resourceId) return "اختر المورد";
    if (!(Number(d.usage) > 0)) return "الاستخدام يجب أن يكون أكبر من صفر";
    const r = db.resources.find((x) => x.id === d.resourceId);
    if (o.workCenterId && r && r.workCenterId !== o.workCenterId) return "المورد يجب أن يتبع نفس مركز العمل";
    if (d.principal && (o.resources || []).some((x) => x.id !== editing?.id && Number(x.seq) === Number(d.seq) && x.principal))
      return "يوجد مورد رئيسي آخر بنفس التسلسل المتزامن";
    return null;
  };
  return (
    <Sheet title={o.code + " — " + o.name} onClose={onClose}>
      <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
        <Badge text={o.type || "داخلية"} color={o.type === "خارجية" ? C.purple : C.blue} />
        {o.countPoint && <Badge text="نقطة عد" color={C.ink} />}
        {o.autoTransact && <Badge text="تنفيذ تلقائي" color={C.amber} />}
        {o.inactiveOn && daysUntil(o.inactiveOn) <= 0 && <Badge text="غير نشطة" color={C.steel} />}
        {can.manage && <Btn bg={C.blue} onClick={() => setEdit(true)}>تعديل</Btn>}
        {can.admin && (used
          ? <Btn bg={C.steel} onClick={() => { update("stdOps", o.id, { inactiveOn: today() }); alert("العملية مستخدمة — عُطّلت بدل الحذف (قاعدة ف7)"); }}>تعطيل (مستخدمة)</Btn>
          : <Btn bg={C.red} onClick={() => { if (confirm("حذف العملية نهائيًا؟")) { remove("stdOps", o.id); onClose(); } }}>حذف</Btn>)}
      </div>
      <div style={{ display: "flex", gap: 5, overflowX: "auto", marginBottom: 10 }}>
        {TABS.map((t) => <Chip key={t} active={sub === t} onClick={() => setSub(t)}>{t}</Chip>)}
      </div>

      {sub === "عام" && (
        <div style={{ ...card(), fontSize: 14, lineHeight: 2 }}>
          {o.description && <>{o.description}<br /></>}
          مركز العمل: <b>{nameOf("workCenters", o.workCenterId)}</b> · المدة: <b>{o.minutes || "—"} د</b><br />
          {o.type === "خارجية" && (<>
            المورد: <b>{o.supplier || "—"}</b> · الموقع: <b>{o.supplierSite || "—"}</b><br />
            صنف الخدمة: <b>{nameOf("items", o.ospItemId)}</b><br />
            <span style={{ fontSize: 12.5, color: C.steel }}>العملية الخارجية لا تحمل موارد داخلية.</span><br />
          </>)}
          {(o.steps || "").split("\n").filter(Boolean).length > 0 && (<>
            <b>الخطوات:</b>
            {(o.steps || "").split("\n").filter(Boolean).map((s, i) => <div key={i} style={{ fontSize: 13.5 }}>{(i + 1) + ". " + s}</div>)}
          </>)}
        </div>
      )}

      {sub === "الموارد" && (<>
        {o.type === "خارجية"
          ? <Empty text="الموارد للعمليات الداخلية فقط (قاعدة ف7)." />
          : (<>
            {(o.resources || []).slice().sort((a, b) => a.seq - b.seq).map((r) => (
              <div key={r.id} style={{ ...card(), borderRightColor: r.principal ? C.orange : C.ink }}>
                <Row main={r.seq + " — " + nameOf("resources", r.resourceId) + (r.principal ? " ★ رئيسي" : "")}
                  sub={[r.units + " وحدة", r.basis, "استخدام " + r.usage, r.chargeType + " التحميل", r.activity,
                    r.scheduled ? "مجدول" : "غير مجدول"].join(" · ")}
                  action={can.manage ? <Btn bg={C.blue} onClick={() => setResForm(r)}>تعديل</Btn> : null} />
                {(r.alternates || []).length > 0 && (
                  <div style={{ fontSize: 12.5, color: C.steel, marginTop: 4 }}>
                    البدائل: {(r.alternates || []).map((a) => nameOf("resources", a.resourceId) + " (أولوية " + a.priority + ")").join("، ")}
                  </div>
                )}
                {can.manage && (
                  <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
                    <button onClick={() => setAltFor(r)} style={{ ...delBtn, color: C.blue, marginTop: 0 }}>+ مورد بديل</button>
                    <button onClick={() => patchRes(o.resources.filter((x) => x.id !== r.id))} style={{ ...delBtn, marginTop: 0 }}>حذف</button>
                  </div>
                )}
              </div>
            ))}
            {(o.resources || []).length === 0 && <Empty text="مثال: تسلسل 10 فني (رئيسي) + جهاز تشخيص متزامن، ثم تسلسل 20 مفتش جودة." />}
            {can.manage && <Btn bg={C.ink} onClick={() => setResForm("new")} style={{ width: "100%" }}>+ إضافة مورد للعملية</Btn>}
          </>)}
      </>)}

      {sub === "المرفقات" && (<>
        <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 8 }}>تورَّث تعليمات العمل إلى أوامر العمل عند الإنشاء (نسخة).</div>
        {(o.attachments || []).map((a) => (
          <div key={a.id} style={card()}>
            <Row main={(a.type === "رابط" ? "🔗 " : "📝 ") + a.name}
              sub={a.type === "نص" ? a.value : ""}
              action={a.type === "رابط" && a.value ? <Btn bg={C.blue} onClick={() => window.open(a.value, "_blank")}>فتح</Btn> : null} />
            {can.manage && <button onClick={() => update("stdOps", o.id, { attachments: o.attachments.filter((x) => x.id !== a.id) })} style={delBtn}>حذف</button>}
          </div>
        ))}
        {can.manage && <AttachForm onAdd={(a) => update("stdOps", o.id, { attachments: [...(o.attachments || []), { id: uid(), ...a }] })} />}
      </>)}

      {sub === "أكواد الإصلاح" && (
        <div style={card()}>
          <div style={{ fontSize: 12.5, color: C.steel, marginBottom: 8 }}>تنتقل إلى عملية أمر العمل عند الإنشاء وتستخدم في تحليل الضمان والتقارير.</div>
          <Field label="سبب الإصلاح">
            <select value={o.repairReason || ""} onChange={(e) => update("stdOps", o.id, { repairReason: e.target.value })} disabled={!can.manage} style={input}>
              <option value="">—</option>{REPAIR_REASONS.map((r) => <option key={r}>{r}</option>)}
            </select>
          </Field>
          <Field label="كود معاملة الإصلاح (النظام/المكون)">
            <input value={o.repairTx || ""} onChange={(e) => update("stdOps", o.id, { repairTx: e.target.value })} disabled={!can.manage} placeholder="ELV-BRG محامل المصاعد…" style={input} />
          </Field>
          <Field label="العمل المنجز">
            <select value={o.workDone || ""} onChange={(e) => update("stdOps", o.id, { workDone: e.target.value })} disabled={!can.manage} style={input}>
              <option value="">—</option>{WORK_DONE.map((r) => <option key={r}>{r}</option>)}
            </select>
          </Field>
        </div>
      )}

      {sub === "الاستخدام" && (<>
        <Section title={"تعريفات العمل (" + u.defs.length + ") — مرجع: تحديث العملية ينعكس عليها"}>
          {u.defs.map((d) => <div key={d.id} style={card()}><Row main={d.name} /></div>)}
          {u.defs.length === 0 && <Empty text="غير مستخدمة في تعريفات عمل." />}
        </Section>
        <Section title={"أوامر العمل (" + u.wos.length + ") — نسخة: لا تتأثر بالتحديث"}>
          {u.wos.map((w) => <div key={w.id} style={card()}><Row main={w.number + " — " + w.title} badge={{ text: w.status, color: WO_COLORS[w.status] }} /></div>)}
          {u.wos.length === 0 && <Empty text="غير مستخدمة في أوامر عمل." />}
        </Section>
      </>)}

      {edit && (
        <FormSheet title="تعديل العملية القياسية" onClose={() => setEdit(false)} db={db} schema={opSchema(o)} initial={o}
          onSave={(d) => { const err = validate(d, o); if (err) { alert(err); return; } update("stdOps", o.id, d); setEdit(false); }} />
      )}
      {resForm && (
        <FormSheet title={resForm === "new" ? "إضافة مورد" : "تعديل مورد"} onClose={() => setResForm(null)} db={db} schema={resSchema}
          initial={resForm === "new" ? { seq: ((o.resources || []).length + 1) * 10, units: 1, basis: "ثابت", usage: 1, chargeType: "يدوي", activity: "تنفيذ", scheduled: true, principal: (o.resources || []).length === 0 } : resForm}
          onSave={(d) => {
            const err = validateRes(d, resForm === "new" ? null : resForm);
            if (err) { alert(err); return; }
            patchRes(resForm === "new" ? [...(o.resources || []), { id: uid(), alternates: [], ...d }]
              : o.resources.map((x) => x.id === resForm.id ? { ...x, ...d } : x));
            setResForm(null);
          }} />
      )}
      {altFor && (
        <FormSheet title={"مورد بديل لـ " + nameOf("resources", altFor.resourceId)} onClose={() => setAltFor(null)} db={db}
          schema={[
            { k: "resourceId", label: "المورد البديل (نشط، نفس مركز العمل)", type: "select", from: "resources", fromKey: "name" },
            { k: "priority", label: "الأولوية", type: "number" },
          ]} initial={{ priority: ((altFor.alternates || []).length + 1) }}
          onSave={(d) => {
            if (!d.resourceId) { alert("اختر البديل"); return; }
            if (d.resourceId === altFor.resourceId) { alert("البديل لا يكون نفس المورد الأساسي"); return; }
            if ((altFor.alternates || []).some((a) => a.resourceId === d.resourceId)) { alert("البديل مضاف مسبقًا"); return; }
            const r = db.resources.find((x) => x.id === d.resourceId);
            if (o.workCenterId && r && r.workCenterId !== o.workCenterId) { alert("البديل يجب أن يتبع نفس مركز العمل"); return; }
            patchRes(o.resources.map((x) => x.id === altFor.id ? { ...x, alternates: [...(x.alternates || []), d] } : x));
            setAltFor(null);
          }} />
      )}
    </Sheet>
  );
}

export function AttachForm({ onAdd }) {
  const [name, setName] = useState(""); const [type, setType] = useState("رابط"); const [value, setValue] = useState("");
  return (
    <div style={card()}>
      <Field label="اسم المرفق"><input value={name} onChange={(e) => setName(e.target.value)} placeholder="فيديو تشحيم المحامل" style={input} /></Field>
      <div style={{ display: "flex", gap: 8 }}>
        <Field label="النوع">
          <select value={type} onChange={(e) => setType(e.target.value)} style={input}>{ATTACH_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
        </Field>
      </div>
      <Field label={type === "رابط" ? "الرابط (URL)" : "نص التعليمات"}>
        {type === "رابط"
          ? <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="https://…" style={input} />
          : <textarea value={value} onChange={(e) => setValue(e.target.value)} rows={3} style={{ ...input, resize: "vertical" }} />}
      </Field>
      <Btn bg={C.ink} style={{ width: "100%" }} onClick={() => { if (name.trim()) { onAdd({ name, type, value }); setName(""); setValue(""); } }}>+ إضافة مرفق</Btn>
    </div>
  );
}

/* تعريفات العمل: عمليات + مواد + موارد + وقت (وثيقة التنفيذ §Work Definition) */
export function WorkDefs({ ctx }) {
  return <Crud ctx={ctx} entity="workDefs" title="تعريفات العمل" schema={[
    { k: "name", label: "اسم التعريف (مثل: PM شهري للمصاعد)" },
    { k: "description", label: "الوصف", type: "textarea" },
    { k: "opIds", label: "العمليات (من القياسية)", type: "multi", from: "stdOps", fromKey: "name" },
    { k: "materials", label: "المواد المطلوبة (شحم، أدوات تنظيف…)" },
    { k: "resources", label: "الموارد المطلوبة (فني ميكانيكي + كهربائي…)" },
    { k: "estimatedHours", label: "الوقت التقديري (ساعات)", type: "number" },
  ]} render={(d) => [d.name, [(d.opIds || []).length + " عملية", d.estimatedHours ? d.estimatedHours + " ساعة" : "", d.materials].filter(Boolean).join(" · ")]} />;
}

/* ───────────────────────── طلبات العمل ───────────────────────── */
