/* Offline queue, conflict detection, and export helpers. */
import { OFFLINE_QUEUE_KEY, OFFLINE_HISTORY_KEY, TAB_META, uid, now } from "./constants";

/* ───────────────────────── Offline Sync + Conflict Resolution v34 ───────────────────────── */
export const safeJsonText = (value) => {
  try { return JSON.stringify(value ?? null); }
  catch { return String(value ?? ""); }
};
export const sameValue = (a, b) => safeJsonText(a) === safeJsonText(b);
export const rowIdentity = (row, index = 0) => String(row?.id ?? row?.uid ?? row?.code ?? row?.number ?? row?.email ?? `row-${index + 1}`).replace(/[\/#[\]?]/g, "-");
export const entityTitle = (key) => (TAB_META[key]?.label || ({
  assets:"الأصول", workOrders:"أوامر العمل", workRequests:"طلبات العمل", items:"الأصناف", stockTx:"حركات المخزون",
  readings:"قراءات العدادات", inventoryRequests:"طلبات المخزون", workOrderPhotos:"صور أوامر العمل", settings:"الإعدادات"
})[key] || key);
export const loadOfflineQueue = () => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return [];
    const raw = window.localStorage.getItem(OFFLINE_QUEUE_KEY);
    const rows = raw ? JSON.parse(raw) : [];
    return Array.isArray(rows) ? rows : [];
  } catch (e) { console.error("فشل قراءة طابور Offline", e); return []; }
};
export const saveOfflineQueue = (rows) => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return false;
    window.localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(rows || []));
    return true;
  } catch (e) { console.error("فشل حفظ طابور Offline", e); return false; }
};
export const loadOfflineHistory = () => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return [];
    const raw = window.localStorage.getItem(OFFLINE_HISTORY_KEY);
    const rows = raw ? JSON.parse(raw) : [];
    return Array.isArray(rows) ? rows : [];
  } catch { return []; }
};
export const addOfflineHistory = (event) => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return;
    const rows = [{ id: uid(), at: now(), ...event }, ...loadOfflineHistory()].slice(0, 250);
    window.localStorage.setItem(OFFLINE_HISTORY_KEY, JSON.stringify(rows));
  } catch {}
};
export const changedKeysBetween = (prev, next) => {
  const keys = new Set([...Object.keys(prev || {}), ...Object.keys(next || {})]);
  keys.delete("_meta");
  return [...keys].filter((k) => !sameValue(prev?.[k], next?.[k]));
};
export const makeOfflineQueueEntry = (prev, next, actor, reason = "") => {
  const changedKeys = changedKeysBetween(prev, next);
  const base = {}; const local = {};
  changedKeys.forEach((k) => { base[k] = prev?.[k]; local[k] = next?.[k]; });
  return {
    id: uid(), status:"pending", createdAt:now(), updatedAt:now(), attempts:0,
    reason:String(reason || "فشل الاتصال أو رفضت المزامنة"), changedKeys, base, local,
    actor:{ uid:actor?.uid || "", email:actor?.email || "", role:actor?.role || "" },
    device:{ online: typeof navigator !== "undefined" ? !!navigator.onLine : true, userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "" }
  };
};
export const offlineQueueStats = (rows) => {
  const q = Array.isArray(rows) ? rows : [];
  return {
    total:q.length,
    pending:q.filter((x)=>["pending","retry"].includes(x.status)).length,
    conflict:q.filter((x)=>x.status === "conflict").length,
    failed:q.filter((x)=>x.status === "failed").length,
    applied:q.filter((x)=>x.status === "applied").length,
    dropped:q.filter((x)=>x.status === "dropped").length,
  };
};
export const buildRecordMap = (rows) => {
  const map = new Map();
  (Array.isArray(rows) ? rows : []).forEach((r, i) => map.set(rowIdentity(r, i), r));
  return map;
};
export const compactConflict = (c) => ({
  entityKey:c.entityKey, recordId:c.recordId || "", field:c.field || "", reason:c.reason || "تعارض تعديل",
  localPreview: String((c.local?.number || c.local?.name || c.local?.title || c.local) ?? "").slice(0, 90),
  remotePreview: String((c.remote?.number || c.remote?.name || c.remote?.title || c.remote) ?? "").slice(0, 90),
});
export const mergeArrayWithConflictResolution = (entityKey, baseRows, localRows, remoteRows) => {
  const baseMap = buildRecordMap(baseRows);
  const localMap = buildRecordMap(localRows);
  const remoteMap = buildRecordMap(remoteRows);
  const ids = new Set([...baseMap.keys(), ...localMap.keys(), ...remoteMap.keys()]);
  const out = [];
  const conflicts = [];
  ids.forEach((id) => {
    const b = baseMap.get(id), l = localMap.get(id), r = remoteMap.get(id);
    const localChanged = !sameValue(l, b);
    const remoteChanged = !sameValue(r, b);
    if (!localChanged) { if (r !== undefined) out.push(r); return; }
    if (!remoteChanged) { if (l !== undefined) out.push(l); return; }
    if (sameValue(l, r)) { if (r !== undefined) out.push(r); return; }
    conflicts.push({ entityKey, recordId:id, local:l, remote:r, base:b, reason:"تم تعديل نفس السجل على الجهاز وعن بُعد" });
    if (r !== undefined) out.push(r);
  });
  return { value:out, conflicts };
};
export const mergeOfflineEntryIntoRemote = (remoteState, entry) => {
  const merged = { ...(remoteState || {}) };
  const conflicts = [];
  (entry.changedKeys || []).forEach((key) => {
    const baseValue = entry.base?.[key];
    const localValue = entry.local?.[key];
    const remoteValue = remoteState?.[key];
    const localChanged = !sameValue(localValue, baseValue);
    const remoteChanged = !sameValue(remoteValue, baseValue);
    if (!localChanged) return;
    if (!remoteChanged || sameValue(localValue, remoteValue)) { merged[key] = localValue; return; }
    if (Array.isArray(baseValue) || Array.isArray(localValue) || Array.isArray(remoteValue)) {
      const r = mergeArrayWithConflictResolution(key, baseValue || [], localValue || [], remoteValue || []);
      merged[key] = r.value;
      conflicts.push(...r.conflicts);
    } else {
      conflicts.push({ entityKey:key, field:key, local:localValue, remote:remoteValue, base:baseValue, reason:"تم تعديل نفس القيمة على الجهاز وعن بُعد" });
      merged[key] = remoteValue;
    }
  });
  return { merged, conflicts };
};
export const forceApplyOfflineEntry = (remoteState, entry) => {
  const merged = { ...(remoteState || {}) };
  (entry.changedKeys || []).forEach((key) => { merged[key] = entry.local?.[key]; });
  return merged;
};
export const downloadJsonFile = (name, value) => {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type:"application/json;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = name; a.click();
};
