/* Core constants, environment flags, date helpers, and CMMS reference lists. */
import { uploadCmmsDataUrlToStorage } from "../firebaseCmms";
/*
 * Core constants and pure utility functions for Alhadi CMMS.
 * This file was extracted from App.tsx to make the project easier to maintain.
 */
/* ───────────────────────── ثوابت ───────────────────────── */
export const C = {
  ink:"#111827",
  paper:"#F6F7FB",
  card:"#FFFFFF",
  orange:"#F97316",
  steel:"#64748B",
  line:"#E2E8F0",
  green:"#16A34A",
  red:"#DC2626",
  amber:"#D97706",
  blue:"#2563EB",
  purple:"#7C3AED",
  soft:"#F8FAFC"
};
export const TAB_META = {
  home:{ label:"الرئيسية", icon:"⌂", desc:"لوحة المؤشرات والتنبيهات", color:C.ink },
  wo:{ label:"أوامر العمل", icon:"▣", desc:"إنشاء، إصدار، متابعة، وإغلاق", color:C.blue },
  super:{ label:"الإشراف", icon:"◈", desc:"توزيع ومراجعة وجدولة", color:C.purple },
  schedule:{ label:"محرك الجدولة", icon:"◷", desc:"سعة، ورديات، تأهيل، مواد، تعارضات، وتطبيق خطة", color:C.purple },
  assets:{ label:"الأصول", icon:"▤", desc:"سجل الأصول و Asset 360", color:C.green },
  qrlabels:{ label:"ملصقات QR للأصول", icon:"▦", desc:"توليد وطباعة ملصقات QR للأصول", color:C.green },
  more:{ label:"المزيد", icon:"☰", desc:"كل الوحدات والإعدادات", color:C.orange },
  notifications:{ label:"التنبيهات", icon:"🔔", desc:"تنبيهات العمل والمواد والاعتمادات", color:C.red },
  mywork:{ label:"أعمالي", icon:"✓", desc:"مهام الفني والتنفيذ", color:C.green },
  inventory:{ label:"المخزون", icon:"▥", desc:"قطع الغيار والصرف والإرجاع", color:C.amber },
  procurement:{ label:"المشتريات", icon:"🛒", desc:"نواقص، طلبات شراء، موردون، وعروض", color:C.orange },
  invgov:{ label:"حوكمة المخزون", icon:"▣", desc:"طلبات، اعتمادات، جرد، فروقات، وتدقيق", color:C.red },
  firebase:{ label:"Firebase والصلاحيات", icon:"◆", desc:"تسجيل الدخول وربط Firestore", color:C.orange },
  users:{ label:"المستخدمون والصلاحيات", icon:"👥", desc:"الأدوار وربط الفنيين", color:C.purple },
  maintenance:{ label:"إدارة الصيانة", icon:"⚙", desc:"طلبات، عمليات، تنفيذ، إغلاق", color:C.blue },
  requests:{ label:"طلبات العمل", icon:"＋", desc:"بلاغات وتحويل إلى أمر عمل", color:C.orange },
  programs:{ label:"البرامج الوقائية", icon:"↻", desc:"PM حسب التاريخ أو العداد", color:C.green },
  forecast:{ label:"توقعات الصيانة", icon:"⌁", desc:"تنبؤ، تحقق، وتوليد أوامر", color:C.blue },
  meters:{ label:"العدادات", icon:"◷", desc:"قراءات وتشغيل واستهلاك", color:C.purple },
  org:{ label:"منظمة الصيانة", icon:"▦", desc:"مناطق، مراكز، موارد، ورديات", color:C.ink },
  oracle:{ label:"مطابقة المتطلبات", icon:"◎", desc:"فحص التغطية حسب الوثائق", color:C.blue },
  governance:{ label:"الحوكمة والرقابة", icon:"◇", desc:"سياسات ومخاطر وجودة بيانات", color:C.amber },
  governance100:{ label:"الحوكمة 100%", icon:"◉", desc:"ضوابط، CAPA، جاهزية إنتاج", color:C.red },
  techs:{ label:"الفنيون", icon:"⚒", desc:"الفنيون والتخصصات", color:C.green },
  groups:{ label:"مجموعات الأصول", icon:"▧", desc:"تجميع وقواعد تحقق", color:C.purple },
  lh:{ label:"الهرميات والمسارات", icon:"⟡", desc:"هياكل ومسارات منطقية", color:C.blue },
  warranty:{ label:"الضمانات", icon:"★", desc:"عقود، مطالبات، استحقاقات", color:C.green },
  stdops:{ label:"العمليات القياسية", icon:"☑", desc:"خطوات قياسية قابلة لإعادة الاستخدام", color:C.ink },
  workdefs:{ label:"تعريفات العمل", icon:"▨", desc:"عمليات + مواد + موارد + وقت", color:C.blue },
  failures:{ label:"تحليل الأعطال", icon:"⚠", desc:"MTTR، MTBF، أعطال متكررة", color:C.red },
  reports:{ label:"التقارير", icon:"▰", desc:"مؤشرات وتصدير وتحليلات", color:C.purple },
  media:{ label:"الصور والمرفقات", icon:"▧", desc:"Firebase Storage، أحجام، ترحيل، وروابط", color:C.green },
  data:{ label:"البيانات والنسخ", icon:"⇩", desc:"تصدير، استيراد، نسخ احتياطي", color:C.steel },
  sync:{ label:"المزامنة Offline", icon:"⇄", desc:"طابور التغييرات، حل التعارضات، وإعادة المزامنة", color:C.blue },
};
export const KEY = "cmms-data-v1";
export const OFFLINE_QUEUE_KEY = "cmms-offline-queue-v2";
export const OFFLINE_HISTORY_KEY = "cmms-offline-history-v1";
export const API = (import.meta as any).env?.VITE_API_URL || (typeof window !== "undefined" && (window as any).__CMMS_API_URL__) || "http://localhost:4000/api";
// v35: Production hardening. أدوات التجربة/الإعداد/الخطر مخفية افتراضيًا في النسخ النهائية.
// لإظهارها مؤقتًا في نسخة تدريب أو إعداد: VITE_CMMS_BUILD_MODE=training أو فعّل المتغير المناسب.
export const CMMS_BUILD_MODE = String((import.meta as any).env?.VITE_CMMS_BUILD_MODE || "production").toLowerCase();
export const PRODUCTION_LOCK = String((import.meta as any).env?.VITE_CMMS_PRODUCTION_LOCK ?? "true").toLowerCase() !== "false";
export const SHOW_DEMO_TOOLS = String((import.meta as any).env?.VITE_CMMS_SHOW_DEMO_TOOLS || "").toLowerCase() === "true";
export const SHOW_SETUP_TOOLS = String((import.meta as any).env?.VITE_CMMS_SHOW_SETUP_TOOLS || (import.meta as any).env?.VITE_CMMS_ALLOW_SETUP_TOOLS || "").toLowerCase() === "true";
export const SHOW_DANGEROUS_TOOLS = String((import.meta as any).env?.VITE_CMMS_SHOW_DANGEROUS_TOOLS || "").toLowerCase() === "true";
export const isProductionBuild = () => PRODUCTION_LOCK && CMMS_BUILD_MODE !== "training" && CMMS_BUILD_MODE !== "development";
export const uid = () => Math.random().toString(36).slice(2, 9);
export const pad2 = (n) => String(n).padStart(2, "0");
export const dateOnly = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
export const today = () => { const d = new Date(); return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()); };
export const now = () => { try { return new Date().toISOString(); } catch { return today(); } };

// محول تاريخ آمن: يمنع انهيار التطبيق برسالة "Invalid time value" عند وجود
// تاريخ قديم كنص عربي، أو Timestamp من Firestore، أو قيمة فارغة/غير صالحة.
export const parseDateValue = (value) => {
  if (!value) return null;
  try {
    if (value instanceof Date) return Number.isFinite(value.getTime()) ? dateOnly(value) : null;
    if (typeof value?.toDate === "function") {
      const d = value.toDate();
      return d instanceof Date && Number.isFinite(d.getTime()) ? dateOnly(d) : null;
    }
    if (typeof value === "object" && (typeof value.seconds === "number" || typeof value._seconds === "number")) {
      const d = new Date(Number(value.seconds ?? value._seconds) * 1000);
      return Number.isFinite(d.getTime()) ? dateOnly(d) : null;
    }
    if (typeof value === "number") {
      const d = new Date(value);
      return Number.isFinite(d.getTime()) ? dateOnly(d) : null;
    }
    const raw = String(value).trim();
    if (!raw) return null;
    const iso = raw.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (iso) {
      const y = Number(iso[1]), m = Number(iso[2]), dd = Number(iso[3]);
      const dt = new Date(y, m - 1, dd);
      return Number.isFinite(dt.getTime()) ? dt : null;
    }
    const parsed = new Date(raw);
    return Number.isFinite(parsed.getTime()) ? dateOnly(parsed) : null;
  } catch { return null; }
};
export const dateKey = (value, fallback = "") => {
  const d = parseDateValue(value);
  return d ? d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) : fallback;
};
export const addDateDays = (base, n) => {
  const d = parseDateValue(base) || parseDateValue(today()) || new Date();
  const amount = Number(n);
  d.setDate(d.getDate() + (Number.isFinite(amount) ? amount : 0));
  return dateKey(d, today());
};
export const daysBetween = (later, earlier) => {
  const a = parseDateValue(later), b = parseDateValue(earlier);
  if (!a || !b) return 1;
  return Math.max(1, Math.round((a.getTime() - b.getTime()) / 86400000));
};
export const fmt = (d) => {
  if (!d) return "—";
  const dt = parseDateValue(d);
  if (!dt) return typeof d === "string" ? d : "—";
  try { return dt.toLocaleDateString("ar", { month: "short", day: "numeric" }); }
  catch { return dateKey(dt, typeof d === "string" ? d : "—"); }
};
export const daysUntil = (d) => {
  if (!d) return Number.NaN;
  const target = parseDateValue(d), base = parseDateValue(today());
  if (!target || !base) return Number.NaN;
  return Math.round((target.getTime() - base.getTime()) / 86400000);
};
export const money = (n) => (Math.round(Number(n || 0) * 100) / 100).toLocaleString("ar") + " ر.س";

/* دورة الحالات الكاملة (وثيقة التنفيذ) */
export const WO_FLOW = ["مسودة", "مُصدر", "جاهز", "قيد التنفيذ", "بانتظار المراجعة", "مغلق"];
export const WO_EXTRA = ["معلق", "بانتظار مواد", "بانتظار اعتماد", "مُعاد للتصحيح", "ملغي", "متأخر", "استثناء"];
export const WO_COLORS = { "مسودة": C.steel, "مُصدر": C.blue, "جاهز": C.purple, "قيد التنفيذ": C.amber,
  "بانتظار المراجعة": C.blue, "مغلق": C.ink, "معلق": C.steel, "بانتظار مواد": C.amber,
  "مُعاد للتصحيح": C.red, "ملغي": C.red, "بانتظار اعتماد": C.amber, "متأخر": C.red, "استثناء": C.amber };
export const ACTIVE_STATES = ["مسودة", "مُصدر", "جاهز", "قيد التنفيذ", "بانتظار المراجعة", "معلق", "بانتظار مواد", "بانتظار اعتماد", "مُعاد للتصحيح", "متأخر", "استثناء"];
export const REQ_FLOW = { "مفتوح": ["قبول", "رفض"], "مقبول": ["تحويل لأمر عمل", "رفض"] };
export const ROLES = ["مدير", "مشرف", "فني", "مخزن", "طالب خدمة", "مدير المشتريات", "مدير المصنع", "مسؤول النظام"];
export const SAFETY_DEFAULTS = ["عزل مصدر الطاقة (LOTO)", "تأمين منطقة العمل", "ارتداء معدات الوقاية الشخصية"];
export const FAILURE_MODES = ["انحشار", "اهتزاز", "تسريب", "كسر", "حرارة زائدة", "خلل كهربائي", "أخرى"];
export const DOC_TYPES = ["دليل تشغيل", "كتالوج قطع غيار", "مخطط كهربائي", "مخطط ميكانيكي", "مرجع PLC/IO", "نموذج فحص", "مستند ضمان", "مستند مورد"];

export const MAINTENANCE_ENTITY_KEYS = [
  "mediaFiles", "workRequestAttachments", "standardOperationSteps",
  "workDefinitionOperations", "workDefinitionSteps", "workDefinitionMaterials", "workDefinitionResources", "workDefinitionVersions",
  "maintenanceProgramAssets", "maintenanceProgramGroups", "maintenanceForecasts",
  "workOrderSteps", "workOrderResources", "workOrderAssignments", "workOrderStatusHistory", "workOrderAttachments", "workOrderPhotos", "workOrderFailures", "workOrderExceptions", "workOrderCosts", "workOrderApprovals",
  "dispatchListViews", "technicianTasks", "workOrderExecutionSessions", "workOrderOperationTransactions", "workOrderLaborTransactions", "workOrderMaterialUsage", "workOrderMaterialReturns", "workOrderFailureRecords", "workOrderInspectionResults", "workOrderSafetyChecklists", "workOrderChecklistAnswers", "workOrderCompletionRequests", "workOrderSupervisorReviews", "workOrderExecutionHistory",
  "supervisionSavedSearches", "supervisionScheduleSnapshots", "workOrderScheduleConflicts",
  "supervisionAssignmentPlans", "resourceCapacitySnapshots", "resourceScheduleConflicts", "advancedScheduleRuns", "advancedScheduleRecommendations", "advancedScheduleApplied",
  "schedulingRules", "schedulingPlans", "schedulingPlanLines", "schedulingAssignments", "schedulingConflicts",
  "maintenanceForecastRuns", "maintenanceForecastActions", "maintenanceReportJobs", "reportJobs", "savedReportOutputs",
  "forecastRuns", "forecastValidationIssues", "forecastSuppressionRules", "forecastMergeGroups",
  "reportJobs", "savedReportOutputs", "reportSchedules", "inventoryReservations", "materialIssueRequests", "materialReturnRequests", "laborCostTransactions",
  "inventoryGovernancePolicies", "inventoryRequests", "inventoryRequestLines", "inventoryApprovals", "inventoryCycleCounts", "inventoryCycleCountLines", "inventoryReconciliationIssues", "inventoryAuditTrail"
];
export const MAINTENANCE_PERMISSIONS = [
  "View_WorkRequests", "Create_WorkRequests", "Convert_WorkRequest_To_WorkOrder",
  "View_WorkOrders", "Create_WorkOrders", "Edit_WorkOrders", "Release_WorkOrders", "Hold_WorkOrders", "Cancel_WorkOrders", "Close_WorkOrders",
  "Assign_WorkOrders", "View_Technician_Tasks", "Execute_WorkOrders", "Complete_WorkOrders",
  "Approve_WorkOrder_Completion", "Reject_WorkOrder_Completion",
  "Manage_StandardOperations", "Manage_WorkDefinitions", "Manage_MaintenancePrograms", "Generate_MaintenanceForecast", "Generate_PM_WorkOrders",
  "Record_Failure", "Record_Labor", "Record_Material_Usage", "View_WorkOrder_Cost"
];
export const MAINTENANCE_REPORTS = [
  "Open Work Orders Report", "Past Due Work Orders Report", "Completed Work Orders Report", "Preventive Maintenance Compliance", "Corrective Maintenance Report", "Emergency Work Orders Report", "Work Order Cost Report", "Technician Performance Report", "Failure Analysis Report", "Asset Maintenance History", "Maintenance Forecast Report", "Material Usage by Work Order", "Repeated Failures Report", "MTBF Report", "MTTR Report",
  "Daily Maintenance Execution Report", "Technician Workload Report", "Work Completion Report", "Rejected Work Report", "Material Usage During Execution", "Labor Hours Report", "Failure Capture Report", "Before / After Photo Report", "Supervisor Review Report"
];
export const MAINTENANCE_RULES = [
  "No Work Order without Asset", "No PM Work Order without Maintenance Program or Work Definition", "No Work Order release without material availability check", "No work order without technicians assign", "No technician completion without checklist", "No final close without supervisor approval", "No material cost without material transaction", "No labor cost without labor transaction", "No failure analysis without asset", "No status change without audit log", "No technician can see unassigned work unless permitted", "No start without safety checklist if required", "No completion without finishing all required operations", "No material usage without issued or approved material", "No corrective work completion without failure data", "No photo-required work completion without photos", "Every execution action must create audit history"
];
export const EXECUTION_PHOTO_TYPES = ["قبل", "أثناء", "بعد", "عطل", "قطعة غيار"];

/* حوكمة 100% — Operating Model / Controls / Evidence */
export const GOVERNANCE100_ENTITY_KEYS = [
  "governanceFrameworks", "governanceControlLibrary", "governanceControlTests", "governanceEvidenceRegister",
  "governanceAuthorityLimits", "governanceSoDRules", "governanceRaciMatrix", "governanceDataOwners",
  "governanceKpiDefinitions", "governanceSlaRules", "governanceExceptionRegister", "governanceCapaActions",
  "governanceBackupPolicies", "governanceRetentionRules", "governanceSecurityReviews", "governanceAccessCertifications",
  "governanceReleaseGates", "governanceReadinessChecklist", "governanceERecords", "governanceEscalationRules",
  "governanceChangeImpactAssessments", "governanceTrainingRecords", "governanceIncidentReviews", "governancePolicyAcknowledgements"
];
export const GOVERNANCE100_DOMAINS = [
  "Operating Model", "Access & RBAC", "Segregation of Duties", "Approvals", "Audit & Evidence", "Data Quality", "Work Control",
  "Inventory Control", "Safety & Execution", "Forecast & Scheduling", "Financial Control", "Reporting", "Backup & Continuity", "Retention", "Change Control"
];


/* مجموعات أصول المطاحن القياسية (وثيقة الأصول) */
export const STANDARD_GROUPS = [
  ["ELV", "مصاعد القواديس (Bucket Elevators)"], ["CCV", "النواقل السلسلية (Chain Conveyors)"],
  ["SCV", "النواقل الحلزونية (Screw Conveyors)"], ["SFN", "مراوح الصوامع (Silo Fans)"],
  ["SGT", "بوابات الصوامع (Silo Gates)"], ["SNS", "الحساسات (Sensors)"],
  ["RML", "الطواحين الدلفينية (Rollermills)"], ["PLS", "المناخل المستوية (Plansifters)"],
  ["PRF", "المنقيات (Purifiers)"], ["CMP", "الضواغط (Compressors)"],
  ["PCK", "ماكينات التعبئة (Packing Machines)"], ["SCL", "الموازين (Scales)"],
];

export const EMPTY = {
  /* فصل 1-2: منظمة الصيانة */
  maintenanceOrganizations:[], plantParameters:[], workAreas:[], workCenters:[], resources:[], workCenterResources:[],
  resourceInstances:[], shifts:[], resourceExceptions:[], infolets:[], importBatches:[],
  governancePolicies:[], approvalMatrix:[], governanceApprovalRequests:[], governanceDataQualityRules:[], governanceRisks:[], governanceChangeRequests:[], governanceReviews:[], governanceAuditEvents:[],
  governanceFrameworks:[], governanceControlLibrary:[], governanceControlTests:[], governanceEvidenceRegister:[], governanceAuthorityLimits:[], governanceSoDRules:[], governanceRaciMatrix:[], governanceDataOwners:[], governanceKpiDefinitions:[], governanceSlaRules:[], governanceExceptionRegister:[], governanceCapaActions:[], governanceBackupPolicies:[], governanceRetentionRules:[], governanceSecurityReviews:[], governanceAccessCertifications:[], governanceReleaseGates:[], governanceReadinessChecklist:[], governanceERecords:[], governanceEscalationRules:[], governanceChangeImpactAssessments:[], governanceTrainingRecords:[], governanceIncidentReviews:[], governancePolicyAcknowledgements:[],
  technicians:[], assets:[], assetGroups:[],
  /* فصل 3: الأصول — كيانات مساندة إضافةً إلى الحقول داخل الأصل */
  assetParts:[], assetRelationships:[], assetLogicalHierarchyNodes:[], assetFlexfields:[], assetImportBatches:[],
  assetFixedAssetLinks:[], assetServiceMappings:[], assetIotSyncEvents:[], assetMaterialComponentTransactions:[],
  meterTemplates:[], assetMeters:[], readings:[], warranties:[],
  stdOps:[], workDefs:[], workRequests:[], programs:[], workOrders:[],
  workRequestAttachments:[], standardOperationSteps:[],
  workDefinitionOperations:[], workDefinitionSteps:[], workDefinitionMaterials:[], workDefinitionResources:[], workDefinitionVersions:[],
  maintenanceProgramAssets:[], maintenanceProgramGroups:[], maintenanceForecasts:[],
  workOrderSteps:[], workOrderResources:[], workOrderAssignments:[], workOrderStatusHistory:[], workOrderAttachments:[], workOrderPhotos:[], workOrderFailures:[], workOrderExceptions:[], workOrderCosts:[], workOrderApprovals:[],
  dispatchListViews:[], technicianTasks:[], workOrderExecutionSessions:[], workOrderOperationTransactions:[], workOrderLaborTransactions:[], workOrderMaterialUsage:[], workOrderMaterialReturns:[], workOrderFailureRecords:[], workOrderInspectionResults:[], workOrderSafetyChecklists:[], workOrderChecklistAnswers:[], workOrderCompletionRequests:[], workOrderSupervisorReviews:[], workOrderExecutionHistory:[],
  supervisionSavedSearches:[], supervisionScheduleSnapshots:[], workOrderScheduleConflicts:[], supervisionAssignmentPlans:[], resourceCapacitySnapshots:[], resourceScheduleConflicts:[], advancedScheduleRuns:[], advancedScheduleRecommendations:[], advancedScheduleApplied:[], schedulingRules:[], schedulingPlans:[], schedulingPlanLines:[], schedulingAssignments:[], schedulingConflicts:[], maintenanceForecastRuns:[], maintenanceForecastActions:[], maintenanceReportJobs:[], forecastRuns:[], forecastValidationIssues:[], forecastSuppressionRules:[], forecastMergeGroups:[], reportJobs:[], savedReportOutputs:[], reportSchedules:[], inventoryReservations:[], materialIssueRequests:[], materialReturnRequests:[], laborCostTransactions:[],
  inventoryGovernancePolicies:[], inventoryRequests:[], inventoryRequestLines:[], inventoryApprovals:[], inventoryCycleCounts:[], inventoryCycleCountLines:[], inventoryReconciliationIssues:[], inventoryAuditTrail:[],
  items:[], warehouses:[], stockTx:[], suppliers:[], purchaseOrders:[], supplierOffers:[], mediaFiles:[], mediaUploadQueue:[], mediaStorageMigrations:[],
  warrantyProviders:[], laborRates:[], repairTimes:[], coverages:[], contracts:[], entitlements:[], claims:[],
  assetGroupRules:[], logicalHierarchies:[],
  settings:{ role:"مدير", myTechId:"", assetCreationMode:"IMMEDIATE", strictAssetValidation:false } };

/* ثوابت فصل 1-2: منظمة الصيانة */
export const MAINT_ORG_STATUS = ["مسودة", "جاهزة", "عاملة", "معطلة"];
export const RESOURCE_TYPES = ["عمالة", "معدات"];
export const RESOURCE_UOMS = ["ساعة", "يوم", "أمر", "قطعة", "دقيقة"];
export const SHIFT_TYPES = ["صباحي", "مسائي", "ليلي", "24 ساعة", "مخصص"];
export const EXCEPTION_TYPES = ["توقف", "إتاحة إضافية", "تغيير وردية", "صيانة داخلية", "عطلة"];
export const INFOLET_NAMES = ["أوامر مفتوحة", "متأخر", "بانتظار مواد", "صيانة وقائية مستحقة", "أصول حرجة", "مطالبات ضمان"];

/* ثوابت فصل 3: الأصول */
export const ASSET_OWNERSHIP = ["مؤسسة", "عميل"];
export const LOCATION_TYPES = ["CUSTOMER_ADDRESS", "EXTERNAL_ADDRESS", "INTERNAL_ADDRESS", "WORK_CENTER", "UNKNOWN", "INVENTORY"];
export const DEFAULT_WO_SUBTYPES = ["", "Emergency", "Planned", "Reactive", "Safety", "Under warranty", "Condition based"];
export const ASSET_CREATION_MODES = ["IMMEDIATE", "DEFERRED"];
export const AUTO_ASSET_SOURCES = ["Miscellaneous Receipt", "Purchase Receipt to Inventory", "Manufacturing Work Order Completion", "Purchase Receipt to Work Order Destination", "Purchase Receipt to Expense Destination", "Sales Order Fulfillment"];
export const ORACLE_FEATURES = [
  ["منظمة صيانة + Plant Parameters", "فصل 1-2", "org"],
  ["Work Areas / Work Centers", "فصل 2", "org"],
  ["Resources + Resource Instances", "فصل 2", "org"],
  ["Shifts + Resource Calendar Exceptions", "فصل 2", "org"],
  ["Infolets / Task Navigator", "فصل 1", "oracle"],
  ["Assets Enterprise/Customer + Item + Location Type", "فصل 3", "assets"],
  ["Manage Assets + Smart Search + Chips", "فصل 3", "assets"],
  ["Asset 360", "فصل 3", "assets"],
  ["Parts / Meters / Hierarchy / Groups", "فصل 3", "assets"],
  ["Split Asset لغير المسلسل", "فصل 3", "assets"],
  ["Flexfields / Fixed Assets / Service Mapping / IoT Sync", "فصل 3", "assets"],
  ["Asset Import/Export", "فصل 3", "data"],
];

/* ثوابت الحوكمة والرقابة */
export const GOV_POLICY_TYPES = ["سياسة", "إجراء", "مصفوفة صلاحيات", "تعليمات تشغيل", "ضابط رقابي"];
export const GOV_POLICY_STATUS = ["مسودة", "سارية", "قيد المراجعة", "مؤرشفة"];
export const GOV_PROCESSES = ["أمر عمل", "أصل", "مخزون", "عداد", "برنامج وقائي", "ضمان", "صلاحيات", "بيانات", "Backend"];
export const GOV_ACTIONS = ["إنشاء", "تعديل", "إصدار", "إغلاق", "حذف", "صرف", "تسوية", "استيراد", "تغيير صلاحية", "تغيير إعداد"];
export const GOV_RISK_LEVELS = ["منخفض", "متوسط", "عال", "حرج"];
export const GOV_RISK_STATUS = ["مفتوح", "قيد المعالجة", "مقبول", "مغلق"];
export const GOV_CHANGE_STATUS = ["مقترح", "قيد المراجعة", "معتمد", "مرفوض", "منفذ", "مغلق"];
export const GOV_REVIEW_FREQ = ["شهري", "ربع سنوي", "نصف سنوي", "سنوي"];
export const GOV_REQUEST_STATUS = ["مفتوح", "معتمد", "مرفوض", "ملغي", "منفذ"];
export const GOV_DATA_SEVERITY = ["منخفض", "متوسط", "عال", "حرج"];

/* ثوابت قواعد مجموعات الأصول (ف4) */
export const GROUP_ATTRS = [["location", "الموقع"], ["type", "النوع"], ["workCenterId", "مركز العمل"]];
export const RULE_USAGES = ["عام (صيانة وبرامج)", "حالة الأصل (قاعدة تحقق)"];
export const END_REASONS = ["إلغاء يدوي", "تغير بيانات الأصل", "إنهاء الأصل"];

/* ثوابت ضمان المورد (ف6) */
export const COV_STATUS = ["مسودة", "جاهز"];
export const COV_TYPES = ["شراء جديد", "ضمان ممتد", "ضمان OEM"];
export const DUR_UOM = { "يوم": 1, "شهر": 30, "سنة": 365 };
export const CLAIM_STATUS = ["قيد المراجعة", "مُقدمة", "محلولة", "مرفوضة"];
export const ENT_TYPES = ["صرف مادة", "إرجاع مادة", "تحميل مورد", "تحميل معدات", "إصلاح قياسي", "أخرى"];

/* ثوابت العمليات القياسية (ف7) */
export const OP_BASIS = ["ثابت", "متغير"];
export const OP_CHARGE = ["يدوي", "تلقائي"];
export const OP_ACTIVITY = ["تجهيز", "تنفيذ", "إنهاء"];
export const REPAIR_REASONS = ["عطل", "صيانة وقائية", "ضمان", "فحص دوري", "تحسين"];
export const WORK_DONE = ["تنظيف", "إصلاح", "استبدال", "ضبط", "تشحيم", "فحص"];
export const ATTACH_TYPES = ["رابط", "نص"];

export const MEDIA_KINDS = ["أصل", "قبل", "أثناء", "بعد", "عطل", "قطعة غيار", "طلب عمل", "أمر عمل", "مستند"];
export const mediaSrc = (m) => m?.url || m?.downloadURL || m?.data || m?.value || "";
export const isStorageMedia = (m) => String(m?.storageProvider || "") === "firebase-storage" && !!m?.storagePath;
export const isLocalMedia = (m) => !!m?.data && !isStorageMedia(m);
export const mediaBytes = (m) => Number(m?.sizeBytes || (m?.data ? estimateDataUrlBytes(m.data) : 0) || 0);
export const mediaSize = (bytes) => {
  const n = Number(bytes || 0);
  if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + " MB";
  if (n >= 1024) return Math.round(n / 1024) + " KB";
  return n + " B";
};
export const estimateDataUrlBytes = (value) => {
  const raw = String(value || "");
  const base64 = raw.includes(",") ? raw.split(",").pop() || "" : raw;
  return Math.round((base64.length * 3) / 4);
};

/* أنواع حركات المخزون (وثيقة المخزون §Stock Transactions) */
export const TX_TYPES = ["استلام", "صرف لأمر عمل", "إرجاع من أمر عمل", "تحويل", "تسوية", "إتلاف"];
export const ITEM_CATS = ["محامل", "سيور", "قواديس", "زيوت وشحوم", "فلاتر", "كهرباء", "حساسات", "أخرى"];

/* ترحيل حالات النسخة السابقة */
export const MIGRATE_STATUS = { "غير مُصدر": "مسودة", "مُصدر": "جاهز", "قيد التنفيذ": "قيد التنفيذ", "مكتمل": "مغلق", "مغلق": "مغلق", "ملغي": "ملغي" };

