/* State normalization and local backup helpers. */
import {
  EMPTY, MIGRATE_STATUS, today, now, uid, INFOLET_NAMES, MAINTENANCE_ENTITY_KEYS, GOVERNANCE100_ENTITY_KEYS, KEY
} from "./constants";

/* ───────────────────────── ربط البيانات بالـ Backend ───────────────────────── */
export const normalizeDb = (raw = {}) => {
  const d = { ...(raw || {}) };

  d.workOrders = (d.workOrders || []).map((w) => ({
    checklist: [], materials: [], photos: [], execLog: [], failure: null,
    resources: [], assignments: [], statusHistory: [], approvals: [], completionRequests: [], supervisorReviews: [],
    executionNotes: "", inspectionResults: [], externalSupplier: "", workCenterId: "", safetyPermit: "", pauseLog: [],
    _cmmsAssignedTechIds: [],
    ...w, status: MIGRATE_STATUS[w.status] || w.status,
  }));
  d.assets = (d.assets || []).map((a) => ({ parts: [], docs: [], photos: [], specs: "",
    allowWO: true, allowPrograms: true, enableIoT: false, endDate: "", quantity: 1,
    ownership: "مؤسسة", assetType: a.assetType || (a.ownership === "عميل" ? "CUSTOMER" : "ENTERPRISE"),
    itemRequired: a.itemRequired ?? false, itemId: "", itemName: "", fullLifecycleTracked: false, customerAssetTracking: false,
    operatingOrganizationId: "", serial: "", lotNumber: "", uom: "", secondaryQuantity: "",
    useBomForInitialHierarchy: false, competitorAsset: false, locationType: a.locationType || "UNKNOWN", locationId: "", locationOrganizationId: "",
    customer: "", customerId: "", customerAccountId: "", shipmentDate: "", installedDate: "", inServiceDate: "",
    contact: "", defaultWOType: "", defaultWOSubtype: "", project: "", task: "", countryOfOrigin: "",
    flexfields: [], fixedAssetNumber: "", fixedAssetBook: "", lastSalesOrderDetails: "", serviceRequests: [],
    notes: [], history: [], ...a }));
  d.stdOps = (d.stdOps || []).map((o) => ({ type: "داخلية", countPoint: true, autoTransact: false,
    resources: [], attachments: [], inactiveOn: "", repairReason: "", repairTx: "", workDone: "", ...o }));
  d.meterTemplates = (d.meterTemplates || []).map((t) => ({ code: t.code || (t.name || "MTR"), description: "",
    startDate: "", endDate: "", initial: t.initial ?? "", recordAtWO: "لا يسمح", resetAllowed: true, resetValue: 0,
    rolloverAllowed: false, rolloverMax: "", rolloverMin: 0, allowSchedule: true, estDailyRate: "", readingsForRate: "", ...t }));
  d.assetMeters = (d.assetMeters || []).map((m) => ({ recordAtWO: "", endDate: "", estDailyRate: "", readingsForRate: "", ...m }));
  d.readings = (d.readings || []).map((r) => ({ status: r.isReset ? "تصفير" : "مسجلة", comments: "", rollover: false, ...r }));

  d.maintenanceOrganizations = (d.maintenanceOrganizations || []).map((o) => ({ code:"", name:"", status:"مسودة", isMaintenanceEnabled:true, isProjectTracked:false, inactiveOn:"", ...o }));
  d.plantParameters = (d.plantParameters || []).map((p) => ({ organizationId:"", assetCreationMode:"IMMEDIATE", autoAssetPrefix:"AST", requireItemForEnterpriseAssets:false, requireFullLifecycleForWO:false, defaultUnknownLocation:true, projectTrackingEnabled:false, inventoryIssuePolicy:"لا صرف بدون أمر عمل", ...p }));
  d.workAreas = (d.workAreas || []).map((x) => ({ organizationId:"", inactiveOn:"", ...x }));
  d.workCenters = (d.workCenters || []).map((x) => ({ organizationId:"", workAreaId:"", inactiveOn:"", ...x }));
  d.resources = (d.resources || []).map((x) => ({ code:"", type:"عمالة", usageUom:"ساعة", workCenterId:"", qty:1, available24h:false, inactiveOn:"", ...x }));
  d.resourceInstances = (d.resourceInstances || []).map((x) => ({ resourceId:"", identifier:"", instanceType:"يدوي", personName:"", assetId:"", active:true, qualifications:"", inactiveOn:"", ...x }));
  d.shifts = (d.shifts || []).map((x) => ({ name:"", code:"", shiftType:"صباحي", startTime:"08:00", endTime:"17:00", days:"الأحد,الاثنين,الثلاثاء,الأربعاء,الخميس", inactiveOn:"", ...x }));
  d.resourceExceptions = (d.resourceExceptions || []).map((x) => ({ workCenterId:"", resourceId:"", date:today(), exceptionType:"توقف", startTime:"", endTime:"", reason:"", ...x }));
  d.workCenterResources = d.workCenterResources || [];
  d.infolets = d.infolets || INFOLET_NAMES.map((name, i) => ({ id: uid(), name, visible:true, order:i+1 }));
  d.importBatches = d.importBatches || [];
  d.assetFlexfields = d.assetFlexfields || [];
  d.assetImportBatches = d.assetImportBatches || [];
  d.assetFixedAssetLinks = d.assetFixedAssetLinks || [];
  d.assetServiceMappings = d.assetServiceMappings || [];
  d.assetIotSyncEvents = d.assetIotSyncEvents || [];
  d.assetMaterialComponentTransactions = d.assetMaterialComponentTransactions || [];

  /* ف4: ترقية المجموعات القديمة إلى قاعدة قياسية + تعيينات بتواريخ */
  d.assetGroupRules = d.assetGroupRules || [];
  if ((d.assetGroups || []).some((g) => !g.ruleId)) {
    let std = d.assetGroupRules.find((r) => r.code === "STD");
    if (!std) { std = { id: uid(), name: "التصنيف القياسي", code: "STD", description: "قاعدة افتراضية للمجموعات السابقة", attributes: [], usages: ["عام (صيانة وبرامج)"], enforceUnique: false, inactiveOn: "" }; d.assetGroupRules.push(std); }
    d.assetGroups = (d.assetGroups || []).map((g, i) => g.ruleId ? g : ({
      number: "AG-" + String(100 + i + 1), description: "", attrValues: {}, excludeFromRequests: false, excludeFromWO: false, inactiveOn: "",
      assignments: (g.assetIds || []).map((aid) => ({ id: uid(), assetId: aid, start: today(), end: "", endReason: "", by: "ترحيل" })),
      ...g, ruleId: std.id }));
  }

  MAINTENANCE_ENTITY_KEYS.forEach((k) => { d[k] = Array.isArray(d[k]) ? d[k] : []; });
  GOVERNANCE100_ENTITY_KEYS.forEach((k) => { d[k] = Array.isArray(d[k]) ? d[k] : []; });
  d.governanceControlLibrary = (d.governanceControlLibrary || []).map((x) => ({ status:"نشط", criticality:"متوسط", automation:"يدوي", frequency:"شهري", ...x }));
  d.governanceControlTests = (d.governanceControlTests || []).map((x) => ({ result:"لم يفحص", severity:"متوسط", status:"مفتوح", ...x }));
  d.governanceCapaActions = (d.governanceCapaActions || []).map((x) => ({ status:"مفتوح", priority:"متوسط", dueDate:"", ...x }));
  d.governanceReadinessChecklist = (d.governanceReadinessChecklist || []).map((x) => ({ status:"غير مكتمل", ownerRole:"مدير", evidence:"", ...x }));
  d.governanceReleaseGates = (d.governanceReleaseGates || []).map((x) => ({ status:"مفتوح", required:true, approvedBy:"", approvedAt:"", ...x }));
  d.workOrderStatusHistory = (d.workOrderStatusHistory || []).map((x) => ({ at: today(), from: "", to: "", by: "", ...x }));
  d.workOrderExecutionHistory = (d.workOrderExecutionHistory || []).map((x) => ({ at: today(), action: "", by: "", ...x }));
  d.supervisionSavedSearches = (d.supervisionSavedSearches || []).map((x) => ({ name:"", filter:"الكل", query:"", ownerRole:"", createdAt:"", ...x }));
  d.supervisionScheduleSnapshots = (d.supervisionScheduleSnapshots || []).map((x) => ({ at:today(), horizonDays:7, total:0, conflicts:0, createdBy:"", ...x }));
  d.workOrderScheduleConflicts = (d.workOrderScheduleConflicts || []).map((x) => ({ severity:"تحذير", type:"تعارض فني", status:"مفتوح", ...x }));
  d.maintenanceForecasts = (d.maintenanceForecasts || []).map((x) => ({ status:"Planned", suppressed:false, mergedIntoForecastId:"", generatedWorkOrderId:"", validationStatus:"غير مفحوص", ...x }));
  d.maintenanceForecastRuns = (d.maintenanceForecastRuns || []).map((x) => ({ runType:"Generate", at:today(), horizonDays:0, created:0, warnings:0, ...x }));
  d.supervisionAssignmentPlans = d.supervisionAssignmentPlans || [];
  d.resourceCapacitySnapshots = d.resourceCapacitySnapshots || [];
  d.resourceScheduleConflicts = d.resourceScheduleConflicts || [];
  d.forecastRuns = d.forecastRuns || [];
  d.forecastValidationIssues = d.forecastValidationIssues || [];
  d.forecastSuppressionRules = d.forecastSuppressionRules || [];
  d.forecastMergeGroups = d.forecastMergeGroups || [];
  d.reportJobs = d.reportJobs || [];
  d.savedReportOutputs = d.savedReportOutputs || [];
  d.reportSchedules = d.reportSchedules || [];
  d.inventoryReservations = d.inventoryReservations || [];
  d.materialIssueRequests = d.materialIssueRequests || [];
  d.materialReturnRequests = d.materialReturnRequests || [];
  d.laborCostTransactions = d.laborCostTransactions || [];
  d.inventoryGovernancePolicies = (d.inventoryGovernancePolicies || []).map((x) => ({ active:true, severity:"متوسط", ownerRole:"مخزن", requiresApproval:true, ...x }));
  d.inventoryRequests = (d.inventoryRequests || []).map((x) => ({ status:"مفتوح", priority:"متوسطة", requestedAt:today(), requestedByRole:"", approvedAt:"", executedAt:"", ...x }));
  d.inventoryRequestLines = d.inventoryRequestLines || [];
  d.inventoryApprovals = d.inventoryApprovals || [];
  d.inventoryCycleCounts = (d.inventoryCycleCounts || []).map((x) => ({ status:"مفتوح", countDate:today(), ownerRole:"مخزن", ...x }));
  d.inventoryCycleCountLines = d.inventoryCycleCountLines || [];
  d.inventoryReconciliationIssues = (d.inventoryReconciliationIssues || []).map((x) => ({ status:"مفتوح", severity:"متوسط", ...x }));
  d.inventoryAuditTrail = d.inventoryAuditTrail || [];
  d.maintenanceForecastActions = (d.maintenanceForecastActions || []).map((x) => ({ at:today(), action:"", forecastId:"", by:"", ...x }));
  d.maintenanceReportJobs = (d.maintenanceReportJobs || []).map((x) => ({ reportName:"", status:"مسودة", createdAt:today(), ...x }));
  d.reportJobs = (d.reportJobs || []).map((x) => ({ name:"", status:"مسودة", requestedAt:"", rowCount:0, ...x }));
  d.savedReportOutputs = (d.savedReportOutputs || []).map((x) => ({ name:"", generatedAt:"", rowCount:0, summary:"", ...x }));
  d.mediaFiles = (d.mediaFiles || []).map((x) => ({ storageProvider:"firebase-storage", source:"firebase-storage", entity:x.entity || x.ownerType || "", recordId:x.recordId || x.ownerId || "", kind:x.kind || "attachment", url:x.url || x.downloadURL || "", storagePath:"", status:x.status || "active", uploadedAtIso:"", ...x }));
  d.mediaUploadQueue = (d.mediaUploadQueue || []).map((x) => ({ status:"pending", createdAtIso:now(), attempts:0, ...x }));
  d.mediaStorageMigrations = d.mediaStorageMigrations || [];

  return { ...EMPTY, ...d, settings: { ...EMPTY.settings, ...(d.settings || {}) } };
};

export const loadLocalBackup = () => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return null;
    const value = window.localStorage.getItem(KEY);
    return value ? JSON.parse(value) : null;
  } catch (e) {
    console.error("فشل قراءة النسخة المحلية", e);
    return null;
  }
};

export const saveLocalBackup = (data) => {
  try {
    if (typeof window === "undefined" || !window.localStorage) return false;
    window.localStorage.setItem(KEY, JSON.stringify(data));
    return true;
  } catch (e) {
    console.error("فشل حفظ النسخة المحلية", e);
    return false;
  }
};


