/* Firebase Storage and media helper functions. */
import { uploadCmmsDataUrlToStorage } from "../firebaseCmms";
import { uid, today, now } from "./constants";

/* ضغط الصور قبل الحفظ (حد التخزين 5MB) */
export const resizeImage = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 960, scale = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = Math.max(1, Math.round(img.width * scale));
      cv.height = Math.max(1, Math.round(img.height * scale));
      cv.getContext("2d").drawImage(img, 0, 0, cv.width, cv.height);
      resolve(cv.toDataURL("image/jpeg", 0.72));
    };
    img.onerror = reject;
    img.src = reader.result;
  };
  reader.onerror = reject;
  reader.readAsDataURL(file);
});

export const readFileAsDataUrl = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result || ""));
  reader.onerror = reject;
  reader.readAsDataURL(file);
});
export const dataUrlToBlob = async (dataUrl) => (await fetch(dataUrl)).blob();
export const dataUrlToFile = async (dataUrl, name, type = "image/jpeg") => {
  const blob = await dataUrlToBlob(dataUrl);
  try { return new File([blob], String(name || "image").replace(/\.[^.]+$/, "") + ".jpg", { type }); }
  catch { return new Blob([blob], { type }); }
};
export const mediaIsRemote = (m) => String(m?.storageProvider || "").includes("firebase") || !!m?.storagePath;
export const formatBytes = (bytes) => {
  const n = Number(bytes || 0);
  if (!n) return "0 KB";
  if (n < 1024 * 1024) return Math.max(1, Math.round(n / 1024)).toLocaleString("ar") + " KB";
  return (Math.round((n / 1024 / 1024) * 10) / 10).toLocaleString("ar") + " MB";
};

export async function buildCmmsMediaRecord(ctx, file, opts = {}) {
  const kind = opts.kind || opts.type || "مرفق";
  const ownerType = opts.ownerType || "general";
  const ownerId = opts.ownerId || "unknown";
  const contentType = file?.type || "application/octet-stream";
  const originalName = file?.name || (kind + "-" + Date.now());
  let previewData = "";
  let payload = file;

  if (contentType.startsWith("image/")) {
    previewData = await resizeImage(file);
    payload = await dataUrlToFile(previewData, originalName, "image/jpeg");
  }

  const base = {
    id: uid(),
    type: kind,
    kind,
    name: originalName,
    at: today(),
    createdAtIso: now(),
    ownerType,
    ownerId,
    contentType,
    originalSize: Number(file?.size || 0),
    status: "نشط",
  };

  if (ctx?.firebaseServices && ctx?.firebaseUser) {
    try {
      const dataForUpload = contentType.startsWith("image/") ? previewData : await readFileAsDataUrl(file);
      const remote = await uploadCmmsDataUrlToStorage(ctx.firebaseServices, dataForUpload, {
        entity: ownerType, recordId: ownerId, kind, fileName: originalName,
        contentType: contentType.startsWith("image/") ? "image/jpeg" : contentType,
        uploadedByUid: ctx.firebaseUser.uid, uploadedByEmail: ctx.firebaseUser.email, uploadedByRole: ctx.role,
      });
      ctx.setSyncStatus?.("تم رفع الملف إلى Firebase Storage — " + (remote.name || originalName));
      return { ...base, ...remote, data: "", storageMode: "remote" };
    } catch (e) {
      console.warn("فشل رفع Firebase Storage؛ سيتم حفظ نسخة محلية مضغوطة", e);
      ctx.setSyncStatus?.("تعذر رفع الملف إلى Storage — حفظ محلي مؤقت داخل البيانات");
    }
  }

  const data = contentType.startsWith("image/") ? previewData : await readFileAsDataUrl(file);
  return { ...base, storageProvider: "local-base64", storageMode: "local", data, size: data.length };
}


