# Alhadi CMMS Android APK — Firebase Edition

هذه حزمة تطبيق CMMS جاهزة للبناء كـ APK عبر GitHub Actions باستخدام React + Capacitor.

## التحديث الحالي v15 — Firebase بسجلات مستقلة + صلاحيات أدق

تم تحويل التخزين والصلاحيات إلى Firebase:

- Firebase Authentication لتسجيل الدخول بالبريد وكلمة المرور.
- Cloud Firestore لحفظ كل سجل في مستند مستقل بدل مستند JSON واحد.
- Firestore Security Rules لتطبيق الصلاحيات من جهة Firebase على مستوى نوع السجل.
- شاشة تسجيل دخول داخل التطبيق.
- شاشة `المزيد → المستخدمون والصلاحيات` للمدير.
- الدور لم يعد يُختار من القائمة داخل التطبيق؛ الدور يأتي من وثيقة المستخدم في Firestore.
- أول حساب يستخدم بريد مالك النظام `mohsenalhadi77555@gmail.com` يصبح مديرًا تلقائيًا.
- بقية الحسابات تبدأ كـ `طالب خدمة` حتى يغيّر المدير دورها.
- الأصول، أوامر العمل، الحركات، القراءات، البرامج، والضمانات تُخزن تحت `cmms/main/entities/<entity>/records/<id>`.

## طريقة التحديث من الهاتف بدون Codespaces

1. افتح مستودع GitHub من المتصفح.
2. اضغط `Add file` ثم `Upload files`.
3. ارفع هذا الملف بنفس الاسم تمامًا:

`alhadi-cmms-apk-github.zip`

4. اضغط `Commit changes`.
5. افتح تبويب `Actions`.
6. افتح Workflow الذي يبني من ZIP.
7. بعد نجاح البناء، حمّل Artifact باسم:

`Alhadi-CMMS-debug-apk`

داخله ستجد:

`app-debug.apk`

## إعداد Firebase بعد تثبيت APK

إذا لم تضف Firebase config كـ GitHub Secrets، سيظهر داخل التطبيق مربع إعداد Firebase. الصق فيه كائن `firebaseConfig` من Firebase Console، وسيُحفظ داخل التطبيق على الهاتف.

الخطوات العامة:

1. أنشئ مشروع Firebase.
2. فعّل Authentication → Email/Password.
3. أنشئ Firestore Database.
4. افتح Rules والصق محتوى الملف `firestore.rules`.
5. من Project settings → Web app انسخ `firebaseConfig` والصقه داخل التطبيق.
6. أنشئ حسابًا بالبريد `mohsenalhadi77555@gmail.com` ليصبح مديرًا.

## ملاحظة أمنية

هذه النسخة تستخدم Firestore Security Rules لتقييد الكتابة حسب الدور مع تخزين كل سجل كمستند مستقل. للبيئة الإنتاجية الكبيرة جدًا، المرحلة التالية الأفضل هي إضافة Cloud Functions للتحقق التفصيلي من انتقالات حالة أمر العمل وحسابات المخزون قبل قبول الكتابة.

## v16 - إصلاح شاشة Firebase الفارغة

إذا ظهرت شاشة فارغة عند الضغط على **Firebase والصلاحيات**، فهذه النسخة تضيف Error Boundary وتعرض رسالة واضحة بدل الشاشة الفارغة. إذا بقيت المشكلة بعد التثبيت، احذف التطبيق القديم من الهاتف ثم ثبت APK الجديد لأن Android قد يحتفظ ببيانات WebView/localStorage من النسخة القديمة.

## ملاحظة إصلاح npm

هذه النسخة لا تحتوي على `package-lock.json` حتى لا يستخدم GitHub Actions روابط registry غير مناسبة. أثناء البناء سيتم إنشاء lock جديد من npm الرسمي.

---

## نسخة نهائية للتثبيت الداخلي

تمت إضافة Workflow لبناء APK Release موقّع داخليًا:

`Build Internal Release APK`

إذا كنت تبني من ملف ZIP داخل مستودع GitHub، استخدم الملف الخارجي:

`.github/workflows/build-internal-release-from-zip.yml`

النتيجة ستكون:

`Alhadi-CMMS-internal-release-apk / app-release.apk`

راجع ملف:

`INTERNAL_RELEASE_FINAL_AR.md`
