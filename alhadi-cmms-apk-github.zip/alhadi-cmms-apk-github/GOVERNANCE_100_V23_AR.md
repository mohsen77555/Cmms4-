# تحديث v23 — حوكمة CMMS 100%

أضيفت شاشة جديدة: **المزيد → الحوكمة 100%**.

## الإضافات

- Governance Operating Model.
- Control Library من 25 ضابطًا.
- Control Testing Engine يولد Pass / Fail / Warning.
- إنشاء CAPA تلقائيًا عند فشل الضوابط.
- Segregation of Duties Matrix.
- RACI Matrix.
- Data Owners.
- Authority Limits و Release Gates.
- KPI Definitions و SLA/Escalation Rules.
- Exception Register.
- Backup Policies.
- Retention Rules.
- Access Certification.
- Production Readiness Checklist.
- Evidence JSON Export.
- Policy Acknowledgement.

## طريقة الاستخدام

1. افتح التطبيق.
2. اذهب إلى: المزيد → الحوكمة 100%.
3. اضغط: إنشاء/تحديث حوكمة CMMS 100%.
4. اضغط: تشغيل اختبار الضوابط الآن.
5. راجع CAPA والاستثناءات وبوابات الجاهزية.

ملاحظة: نسبة 100% هنا تعني اكتمال إطار الحوكمة داخل التطبيق، وليست تدقيقًا قانونيًا خارجيًا.
