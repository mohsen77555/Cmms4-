# إصلاح فشل npm install في GitHub Actions

تم حذف `package-lock.json` لأن النسخة السابقة كانت تحتوي روابط Registry داخلية من بيئة البناء، وهذا قد يسبب فشل `npm install` في GitHub.

النسخة الحالية تعتمد على `package.json` فقط، وGitHub سيحمّل الحزم من registry الرسمي:

```txt
https://registry.npmjs.org/
```

إذا فشل البناء مرة أخرى، عدّل workflow ليحذف `package-lock.json` قبل التثبيت ويستخدم Node.js 20.
