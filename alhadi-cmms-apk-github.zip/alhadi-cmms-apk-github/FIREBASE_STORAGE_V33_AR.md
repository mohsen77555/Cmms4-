# تحديث v33 — Firebase Storage للصور والمرفقات

تم إضافة Firebase Storage لتخفيف Firestore ومنع تضخم البيانات بسبب الصور.

## ما الذي تغير؟

- صور أوامر العمل ترفع إلى Firebase Storage عند توفر Firebase.
- صور الأصول ترفع إلى Firebase Storage عند توفر Firebase.
- Firestore يحفظ الرابط والمسار فقط بدل حفظ Base64 داخل السجل.
- عند فشل Storage أو عدم تفعيل Firebase، يتم حفظ نسخة Base64 مؤقتة كخطة احتياط.
- شاشة `المزيد → الصور والمرفقات` تعرض:
  - عدد الملفات.
  - عدد ملفات Storage.
  - عدد الصور المحلية/Base64.
  - الحجم التقريبي.
  - آخر الملفات.
  - زر ترحيل الصور القديمة إلى Storage.
- شاشة `Firebase والصلاحيات` أصبحت تعرض حالة Storage والـ bucket.

## الملفات الجديدة/المعدلة

- `src/firebaseCmms.ts`: إضافة Storage service ورفع/حذف ملفات Storage.
- `src/firebase.ts`: تصدير Storage.
- `src/App.tsx`: رفع صور الأصول وأوامر العمل إلى Storage.
- `storage.rules`: قواعد Firebase Storage.
- `firebase.json`: ربط قواعد Storage.
- `firestore.rules`: السماح بسجلات `mediaFiles` حسب الدور.

## خطوات Firebase المطلوبة

1. افتح Firebase Console.
2. ادخل إلى `Build → Storage`.
3. اضغط `Get started` إذا لم يكن Storage مفعلاً.
4. اختر نفس المنطقة أو منطقة قريبة من Firestore.
5. افتح تبويب `Rules` داخل Storage.
6. الصق محتوى ملف `storage.rules`.
7. اضغط `Publish`.
8. افتح `Firestore Database → Rules` والصق القواعد الجديدة من `firestore.rules` أيضاً.

## بعد تثبيت APK الجديد

ادخل كمدير إلى:

`المزيد → الصور والمرفقات`

ثم اضغط:

`رفع الصور المحلية إلى Firebase Storage`

سيتم ترحيل الصور القديمة التي بقيت Base64 إلى Storage، ثم تصبح البيانات أخف.
